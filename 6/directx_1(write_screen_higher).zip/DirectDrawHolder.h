// DirectDrawHolder.h: interface for the DirectDrawHolder class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DIRECTDRAWHOLDER_H__D70F48A2_9067_11D2_8CE1_002D06C10000__INCLUDED_)
#define AFX_DIRECTDRAWHOLDER_H__D70F48A2_9067_11D2_8CE1_002D06C10000__INCLUDED_

#ifndef __DDRAW_INCLUDED__
#define INITGUID
#endif

#include "LinkStore.h"

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include <ddraw.h>
#include <vector>

using namespace std;

class CDDSurfaceHolder;

class CDDirectDrawHolder {
	friend class CDDSurfaceHolder;
	LPDIRECTDRAWSURFACE m_lpDDPrimarySurface;//Primary surface
	LPDIRECTDRAWSURFACE m_lpDDBackSurface;//Back surface
	LPDIRECTDRAW2 m_lpDD2;
	HWND m_hWnd;//Window handle
	BOOL m_bFullScreen;//indicates fullscreen or not
	/*******************************************
	 *used when in windowmode, to clip inside window
	 *******************************************/
	LPDIRECTDRAWCLIPPER m_lpClipper;
	/*******************************************
	 *Used to contain screen dimension to clip against in
	 *fullscreen mode and used by CDDSurfaceHolder to 
	 *divide each surface into smaller regions if necessary
	 *******************************************/
	RECT m_cScreenRect;
	vector<CDDSurfaceHolder*> m_cSurfaces;
public:
	//Need i say more
	void SetScreenRect(int x0,int y0,int x1,int y1);
	/**********************************************
	 *Draws the rc part of image in CDDSurfaceHolder at pos ix,iy,
	 *it is scaled at dscale and if transparent is on
	 *then it doesn't draw the color specified in colorkey
	 ***********************************************/
    BOOL Draw(CDDSurfaceHolder *pDSHolder,int ix,int iy,RECT rc,
								   double dscale=1.0,BOOL btransparent=FALSE) const;
	// pt = sta�setning � dest surface,
	// iscale = st�kkun � mynd. 1=normal
	// vi� scale �tti pt a� breyta � r�t�nunni.
	// btransparent segir til hvort teikna eigi me�
	// colorkey e�ur ei.
	/*****************************************
	 *Makes back surface black.
	 *Note:Easy to modifiy so it uses another color
	 *or take as a parameter,black is classic
	 *****************************************/
	void ClearBackSurface();
	/*****************************************
	 *Flips surfaces if in fullscreen, else uses
	 *standard double buffering.
	 *Note: If you haven't realised it already
	 *everytime you use Draw you draw on the back-
	 *surface and it isn't visible until you call show
	 *****************************************/
	BOOL Show() const;
	/******************************************
	 *This function takes a callback function and sends
	 *it the modes. Neccessary to see what mode
	 *your driver supports.
	 ******************************************/
	void GetAvailDisplayModes(
			LPDDENUMMODESCALLBACK lpEnumModesCallback,LPVOID lpContext) const;
	/******************************************
	 *It fills the CDDSurfaceHolder with the data
	 *so it can load/reload from resource/disk
	 *pszBuffer,rc stores the part of the image that you
	 *want into the surface. {0,0,0,0} makes rc equal to
	 *the picture size. dwcolor sets the colorkey. f.eks.
	 *Setting dwcolor equal to RGB(0,0,0) and drawing
	 *with btransparent=TRUE makes black transparent
	 ******************************************/
	CDDSurfaceHolder *MakeSurface(char szBuffer[],
		RECT rc,DWORD dwcolor=0);
	//Constructor
	CDDirectDrawHolder();
	/******************************************
	 *Initializes the directdraw object,sets
	 *cooperative level and screen rect
	 *******************************************/
	BOOL InitializeDirectDraw(LPGUID,HWND);
	/***************************************
	 *Release all surfaces and Resources.
	 *Clipper,directdraw etc,etc
	 ***************************************/
	void ReleaseAllResources();
	// A backdoor to directdraw,just in case
	LPDIRECTDRAW2 GetDrawObject() const;
	//Get the window handle
	HWND GetWindowHandle() const;
	/****************************************************
	 *Set the modes,f.eks. 800,600,16,TRUE for fullscreen
	 *in 800x600 16 bit colors.
	 *Note: If bFull=FALSE then other parameters are ignored
	 ****************************************************/
	BOOL SetMode(int iWidth,int iHeight,int iBpp,BOOL bFull);
	/***************************************************
	 *Call this when you use GDI without drawing on your dx
	 *surfaces. f.eks. display a dialog,menu,etc. Otherwise
	 *you dialog may be drawn into the backbuffer and is
	 *therefor not visible
	 ***************************************************/
	BOOL FlipToGDI();
	RECT GetScreenRect() const { return m_cScreenRect; }
	/****************************************************
	 *Helpfull if you want to draw 
	 ****************************************************/
	LPDIRECTDRAWSURFACE GetBackSurface() const;
	virtual ~CDDirectDrawHolder();
};

#endif // !defined(AFX_DIRECTDRAWHOLDER_H__D70F48A2_9067_11D2_8CE1_002D06C10000__INCLUDED_)
