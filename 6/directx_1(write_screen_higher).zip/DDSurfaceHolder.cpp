// DDSurfaceHolder.cpp: implementation of the DDSurfaceHolder class.
//
//////////////////////////////////////////////////////////////////////

#include "DDSurfaceHolder.h"
#include "DirectDrawHolder.h"
#include <vector>

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDDSurfaceHolder::CDDSurfaceHolder(CDDirectDrawHolder &refholder)
: m_cRefHolder(refholder),m_dwColor(0){}

CDDSurfaceHolder::~CDDSurfaceHolder()
{
	vector<CDDSurfaceHolder*>::iterator CItr;
	for(CItr=m_cRefHolder.m_cSurfaces.begin();
		CItr!=m_cRefHolder.m_cSurfaces.end();CItr++)
			if(*CItr==this) {
				m_cRefHolder.m_cSurfaces.erase(CItr,CItr);
				break;
			}
	ClearMem();
}

void CDDSurfaceHolder::ClearMem()
{
	vector<CDDSurfaceList*>::iterator CItr;
	if(!m_cDividedList.empty()) {
		for(CItr=m_cDividedList.begin();CItr!=m_cDividedList.end();CItr++)
			delete *CItr;
		m_cDividedList.erase(m_cDividedList.begin(),m_cDividedList.end());
	}
}

/////////////////////////////////
// LoadBitmap
// Sets the members ready to load bitmap when it
// should be loaded into memory.
//  szPath : Path to the bitmap.
//  x0,y0,x1,y1 sets rect of the bitmap to be loaded.
//
//
//
/////////////////////////////////
BOOL CDDSurfaceHolder::LoadBitmap(char *szpath,
							int x0,int y0,
							int x1,int y1,
							DWORD dwcolor)
{
	SetRect(&m_cRect,x0,y0,x1,y1);//Breytt � putintomem ef x0==x1	
	strcpy(m_szPicturePath,szpath);
	m_dwColor=dwcolor;
	return TRUE;
}

DWORD CDDSurfaceHolder::DDColorMatch(LPDIRECTDRAWSURFACE lpSurf,DWORD dwrgb)
{
    COLORREF rgbT;
    HDC hdc;
    DWORD dw = CLR_INVALID;
    DDSURFACEDESC ddsd;
    HRESULT hres;

    if (dwrgb != -1 && lpSurf->GetDC(&hdc) == DD_OK)
    {
        rgbT = GetPixel(hdc, 0, 0);             // save current pixel value
        SetPixel(hdc,0,0,dwrgb);               // set our value
        lpSurf->ReleaseDC(hdc);
    }

    ddsd.dwSize = sizeof(ddsd);
    hres=lpSurf->Lock(NULL,&ddsd,DDLOCK_WAIT,NULL);

    if (hres == DD_OK)
    {
        dw  = *(DWORD *)ddsd.lpSurface;                     // get DWORD
        dw &= (1 << ddsd.ddpfPixelFormat.dwRGBBitCount)-1;  // mask it to bpp
        lpSurf->Unlock(NULL);
    }
    if (dwrgb != CLR_INVALID && lpSurf->GetDC(&hdc) == DD_OK)
    {
        SetPixel(hdc, 0, 0, rgbT);
        lpSurf->ReleaseDC(hdc);
    }
    return dw;
}

LPDIRECTDRAWSURFACE CDDSurfaceHolder::MakeFilledSurface(HDC hdcImage,RECT rc)
{
	HDC hdcSurf=NULL;
	DDSURFACEDESC ddsd;
	ZeroMemory(&ddsd,sizeof(DDSURFACEDESC));
	ddsd.dwSize=sizeof(ddsd);
	ddsd.dwFlags=DDSD_CAPS|DDSD_HEIGHT|DDSD_WIDTH;
	ddsd.ddsCaps.dwCaps=DDSCAPS_OFFSCREENPLAIN;
	ddsd.dwHeight=rc.bottom-rc.top;
	ddsd.dwWidth=rc.right-rc.left;

	LPDIRECTDRAWSURFACE lpSurf;

	if(FAILED(m_cRefHolder.GetDrawObject()->CreateSurface(&ddsd,&lpSurf,NULL)))
		return NULL;
	lpSurf->Restore();

	lpSurf->GetDC(&hdcSurf);
	BitBlt(hdcSurf,0,0,ddsd.dwWidth,
		ddsd.dwHeight,hdcImage,rc.left,rc.top,SRCCOPY);
	lpSurf->ReleaseDC(hdcSurf);

	if(m_dwColor!=-1) {
		DDCOLORKEY ddck;
		ddck.dwColorSpaceLowValue =DDColorMatch(lpSurf,m_dwColor);
		ddck.dwColorSpaceHighValue=ddck.dwColorSpaceLowValue;
		lpSurf->SetColorKey(DDCKEY_SRCBLT, &ddck);
	}

	return lpSurf;
}

vector<CDDSurfaceList*> *CDDSurfaceHolder::GetSurface()
{
	BOOL bLost=TRUE;
	if(!m_cDividedList.empty())
		bLost=((*m_cDividedList.begin())->m_lpSurface->IsLost()==DDERR_SURFACELOST);
	if(bLost) PutIntoMem();
	return &m_cDividedList;
}

///////////////////////////////////////
// Load the Bitmap into a list of
// directdrawbuffers.
// 
//
///////////////////////////////////////
BOOL CDDSurfaceHolder::PutIntoMem()
{
	// Free memory if used
	ClearMem();

	HBITMAP hbm;
	HDC hdcImage=NULL;

	//Load bitmap
	hbm=(HBITMAP) LoadImage(NULL,m_szPicturePath,IMAGE_BITMAP,
		0,0,
		LR_LOADFROMFILE|LR_CREATEDIBSECTION);

	if(!hbm) return FALSE;

	// If zero rect then make rect equal to picture.
	if(m_cRect.right==m_cRect.left) {
		BITMAP bm;
		GetObject(hbm,sizeof(BITMAP),(LPVOID)&bm);
		SetRect(&m_cRect,0,0,bm.bmWidth,bm.bmHeight);
	}

	hdcImage=CreateCompatibleDC(NULL);
	SelectObject(hdcImage,hbm);

	int iScreenWidth,iScreenHeight,iPicWidth,iPicHeight;
	RECT rcScreen;

	// Get the resolution
	rcScreen=m_cRefHolder.GetScreenRect();
	//Get the picture rectangle height
	iPicHeight=m_cRect.bottom-m_cRect.top+1;
	iPicWidth=m_cRect.right-m_cRect.left+1;
	//Get the screen rectangle height
	iScreenWidth=rcScreen.right-rcScreen.left;
	iScreenHeight=rcScreen.bottom-rcScreen.top;

	LPDIRECTDRAWSURFACE lpSurf;
	RECT rcNow;
	int ix,iy;

	// Store in memory as a list of surfaces
	// Because DD 5.0 doesn't support images that are
	// bigger than screen.

	iy=m_cRect.top;
	while(iy<iPicHeight) {
		ix=m_cRect.left;
		while(ix<iPicWidth) {
			rcNow.left=ix-m_cRect.left;
			rcNow.top=iy;
			rcNow.right=min(ix+iScreenWidth-m_cRect.left,iPicWidth);
			rcNow.bottom=min(iy+iScreenHeight-m_cRect.top,iPicHeight);
			lpSurf=MakeFilledSurface(hdcImage,rcNow);
			m_cDividedList.push_back(new CDDSurfaceList(lpSurf,rcNow));
			ix+=iScreenWidth-1;
		}
		iy+=iScreenHeight-1;
	}
	DeleteDC(hdcImage);
	DeleteObject(hbm);//Delete lose ends.
	return TRUE;
}
