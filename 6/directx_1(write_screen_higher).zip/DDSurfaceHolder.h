// DDSurfaceHolder.h: interface for the DDSurfaceHolder class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DDSURFACEHOLDER_H__D70F48A3_9067_11D2_8CE1_002D06C10000__INCLUDED_)
#define AFX_DDSURFACEHOLDER_H__D70F48A3_9067_11D2_8CE1_002D06C10000__INCLUDED_


#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
#include <ddraw.h>
#include <vector>

using namespace std;

//User should ignore that this class exists.

class CDDSurfaceList {
	friend class CDDSurfaceHolder;
	friend class CDDirectDrawHolder;
	LPDIRECTDRAWSURFACE m_lpSurface;
	RECT m_cRect; // Holds list of surfaces
	CDDSurfaceList(LPDIRECTDRAWSURFACE lpsurf,RECT rc)
		: m_lpSurface(lpsurf),m_cRect(rc){}
	virtual ~CDDSurfaceList() {
		if(m_lpSurface) m_lpSurface->Release();
	}
};


class CDDSurfaceHolder {
	friend class CDDirectDrawHolder;
	// Picturepath; needed for reloading
	char m_szPicturePath[_MAX_PATH];
	RECT m_cRect;//Size of the whole Picture
	/************************************
	 *Stores regions of this surface. When
	 *You change resolution this gets update
	 ************************************/
	vector<CDDSurfaceList*> m_cDividedList;
	DWORD m_dwColor;//Color of Transparent
	/*******************************************
	 *Fill surface with rect of image 
	 ********************************************/
	LPDIRECTDRAWSURFACE MakeFilledSurface(HDC hdcImage,RECT rc);
	CDDirectDrawHolder &m_cRefHolder;
	CDDSurfaceHolder(CDDirectDrawHolder &pholder);
	/*******************************************
	 *I'm lying doesn't load, only sets m_szPicturepath,
	 *m_cRect & m_dwColor
	 *******************************************/
	BOOL LoadBitmap(char *szpath,int x0=0,
		int y0=0,int x1=0,int y1=0,DWORD dwcolor=0);
	// Gets holder
	const CDDirectDrawHolder &GetHolder() const { return m_cRefHolder; }
	vector<CDDSurfaceList*> *GetSurface();
	/******************************************
	 *This loads the picture & divides it into surfaces
	 ******************************************/
	BOOL PutIntoMem();//Load bitmap into memory
	//Clears memory of regions...
	//Now that i think of it CDDSurfaceRegions would be a much
	//better name that CDDSurfaceList.
	void ClearMem();
	DWORD DDColorMatch(LPDIRECTDRAWSURFACE lpSurf,DWORD dwrgb);
public:
	virtual ~CDDSurfaceHolder();
};

#endif // !defined(AFX_DDSURFACEHOLDER_H__D70F48A3_9067_11D2_8CE1_002D06C10000__INCLUDED_)
