// WinMain.cpp
#define WIN32_LEAN_AND_MEAN
// You must include this define to use QueryInterface

#include <windows.h>
#include "resource.h"
#include <ddraw.h>
#include <stdio.h>
#include <math.h>
#include "DirectDrawHolder.h"
#include "DDSurfaceHolder.h"

LRESULT CALLBACK WndProc(HWND,UINT,WPARAM,LPARAM);
BOOL CALLBACK DialogProc(HWND,UINT,WPARAM,LPARAM);
BOOL CALLBACK ResDlgProc(HWND,UINT,WPARAM,LPARAM);
BOOL CALLBACK SoundDialogProc(HWND,UINT,WPARAM,LPARAM);

CDDirectDrawHolder g_DDHolder;
CDDSurfaceHolder *g_pDSPicture1=NULL,*g_pDSPicture2=NULL;

HWND ghWnd;
BOOL gbActive=FALSE;
const double PI180=3.14/180;

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
				   PSTR szCmdLine,int iCmdShow)
{
	
	static char szAppName[]="DxProcTest";
	int iDeg=0;
	int iCenterX,iCenterY;

	MSG msg;
	HWND hWnd;
	WNDCLASSEX wcl;

	wcl.cbSize=sizeof(wcl);
	wcl.style=CS_HREDRAW|CS_VREDRAW;
	wcl.lpfnWndProc=WndProc;
	wcl.cbClsExtra=wcl.cbWndExtra=NULL;
	wcl.hInstance=hInstance;
	wcl.hIcon=LoadIcon(hInstance,szAppName);
	wcl.hCursor=LoadCursor(NULL,IDC_ARROW);
	wcl.hbrBackground=(HBRUSH)GetStockObject(WHITE_BRUSH);
	wcl.lpszMenuName=MAKEINTRESOURCE(IDM_MENU);
	wcl.lpszClassName=szAppName;
	wcl.hIconSm=LoadIcon(hInstance,szAppName);

	RegisterClassEx(&wcl);

	ghWnd=hWnd=CreateWindowEx(
		0,szAppName,"Dx Test",
		WS_POPUP,
		0,0,
		GetSystemMetrics(SM_CXSCREEN),
	    GetSystemMetrics(SM_CYSCREEN),
		NULL,NULL,hInstance,
		NULL);

	ShowWindow(hWnd,iCmdShow);
	UpdateWindow(hWnd);
	g_DDHolder.InitializeDirectDraw(0,ghWnd);
	g_DDHolder.SetMode(800,600,16,FALSE);
	RECT rc;
	SetRect(&rc,0,0,0,0);
	g_pDSPicture1=g_DDHolder.MakeSurface("dx.bmp",rc,RGB(255,255,255));
	g_pDSPicture2=g_DDHolder.MakeSurface("codeguru.bmp",rc,RGB(0,0,0));

	while(TRUE) {
		if(PeekMessage(&msg,NULL,0,0,PM_REMOVE)) {
			if(msg.message==WM_QUIT) break;			
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		} else {
			if(gbActive) {
				g_DDHolder.ClearBackSurface();
				SetRect(&rc,0,0,0,0);
				iDeg=(iDeg+1)%360;
				iCenterX=g_DDHolder.GetScreenRect().right/2;
				iCenterY=g_DDHolder.GetScreenRect().bottom/2;
				g_DDHolder.Draw(g_pDSPicture1,
					iCenterX-260/2,iCenterY-290/2,rc,1,TRUE);
				g_DDHolder.Draw(g_pDSPicture2,
					iCenterX-175/2+200*cos(iDeg*PI180),
					iCenterY-70/2+200*sin(iDeg*PI180),rc,1,FALSE);
				g_DDHolder.Show();
			}
		}
	}
	return msg.wParam;
}

BOOL WINAPI EnumDDrawDevice(GUID FAR *lpGuid,
							LPSTR lpDirectDescription,
							LPSTR lpDriverName,
							LPVOID lpContext)
{
	LONG iIndex;
	HWND hWnd=(HWND)lpContext;
	LPVOID lpDevice=NULL;

	iIndex=SendMessage(hWnd,CB_ADDSTRING,0,
		               (LPARAM)lpDirectDescription);

	if(lpGuid) {
	  lpDevice=new GUID;
	  memcpy(lpDevice,lpGuid,sizeof(GUID));
	  SendMessage(hWnd,CB_SETITEMDATA,iIndex,(LPARAM)lpDevice);
	}
	
	return DDENUMRET_OK;
}

LRESULT CALLBACK WndProc(HWND hwnd,UINT imsg,WPARAM wparam,
						 LPARAM lparam)
{
	static HINSTANCE hInstance;
	RECT rc;

	switch(imsg) {
	case WM_ACTIVATE:
		gbActive = LOWORD(wparam)&&!HIWORD(wparam);
		return 0;
	case WM_CREATE:
		ghWnd=hwnd;
		hInstance=((LPCREATESTRUCT)lparam)->hInstance;
		return 0;
	case WM_KEYDOWN:
		return 0;
	case WM_SIZE:
		GetWindowRect(hwnd,&rc);
		g_DDHolder.SetScreenRect(rc.left,rc.top,rc.right,rc.bottom);
		return TRUE;
	case WM_COMMAND:
		switch(LOWORD(wparam)) {
		case IDM_SETRES:
            DialogBox(hInstance,
			  MAKEINTRESOURCE(IDD_DRESOLUTION),
			  hwnd,(DLGPROC)ResDlgProc);
			return 0;
		case IDM_SETDEVICE:
			DialogBox(hInstance,
			MAKEINTRESOURCE(IDD_DDDEVICE),hwnd,(DLGPROC)DialogProc);
			return 0;
		}
		break;
	case WM_MOUSEMOVE:
		return 0;
	case WM_LBUTTONDOWN:
		return 0;
	case WM_RBUTTONDOWN:
		return 0;
	case WM_RBUTTONUP:
		return 0;
	case WM_RBUTTONDBLCLK:
		return 0;
	case WM_DESTROY:
		delete g_pDSPicture1;
		delete g_pDSPicture2;
		g_DDHolder.ReleaseAllResources();
		PostQuitMessage(0);
		return 0;
	}
	return DefWindowProc(hwnd,imsg,wparam,lparam);
}


BOOL CALLBACK DialogProc(HWND hdlg,UINT imsg,
						 WPARAM wparam,LPARAM lparam)
{
	LPGUID lpGuid;
	int iIndex;
	switch(imsg) {
	case WM_INITDIALOG:
		DirectDrawEnumerate(EnumDDrawDevice,GetDlgItem(hdlg,IDC_DEVICES));
		SendMessage(GetDlgItem(hdlg,IDC_DEVICES),CB_SETCURSEL,1,0);
		return TRUE;
	case WM_COMMAND:
		switch(LOWORD(wparam)) {
		case IDOK:
			iIndex=SendMessage(GetDlgItem(hdlg,IDC_DEVICES),
				               CB_GETCURSEL,0,0);
			lpGuid=(GUID*)SendMessage(GetDlgItem(hdlg,IDC_DEVICES),
				               CB_GETITEMDATA,iIndex,0);
			g_DDHolder.ReleaseAllResources();
			if(!g_DDHolder.InitializeDirectDraw(lpGuid,ghWnd)) {
				MessageBox(hdlg,"Unable to initialize directdraw","",MB_OK);
			}
			g_DDHolder.SetMode(800,600,16,FALSE);
			EndDialog(hdlg,0);
			return TRUE;
		}
		break;
    case WM_DELETEITEM:
		if(((LPDELETEITEMSTRUCT)lparam)->itemData) 
			delete (UINT *)((LPDELETEITEMSTRUCT)lparam)->itemData;
		return TRUE;
	}
	return FALSE;
}

BOOL WINAPI EnumDisplayModes(LPDDSURFACEDESC lpddsurfacedesc,
							 LPVOID lpcontext)
{
	LONG iIndex;
	char buff[300];
	HWND hWnd=(HWND)lpcontext;
	LPVOID lpDesc=NULL;

	wsprintf(buff,"%dx%dx%dx%d",
		lpddsurfacedesc->dwWidth,
		lpddsurfacedesc->dwHeight,
		lpddsurfacedesc->ddpfPixelFormat.dwRGBBitCount,
		lpddsurfacedesc->dwRefreshRate);
	iIndex=SendMessage(hWnd,LB_ADDSTRING,0,(LONG)(LPSTR)buff);

	lpDesc=new DDSURFACEDESC;
	memcpy(lpDesc,lpddsurfacedesc,sizeof(DDSURFACEDESC));
	SendMessage(hWnd,LB_SETITEMDATA,iIndex,(LPARAM)lpDesc);
	return DDENUMRET_OK;
}



BOOL CALLBACK ResDlgProc(HWND hdlg,UINT imsg,
						 WPARAM wparam,LPARAM lparam)
{
	int iIndex;
	LPDDSURFACEDESC lpDesc;
	RECT rc;

	switch(imsg) {
	case WM_INITDIALOG:
		g_DDHolder.FlipToGDI();
		g_DDHolder.GetAvailDisplayModes(
			  (LPDDENUMMODESCALLBACK)EnumDisplayModes,GetDlgItem(hdlg,IDC_RESOLUTION));
		SendMessage(GetDlgItem(hdlg,IDC_RESOLUTION),LB_SETCURSEL,18,0);
		return TRUE;
	case WM_COMMAND:
		switch(LOWORD(wparam)) {
		case IDOK:
			iIndex=SendMessage(GetDlgItem(hdlg,IDC_RESOLUTION),LB_GETCURSEL,0,0);
			lpDesc=(LPDDSURFACEDESC)SendMessage(GetDlgItem(hdlg,IDC_RESOLUTION),LB_GETITEMDATA,iIndex,0);
			g_DDHolder.SetMode(lpDesc->dwWidth,lpDesc->dwHeight,
				lpDesc->ddpfPixelFormat.dwRGBBitCount,TRUE);
			SetRect(&rc,0,0,0,0);
			EndDialog(hdlg,0);
			return TRUE;
		}
		break;
    case WM_DELETEITEM:
		if(((LPDELETEITEMSTRUCT)lparam)->itemData) 
			delete (UINT *)((LPDELETEITEMSTRUCT)lparam)->itemData;
		return TRUE;
	}
	return FALSE;
}