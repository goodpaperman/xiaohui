// CDDirectDrawHolder.cpp: implementation of the CDDirectDrawHolder class.
//
//////////////////////////////////////////////////////////////////////

#include "DirectDrawHolder.h"
#include "DDSurfaceHolder.h"
#include "LinkStore.h"
#include <string.h>
#include <vector>


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDDirectDrawHolder::CDDirectDrawHolder()
:m_lpDDPrimarySurface(NULL),
m_lpDDBackSurface(NULL),m_lpDD2(NULL),
m_hWnd(NULL),m_bFullScreen(FALSE),
m_lpClipper(NULL)
{
}

CDDirectDrawHolder::~CDDirectDrawHolder()
{
	m_cSurfaces.erase(m_cSurfaces.begin(),m_cSurfaces.end());
	if(m_lpDD2) ReleaseAllResources();
}

//////////////////////////////////////
//bmp picture path,rectangle of the picture
//to be copied into a surface,0,0,0,0 causes
//all the pictures to be loaded, color
//value of the transparent color.
//////////////////////////////////////

CDDSurfaceHolder *CDDirectDrawHolder::MakeSurface(char *pszBuffer,
													RECT rc,DWORD dwcolor)
{
	CDDSurfaceHolder *pDDSurfHolder;
	pDDSurfHolder=new CDDSurfaceHolder(*this);
	pDDSurfHolder->LoadBitmap(pszBuffer,
		rc.left,rc.top,
		rc.right,rc.bottom,dwcolor);
	m_cSurfaces.push_back(pDDSurfHolder);
	return pDDSurfHolder;
}

////////////////////////
//  Initializes directdraw,
//  If GUID == null => Uses default directdraw driver
////////////////////////

BOOL CDDirectDrawHolder::InitializeDirectDraw(LPGUID lpguid,HWND hwnd)
{
	LPDIRECTDRAW lpDD;
	BOOL bSucceeded;

	if(FAILED(DirectDrawCreate(lpguid,&lpDD,NULL))) return FALSE;

	if(SUCCEEDED(lpDD->QueryInterface(IID_IDirectDraw2,
		(LPVOID*)&m_lpDD2))) bSucceeded=TRUE;
	else bSucceeded=FALSE;

	lpDD->Release();
	m_hWnd=hwnd;
	if(FAILED(m_lpDD2->SetCooperativeLevel(m_hWnd,
		DDSCL_EXCLUSIVE|
		DDSCL_FULLSCREEN|
		DDSCL_NOWINDOWCHANGES))) {
		m_lpDD2->Release();
		m_lpDD2=NULL;
		bSucceeded=FALSE;
	}
	SetRect(&m_cScreenRect,0,0,
		GetSystemMetrics(SM_CXSCREEN),
		GetSystemMetrics(SM_CYSCREEN));
	return bSucceeded;
}

LPDIRECTDRAW2 CDDirectDrawHolder::GetDrawObject() const
{
	return m_lpDD2;
}

HWND CDDirectDrawHolder::GetWindowHandle() const
{
	return m_hWnd;
}

//////////////////////////////////////
// Gets available display modes
// and sends them to a callback function
// of type EnumModesCallback
// Used to enumerate display modes
//////////////////////////////////////

void CDDirectDrawHolder::GetAvailDisplayModes(
			LPDDENUMMODESCALLBACK lpEnumModesCallback,LPVOID lpContext) const
{
	m_lpDD2->EnumDisplayModes(0,NULL,
			  lpContext,lpEnumModesCallback);
}

//////////////////////////////////
// Releases everything.
// Note: Including surfaces!
//////////////////////////////////

void CDDirectDrawHolder::ReleaseAllResources()
{
	vector<CDDSurfaceHolder*>::iterator CItr;
	for(CItr=m_cSurfaces.begin();CItr!=m_cSurfaces.end();CItr++)
		(*CItr)->ClearMem();

	if(m_lpClipper) {
		m_lpClipper->Release();
		m_lpClipper=NULL;
	}

	if(m_lpDDBackSurface) {
	  m_lpDDBackSurface->Release();
	  m_lpDDBackSurface=NULL;
	}

	if(m_lpDDPrimarySurface) {
		m_lpDDPrimarySurface->Release();
		m_lpDDPrimarySurface=NULL;
	}
	m_lpDD2->Release();
	m_lpDD2=NULL;
}

////////////////////////////////////////
// if bfull is high => iwidth,iheight,ibpp will
// be used else current res.
////////////////////////////////////////
BOOL CDDirectDrawHolder::SetMode(int iwidth,
							   int iheight,
							   int ibpp,BOOL bfull)
{
	DDSURFACEDESC ddsd;
	m_bFullScreen=bfull;
	DWORD dWord;

	if(m_lpClipper) {
		m_lpClipper->Release();
		m_lpClipper=NULL;
	}
	if(m_lpDDBackSurface) {
	    m_lpDDBackSurface->Release();
		m_lpDDBackSurface=NULL;
	}
	if(m_lpDDPrimarySurface) {
		m_lpDDPrimarySurface->Release();
		m_lpDDPrimarySurface=NULL;
	}

	if(bfull)
		  dWord=DDSCL_EXCLUSIVE|DDSCL_FULLSCREEN;
	else dWord=DDSCL_NORMAL;
	if(FAILED(m_lpDD2->SetCooperativeLevel(m_hWnd,dWord))) {
		  m_lpDD2->Release();
		  m_lpDD2=NULL;
		  return FALSE;
	}

	if(bfull) {
		m_lpDD2->SetDisplayMode(iwidth,iheight,ibpp,0,0);
	    ZeroMemory(&ddsd,sizeof(ddsd));
	    ddsd.dwFlags=DDSD_CAPS| DDSD_BACKBUFFERCOUNT;
		ddsd.dwSize = sizeof( ddsd );
		ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE | 
                            DDSCAPS_FLIP | 
                            DDSCAPS_COMPLEX;
		ddsd.dwBackBufferCount=1;
		if(FAILED(m_lpDD2->CreateSurface(&ddsd,&m_lpDDPrimarySurface,NULL))) {
			return FALSE;
		}
		DDSCAPS ddsCaps;
		ddsCaps.dwCaps=DDSCAPS_BACKBUFFER;
		m_lpDDPrimarySurface->GetAttachedSurface(&ddsCaps,&m_lpDDBackSurface);
		SetRect(&m_cScreenRect,0,0,
		GetSystemMetrics(SM_CXSCREEN),
		GetSystemMetrics(SM_CYSCREEN));
	}
	else {
		ZeroMemory(&ddsd,sizeof(ddsd));
	    ddsd.dwFlags=DDSD_CAPS;
		ddsd.dwSize = sizeof(ddsd);
		ddsd.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE;
		if(FAILED(m_lpDD2->CreateSurface(&ddsd,&m_lpDDPrimarySurface,NULL))) {
			return FALSE;
		}
		m_lpDDPrimarySurface->GetSurfaceDesc(&ddsd);
		ddsd.dwFlags=DDSD_CAPS|DDSD_HEIGHT|DDSD_WIDTH;
		ddsd.ddsCaps.dwCaps=DDSCAPS_OFFSCREENPLAIN;
		if(FAILED(m_lpDD2->CreateSurface(&ddsd,&m_lpDDBackSurface,NULL)))
			return FALSE;
		GetWindowRect(m_hWnd,&m_cScreenRect);
		
	    if(FAILED(m_lpDD2->CreateClipper(0,&m_lpClipper,NULL))) return FALSE;
		m_lpClipper->SetHWnd(0,m_hWnd);
		m_lpDDPrimarySurface->SetClipper(m_lpClipper);
		m_lpClipper->Release();
	}
	return TRUE;
}

///////////////////////////////
//Fills backbuffer with black//
///////////////////////////////
void CDDirectDrawHolder::ClearBackSurface()
{
	DDBLTFX ddbltfx;
	ZeroMemory(&ddbltfx,sizeof(ddbltfx));
	ddbltfx.dwSize = sizeof( ddbltfx );
	m_lpDDBackSurface->Blt(&m_cScreenRect,NULL,NULL,
		DDBLT_COLORFILL|DDBLT_WAIT,&ddbltfx);
}

//////////////////////////////////////////
//  Draws the rc part of surface at 
//  position ix,iy on the scale dscale
//  (expands down & right). if btransparent
//  is high the colorkey is used.
//////////////////////////////////////////
BOOL CDDirectDrawHolder::Draw(CDDSurfaceHolder *pDSHolder,
							int ix,int iy,RECT rc,
							double dscale,BOOL btransparent) const
{
	using namespace std;

	RECT rcdest;
	if(rc.left==rc.right) 
		CopyRect(&rc,&pDSHolder->m_cRect);

	LPDIRECTDRAWSURFACE lpSurf;

	vector<CDDSurfaceList*> *pListVector=pDSHolder->GetSurface();
	if(pListVector->empty()) return FALSE;

	vector<CDDSurfaceList*>::iterator CItr;

	int iOffset;
	RECT rcNowSource;
	// Iterate throught the list and
	// for every iteration draw the visible
	// part of the surface
	for(CItr=pListVector->begin();CItr!=pListVector->end();CItr++) {
		lpSurf=(*CItr)->m_lpSurface;
		//rc heildarmyndin sem vill teikna
		//rcNowSource source � myndhluta

		//Find the part that rc covers
		CopyRect(&rcNowSource,&(*CItr)->m_cRect);

		rcNowSource.left=max(rc.left,rcNowSource.left);
		rcNowSource.top=max(rc.top,rcNowSource.top);
		rcNowSource.right=min(rc.right,rcNowSource.right);
		rcNowSource.bottom=min(rc.bottom,rcNowSource.bottom);

		rcdest.left=rcNowSource.left-rc.left;
		rcdest.left=(long)(rcdest.left*dscale);
		rcdest.left+=ix;
		rcdest.top=rcNowSource.top-rc.top;
		rcdest.top=(long)(rcdest.top*dscale);
		rcdest.top+=iy;

		rcdest.right=rcNowSource.right-rcNowSource.left;
		rcdest.right=(long)(rcdest.right*dscale);
		rcdest.right+=rcdest.left;
		rcdest.bottom=rcNowSource.bottom-rcNowSource.top;
		rcdest.bottom=(long)(rcdest.bottom*dscale);
		rcdest.bottom+=rcdest.top;

		//Clipping
		rcNowSource.right-=(*CItr)->m_cRect.left;
		rcNowSource.bottom-=(*CItr)->m_cRect.top;
		rcNowSource.left-=(*CItr)->m_cRect.left;
		rcNowSource.top-=(*CItr)->m_cRect.top;

		if(rcdest.left<m_cScreenRect.left) {
			iOffset=m_cScreenRect.left-rcdest.left;
			rcNowSource.left+=(long)(iOffset/dscale);
			rcdest.left+=iOffset;
		}
		if(rcdest.top<m_cScreenRect.top) {
			iOffset=m_cScreenRect.top-rcdest.top;
			rcNowSource.top+=(long)(iOffset/dscale);
			rcdest.top+=iOffset;
		}
		if(rcdest.right>m_cScreenRect.right) {
			iOffset=rcdest.right-m_cScreenRect.right;
			rcNowSource.right-=(long)(iOffset/dscale);
			rcdest.right-=iOffset;
		}
		if(rcdest.bottom>m_cScreenRect.bottom) {
			iOffset=rcdest.bottom-m_cScreenRect.bottom;
			rcNowSource.bottom-=(long)(iOffset/dscale);
			rcdest.bottom-=iOffset;
		}
		if(rcNowSource.left>rcNowSource.right || 
			rcNowSource.top>rcNowSource.bottom
			|| rcdest.right<0 || rcdest.bottom<0
			|| rcdest.left>m_cScreenRect.right ||
			rcdest.top>m_cScreenRect.bottom) continue;

		if(btransparent)
			m_lpDDBackSurface->Blt(&rcdest,lpSurf,&rcNowSource,
			DDBLT_WAIT|DDBLT_KEYSRC,NULL);
		else m_lpDDBackSurface->Blt(&rcdest,lpSurf,&rcNowSource,
			DDBLT_WAIT,NULL);
	}
	return TRUE;
}

//////////////////////////////////////////
// Call this function if you want to make
// the gdi surface the current surface
// f.eks. for displaying dialog boxes
//////////////////////////////////////////

BOOL CDDirectDrawHolder::FlipToGDI()
{
	if(m_lpDD2) m_lpDD2->FlipToGDISurface();
	return TRUE;
}


void CDDirectDrawHolder::SetScreenRect(int x0,int y0,int x1,int y1)
{
	SetRect(&m_cScreenRect,x0,y0,x1,y1);
}

inline LPDIRECTDRAWSURFACE CDDirectDrawHolder::GetBackSurface() const
{
	return m_lpDDBackSurface;
}

///////////////////////
// If in fullscreen mode then use 
// page flipping else use standard blitting
///////////////////////

BOOL CDDirectDrawHolder::Show() const
{
	return m_bFullScreen?
		SUCCEEDED(m_lpDDPrimarySurface->Flip(NULL,DDFLIP_WAIT)):
	    SUCCEEDED(m_lpDDPrimarySurface->Blt(NULL,
		            m_lpDDBackSurface,NULL,DDBLTFAST_WAIT,NULL));
}
