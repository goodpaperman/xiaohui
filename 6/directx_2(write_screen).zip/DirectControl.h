// -------------------------------------------------------------------------
// CDirectControl Class
// -------------------------------------------------------------------------

#pragma once
#include "DirectDraw.h"
#include "DirectSurface.h"

class CDirectControl : public CDirectObject  
{
private:
	POSITION m_Pos;
private:
	CWnd *m_pWnd;
	CDirectDraw* m_pDirectDraw;
	CDirectSurfaceList* m_pDirectSurfaceList;
private:
	void Release();
public:
	CWnd* CreateFullScreen(int nXRes,int nYRes,int nBpp);
	BOOL  CreateOffScreenSurface(LPCTSTR szIdentifier,int nWidth,int nHeight);
	BOOL  CreateOffScreenSurface(LPCTSTR szIdentifier,UINT uiResBmpId);
	BOOL  Render(BOOL bClearFirst,BOOL bRenderSurfaces,BOOL bRenderOSB);
public:
	CDirectSurface* GetSurface(LPCTSTR szIdentifier);
public:
	CDirectControl();
	virtual ~CDirectControl();
};


