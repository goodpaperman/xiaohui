#pragma once

#define VC_EXTRALEAN		

#include <afxwin.h>         
#include <afxext.h>         
#include <afxdtctl.h>		
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			
#endif 

#include <afxTempl.h>


