// -------------------------------------------------------------------------
// CDirectSurface Class
// -------------------------------------------------------------------------

#include "stdafx.h"
#include "DirectSurface.h"

// -------------------------------------------------------------------------
// CDirectSurface Constructor
// -------------------------------------------------------------------------

CDirectSurface::CDirectSurface()
{
	m_pSurface		= NULL;
	m_pSurfaceInfo	= NULL;
	m_nXPos			= 0;
	m_nYPos			= 0;
	m_bRender		= FALSE;
}

// -------------------------------------------------------------------------
// CDirectSurface Destructor
// -------------------------------------------------------------------------

CDirectSurface::~CDirectSurface()
{
	if (m_pSurfaceInfo){
		delete m_pSurfaceInfo;
		m_pSurfaceInfo = NULL;
	}
	if (m_pSurface){
		m_pSurface->Release();
		m_pSurface = NULL;
	}
}

// -------------------------------------------------------------------------
// CDirectSurface Clear
// -------------------------------------------------------------------------

BOOL CDirectSurface::Clear(int nColor)
{
	if (Lock()){
		BYTE* pAddress = (BYTE*) m_pSurfaceInfo->lpSurface;
		DWORD dwBuffer = m_pSurfaceInfo->lPitch*m_pSurfaceInfo->dwHeight;
		memset(pAddress,nColor,dwBuffer);
		Unlock();
	}
	return TRUE;
}

// -------------------------------------------------------------------------
// CDirectSurface Create
// -------------------------------------------------------------------------

BOOL CDirectSurface::Create(LPDIRECTDRAW2 pDD,int nWidth, int nHeight)
{
	if (m_pSurface || !pDD || m_pSurfaceInfo)
		return Error("Cannot Create OffScreen Surface Without First Creating DirectDraw Object");

	// Create Primary Surface Structure
	m_pSurfaceInfo = new DDSURFACEDESC;
	memset(m_pSurfaceInfo,0,sizeof(DDSURFACEDESC));
	m_pSurfaceInfo->dwSize = sizeof(DDSURFACEDESC);
	m_pSurfaceInfo->dwFlags = DDSD_CAPS|DDSD_HEIGHT|DDSD_WIDTH;
	m_pSurfaceInfo->ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN;
	m_pSurfaceInfo->dwHeight = nHeight;
	m_pSurfaceInfo->dwWidth = nWidth;

	// Create Primary Surface
	if (FAILED(pDD->CreateSurface(m_pSurfaceInfo,&m_pSurface,NULL)))
		return Error("OffScreen Surface Creation Failure");

	return TRUE;
}

// -------------------------------------------------------------------------
// CDirectSurface Create From Resource Bitmap
// -------------------------------------------------------------------------

BOOL CDirectSurface::Create(LPDIRECTDRAW2 pDD, UINT uiResBmpId)
{
	// Load Bitmap
    HBITMAP hbm = (HBITMAP)LoadImage(AfxGetResourceHandle(),MAKEINTRESOURCE((WORD)uiResBmpId),IMAGE_BITMAP,0,0,LR_CREATEDIBSECTION);
	if (!hbm)
		return Error("Cannot Load Resource Bitmap");

	// Get Bitmap Size
	BITMAP bmInfo;
	GetObject(hbm,sizeof(BITMAP),&bmInfo);

	// Create Surface
	Create(pDD,bmInfo.bmWidth,bmInfo.bmHeight);

	// Create Compatible DC
    HDC hdcBitmap = CreateCompatibleDC(NULL);
	if (!hdcBitmap)
		return Error("Cannot Create DC For Surface Bitmap Copy");

	// Select Object
    SelectObject(hdcBitmap,hbm);

	// Copy Bitmap
	HDC hdc;
	if (FAILED(m_pSurface->GetDC(&hdc)))
		return Error("Cannot Get Surface Device Context");

	StretchBlt(hdc,0,0,bmInfo.bmWidth,bmInfo.bmHeight,hdcBitmap,0,0,bmInfo.bmWidth,bmInfo.bmHeight,SRCCOPY);

	// Cleanup
	m_pSurface->ReleaseDC(hdc);
    DeleteDC(hdcBitmap);
    DeleteObject(hbm);

	return TRUE;
}

// -------------------------------------------------------------------------
// CDirectSurface Lock
// -------------------------------------------------------------------------

BOOL CDirectSurface::Lock()
{
	memset(m_pSurfaceInfo,0,sizeof(DDSURFACEDESC));
	m_pSurfaceInfo->dwSize = sizeof(DDSURFACEDESC);
	if (FAILED(m_pSurface->Lock(NULL,m_pSurfaceInfo,DDLOCK_WAIT,NULL)))
		return Error("Could Not Lock Off Screen Surface For Drawing");

	return TRUE;

}

// -------------------------------------------------------------------------
// CDirectSurface Set Position
// -------------------------------------------------------------------------

void CDirectSurface::SetPosition(int nXPos, int nYPos)
{
	m_nXPos = nXPos;
	m_nYPos = nYPos;
}

// -------------------------------------------------------------------------
// CDirectSurface Set Render
// -------------------------------------------------------------------------

void CDirectSurface::SetRender(BOOL bRender)
{
	m_bRender = bRender;
}

// -------------------------------------------------------------------------
// CDirectSurface Unlock
// -------------------------------------------------------------------------

BOOL CDirectSurface::Unlock()
{
	if (FAILED(m_pSurface->Unlock(m_pSurfaceInfo->lpSurface)))
		return Error("Could Not UnLock Off Screen Surface");

	return TRUE;
}

