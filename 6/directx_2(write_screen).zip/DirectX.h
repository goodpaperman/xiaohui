// -------------------------------------------------------------------------
// CApplication Class
// -------------------------------------------------------------------------

#pragma once
#include "resource.h"   
#include "DirectControl.h"    

class CApplication : public CWinApp
{
public:
	CDirectControl m_Control;
public:
	void OnRunning();
public:
	CApplication();
	//{{AFX_VIRTUAL(CApplication)
	public:
	virtual BOOL InitInstance();
	virtual BOOL OnIdle(LONG lCount);
	//}}AFX_VIRTUAL
public:
	//{{AFX_MSG(CApplication)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

