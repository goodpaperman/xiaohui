// -------------------------------------------------------------------------
// CDirectObject Class
// -------------------------------------------------------------------------

#include "stdafx.h"
#include "DirectObject.h"

// -------------------------------------------------------------------------
// CDirectObject Constructor
// -------------------------------------------------------------------------

CDirectObject::CDirectObject(){}

// -------------------------------------------------------------------------
// CDirectObject Destructor
// -------------------------------------------------------------------------

CDirectObject::~CDirectObject(){}

// -------------------------------------------------------------------------
// CDirectObject Error Occured
// -------------------------------------------------------------------------

BOOL CDirectObject::Error(LPCSTR szError)
{
	AfxMessageBox (szError);
	PostQuitMessage(0);
	return FALSE;
}

// -------------------------------------------------------------------------
// CDirectObject Set Identifier
// -------------------------------------------------------------------------

void CDirectObject::SetIdentifier(LPCTSTR szIdentifier)
{
	m_szIdentifier = (CString)szIdentifier;
}

