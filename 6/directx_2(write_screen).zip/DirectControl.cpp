// -------------------------------------------------------------------------
// CDirectControl Class
// -------------------------------------------------------------------------

#include "stdafx.h"
#include "DirectControl.h"

// -------------------------------------------------------------------------
// CDirectControl Constructor
// -------------------------------------------------------------------------

CDirectControl::CDirectControl()
{
	m_pWnd				 = NULL;
	m_Pos				 = NULL;
	m_pDirectDraw		 = NULL;
	m_pDirectSurfaceList = NULL;
}

// -------------------------------------------------------------------------
// CDirectControl Destructor
// -------------------------------------------------------------------------

CDirectControl::~CDirectControl()
{
	Release();
}

// -------------------------------------------------------------------------
// CDirectControl Create Direct Control FullScreen
// -------------------------------------------------------------------------

CWnd* CDirectControl::CreateFullScreen(int nXRes,int nYRes,int nBpp)
{
	// Check Window Is Valid
	m_pWnd = new CWnd;
	if (!m_pWnd->CreateEx(NULL,AfxRegisterWndClass(CS_DBLCLKS),"",WS_POPUP,CRect(0,0,1,1),NULL,NULL))
		return NULL;

	if (!IsWindow(m_pWnd->m_hWnd))
		return NULL;

	// Create Direct Draw Object
	m_pDirectDraw = new CDirectDraw;
	if (!m_pDirectDraw->Create(m_pWnd,nXRes,nYRes,nBpp)){
		Release();
		return NULL;
	}

	// Create Direct Surfaces Object
	m_pDirectSurfaceList = new CDirectSurfaceList;

	return m_pWnd;
}

// -------------------------------------------------------------------------
// CDirectControl Create Off-Screen Surface
// -------------------------------------------------------------------------

BOOL CDirectControl::CreateOffScreenSurface(LPCTSTR szIdentifier,int nWidth,int nHeight)
{
	if (!m_pDirectDraw || !m_pDirectSurfaceList)
		return Error("CreateOffScreenSurface Called Without Creating DirectDraw Object");

	CDirectSurface* pSurface = new CDirectSurface;
	
	pSurface->Create(m_pDirectDraw->GetDirectDraw(),nWidth,nHeight);
	pSurface->SetIdentifier(szIdentifier);
	pSurface->Clear(10);
	pSurface->SetRender(FALSE);
	
	m_pDirectSurfaceList->AddTail(pSurface);

	return TRUE;
}

// -------------------------------------------------------------------------
// CDirectControl Create Off-Screen Surface From Resource Bitmap
// -------------------------------------------------------------------------

BOOL CDirectControl::CreateOffScreenSurface(LPCTSTR szIdentifier,UINT uiResBmpId)
{
	if (!m_pDirectDraw || !m_pDirectSurfaceList)
		return Error("CreateOffScreenSurface Called Without Creating DirectDraw Object");

	CDirectSurface* pSurface = new CDirectSurface;
	
	pSurface->Create(m_pDirectDraw->GetDirectDraw(),uiResBmpId);
	pSurface->SetIdentifier(szIdentifier);
	pSurface->SetRender(FALSE);

	m_pDirectSurfaceList->AddTail(pSurface);

	return TRUE;
}

// -------------------------------------------------------------------------
// CDirectControl Get Surface
// -------------------------------------------------------------------------

CDirectSurface* CDirectControl::GetSurface(LPCTSTR szIdentifier)
{
	if (!m_pDirectSurfaceList)
		return NULL;

	m_Pos = m_pDirectSurfaceList->GetHeadPosition();
	while (m_Pos){
		CDirectSurface *pSurface = m_pDirectSurfaceList->GetNext(m_Pos);
		if ((CString)pSurface->GetIdentifier() == (CString)szIdentifier)
			return pSurface;
	}
	return NULL;
}

// -------------------------------------------------------------------------
// CDirectControl Release
// -------------------------------------------------------------------------

void CDirectControl::Release()
{
	if (m_pDirectSurfaceList){
		m_Pos = m_pDirectSurfaceList->GetHeadPosition();
		while (m_Pos)
			delete m_pDirectSurfaceList->GetNext(m_Pos);
		delete m_pDirectSurfaceList;
		m_pDirectSurfaceList = NULL;
	}
	if (m_pDirectDraw){
		delete m_pDirectDraw;
		m_pDirectDraw = NULL;
	}
	if (m_pWnd){
		m_pWnd->DestroyWindow();
		delete m_pWnd;
		m_pWnd = NULL;
	}
}

// -------------------------------------------------------------------------
// CDirectControl Render
// -------------------------------------------------------------------------

BOOL CDirectControl::Render(BOOL bClearFirst,BOOL bRenderSurfaces,BOOL bRenderOSB)
{
	if (m_pDirectDraw && m_pDirectSurfaceList){
		// Clear Buffer
		if (bClearFirst)
			m_pDirectDraw->Clear(0);

		// Draw Renderable Surfaces
		if (bRenderSurfaces){
			m_Pos = m_pDirectSurfaceList->GetHeadPosition();
			while (m_Pos){
				CDirectSurface *pSurface = m_pDirectSurfaceList->GetNext(m_Pos);
				if (pSurface && pSurface->IsRenderable())
					m_pDirectDraw->RenderSurface(pSurface->GetSurface(),pSurface->GetXPosition(),pSurface->GetYPosition());
			}
		}

		// Render Back Buffer
		if (bRenderOSB)
			m_pDirectDraw->Render();

		return TRUE;
	}
	return FALSE;
}



