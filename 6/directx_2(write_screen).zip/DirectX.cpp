// -------------------------------------------------------------------------
// CApplication Class
// -------------------------------------------------------------------------

#include "stdafx.h"
#include "DirectX.h"

// -------------------------------------------------------------------------
// CApplication Standards
// -------------------------------------------------------------------------

BEGIN_MESSAGE_MAP(CApplication, CWinApp)
	//{{AFX_MSG_MAP(CApplication)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

#define RESX	800
#define RESY	600

// -------------------------------------------------------------------------
// CApplication Constructor
// -------------------------------------------------------------------------

CApplication::CApplication(){}
CApplication theApp;

// -------------------------------------------------------------------------
// CApplication Init Instance
// -------------------------------------------------------------------------

BOOL CApplication::InitInstance()
{
	m_pMainWnd = m_Control.CreateFullScreen(RESX,RESY,16);
	if (!m_pMainWnd)
		return FALSE;

	m_Control.CreateOffScreenSurface("1",IDB_IMAGE);
	m_Control.GetSurface("1")->SetRender(TRUE);

	return TRUE;
}

// -------------------------------------------------------------------------
// CApplication On Idle
// -------------------------------------------------------------------------

BOOL CApplication::OnIdle(LONG lCount) 
{
	MSG msg;
	if(::PeekMessage(&msg,NULL,NULL,NULL,PM_REMOVE)){
		if (msg.message == WM_QUIT)
			PostQuitMessage(0);
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	m_Control.Render(TRUE,FALSE,FALSE);
	CDirectSurface *pSurf = m_Control.GetSurface("1");

	static int dx = -pSurf->GetWidth(),dy = -pSurf->GetHeight();

	for (int y=-100; y<RESY+100; y+= pSurf->GetHeight()){
		for (int x=-100; x<RESX+100; x+= pSurf->GetWidth()){
			pSurf->SetPosition(x+dx,y+dy);
			m_Control.Render(FALSE,TRUE,FALSE);
		}
	}
	m_Control.Render(FALSE,FALSE,TRUE);

	dx += 3;
	dy += 3;

	if (dx > pSurf->GetWidth())
		dx = -pSurf->GetWidth();
	if (dy > pSurf->GetHeight())
		dy = -pSurf->GetHeight();

	return TRUE;
}
