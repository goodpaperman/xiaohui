// -------------------------------------------------------------------------
// CDirectObject Class
// -------------------------------------------------------------------------

#pragma once

class CDirectObject : public CObject
{
private:
	CString m_szIdentifier;
public:
	LPCTSTR GetIdentifier(){return m_szIdentifier;};
	BOOL Error(LPCSTR szError);
	void SetIdentifier(LPCTSTR szIdentifier);
public:
	CDirectObject();
	virtual ~CDirectObject();
};


