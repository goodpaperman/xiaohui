// -------------------------------------------------------------------------
// CDirectSurface Class
// -------------------------------------------------------------------------

#pragma once

#include "DDraw.h"
#include "DirectObject.h"

class CDirectSurface : public CDirectObject
{
private:
	BOOL m_bRender;
private:
	int m_nXPos;
	int m_nYPos;
private:
	LPDDSURFACEDESC m_pSurfaceInfo;
	LPDIRECTDRAWSURFACE m_pSurface;
public:
	LPDIRECTDRAWSURFACE GetSurface(){return m_pSurface;};
	BOOL Clear(int nColor);
	BOOL Create(LPDIRECTDRAW2 pDD,int nWidth,int nHeight);
	BOOL IsRenderable(){return m_bRender;};
	int  GetXPosition(){return m_nXPos;};
	int  GetYPosition(){return m_nYPos;};
	int  GetWidth(){return m_pSurfaceInfo->dwWidth;};
	int  GetHeight(){return m_pSurfaceInfo->dwHeight;};
	void SetPosition(int nXPos,int nYPos);
	void SetRender(BOOL bRender);
private:
	BOOL Unlock();
	BOOL Lock();
public:
	BOOL Create(LPDIRECTDRAW2 pDD,UINT uiResBmpId);
	CDirectSurface();
	virtual ~CDirectSurface();
};

typedef CTypedPtrList<CObList,CDirectSurface*> CDirectSurfaceList;
