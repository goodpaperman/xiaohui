// -------------------------------------------------------------------------
// CDirectDraw Class
// -------------------------------------------------------------------------

#pragma once

#include "DDraw.h"
#include "DirectObject.h"

// -------------------------------------------------------------------------
// CDirectDraw Class
// -------------------------------------------------------------------------

class CDirectDraw : public CDirectObject
{
private:
	BOOL m_bLocked;
private:
	LPDIRECTDRAW2		m_pDD;
	LPDIRECTDRAWSURFACE m_pPrimary;
	LPDIRECTDRAWSURFACE m_pBuffer;
	LPDDSURFACEDESC		m_pOSBInfo;
public:
	LPDIRECTDRAW2 GetDirectDraw(){return m_pDD;};
public:
	void Clear(int nColor);
	BOOL Create(CWnd* pWnd,int nXRes,int nYRes,int nBpp);
	BOOL Render();
private:
	BOOL Unlock();
	BOOL Lock();
public:
	BOOL RenderSurface(LPDIRECTDRAWSURFACE pSurface,int nXPos,int nYPos);
	CDirectDraw();
	virtual ~CDirectDraw();
};
