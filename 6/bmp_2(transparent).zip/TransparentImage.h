//******************************************************************************
//******************************************************************************
// Owner:   Andrew Forget (andrewfo@csolve.net) 
//          Copyright � 1999, DragonWerks Software, Inc.
//------------------------------------------------------------------------------
//
// @doc     TRANSPARENTIMAGE
//
// @module  TransparentImage.h |
//          This file declares the transparent image static class
//          <c CTransparentImage>.
//
// @version
//------------------------------------------------------------------------------
//.Version: Date:       Author:     Comments:
//.-------- ----------- ----------- --------------------------------------------
//.  1.0    11/11/99    andrewfo    New file.
//******************************************************************************
//******************************************************************************

#ifndef __TRANSPARENTIMAGE_H_TRANSPARENTIMAGE_42A6E395_97E4_11D3_B6F0_005004024A9E
#define __TRANSPARENTIMAGE_H_TRANSPARENTIMAGE_42A6E395_97E4_11D3_B6F0_005004024A9E

#if _MSC_VER >= 1000
#pragma once
#endif


//******************************************************************************
// Owner:   Andrew Forget (andrewfo@csolve.net) 
//------------------------------------------------------------------------------
//
// @class   CTransparentImage |
//          This is the transparent image static class.
//
// @base    public | CStatic
//
// @version
//------------------------------------------------------------------------------
//.Version: Date:       Author:     Comments:
//.-------- ----------- ----------- --------------------------------------------
//.  1.0    11/11/99    andrewfo    New code.
//******************************************************************************

class CTransparentImage 
	: public CStatic
{
	////////////////////////////////////////////////////////////////////////////
	// @access Public methods.
	//
	public:
	//
	// @cmember Constructor.
	CTransparentImage() ;
	//
	// @cmember Constructor.
	virtual ~CTransparentImage() ;
	//
	////////////////////////////////////////////////////////////////////////////

	////////////////////////////////////////////////////////////////////////////
	// @access ClassWizard generated virtual function overrides
	//
	//{{AFX_VIRTUAL( CTransparentImage )
	//}}AFX_VIRTUAL
	//
	////////////////////////////////////////////////////////////////////////////

	////////////////////////////////////////////////////////////////////////////
	// @access Generated message map functions
	//
	protected:
	//
	//{{AFX_MSG( CTransparentImage )
	afx_msg void OnPaint() ;
	//}}AFX_MSG
	//
	DECLARE_MESSAGE_MAP()
	//
	////////////////////////////////////////////////////////////////////////////
} ;

//{{AFX_INSERT_LOCATION}}

#endif
