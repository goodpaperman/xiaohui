//******************************************************************************
//******************************************************************************
// Owner:   Andrew Forget (andrewfo@csolve.net) 
//          Copyright � 1999, DragonWerks Software, Inc.
//------------------------------------------------------------------------------
//
// @doc     TRANSPARENTIMAGETEST
//
// @module  MainDialog.cpp |
//          This file implements the main dialog class <c CMainDialog>.
//
// @version
//------------------------------------------------------------------------------
//.Version: Date:       Author:     Comments:
//.-------- ----------- ----------- --------------------------------------------
//.  1.0    11/14/99    andrewfo    New file.
//******************************************************************************
//******************************************************************************


//******************************************************************************
//
// Includes
//
//******************************************************************************

#include "StdAfx.h"

#include "TransparentImageTest.h"

#include "MainDialog.h"


//******************************************************************************
//
// Debugging
//
//******************************************************************************

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__ ;
#endif


//******************************************************************************
// Owner:   Andrew Forget (andrewfo@csolve.net) 
//------------------------------------------------------------------------------
//
// @mfunc   | CMainDialog | CMainDialog |
//          Constructor for <c CMainDialog>.
//
// @syntax  CMainDialog(
//          			CWnd* in_pParent ) ;
//
// @parm    CWnd* | in_pParent |
//          Pointer to the <c CWnd> parent.
//
// @version
//------------------------------------------------------------------------------
//.Version: Date:       Author:     Comments:
//.-------- ----------- ----------- --------------------------------------------
//.  1.0    11/14/99    andrewfo    New code.
//******************************************************************************

CMainDialog::CMainDialog(
			CWnd* in_pParent )
	: CDialog( CMainDialog::IDD, in_pParent )
{
	//{{AFX_DATA_INIT( CMainDialog )
	//}}AFX_DATA_INIT

	m_hIcon = ::AfxGetApp()->LoadIcon( IDR_MAINFRAME ) ;
}

//******************************************************************************
// Owner:   Andrew Forget (andrewfo@csolve.net) 
//------------------------------------------------------------------------------
//
// @mfunc   void | CMainDialog | DoDataExchange |
//          This method handles the data exchange for <c CMainDialog>.
//
// @syntax  void DoDataExchange(
//          			CDataExchange* pDX ) ;
//
// @parm    CDataExchange* | pDX |
//          Pointer to the <c CDataExchange>.
//
// @version
//------------------------------------------------------------------------------
//.Version: Date:       Author:     Comments:
//.-------- ----------- ----------- --------------------------------------------
//.  1.0    11/14/99    andrewfo    New code.
//******************************************************************************

void CMainDialog::DoDataExchange(
			CDataExchange* pDX )
{
	CDialog::DoDataExchange( pDX ) ;

	//{{AFX_DATA_MAP( CMainDialog )
	DDX_Control(pDX, IDC_HYPERLINK, m_HyperLink);
	DDX_Control( pDX, IDC_IMAGE, m_Image ) ;
	DDX_Control( pDX, IDC_TITLE, m_Title ) ;
	//}}AFX_DATA_MAP
}


//******************************************************************************
// Owner:   Andrew Forget (andrewfo@csolve.net) 
//------------------------------------------------------------------------------
//
// @msgmap  CMainDialog | CDialog |
//          Message map for <c CMainDialog>.
//
// @version
//------------------------------------------------------------------------------
//.Version: Date:       Author:     Comments:
//.-------- ----------- ----------- --------------------------------------------
//.  1.0    11/14/99    andrewfo    New code.
//******************************************************************************

BEGIN_MESSAGE_MAP( CMainDialog, CDialog )

	//{{AFX_MSG_MAP( CMainDialog )
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP

END_MESSAGE_MAP()


//******************************************************************************
// Owner:   Andrew Forget (andrewfo@csolve.net) 
//------------------------------------------------------------------------------
//
// @mfunc   BOOL | CMainDialog | OnInitDialog |
//          This handles the WM_INITDIALOG windows message for the dialog.
//
// @syntax  BOOL OnInitDialog() ;
//
// @rdesc   BOOL : A boolean value indicating:
// @flag        TRUE  | Set default focus.
// @flag        FALSE | Focus has been set, do not set default focus.
//
// @version
//------------------------------------------------------------------------------
//.Version: Date:       Author:     Comments:
//.-------- ----------- ----------- --------------------------------------------
//.  1.0    11/14/99    andrewfo    New code.
//******************************************************************************

BOOL CMainDialog::OnInitDialog()
{
	CDialog::OnInitDialog() ;

	CFont*  l_pFont = m_Title.GetFont() ;
	LOGFONT l_LogFont ;

	l_pFont->GetLogFont( &l_LogFont ) ;

	if( l_LogFont.lfHeight < 0 )
	{
		l_LogFont.lfHeight -= 4 ;
	}
	else
	{
		l_LogFont.lfHeight += 4 ;
	}

	l_LogFont.lfWeight += 200 ;
	
	_tcscpy( l_LogFont.lfFaceName, _T( "Tahoma" ) ) ;

	CFont l_Font ;
		  l_Font.CreateFontIndirect( &l_LogFont ) ;

	m_Title.SetFont( &l_Font ) ;

	l_Font.Detach() ;

	m_HyperLink.SetURL( _T( "http://www.DragonWerks.Huronia.com" ) ) ;

	SetIcon( m_hIcon, TRUE  ) ;			// Set big icon
	SetIcon( m_hIcon, FALSE ) ;			// Set small icon
	
	return TRUE ;
}

//******************************************************************************
// Owner:   Andrew Forget (andrewfo@csolve.net) 
//------------------------------------------------------------------------------
//
// @mfunc   void | CMainDialog | OnPaint |
//          This handles the WM_PAINT windows message for the dialog.  If you
//          add a minimize button to your dialog, you will need the code below
//          to draw the icon.  For MFC applications using the document/view
//          model, this is automatically done for you by the framework.
//
// @syntax  void OnPaint() ;
//
// @version
//------------------------------------------------------------------------------
//.Version: Date:       Author:     Comments:
//.-------- ----------- ----------- --------------------------------------------
//.  1.0    11/14/99    andrewfo    New code.
//******************************************************************************

void CMainDialog::OnPaint() 
{
	if( IsIconic() )
	{
		CPaintDC l_PaintDC( this ) ;

		SendMessage( WM_ICONERASEBKGND, ( WPARAM )l_PaintDC.GetSafeHdc(), 0 ) ;

		////////////////////////////////////////////////////////////////////////
		// Center icon in client rectangle
		////////////////////////////////////////////////////////////////////////

		int l_cIconX = ::GetSystemMetrics( SM_CXICON ) ;
		int l_cIconY = ::GetSystemMetrics( SM_CYICON ) ;

		CRect l_rcClient ;

		GetClientRect( &l_rcClient ) ;

		int l_nIconX = ( l_rcClient.Width()  - l_cIconX + 1 ) / 2 ;
		int l_nIconY = ( l_rcClient.Height() - l_cIconY + 1 ) / 2 ;

		////////////////////////////////////////////////////////////////////////
		// Draw the icon
		////////////////////////////////////////////////////////////////////////

		l_PaintDC.DrawIcon( l_nIconX, l_nIconY, m_hIcon ) ;
	}
	else
	{
		CDialog::OnPaint() ;
	}
}

//******************************************************************************
// Owner:   Andrew Forget (andrewfo@csolve.net) 
//------------------------------------------------------------------------------
//
// @mfunc   HCURSOR | CMainDialog | OnQueryDragIcon |
//          This handles the WM_QUERYDRAGICON windows message for the dialog.
//
// @syntax  HCURSOR OnQueryDragIcon() ;
//
// @rdesc   HCURSOR : Handle to the cursor for dragging the dialog.
//
// @version
//------------------------------------------------------------------------------
//.Version: Date:       Author:     Comments:
//.-------- ----------- ----------- --------------------------------------------
//.  1.0    11/14/99    andrewfo    New code.
//******************************************************************************

HCURSOR CMainDialog::OnQueryDragIcon()
{
	return ( HCURSOR )m_hIcon ;
}
