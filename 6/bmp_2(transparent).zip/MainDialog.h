//******************************************************************************
//******************************************************************************
// Owner:   Andrew Forget (andrewfo@csolve.net) 
//          Copyright � 1999, DragonWerks Software, Inc.
//------------------------------------------------------------------------------
//
// @doc     TRANSPARENTIMAGETEST
//
// @module  MainDialog.h |
//          This file declares the main dialog class <c CMainDialog>.
//
// @version
//------------------------------------------------------------------------------
//.Version: Date:       Author:     Comments:
//.-------- ----------- ----------- --------------------------------------------
//.  1.0    11/14/99    andrewfo    New file.
//******************************************************************************
//******************************************************************************

#ifndef __MAINDIALOG_H_TRANSPARENTIMAGETEST_5FD5D0BB_9A7E_11D3_B6F1_005004024A9E
#define __MAINDIALOG_H_TRANSPARENTIMAGETEST_5FD5D0BB_9A7E_11D3_B6F1_005004024A9E

#if _MSC_VER >= 1000
#pragma once
#endif


//******************************************************************************
//
// Includes
//
//******************************************************************************

#include "HyperLink.h"
#include "TransparentImage.h"


//******************************************************************************
// Owner:   Andrew Forget (andrewfo@csolve.net) 
//------------------------------------------------------------------------------
//
// @class   CMainDialog |
//          This is the main dialog class for the application.
//
// @base    public | CDialog
//
// @version
//------------------------------------------------------------------------------
//.Version: Date:       Author:     Comments:
//.-------- ----------- ----------- --------------------------------------------
//.  1.0    11/14/99    andrewfo    New code.
//******************************************************************************

class CMainDialog 
	: public CDialog
{
	////////////////////////////////////////////////////////////////////////////
	// @access Public methods.
	//
	public:
	//
	// @cmember Constructor.
	CMainDialog( CWnd* in_pParent = NULL ) ;
	//
	////////////////////////////////////////////////////////////////////////////

	////////////////////////////////////////////////////////////////////////////
	// Dialog Data
	//
	//{{AFX_DATA( CMainDialog )
	enum { IDD = IDD_TRANSPARENTIMAGETEST_DIALOG };
	CTransparentImage m_Image ;
	CStatic			  m_Title ;
	CHyperLink		  m_HyperLink ;
	//}}AFX_DATA
	//
	////////////////////////////////////////////////////////////////////////////

	////////////////////////////////////////////////////////////////////////////
	// ClassWizard generated virtual function overrides
	//
	//{{AFX_VIRTUAL( CMainDialog )
	protected:
	virtual void DoDataExchange( CDataExchange* pDX ) ;
	//}}AFX_VIRTUAL
	//
	////////////////////////////////////////////////////////////////////////////

	////////////////////////////////////////////////////////////////////////////
	// Generated message map functions
	//
	//{{AFX_MSG( CMainDialog )
	virtual BOOL OnInitDialog() ;
	afx_msg void OnPaint() ;
	afx_msg HCURSOR OnQueryDragIcon() ;
	//}}AFX_MSG
	//
	DECLARE_MESSAGE_MAP()
	//
	////////////////////////////////////////////////////////////////////////////

	////////////////////////////////////////////////////////////////////////////
	// Private data
	//
	private:
	//
	// Icon for the dialog.
	HICON m_hIcon ;
	//
	////////////////////////////////////////////////////////////////////////////
} ;

//{{AFX_INSERT_LOCATION}}

#endif
