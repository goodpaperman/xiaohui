// DIBsectionLiteDemoDoc.cpp : implementation of the CDIBsectionLiteDemoDoc class
//

#include "stdafx.h"
#include "DIBsectionLiteDemo.h"

#include "DIBsectionLiteDemoDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDIBsectionLiteDemoDoc

IMPLEMENT_DYNCREATE(CDIBsectionLiteDemoDoc, CDocument)

BEGIN_MESSAGE_MAP(CDIBsectionLiteDemoDoc, CDocument)
	//{{AFX_MSG_MAP(CDIBsectionLiteDemoDoc)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDIBsectionLiteDemoDoc construction/destruction

CDIBsectionLiteDemoDoc::CDIBsectionLiteDemoDoc()
{
}

CDIBsectionLiteDemoDoc::~CDIBsectionLiteDemoDoc()
{
}

BOOL CDIBsectionLiteDemoDoc::OnNewDocument()
{
    //return m_DIBSection.SetBitmap(IDB_GRADIENT2);
    //return m_DIBSection.SetBitmap(IDB_GRADIENT16);
    //return m_DIBSection.SetBitmap(IDB_GRADIENT256);
    //return m_DIBSection.SetBitmap(IDB_GRADIENT65K);
    //return m_DIBSection.SetBitmap(IDB_GRADIENT_TRUE);
    return m_DIBSection.SetBitmap(IDB_BITMAP);
}



/////////////////////////////////////////////////////////////////////////////
// CDIBsectionLiteDemoDoc serialization

void CDIBsectionLiteDemoDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CDIBsectionLiteDemoDoc diagnostics

#ifdef _DEBUG
void CDIBsectionLiteDemoDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CDIBsectionLiteDemoDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDIBsectionLiteDemoDoc commands

BOOL CDIBsectionLiteDemoDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{
    return m_DIBSection.Load(lpszPathName);
}