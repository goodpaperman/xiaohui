// DIBsectionLiteDemoView.h : interface of the CDIBsectionLiteDemoView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DIBSECTIONLITEDEMOVIEW_H__80F115E0_1198_11D3_AA06_A8978A000000__INCLUDED_)
#define AFX_DIBSECTIONLITEDEMOVIEW_H__80F115E0_1198_11D3_AA06_A8978A000000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DIBsectionLiteDemoDoc.h"

class CDIBsectionLiteDemoView : public CView
{
protected: // create from serialization only
	CDIBsectionLiteDemoView();
	DECLARE_DYNCREATE(CDIBsectionLiteDemoView);

// Attributes
public:
	CDIBsectionLiteDemoDoc* GetDocument();
    BOOL m_bStretch;
    BOOL m_bDither;
    BOOL m_bForeground;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDIBsectionLiteDemoView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDIBsectionLiteDemoView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CDIBsectionLiteDemoView)
	afx_msg void OnViewStretch();
	afx_msg void OnUpdateViewStretch(CCmdUI* pCmdUI);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnFileOpen();
	afx_msg void OnViewDither();
	afx_msg void OnUpdateViewDither(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in DIBsectionLiteDemoView.cpp
inline CDIBsectionLiteDemoDoc* CDIBsectionLiteDemoView::GetDocument()
   { return (CDIBsectionLiteDemoDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DIBSECTIONLITEDEMOVIEW_H__80F115E0_1198_11D3_AA06_A8978A000000__INCLUDED_)
