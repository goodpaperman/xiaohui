// DIBsectionLiteDemoView.cpp : implementation of the CDIBsectionLiteDemoView class
//

#include "stdafx.h"
#include "DIBsectionLiteDemo.h"

#include "DIBsectionLiteDemoDoc.h"
#include "DIBsectionLiteDemoView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDIBsectionLiteDemoView

IMPLEMENT_DYNCREATE(CDIBsectionLiteDemoView, CView)

BEGIN_MESSAGE_MAP(CDIBsectionLiteDemoView, CView)
	//{{AFX_MSG_MAP(CDIBsectionLiteDemoView)
	ON_COMMAND(ID_VIEW_STRETCH, OnViewStretch)
	ON_UPDATE_COMMAND_UI(ID_VIEW_STRETCH, OnUpdateViewStretch)
	ON_WM_ERASEBKGND()
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	ON_COMMAND(ID_VIEW_DITHER, OnViewDither)
	ON_UPDATE_COMMAND_UI(ID_VIEW_DITHER, OnUpdateViewDither)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDIBsectionLiteDemoView construction/destruction

CDIBsectionLiteDemoView::CDIBsectionLiteDemoView()
{
    m_bForeground = TRUE;
    m_bStretch = TRUE;
    m_bDither = FALSE;
}

CDIBsectionLiteDemoView::~CDIBsectionLiteDemoView()
{
}

BOOL CDIBsectionLiteDemoView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CDIBsectionLiteDemoView drawing

void CDIBsectionLiteDemoView::OnDraw(CDC* pDC)
{
	CDIBsectionLiteDemoDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

    if (pDoc->m_DIBSection.GetSafeHandle())
    {
        pDoc->m_DIBSection.SetDither(m_bDither);

        if (m_bStretch)
        {
            CRect rect;
            GetClientRect(rect);
            pDoc->m_DIBSection.Stretch(pDC, CPoint(0,0), rect.Size(), m_bForeground);
        }
        else
            pDoc->m_DIBSection.Draw(pDC, CPoint(0,0), m_bForeground);
    }
}

/////////////////////////////////////////////////////////////////////////////
// CDIBsectionLiteDemoView diagnostics

#ifdef _DEBUG
void CDIBsectionLiteDemoView::AssertValid() const
{
	CView::AssertValid();
}

void CDIBsectionLiteDemoView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CDIBsectionLiteDemoDoc* CDIBsectionLiteDemoView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDIBsectionLiteDemoDoc)));
	return (CDIBsectionLiteDemoDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDIBsectionLiteDemoView message handlers

void CDIBsectionLiteDemoView::OnViewStretch() 
{
    m_bStretch = !m_bStretch;
    Invalidate();
}

void CDIBsectionLiteDemoView::OnUpdateViewStretch(CCmdUI* pCmdUI) 
{
    pCmdUI->SetCheck(m_bStretch);
}

void CDIBsectionLiteDemoView::OnViewDither() 
{
    m_bDither = !m_bDither;
    Invalidate();
}

void CDIBsectionLiteDemoView::OnUpdateViewDither(CCmdUI* pCmdUI) 
{
	CDIBsectionLiteDemoDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

    pCmdUI->Enable(pDoc->m_DIBSection.GetBitCount() >= 8);
    pCmdUI->SetCheck(m_bDither);
}

BOOL CDIBsectionLiteDemoView::OnEraseBkgnd(CDC* pDC) 
{
	CDIBsectionLiteDemoDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

    if (!pDoc->m_DIBSection.GetSafeHandle())
	    return CView::OnEraseBkgnd(pDC);

    if (m_bStretch)
        return TRUE;

    CRect ClientRect, ImageRect;
    GetClientRect(ClientRect);
    ImageRect.SetRect(0,0, pDoc->m_DIBSection.GetWidth(), pDoc->m_DIBSection.GetHeight());

    HBRUSH hBrush =  (HBRUSH) GetClassLong(m_hWnd, GCL_HBRBACKGROUND);
    ::FillRect(pDC->GetSafeHdc(), 
               CRect(ImageRect.right,0, ClientRect.right, ImageRect.bottom), hBrush);
    ::FillRect(pDC->GetSafeHdc(), 
               CRect(0, ImageRect.bottom, ClientRect.right, ClientRect.bottom), hBrush);


    return TRUE;
}

void CDIBsectionLiteDemoView::OnFileOpen() 
{
	CDIBsectionLiteDemoDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CString strFilter = "Bitmap Files (*.bmp)|*.bmp|All Files (*.*) |*.*||";

	CFileDialog	dlg(TRUE, NULL, NULL, OFN_HIDEREADONLY|OFN_EXPLORER, strFilter, NULL); 
	if (dlg.DoModal() == IDOK) 
    {
        pDoc->m_DIBSection.Load(dlg.GetPathName());
        pDoc->SetTitle(dlg.GetFileTitle());
        Invalidate();
    }
}
