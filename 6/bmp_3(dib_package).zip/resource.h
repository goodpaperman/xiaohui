//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DIBsectionLiteDemo.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_DIBSECTYPE                  129
#define IDB_BITMAP                      130
#define IDB_GRADIENT_TRUE               133
#define IDB_GRADIENT16                  134
#define IDB_GRADIENT256                 135
#define IDB_GRADIENT65K                 136
#define IDB_GRADIENT2                   137
#define ID_VIEW_STRETCH                 32771
#define ID_VIEW_DITHER                  32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
