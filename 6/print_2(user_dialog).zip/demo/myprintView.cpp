// myprintView.cpp : implementation of the CMyprintView class
//

#include "stdafx.h"
#include "myprint.h"

#include "myprintDoc.h"
#include "myprintView.h"
#include "MyPrintDialog.h"
#include <Dlgs.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyprintView

IMPLEMENT_DYNCREATE(CMyprintView, CView)

BEGIN_MESSAGE_MAP(CMyprintView, CView)
	//{{AFX_MSG_MAP(CMyprintView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyprintView construction/destruction

CMyprintView::CMyprintView()
{
	// TODO: add construction code here

}

CMyprintView::~CMyprintView()
{
}

BOOL CMyprintView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMyprintView drawing

void CMyprintView::OnDraw(CDC* pDC)
{
	CMyprintDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CMyprintView printing

BOOL CMyprintView::OnPreparePrinting(CPrintInfo* pInfo)
{
	delete pInfo->m_pPD;
	pInfo->m_pPD = new CMyPrintDialog(FALSE);
	return DoPreparePrinting(pInfo);
}

void CMyprintView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CMyprintView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CMyprintView diagnostics

#ifdef _DEBUG
void CMyprintView::AssertValid() const
{
	CView::AssertValid();
}

void CMyprintView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMyprintDoc* CMyprintView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMyprintDoc)));
	return (CMyprintDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMyprintView message handlers
