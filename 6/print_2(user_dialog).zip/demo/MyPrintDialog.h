#if !defined(AFX_MYPRINTDIALOG_H__1A9B4E00_6B86_11D3_A577_00E0189032F8__INCLUDED_)
#define AFX_MYPRINTDIALOG_H__1A9B4E00_6B86_11D3_A577_00E0189032F8__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// MyPrintDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMyPrintDialog dialog

class CMyPrintDialog : public CPrintDialog
{
	DECLARE_DYNAMIC(CMyPrintDialog)

public:
	CMyPrintDialog(BOOL bPrintSetupOnly,
		// TRUE for Print Setup, FALSE for Print Dialog
		DWORD dwFlags = PD_RETURNDC |PD_ALLPAGES | PD_USEDEVMODECOPIES | PD_ENABLEPRINTTEMPLATE, CWnd* pParentWnd = NULL);

protected:
	//{{AFX_MSG(CMyPrintDialog)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYPRINTDIALOG_H__1A9B4E00_6B86_11D3_A577_00E0189032F8__INCLUDED_)
