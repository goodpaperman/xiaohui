// myprintDoc.cpp : implementation of the CMyprintDoc class
//

#include "stdafx.h"
#include "myprint.h"

#include "myprintDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyprintDoc

IMPLEMENT_DYNCREATE(CMyprintDoc, CDocument)

BEGIN_MESSAGE_MAP(CMyprintDoc, CDocument)
	//{{AFX_MSG_MAP(CMyprintDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyprintDoc construction/destruction

CMyprintDoc::CMyprintDoc()
{
	// TODO: add one-time construction code here

}

CMyprintDoc::~CMyprintDoc()
{
}

BOOL CMyprintDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CMyprintDoc serialization

void CMyprintDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CMyprintDoc diagnostics

#ifdef _DEBUG
void CMyprintDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CMyprintDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMyprintDoc commands
