// MyPrintDialog.cpp : implementation file
//

#include "stdafx.h"
#include "myprint.h"
#include "MyPrintDialog.h"
#include <Dlgs.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyPrintDialog

IMPLEMENT_DYNAMIC(CMyPrintDialog, CPrintDialog)

CMyPrintDialog::CMyPrintDialog(BOOL bPrintSetupOnly, DWORD dwFlags, CWnd* pParentWnd) :
	CPrintDialog(bPrintSetupOnly, dwFlags, pParentWnd)
{
	m_pd.lpPrintTemplateName = (LPTSTR) MAKEINTRESOURCE(PRINTDLGORD);
	m_pd.Flags |= PD_ENABLEPRINTTEMPLATE;
	m_pd.hInstance = AfxGetInstanceHandle();
	AfxGetApp()->GetPrinterDeviceDefaults(&m_pd);
}


BEGIN_MESSAGE_MAP(CMyPrintDialog, CPrintDialog)
	//{{AFX_MSG_MAP(CMyPrintDialog)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

