//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by myprint.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_CUSTOM_PRINT                101
#define IDR_MAINFRAME                   128
#define IDR_MYPRINTYPE                  129
#define IDC_CHECK1                      1001
#define IDC_CHECK2                      1002
#define IDC_CHECK3                      1005
#define IDD_MYPRINT                     1547

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
