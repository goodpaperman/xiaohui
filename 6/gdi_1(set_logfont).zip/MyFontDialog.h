/************************************
  REVISION LOG ENTRY
  Revision By: Mihai Filimon
  Revised on 2/1/99 2:27:51 PM
  Comments: MyFontDialog.h : header file
 ************************************/

#if !defined(AFX_MYFONTDIALOG_H__F36D09A3_B8F5_11D2_8766_0040055C08D9__INCLUDED_)
#define AFX_MYFONTDIALOG_H__F36D09A3_B8F5_11D2_8766_0040055C08D9__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// 
//

/////////////////////////////////////////////////////////////////////////////
// CMyFontDialog dialog

class CMyFontDialog : public CFontDialog
{
	DECLARE_DYNAMIC(CMyFontDialog)

public:
	CMyFontDialog(LPLOGFONT lplfInitial = NULL,
		DWORD dwFlags = CF_EFFECTS | CF_SCREENFONTS,
		CDC* pdcPrinter = NULL,
		CWnd* pParentWnd = NULL);
#ifndef _AFX_NO_RICHEDIT_SUPPORT
	CMyFontDialog(const CHARFORMAT& charformat,
		DWORD dwFlags = CF_SCREENFONTS,
		CDC* pdcPrinter = NULL,
		CWnd* pParentWnd = NULL);
#endif

protected:
	static CString GetLong(long l);
	virtual CString GetCurrentFontAsString();
	CEdit m_edit;
	void operator = (LPCTSTR lpszNewText);
	virtual BOOL OnCommand( WPARAM wParam, LPARAM lParam );
	//{{AFX_MSG(CMyFontDialog)
	virtual BOOL OnInitDialog();
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYFONTDIALOG_H__F36D09A3_B8F5_11D2_8766_0040055C08D9__INCLUDED_)
