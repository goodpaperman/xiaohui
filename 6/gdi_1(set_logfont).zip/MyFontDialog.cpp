/************************************
  REVISION LOG ENTRY
  Revision By: Mihai Filimon
  Revised on 2/1/99 2:27:44 PM
  Comments: MyFontDialog.cpp : implementation file
 ************************************/

#include "stdafx.h"
#include "GetF.h"
#include "MyFontDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyFontDialog

IMPLEMENT_DYNAMIC(CMyFontDialog, CFontDialog)

CMyFontDialog::CMyFontDialog(LPLOGFONT lplfInitial, DWORD dwFlags, CDC* pdcPrinter, CWnd* pParentWnd) : 
	CFontDialog(lplfInitial, dwFlags, pdcPrinter, pParentWnd)
{
}


BEGIN_MESSAGE_MAP(CMyFontDialog, CFontDialog)
	//{{AFX_MSG_MAP(CMyFontDialog)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


#include <dlgs.h>
// Function name	: CMyFontDialog::OnInitDialog
// Description	    : 
// Return type		: BOOL 
BOOL CMyFontDialog::OnInitDialog() 
{
	CFontDialog::OnInitDialog();
	
	m_edit.Create(WS_BORDER | WS_CHILD | WS_VISIBLE | ES_MULTILINE | ES_CENTER, CRect(0,0,0,0), this, 0);
	m_edit.SetFont(GetFont());
	CRect rect; GetDlgItem(stc6)->GetWindowRect(rect);
	ScreenToClient(&rect);
	m_edit.MoveWindow(rect);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

// Function name	: = 
// Description	    : Just set the new text for edit.
// Return type		: void CMyFontDialog::operator 
// Argument         : LPCTSTR lpszNewText
void CMyFontDialog::operator = (LPCTSTR lpszNewText)
{
	ASSERT( m_edit.GetSafeHwnd() );
	m_edit.SetWindowText(lpszNewText);
}

// Function name	: CMyFontDialog::OnCommand
// Description	    : 
// Return type		: BOOL 
// Argument         :  WPARAM wParam
// Argument         : LPARAM lParam
BOOL CMyFontDialog::OnCommand( WPARAM wParam, LPARAM lParam )
{
	BOOL bResult = CFontDialog::OnCommand(wParam, lParam);
	if (LOWORD(wParam) != m_edit.GetDlgCtrlID())
		SetTimer(0, 100, NULL);
	return bResult;
}


CString CMyFontDialog::GetLong(long l)
{
	CString sResult;
	sResult.Format(_T("%i,"), l);
	return sResult;
}

// Function name	: CMyFontDialog::GetCurrentFontAsString
// Description	    : 
// Return type		: CString 
CString CMyFontDialog::GetCurrentFontAsString()
{
	LOGFONT logFont;
	GetCurrentFont(&logFont);
	CString sResult;
	sResult += GetLong(logFont.lfHeight);
	sResult += GetLong(logFont.lfWidth);
	sResult += GetLong(logFont.lfEscapement);
	sResult += GetLong(logFont.lfOrientation);
	sResult += GetLong(logFont.lfWeight);
	sResult += GetLong(logFont.lfItalic);
	sResult += GetLong(logFont.lfUnderline);
	sResult += GetLong(logFont.lfStrikeOut);
	sResult += GetLong(logFont.lfCharSet);
	sResult += GetLong(logFont.lfOutPrecision);
	sResult += GetLong(logFont.lfClipPrecision);
	sResult += GetLong(logFont.lfQuality);
	sResult += GetLong(logFont.lfPitchAndFamily);
	sResult += logFont.lfFaceName;
	return sResult;
}

// Function name	: CMyFontDialog::OnTimer
// Description	    : 
// Return type		: void 
// Argument         : UINT nIDEvent
void CMyFontDialog::OnTimer(UINT nIDEvent) 
{
	if (!nIDEvent)
	{
		*this = GetCurrentFontAsString();
		KillTimer(nIDEvent);
	}
	
	CFontDialog::OnTimer(nIDEvent);
}
