// TestRotDCView.cpp : implementation of the CTestRotDCView class
//

#include "stdafx.h"
#include "TestRotDC.h"

#include "TestRotDCDoc.h"
#include "TestRotDCView.h"

#include	"cdxCRot90DC.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestRotDCView

IMPLEMENT_DYNCREATE(CTestRotDCView, CView)

BEGIN_MESSAGE_MAP(CTestRotDCView, CView)
	//{{AFX_MSG_MAP(CTestRotDCView)
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestRotDCView construction/destruction

CTestRotDCView::CTestRotDCView()
{
	// TODO: add construction code here

}

CTestRotDCView::~CTestRotDCView()
{
}

BOOL CTestRotDCView::PreCreateWindow(CREATESTRUCT& cs)
{
	cs.style	|=	WS_CLIPCHILDREN;
	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CTestRotDCView drawing

/*
 * calls "DrawRot()" for each rectangle
 */

void CTestRotDCView::OnDraw(CDC* pDC)
{
	CTestRotDCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// get current client rect
	CRect	rectClient,rect;
	CSize	sz;
	GetClientRect(rectClient);

	//
	// create a normal memory device context
	//

	cdxCRot90DC	memDC(pDC,rectClient,0);
	COLORREF		ct	=	memDC.SetTextColor(RGB(160,0,0)),
					cb	=	memDC.GetBkColor();

	// fill with background (FillSolidRect() changes the bk color)
	// note that I've modified OnEraseBkGnd()
	memDC.FillSolidRect(rectClient,RGB(255,255,255));

	// draw header text
	CString	s	=	_T("This is an example on how to use cdxCRot90DC.\n"
							"It illustrates:\n"
							" a) How to use it as a replacement for a standard \"CMemDC\".\n"
							"    (member \"memDC\" in OnDraw()).\n"
							" b) How to use it to draw rotated stuff and how to re-use it.\n"
							"    Note that another function Draw() is used to perform the drawing.");

	rect	=	rectClient;
	int	i	=	memDC.DrawText(s,rect,DT_CALCRECT|DT_LEFT|DT_END_ELLIPSIS|DT_WORDBREAK);
	rect.top		+=	5;
	rect.bottom	=	rect.top + i;
	i	=	rect.Width();
	rect.left	=	rectClient.left + (rectClient.Width() - i) / 2;
	rect.right	=	rect.left + i;
	memDC.DrawText(s,rect,DT_LEFT|DT_END_ELLIPSIS|DT_WORDBREAK);

	//
	// some calculations to render my 4 rectangles
	//

	rectClient.top	=	rect.bottom + 5;
	sz	=	rectClient.Size();
	sz.cx	/=	5;
	sz.cy	/=	5;

	//
	// draw rotated rects
	//

	cdxCRot90DC	rotDC;

	// draw 0�

	rect		=	CRect(rectClient.left + 1*sz.cx,
							rectClient.top  + 1*sz.cy,
							rectClient.left + 2*sz.cx,
							rectClient.top  + 2*sz.cy);
	if(rotDC.Create(memDC,rect,0,true))
	{
		Draw(rotDC,rotDC);		// draw it
		rotDC.Finish();			// clip result into memory dc
	}
	memDC.DrawEdge(rect,EDGE_SUNKEN,BF_RECT);
//	memDC.TextOut(rect.left, rect.bottom + 2, _T("Angle 0�"));

	// draw 90�

	rect		=	CRect(rectClient.left + 3*sz.cx,
							rectClient.top  + 1*sz.cy,
							rectClient.left + 4*sz.cx,
							rectClient.top  + 2*sz.cy);
	if(rotDC.Create(memDC,rect,90,true))
	{
		Draw(rotDC,rotDC);
		rotDC.Finish();
	}
	memDC.DrawEdge(rect,EDGE_SUNKEN,BF_RECT);
//	memDC.TextOut(rect.left, rect.bottom + 2, _T("Angle 90�"));

	// draw 180�

	rect		=	CRect(rectClient.left + 1*sz.cx,
							rectClient.top  + 3*sz.cy,
							rectClient.left + 2*sz.cx,
							rectClient.top  + 4*sz.cy);
	if(rotDC.Create(memDC,rect,180,true))
	{
		Draw(rotDC,rotDC);
		rotDC.Finish();
	}
	memDC.DrawEdge(rect,EDGE_SUNKEN,BF_RECT);
//	memDC.TextOut(rect.left, rect.bottom + 2, _T("Angle 180�"));

	// draw 270�

	rect		=	CRect(rectClient.left + 3*sz.cx,
							rectClient.top  + 3*sz.cy,
							rectClient.left + 4*sz.cx,
							rectClient.top  + 4*sz.cy);
	if(rotDC.Create(memDC,rect,270,true))
	{
		Draw(rotDC,rotDC);
		rotDC.Finish();
	}
	memDC.DrawEdge(rect,EDGE_SUNKEN,BF_RECT);
//	memDC.TextOut(rect.left, rect.bottom + 2, _T("Angle 270�"));

	//
	// restore memory DC - Finish() is called by the destructor
	//
	memDC.SetTextColor(ct);
	memDC.SetBkColor(cb);
}

/*
 * draws into the rotated rect
 */

void CTestRotDCView::Draw(CDC *pDC, const CRect & rectDC)
{
	// draw some text

	CString	s	=	_T("Hello world");
	CSize		sz	=	pDC->GetTextExtent(s);
	pDC->TextOut(	rectDC.left + (rectDC.Width() - sz.cx) / 2,
						rectDC.top  + (rectDC.Height() - sz.cy) / 2,
						s);

	// draw an arrow

	CRect	rectArrow;
	rectArrow.top		=	rectDC.top  + (rectDC.Height() - sz.cy) / 2
								+ sz.cy + 4;
	rectArrow.bottom	=	rectArrow.top + 10;
	rectArrow.left		=	rectDC.left + (rectDC.Width() - 30) / 2;
	rectArrow.right	=	rectArrow.left + 30;

	pDC->MoveTo(rectArrow.right,(rectArrow.top + rectArrow.bottom) / 2);
	pDC->LineTo(rectArrow.left-1,(rectArrow.top + rectArrow.bottom) / 2);
	pDC->MoveTo(rectArrow.right,(rectArrow.top + rectArrow.bottom) / 2);
	pDC->LineTo(rectArrow.right-5,rectArrow.top);
	pDC->MoveTo(rectArrow.right,(rectArrow.top + rectArrow.bottom) / 2);
	pDC->LineTo(rectArrow.right-5,rectArrow.bottom);
}

/*
 * do nothing in erase background
 */

BOOL CTestRotDCView::OnEraseBkgnd(CDC* pDC) 
{
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CTestRotDCView diagnostics

#ifdef _DEBUG
void CTestRotDCView::AssertValid() const
{
	CView::AssertValid();
}

void CTestRotDCView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CTestRotDCDoc* CTestRotDCView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTestRotDCDoc)));
	return (CTestRotDCDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTestRotDCView message handlers


