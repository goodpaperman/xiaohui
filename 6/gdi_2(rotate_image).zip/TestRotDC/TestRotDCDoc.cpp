// TestRotDCDoc.cpp : implementation of the CTestRotDCDoc class
//

#include "stdafx.h"
#include "TestRotDC.h"

#include "TestRotDCDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestRotDCDoc

IMPLEMENT_DYNCREATE(CTestRotDCDoc, CDocument)

BEGIN_MESSAGE_MAP(CTestRotDCDoc, CDocument)
	//{{AFX_MSG_MAP(CTestRotDCDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestRotDCDoc construction/destruction

CTestRotDCDoc::CTestRotDCDoc()
{
	// TODO: add one-time construction code here

}

CTestRotDCDoc::~CTestRotDCDoc()
{
}

BOOL CTestRotDCDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CTestRotDCDoc serialization

void CTestRotDCDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CTestRotDCDoc diagnostics

#ifdef _DEBUG
void CTestRotDCDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CTestRotDCDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTestRotDCDoc commands
