// FontCombo.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFontCombo window

class CFontCombo : public CComboBox
{
// Construction
public:
	CFontCombo();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFontCombo)
	protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
	BYTE required_charset;
	virtual ~CFontCombo();
	static int CALLBACK EnumFontFamExProc(
		ENUMLOGFONTEX *lpelfe,	
		NEWTEXTMETRICEX *lpntme,	
		int FontType,	
		LPARAM lParam);


	// Generated message map functions
protected:
	//{{AFX_MSG(CFontCombo)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()

protected:
	// this class can be CObList for storing any font properties
	CStringList fontlist;
private:
	void ProcessFonts(void);
};

/////////////////////////////////////////////////////////////////////////////
