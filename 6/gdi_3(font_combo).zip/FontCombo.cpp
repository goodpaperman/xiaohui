// FontCombo.cpp : implementation file
//

#include "stdafx.h"
#include "FontCombo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFontCombo

CFontCombo::CFontCombo()
{
	required_charset = ANSI_CHARSET;
}

CFontCombo::~CFontCombo()
{
}


BEGIN_MESSAGE_MAP(CFontCombo, CComboBox)
	//{{AFX_MSG_MAP(CFontCombo)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFontCombo message handlers

void CFontCombo::ProcessFonts(void)
{
	LOGFONT lf;
	POSITION pos;

	lf.lfCharSet = required_charset;
	lf.lfFaceName[0]='\0';

	::EnumFontFamiliesEx( this->GetParent()->GetDC()->m_hDC, &lf, (FONTENUMPROC) CFontCombo::EnumFontFamExProc, (LPARAM) &fontlist, 0);
	this->ResetContent();
	for(pos = fontlist.GetHeadPosition(); pos != NULL;)
		this->AddString(fontlist.GetNext(pos));
}

int CALLBACK CFontCombo::EnumFontFamExProc(ENUMLOGFONTEX *lpelfe,NEWTEXTMETRICEX *lpntme,int FontType,LPARAM lParam)
{
	CStringList* m_temp = (CStringList*) lParam;
	m_temp->AddTail((char*)lpelfe->elfFullName);
	return 1; 	// I want to get all fonts
}

// this is only for subclassing
void CFontCombo::PreSubclassWindow() 
{
	this->ProcessFonts();
	CComboBox::PreSubclassWindow();
}
