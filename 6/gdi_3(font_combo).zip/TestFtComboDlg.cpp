// TestFtComboDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TestFtCombo.h"
#include "FontCombo.h"
#include "TestFtComboDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestFtComboDlg dialog

CTestFtComboDlg::CTestFtComboDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTestFtComboDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTestFtComboDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTestFtComboDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestFtComboDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTestFtComboDlg, CDialog)
	//{{AFX_MSG_MAP(CTestFtComboDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_CBN_SELCHANGE(IDC_COMBO1, OnSelchangeCombo1)
	ON_BN_CLICKED(ID_OK, OnOk)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestFtComboDlg message handlers

BOOL CTestFtComboDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// that's all
	m_fontcombo.SubclassDlgItem(IDC_COMBO1, this);
	
	fontname = "MS Sans Serif";

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTestFtComboDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CPaintDC dc(this);
		CFont font;
		CFont* oldfont;
		font.CreateFont(-20, 0, 0, 0, FW_DONTCARE, 0,0,0,DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,DEFAULT_PITCH|FF_ROMAN,fontname);
		oldfont = dc.SelectObject(&font);
		int mode = dc.SetBkMode(TRANSPARENT);
			// one
			dc.SetTextColor(RGB(0,0,0));
			dc.TextOut(22,102,fontname);
			// two
			dc.SetTextColor(RGB(255,255,255));
			dc.TextOut(20,100,fontname);
		dc.SelectObject(oldfont);
		dc.SetBkMode(mode);

		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTestFtComboDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CTestFtComboDlg::OnSelchangeCombo1() 
{
	GetDlgItem(IDC_COMBO1)->GetWindowText(this->fontname);
	InvalidateRect(&CRect(20,100,330,140));
}

void CTestFtComboDlg::OnOk() 
{
	CDialog::OnOK();	
}

void CTestFtComboDlg::OnOK()
{
	//
}

void CTestFtComboDlg::OnCancel()
{
	//
}
