// PageWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CBasicWnd window

class CBasicWnd : public CWnd
{
// Construction
public:
	CBasicWnd();

// Attributes
public:
  CBasicApp* m_pApp;

// Operations
public:
  BOOL Create();
 
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBasicWnd)
	protected:
	virtual void PostNcDestroy();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CBasicWnd();

	// Generated message map functions
protected:
	//{{AFX_MSG(CBasicWnd)
	afx_msg void OnActivateApp(BOOL bActive, HTASK hTask);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
