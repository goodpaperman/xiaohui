Basic DirectX + MFC game project template

When I wrote my first DirectX program, I didn't want to leave out the advantages of MFC.
So I was looking for a demo project which used both - DirectX and MFC.
Finally I have found one and I have modified it.
This project is suitable not only for games.
(Thanks to Brian Hughes)

The project contains 3 classes:

CBasicApp (derived from CWinApp)
CBasicWnd (derived from CWnd)
CGame (generic class - for the game)
