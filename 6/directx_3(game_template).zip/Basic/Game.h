// Game.h: interface for the CGame class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GAME_H__3F46C590_0C3A_11D2_BFFD_8AD580CF464A__INCLUDED_)
#define AFX_GAME_H__3F46C590_0C3A_11D2_BFFD_8AD580CF464A__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CGame  
{
public:
	CGame();
	virtual ~CGame();

  bool  Init();
  bool  UpdateFrame();
  void  Activate();
  bool  Finish();
};

#endif // !defined(AFX_GAME_H__3F46C590_0C3A_11D2_BFFD_8AD580CF464A__INCLUDED_)
