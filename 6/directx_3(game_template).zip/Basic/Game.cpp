// Game.cpp: implementation of the CGame class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "basic.h"
#include "Game.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGame::CGame()
{

}

CGame::~CGame()
{

}

//////////////////////////////////////////////////////////////////////

bool CGame::Init()
{

// HERE insert DirectDraw, DirectInput, DirectSound initialization

  AfxMessageBox("Game initialization");
  return true;
}

//////////////////////////////////////////////////////////////////////

bool CGame::UpdateFrame()
{

// HERE insert main game loop
// You should wait here for vertical blank

  AfxMessageBox("Game loop");
  return true;
}

//////////////////////////////////////////////////////////////////////

void CGame::Activate()
{

// HERE restore the screen

}

//////////////////////////////////////////////////////////////////////

bool CGame::Finish()
{

// HERE release all DirectX objects

  AfxMessageBox("Game over");
  return true;
}
