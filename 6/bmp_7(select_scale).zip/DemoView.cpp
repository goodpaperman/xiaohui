// DemoView.cpp : implementation of the CDemoView class
//

#include "stdafx.h"
#include "MultiRectTracker_Demo.h"

#include "DemoDoc.h"
#include "DemoView.h"
#include "MultiRectTracker.h"
#include "memDC.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDemoView

IMPLEMENT_DYNCREATE(CDemoView, CView)

BEGIN_MESSAGE_MAP(CDemoView, CView)
	//{{AFX_MSG_MAP(CDemoView)
	ON_WM_LBUTTONDOWN()
	ON_WM_SETCURSOR()
	ON_COMMAND(ID_DEMO_BMPFILE, OnDemoBmpfile)
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDemoView construction/destruction

CDemoView::CDemoView()
{
}


CDemoView::~CDemoView()
{
}

BOOL CDemoView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}


/////////////////////////////////////////////////////////////////////////////
// CDemoView drawing

void CDemoView::OnDraw(CDC* pDC)
{
	CMemDC memDC(pDC);
    
    CDemoDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here

    CRect rect;
    GetClientRect (rect);
    memDC.FillSolidRect(rect, RGB(255,255,255));
    // Classic drawing
    POSITION pos = pDoc->m_objects.GetTailPosition ();
    while (pos != NULL)
        ((CDemoObject*)(pDoc->m_objects.GetPrev (pos)))->Draw (&memDC);

    // Don't forget the multitrack
    multiTrack.Draw(&memDC);
}


/////////////////////////////////////////////////////////////////////////////
// CDemoView printing

BOOL CDemoView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CDemoView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CDemoView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CDemoView diagnostics

#ifdef _DEBUG
void CDemoView::AssertValid() const
{
	CView::AssertValid();
}

void CDemoView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CDemoDoc* CDemoView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDemoDoc)));
	return (CDemoDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDemoView message handlers

void CDemoView::OnLButtonDown(UINT nFlags, CPoint point) 
{
    CDemoDoc* pDoc = GetDocument();

    // Ask the multitrack if an object is already selected
    // or a handle. If not, start the local tracker.
    if (multiTrack.HitTest(point) < 0) {

        // Reset the multitrack only if there
        // is no CTRL key.
        if (!(nFlags & MK_CONTROL))
            multiTrack.RemoveAll();

		CRect rcObject;
        CDemoObject* pObject;

        // local tracker...
        CRectTracker tracker;
        if (tracker.TrackRubberBand(this, point, TRUE)) {

            // see if rubber band intersects with the objects
			CRect rectT;
			tracker.m_rect.NormalizeRect();
            POSITION pos = pDoc->m_objects.GetHeadPosition ();
            while (pos != NULL) {
                pObject = (CDemoObject*)(pDoc->m_objects.GetNext(pos));
                rcObject = pObject->GetRect();
                rectT.IntersectRect(tracker.m_rect, rcObject);
                if (rectT == rcObject) {
                    multiTrack.Add(pObject); // add it to the multitrack,
                                             // and continue the loop
                }
            }
        } else {
            // No rubber band, see if the point selects an object.
            POSITION pos = pDoc->m_objects.GetHeadPosition ();
            while (pos != NULL) {
                pObject = (CDemoObject*)(pDoc->m_objects.GetNext(pos));
                rcObject = pObject->GetRect();
                if (rcObject.PtInRect(point)) {
                    multiTrack.Add(pObject); // add just one object to the multitrack
                    break;
                }
            }

        }
    } else {
        // Click on the multitrack, forward actions to it.
        if (multiTrack.Track(this, point, FALSE))
            pDoc->SetModifiedFlag();
    }
    // Update drawing.
    Invalidate();
    UpdateWindow();

	CView::OnLButtonDown(nFlags, point);
}


BOOL CDemoView::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	// forward to multitracker
	if (pWnd == this && multiTrack.SetCursor(this, nHitTest))
		return TRUE;

	return CView::OnSetCursor(pWnd, nHitTest, message);
}



void CDemoView::OnDemoBmpfile() 
{
    CDemoDoc* pDoc = GetDocument();
    CFileDialog dlg (TRUE);
    if (dlg.DoModal () == IDOK) {
        if (dlg.GetFileExt () != "bmp" && 
            dlg.GetFileExt () != "BMP")
            return;
        pDoc->m_objects.AddTail(new CBmpDemoObj ( CRect (100,100,200,200), dlg.GetPathName() ));
    }
}

BOOL CDemoView::OnEraseBkgnd(CDC* pDC) 
{
	// TODO: Add your message handler code here and/or call default
	return TRUE;
	//return CView::OnEraseBkgnd(pDC);
}
