// DemoDoc.h : interface of the CDemoDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DEMODOC_H__6227880D_5EF6_11D3_9F79_AE25E9FEAB06__INCLUDED_)
#define AFX_DEMODOC_H__6227880D_5EF6_11D3_9F79_AE25E9FEAB06__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000



#include "MultiRectTracker.h"


////////////////////////////////////////////////////////////////////
// This is a demo object. As long as it contains CMRTObject in its
// base classes, the multitrack works. Change the Draw fct, datas, etc..
// If derived from CObject, the serialize capacities can be added.
//
class CDemoObject : public CMRTObject, public CObject
{
public:
    CDemoObject (COLORREF rgb)
        : CMRTObject(), m_color(rgb) {;}
    CDemoObject (LPCRECT lpSrcRect, COLORREF rgb)
    : CMRTObject(lpSrcRect), m_color(rgb) {;}

    ~CDemoObject () {;}

public:
    virtual void Draw (CDC* pDC) {
        pDC->FillSolidRect (GetRect(), m_color);
    }

protected:
    COLORREF m_color;
};

class CPictureDemoObj : public CDemoObject
{
public:
    CPictureDemoObj (COLORREF rgb, UINT nBitmap)
        : CDemoObject (rgb), m_nBitmap(nBitmap) {;}
    CPictureDemoObj (LPCRECT lpSrcRect, COLORREF rgb, UINT nBitmap)
        : CDemoObject (lpSrcRect, rgb), m_nBitmap(nBitmap) {;}

    virtual ~CPictureDemoObj () {;}

public:
    virtual void Draw (CDC* pDC) {
        if (m_nBitmap == 0) {
            pDC->FillSolidRect (GetRect(), m_color);
        } else {
            if (m_bitmap.m_hObject == NULL) {
                m_bitmap.LoadBitmap (m_nBitmap);
                BITMAP bm;
                m_bitmap.GetObject (sizeof (BITMAP), &bm);
                m_iBmpWidth = bm.bmWidth;
                m_iBmpHeight = bm.bmHeight;
            }

            CRect rc = GetRect();
            
            CDC dc;
            dc.CreateCompatibleDC (NULL);
            CBitmap* pOldBmp = dc.SelectObject (&m_bitmap);
            pDC->StretchBlt ( rc.left, rc.top, rc.Width(), rc.Height(),
                              &dc,
                              0,0,m_iBmpWidth, m_iBmpHeight,
                              SRCCOPY);
            dc.SelectObject (pOldBmp);
            dc.DeleteDC ();
        }
    }

protected:
    UINT        m_nBitmap;
    CBitmap     m_bitmap;
    int         m_iBmpWidth;
    int         m_iBmpHeight;
};


class CBmpDemoObj : public CDemoObject
{
public:
    CBmpDemoObj (LPCSTR szBmpFile)
        : CDemoObject (0), m_szBmpFile(szBmpFile) {;}
    CBmpDemoObj (LPCRECT lpSrcRect, LPCSTR szBmpFile)
        : CDemoObject (lpSrcRect, 0), m_szBmpFile(szBmpFile) {;}

    virtual ~CBmpDemoObj() {;}

public:
    virtual void Draw (CDC* pDC);

protected:
    CString     m_szBmpFile;
    CBitmap     m_bitmap;
    CPalette    m_palette;
    int         m_iBmpWidth;
    int         m_iBmpHeight;
};



class CDemoDoc : public CDocument
{
protected: // create from serialization only
	CDemoDoc();
	DECLARE_DYNCREATE(CDemoDoc)

// Attributes
public:
    CObList m_objects;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDemoDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDemoDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CDemoDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DEMODOC_H__6227880D_5EF6_11D3_9F79_AE25E9FEAB06__INCLUDED_)
