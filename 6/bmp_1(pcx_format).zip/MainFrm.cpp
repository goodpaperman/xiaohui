// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "PCXView.h"
#include "ChildFrm.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CMDIFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CMDIFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
   ON_COMMAND( ID_FILE_OPEN,           OnFileOpen )
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
}

CMainFrame::~CMainFrame()
{
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CMDIFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CMDIFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CMDIFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers
void CMainFrame::OnFileOpen()
{
   CFileDialog DlgFileOpen( true, "pcx", NULL,
                            OFN_PATHMUSTEXIST|OFN_LONGNAMES|OFN_HIDEREADONLY,
                            "PCX Files (*.pcx)|*.pcx||", this );
   if ( DlgFileOpen.DoModal() != IDOK )
      return;
   CString Filename = DlgFileOpen.GetPathName();

	// create a new MDI child window
   CChildFrame *pChild = new CChildFrame;
   pChild->Create( NULL, Filename );

   pChild->LoadPCX( Filename );
}