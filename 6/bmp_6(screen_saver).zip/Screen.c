#include <windows.h>
#include <scrnsave.h>
#include <string.h>
#include <io.h>

BOOL LocateTheBmp(char *);
BOOL LoadTheBmp(char *);
BITMAPINFOHEADER        *pMem, *pBit;
LPSTR   lpBit, lpMemTmp;
HPALETTE	hPalette;
struct _finddata_t     ff;
HANDLE	hFile;
HGLOBAL hGMem, hGMemMain;
HLOCAL  hLMem, hLMem1, hLMemMain;
HDC hDC;
PSTR pTmp, pPalette;

LRESULT WINAPI ScreenSaverProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
        static RECT re;
        static UINT uTimer;
        char lpstrBitName[400];
        char lpstrDirName[]="C:\\Screen\\";
        char BitWildCard[]="*.BMP";

        switch(message)
        {
                case WM_CREATE:
                        uTimer=SetTimer(hwnd, 1, 7000, NULL);
                        break;
                case WM_ERASEBKGND:
                        hDC=GetDC(hwnd);
                        GetClientRect(hwnd, &re);
                        FillRect(hDC, &re, GetStockObject(BLACK_BRUSH));
                        ReleaseDC(hwnd, hDC);
                        break;
                case WM_TIMER:
			strcpy(lpstrBitName, lpstrDirName);
			strcat(lpstrBitName, BitWildCard);
			if(!LocateTheBmp(&lpstrBitName))
				break;
			strcpy(lpstrBitName, lpstrDirName);
			strcat(lpstrBitName, ff.name);
			if(!LoadTheBmp(&lpstrBitName))
				break;
                        hDC=GetDC(hwnd);
			lpBit = GlobalLock(hGMem);
			pBit = LocalLock(hLMem1);
			GetClientRect(hwnd, &re);
                        SelectPalette(hDC, hPalette, FALSE);
			RealizePalette(hDC);
			
			SetDIBitsToDevice(hDC, 0, 0, pBit->biWidth, pBit->biHeight,
					0, 0, 0, pBit->biHeight, lpBit, pBit, DIB_RGB_COLORS);
                        GetClientRect(hwnd, &re);
                        ReleaseDC(hwnd, hDC);
			GlobalFree(hGMem);
			LocalFree(hLMem);
			DeleteObject(hPalette);
                        break;
                case WM_DESTROY:
                        if(uTimer)
                                KillTimer(hwnd, uTimer);
                        break;
                default:
                        return (DefScreenSaverProc(hwnd, message, wParam, lParam));
        }
        return 0;
}

BOOL WINAPI ScreenSaverConfigureDialog(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
        return TRUE;
}

BOOL WINAPI RegisterDialogClasses(HANDLE hInst)
{
        return TRUE;
}

BOOL	LoadTheBmp(char *lpstrBitName)
{
	LPSTR	lpTmp;
	HANDLE	hFile;
	WORD	i, T;
	char bTemp, bTemp1;
	OFSTRUCT of;
	DWORD	TmpDVal, dwRead;
	BITMAPFILEHEADER	bHdr;

	hFile = OpenFile(lpstrBitName, &of, OF_READ);
    
	ReadFile(hFile, &bHdr, sizeof(BITMAPFILEHEADER), &dwRead, NULL);
	if(bHdr.bfType != 'MB'){
		CloseHandle(hFile);
		return FALSE;
	}
//Now Allocate for the colors & info header with space for 0 to bfOffBits-1 bytes
	if (!(hLMem = LocalAlloc(LMEM_MOVEABLE, bHdr.bfOffBits-sizeof(BITMAPFILEHEADER)))){
		CloseHandle(hFile);
		return FALSE;
	}
	if (!(hLMem1 = LocalAlloc(LMEM_MOVEABLE, bHdr.bfOffBits-sizeof(BITMAPFILEHEADER)))){
		LocalFree(hLMem);
		CloseHandle(hFile);
		return FALSE;
	}
	pMem = LocalLock(hLMem);
	ReadFile(hFile, pMem, sizeof(BITMAPINFOHEADER), &dwRead, NULL);
//Allocate for the data bits
	if (!(hGMem = GlobalAlloc(GMEM_MOVEABLE, pMem->biSizeImage+1))){
		LocalFree(hLMem);
		LocalFree(hLMem1);
		CloseHandle(hFile);
		return FALSE;
	}
        pBit = LocalLock(hLMem1);
        lpBit = GlobalLock(hGMem);
	hLMemMain = hLMem1;
	hGMemMain = hGMem;
	if(pMem->biSize != sizeof(BITMAPINFOHEADER)){
		LocalFree(hLMem);
		LocalFree(hLMem1);
		GlobalFree(hGMem);
		CloseHandle(hFile);
		return FALSE;
	}
//Read num colors * 4 bytes into memory
        T = (1 << ((pMem->biBitCount) != 24 ? pMem->biBitCount:16));
	if(pMem->biClrUsed)
    	T = pMem->biClrUsed;
	if((pMem->biBitCount) != 24){
		ReadFile(hFile, (char near *)pMem+sizeof(BITMAPINFOHEADER), T*4, &dwRead, NULL);
	}
        memcpy(pBit, pMem, bHdr.bfOffBits-sizeof(BITMAPFILEHEADER));
        lpTmp = lpBit;
//      _hread(hFile, lpBit, pMem->biSizeImage+1);
        ReadFile(hFile, lpBit, pMem->biSizeImage+1, &dwRead, NULL);
	CloseHandle(hFile);
// Now init the palette for palette creation
	pTmp = (char near *)pMem+sizeof(BITMAPINFOHEADER);
	pPalette = pTmp - 4;
        hPalette=0;
	if(T){		//T is number of palette colors, 0 for 24-bit
		for(i=0 ; i < T ; i++){
			bTemp = *pTmp;
			bTemp1 = *(pTmp+2);
			*pTmp = bTemp1;
			*(pTmp+2) = bTemp;
			*(pTmp+3) = 0;
			pTmp += 4;
		}
		__asm MOV EBX, pPalette
		__asm MOV Word Ptr [EBX], 300h
		__asm MOV AX, T
		__asm MOV Word Ptr [EBX][2], AX
		hPalette = CreatePalette((LOGPALETTE *)pPalette);
	}
	LocalFree(hLMem);
	GlobalUnlock(hGMem);
	LocalUnlock(hLMem1);
	return TRUE;
}

BOOL LocateTheBmp(char *lpstrBitName)
{
	static long hBitFind;
	static BOOL foundfirst;

	if(!foundfirst){
		if((hBitFind=_findfirst(lpstrBitName, &ff))==-1){
//			_findclose(hBitFind);
//			if((hBitFind=_findfirst(lpstrBitName, &ff))==-1)
			return FALSE;
        	}
		else
			foundfirst=TRUE;
	}
	else{
		if((_findnext(hBitFind, &ff))==-1){
			_findclose(hBitFind);
			if((hBitFind=_findfirst(lpstrBitName, &ff))==-1)
				return FALSE;
        	}
		
	}
	


	return TRUE;
}
