// FileAlarmDoc.cpp : Implementierung der Klasse CFileAlarmDoc
//

#include "stdafx.h"
#include "FileAlarm.h"
#include "MainFrm.h"
#include "FileAlarmDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFileAlarmDoc

IMPLEMENT_DYNCREATE(CFileAlarmDoc, CDocument)

BEGIN_MESSAGE_MAP(CFileAlarmDoc, CDocument)
	//{{AFX_MSG_MAP(CFileAlarmDoc)
		// HINWEIS - Hier werden Mapping-Makros vom Klassen-Assistenten eingef�gt und entfernt.
		//    Innerhalb dieser generierten Quelltextabschnitte NICHTS VER�NDERN!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFileAlarmDoc Konstruktion/Destruktion

CFileAlarmDoc::CFileAlarmDoc()
{
	// ZU ERLEDIGEN: Hier Code f�r One-Time-Konstruktion einf�gen

}

CFileAlarmDoc::~CFileAlarmDoc()
{
}

BOOL CFileAlarmDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// ZU ERLEDIGEN: Hier Code zur Reinitialisierung einf�gen
	// (SDI-Dokumente verwenden dieses Dokument)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CFileAlarmDoc Serialisierung

void CFileAlarmDoc::Serialize(CArchive& ar)
{
	// CEditView enth�lt ein Edit-Steuerelement, das die Serialisierung automatisch erledigt
	((CEditView*)m_viewList.GetHead())->SerializeRaw(ar);
}

/////////////////////////////////////////////////////////////////////////////
// CFileAlarmDoc Diagnose

#ifdef _DEBUG
void CFileAlarmDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CFileAlarmDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CFileAlarmDoc Befehle


BOOL CFileAlarmDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{
	if (!CDocument::OnOpenDocument(lpszPathName))
		return FALSE;

	//save the filename
	m_strPathName=lpszPathName;
	//start the watch
	WatchStart();

	return TRUE;
}

UINT CFileAlarmDoc::FileChangeWatch(LPVOID lpParam)
{
	CFileAlarmDoc* pDoc=(CFileAlarmDoc*)lpParam;
	ASSERT(pDoc);

	//open the docfile
	CFile* pFile = pDoc->GetFile(pDoc->GetPathName(),CFile::modeRead|CFile::shareDenyWrite,NULL);	
	ASSERT(pFile);
	if(pFile)
	{
		//save the last write time
		FILETIME ftLastWriteTime;
		BY_HANDLE_FILE_INFORMATION fileinfo;
		if(!GetFileInformationByHandle((HANDLE)pFile->m_hFile,&fileinfo))
			return 0;
		ftLastWriteTime=fileinfo.ftLastWriteTime;
		pDoc->ReleaseFile(pFile,FALSE);	

		//determine the path
		char path[_MAX_PATH];
		_splitpath(pDoc->GetPathName(), NULL, path, NULL, NULL);
					
		
		//endless...
		while(1)
		{
			//get file notify event
			HANDLE hFileChanged=FindFirstChangeNotification(path,FALSE,FILE_NOTIFY_CHANGE_LAST_WRITE | FILE_NOTIFY_CHANGE_SIZE | FILE_NOTIFY_CHANGE_FILE_NAME);
						
			//wait for file changes and stop from the doc
			HANDLE hWaitEvents[]={pDoc->m_evStopWatch,hFileChanged};
	
			//wait....
			DWORD dwResult=WaitForMultipleObjects(2,hWaitEvents,FALSE,INFINITE);
			FindCloseChangeNotification(hFileChanged);	
			
			if(dwResult==WAIT_OBJECT_0+1)
			{
				//any file in the directory changed?					

				//retrieve docfiles write time
				pFile = pDoc->GetFile(pDoc->GetPathName(),CFile::modeRead|CFile::shareDenyWrite,NULL);	
				//ASSERT(pFile);
				if(pFile)
				{
					if(GetFileInformationByHandle((HANDLE)pFile->m_hFile, &fileinfo))
					{
						//detect if changes made
						if((ftLastWriteTime.dwHighDateTime+ftLastWriteTime.dwLowDateTime)!=(fileinfo.ftLastWriteTime.dwHighDateTime+fileinfo.ftLastWriteTime.dwLowDateTime))
							pDoc->OnFileAlarm(FA_WRITTEN);//do alarm

						//resave last time
						ftLastWriteTime=fileinfo.ftLastWriteTime;
					}
					pDoc->ReleaseFile(pFile,FALSE);
				}
				else
				{
					pDoc->OnFileAlarm(FA_FILELOST);//do alarm
				}

			}
			else
				break;
			
		}
			
		
	}
	return 0;
}

BOOL CFileAlarmDoc::OnSaveDocument(LPCTSTR lpszPathName) 
{
	//stop watching
	WatchStop();

	BOOL bRet=CDocument::OnSaveDocument(lpszPathName);
	
	//start watching
	WatchStart();
	return bRet;
}

void CFileAlarmDoc::OnCloseDocument() 
{
	//stop watching
	WatchStop();

	CDocument::OnCloseDocument();
}

void CFileAlarmDoc::OnFileAlarm(short nCause)
{
	//alarm
	MessageBeep(MB_ICONEXCLAMATION);

	//if the mainwindow haven't the focus then
	//flash the icon until mainwindow became focus
	CMainFrame* pwndMain=(CMainFrame*)AfxGetApp()->GetMainWnd();	
	ASSERT(pwndMain);
	if(!pwndMain->IsWindowVisible())
		pwndMain->FlashUntilFocus();

	//bring first view to top
	CView* pView=(CView*)m_viewList.GetHead();
	pwndMain->MDIActivate(pView->GetParent());

	
	//implement further code....

	
	//inform user
	CString sMsg=_T("");
	switch(nCause)
	{
	case FA_WRITTEN:
		AfxMessageBox("file changed");		
		WatchStart();	
		break;
	case FA_FILELOST:
		AfxMessageBox("file deleted/moved");
		break;
	}	
	
	
	
}	

//Start the watching thread
void CFileAlarmDoc::WatchStart()
{
	m_evStopWatch.ResetEvent();
	AfxBeginThread(FileChangeWatch,(LPVOID)this);	
}

//Stop the watching thread
void CFileAlarmDoc::WatchStop()
{
	m_evStopWatch.SetEvent();
}
