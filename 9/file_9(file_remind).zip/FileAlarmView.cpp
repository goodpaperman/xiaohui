// FileAlarmView.cpp : Implementierung der Klasse CFileAlarmView
//

#include "stdafx.h"
#include "FileAlarm.h"

#include "FileAlarmDoc.h"
#include "FileAlarmView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFileAlarmView

IMPLEMENT_DYNCREATE(CFileAlarmView, CEditView)

BEGIN_MESSAGE_MAP(CFileAlarmView, CEditView)
	//{{AFX_MSG_MAP(CFileAlarmView)
		// HINWEIS - Hier werden Mapping-Makros vom Klassen-Assistenten eingef�gt und entfernt.
		//    Innerhalb dieser generierten Quelltextabschnitte NICHTS VER�NDERN!
	//}}AFX_MSG_MAP
	// Standard-Druckbefehle
	ON_COMMAND(ID_FILE_PRINT, CEditView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CEditView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CEditView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFileAlarmView Konstruktion/Destruktion

CFileAlarmView::CFileAlarmView()
{
	// ZU ERLEDIGEN: Hier Code zur Konstruktion einf�gen,

}

CFileAlarmView::~CFileAlarmView()
{
}

BOOL CFileAlarmView::PreCreateWindow(CREATESTRUCT& cs)
{
	// ZU ERLEDIGEN: �ndern Sie hier die Fensterklasse oder das Erscheinungsbild, indem Sie
	//  CREATESTRUCT cs modifizieren.

	BOOL bPreCreated = CEditView::PreCreateWindow(cs);
	cs.style &= ~(ES_AUTOHSCROLL|WS_HSCROLL);	// Automatischen Wortumbruch aktivieren

	return bPreCreated;
}

/////////////////////////////////////////////////////////////////////////////
// CFileAlarmView Zeichnen

void CFileAlarmView::OnDraw(CDC* pDC)
{
	CFileAlarmDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// ZU ERLEDIGEN: Hier Code zum Zeichnen der urspr�nglichen Daten hinzuf�gen
}

/////////////////////////////////////////////////////////////////////////////
// CFileAlarmView Drucken

BOOL CFileAlarmView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// Standard-CEditView-Vorbereitung
	return CEditView::OnPreparePrinting(pInfo);
}

void CFileAlarmView::OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo)
{
	// Standard-CEditView Beginn des Druckens.
	CEditView::OnBeginPrinting(pDC, pInfo);
}

void CFileAlarmView::OnEndPrinting(CDC* pDC, CPrintInfo* pInfo)
{
	// Standard-CEditView Ende des Druckens
	CEditView::OnEndPrinting(pDC, pInfo);
}

/////////////////////////////////////////////////////////////////////////////
// CFileAlarmView Diagnose

#ifdef _DEBUG
void CFileAlarmView::AssertValid() const
{
	CEditView::AssertValid();
}

void CFileAlarmView::Dump(CDumpContext& dc) const
{
	CEditView::Dump(dc);
}

CFileAlarmDoc* CFileAlarmView::GetDocument() // Die endg�ltige (nicht zur Fehlersuche kompilierte) Version ist Inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CFileAlarmDoc)));
	return (CFileAlarmDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CFileAlarmView Nachrichten-Handler

