// FileAlarmView.h : Schnittstelle der Klasse CFileAlarmView
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_FILEALARMVIEW_H__EC63591E_F947_11D2_B3F8_0000E84C63B1__INCLUDED_)
#define AFX_FILEALARMVIEW_H__EC63591E_F947_11D2_B3F8_0000E84C63B1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CFileAlarmView : public CEditView
{
protected: // Nur aus Serialisierung erzeugen
	CFileAlarmView();
	DECLARE_DYNCREATE(CFileAlarmView)

// Attribute
public:
	CFileAlarmDoc* GetDocument();

// Operationen
public:

// �berladungen
	// Vom Klassenassistenten generierte �berladungen virtueller Funktionen
	//{{AFX_VIRTUAL(CFileAlarmView)
	public:
	virtual void OnDraw(CDC* pDC);  // �berladen zum Zeichnen dieser Ansicht
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementierung
public:
	virtual ~CFileAlarmView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generierte Message-Map-Funktionen
protected:
	//{{AFX_MSG(CFileAlarmView)
		// HINWEIS - An dieser Stelle werden Member-Funktionen vom Klassen-Assistenten eingef�gt und entfernt.
		//    Innerhalb dieser generierten Quelltextabschnitte NICHTS VER�NDERN!
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // Testversion in FileAlarmView.cpp
inline CFileAlarmDoc* CFileAlarmView::GetDocument()
   { return (CFileAlarmDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // !defined(AFX_FILEALARMVIEW_H__EC63591E_F947_11D2_B3F8_0000E84C63B1__INCLUDED_)
