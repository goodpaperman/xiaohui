// VersionAppDemoDoc.cpp : Implementierung der Klasse CVersionAppDemoDoc
//

#include "stdafx.h"
#include "VersionAppDemo.h"

#include "VersionAppDemoDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CVersionAppDemoDoc

IMPLEMENT_DYNCREATE(CVersionAppDemoDoc, CDocument)

BEGIN_MESSAGE_MAP(CVersionAppDemoDoc, CDocument)
	//{{AFX_MSG_MAP(CVersionAppDemoDoc)
		// HINWEIS - Hier werden Mapping-Makros vom Klassen-Assistenten eingef�gt und entfernt.
		//    Innerhalb dieser generierten Quelltextabschnitte NICHTS VER�NDERN!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CVersionAppDemoDoc Konstruktion/Destruktion

CVersionAppDemoDoc::CVersionAppDemoDoc()
{
	// ZU ERLEDIGEN: Hier Code f�r One-Time-Konstruktion einf�gen

}

CVersionAppDemoDoc::~CVersionAppDemoDoc()
{
}

BOOL CVersionAppDemoDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// ZU ERLEDIGEN: Hier Code zur Reinitialisierung einf�gen
	// (SDI-Dokumente verwenden dieses Dokument)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CVersionAppDemoDoc Serialisierung

void CVersionAppDemoDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// ZU ERLEDIGEN: Hier Code zum Speichern einf�gen
	}
	else
	{
		// ZU ERLEDIGEN: Hier Code zum Laden einf�gen
	}
}

/////////////////////////////////////////////////////////////////////////////
// CVersionAppDemoDoc Diagnose

#ifdef _DEBUG
void CVersionAppDemoDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CVersionAppDemoDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CVersionAppDemoDoc Befehle
