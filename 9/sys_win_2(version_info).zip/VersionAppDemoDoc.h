// VersionAppDemoDoc.h : Schnittstelle der Klasse CVersionAppDemoDoc
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_VERSIONAPPDEMODOC_H__337FB95E_5F06_11D3_9EB9_0000E87CD125__INCLUDED_)
#define AFX_VERSIONAPPDEMODOC_H__337FB95E_5F06_11D3_9EB9_0000E87CD125__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CVersionAppDemoDoc : public CDocument
{
protected: // Nur aus Serialisierung erzeugen
	CVersionAppDemoDoc();
	DECLARE_DYNCREATE(CVersionAppDemoDoc)

// Attribute
public:

// Operationen
public:

// �berladungen
	// Vom Klassenassistenten generierte �berladungen virtueller Funktionen
	//{{AFX_VIRTUAL(CVersionAppDemoDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementierung
public:
	virtual ~CVersionAppDemoDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generierte Message-Map-Funktionen
protected:
	//{{AFX_MSG(CVersionAppDemoDoc)
		// HINWEIS - An dieser Stelle werden Member-Funktionen vom Klassen-Assistenten eingef�gt und entfernt.
		//    Innerhalb dieser generierten Quelltextabschnitte NICHTS VER�NDERN!
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // !defined(AFX_VERSIONAPPDEMODOC_H__337FB95E_5F06_11D3_9EB9_0000E87CD125__INCLUDED_)
