// VersionAppDemo.h : Haupt-Header-Datei f�r die Anwendung VERSIONAPPDEMO
//

#if !defined(AFX_VERSIONAPPDEMO_H__337FB958_5F06_11D3_9EB9_0000E87CD125__INCLUDED_)
#define AFX_VERSIONAPPDEMO_H__337FB958_5F06_11D3_9EB9_0000E87CD125__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // Hauptsymbole
#include "VersionApp.h"
/////////////////////////////////////////////////////////////////////////////
// CVersionAppDemoApp:
// Siehe VersionAppDemo.cpp f�r die Implementierung dieser Klasse
//

class CVersionAppDemoApp : public CVersionApp
{
public:
	CVersionAppDemoApp();

// �berladungen
	// Vom Klassenassistenten generierte �berladungen virtueller Funktionen
	//{{AFX_VIRTUAL(CVersionAppDemoApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementierung
	//{{AFX_MSG(CVersionAppDemoApp)
	afx_msg void OnAppAbout();
		// HINWEIS - An dieser Stelle werden Member-Funktionen vom Klassen-Assistenten eingef�gt und entfernt.
		//    Innerhalb dieser generierten Quelltextabschnitte NICHTS VER�NDERN!
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // !defined(AFX_VERSIONAPPDEMO_H__337FB958_5F06_11D3_9EB9_0000E87CD125__INCLUDED_)
