// VersionAppDemoView.cpp : Implementierung der Klasse CVersionAppDemoView
//

#include "stdafx.h"
#include "VersionAppDemo.h"

#include "VersionAppDemoDoc.h"
#include "VersionAppDemoView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CVersionAppDemoView

IMPLEMENT_DYNCREATE(CVersionAppDemoView, CView)

BEGIN_MESSAGE_MAP(CVersionAppDemoView, CView)
	//{{AFX_MSG_MAP(CVersionAppDemoView)
		// HINWEIS - Hier werden Mapping-Makros vom Klassen-Assistenten eingef�gt und entfernt.
		//    Innerhalb dieser generierten Quelltextabschnitte NICHTS VER�NDERN!
	//}}AFX_MSG_MAP
	// Standard-Druckbefehle
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CVersionAppDemoView Konstruktion/Destruktion

CVersionAppDemoView::CVersionAppDemoView()
{
	// ZU ERLEDIGEN: Hier Code zur Konstruktion einf�gen,

}

CVersionAppDemoView::~CVersionAppDemoView()
{
}

BOOL CVersionAppDemoView::PreCreateWindow(CREATESTRUCT& cs)
{
	// ZU ERLEDIGEN: �ndern Sie hier die Fensterklasse oder das Erscheinungsbild, indem Sie
	//  CREATESTRUCT cs modifizieren.

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CVersionAppDemoView Zeichnen

void CVersionAppDemoView::OnDraw(CDC* pDC)
{
	CVersionAppDemoDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// ZU ERLEDIGEN: Hier Code zum Zeichnen der urspr�nglichen Daten hinzuf�gen
}

/////////////////////////////////////////////////////////////////////////////
// CVersionAppDemoView Drucken

BOOL CVersionAppDemoView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// Standardvorbereitung
	return DoPreparePrinting(pInfo);
}

void CVersionAppDemoView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// ZU ERLEDIGEN: Zus�tzliche Initialisierung vor dem Drucken hier einf�gen
}

void CVersionAppDemoView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// ZU ERLEDIGEN: Hier Bereinigungsarbeiten nach dem Drucken einf�gen
}

/////////////////////////////////////////////////////////////////////////////
// CVersionAppDemoView Diagnose

#ifdef _DEBUG
void CVersionAppDemoView::AssertValid() const
{
	CView::AssertValid();
}

void CVersionAppDemoView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CVersionAppDemoDoc* CVersionAppDemoView::GetDocument() // Die endg�ltige (nicht zur Fehlersuche kompilierte) Version ist Inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CVersionAppDemoDoc)));
	return (CVersionAppDemoDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CVersionAppDemoView Nachrichten-Handler
