// Project: D:\dev\where\where.dsp.  DO NOT MODIFY THIS FILE BY HAND.
//
#define BUILDNUM_ENABLED (1)
#define MODIFY_VERSIONINFO (1)
#define FILE_VERSION0 (1)
#define FILE_VERSION1 (0)
#define FILE_VERSION2 (0)
#define BUILD_NUMBER (9)
