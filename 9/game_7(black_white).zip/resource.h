//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by myothello.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define ID_CHESSBOARD                   101
#define IDD_MYOTHELLO_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDB_BLACKCHESS                  131
#define IDB_WHITECHESS                  132
#define IDB_CHESSBOARD                  133
#define IDR_MENU1                       134
#define IDB_TURN1                       135
#define IDB_TURN2                       136
#define IDB_TURN3                       137
#define IDB_TURN4                       138
#define IDB_TURN5                       139
#define IDB_TURN6                       140
#define IDB_XIAOYAO                     146
#define IDC_STATUS                      1002
#define ID_NEWGAME                      32774
#define ID_EASY                         32776
#define ID_MID                          32777
#define ID_ADV                          32778
#define IDC_BUTTON1                     32779
#define ID_MOVEBACK                     32780

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        148
#define _APS_NEXT_COMMAND_VALUE         32785
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
