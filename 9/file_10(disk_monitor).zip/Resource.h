//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DiskSpace.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_DISKSPACE_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDC_INTERVAL                    1000
#define IDC_CURRENT                     1001
#define IDC_LOW                         1002
#define IDC_HIGH                        1003
#define IDC_ACTION                      1004
#define IDC_UNC                         1006
#define IDC_CURRENT_KB                  1007
#define IDC_LOW_KB                      1008
#define IDC_HIGH_KB                     1009
#define IDC_CURRENT_MB                  1010
#define IDC_LOW_MB                      1011
#define IDC_HIGH_MB                     1012
#define IDC_STAYONTOP                   1013
#define IDC_LOOPTIME                    1015

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
