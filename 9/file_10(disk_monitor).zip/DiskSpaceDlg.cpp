// DiskSpaceDlg.cpp : implementation file
//

#include "stdafx.h"
#include "DiskSpace.h"
#include "DiskSpaceDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static NUMBERFMT nFmt = { 0, 0, 3, ",", ".", 0 };

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDiskSpaceDlg dialog

CDiskSpaceDlg::CDiskSpaceDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDiskSpaceDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDiskSpaceDlg)
	m_dInterval = 0.0;
	m_strUNC = _T("");
	m_bStayOnTop = FALSE;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_bRunning = false;
}

void CDiskSpaceDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDiskSpaceDlg)
	DDX_Control(pDX, IDC_ACTION, m_btnAction);
	DDX_Text(pDX, IDC_INTERVAL, m_dInterval);
	DDV_MinMaxDouble(pDX, m_dInterval, 1.e-003, 99.99);
	DDX_Text(pDX, IDC_UNC, m_strUNC);
	DDX_Check(pDX, IDC_STAYONTOP, m_bStayOnTop);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CDiskSpaceDlg, CDialog)
	//{{AFX_MSG_MAP(CDiskSpaceDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_ACTION, OnAction)
	ON_WM_TIMER()
	ON_EN_KILLFOCUS(IDC_INTERVAL, OnKillfocusInterval)
	ON_EN_KILLFOCUS(IDC_UNC, OnKillfocusUnc)
	ON_BN_CLICKED(IDC_STAYONTOP, OnStayontop)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDiskSpaceDlg message handlers

BOOL CDiskSpaceDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	OnStayontop();		// Activate Z-Order
	OnKillfocusUnc();	// Initialize some variables
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CDiskSpaceDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CDiskSpaceDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CDiskSpaceDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

// From here on most code added. Stuff above is mostly AppWizard

void CDiskSpaceDlg::OnCancel() 
{
	// Prevent erroneous (does one spell it like that?) closure
	// CDialog::OnCancel();
}

void CDiskSpaceDlg::OnStayontop() 
{
	UpdateData(TRUE);
	SetWindowPos(m_bStayOnTop ? &CWnd::wndTopMost : &CWnd::wndNoTopMost,
				 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
}

void CDiskSpaceDlg::DoTimer()
{
	UINT nInterval = (UINT)(m_dInterval * 1000.0);
	if (m_bRunning)
		m_nTimer = SetTimer(1, nInterval, 0);
	else
		KillTimer(1);
}

void CDiskSpaceDlg::OnAction() 
{
	m_bRunning = !m_bRunning;
	m_btnAction.SetWindowText(m_bRunning ? "&Stop" : "&Start");
	DoTimer();
}

void CDiskSpaceDlg::OnKillfocusInterval() 
{
	UpdateData(TRUE);
	DoTimer();
}

void CDiskSpaceDlg::OnKillfocusUnc() 
{
	UpdateData(TRUE);
	m_iCurrent = m_iHigh = 0;
	m_iLow     = _UI64_MAX;
}

void CDiskSpaceDlg::UpdateCounters(UINT nID, UINT nIDKB, UINT nIDMB)
{
	TCHAR szVal[35];
	TCHAR szOut[35];

	// # bytes
	_i64toa(m_iCurrent, szVal, 10);
	GetNumberFormat(NULL, NULL, szVal, &nFmt, szOut, 32);
 	SetDlgItemText(nID, szOut);

	// # kb
	_i64toa(m_iCurrent / 1024, szVal, 10);
	GetNumberFormat(NULL, NULL, szVal, &nFmt, szOut, 32);
 	SetDlgItemText(nIDKB, szOut);

	// # Mb
	_i64toa(m_iCurrent / 1024 / 1024, szVal, 10);
	GetNumberFormat(NULL, NULL, szVal, &nFmt, szOut, 32);
 	SetDlgItemText(nIDMB, szOut);
}

void CDiskSpaceDlg::OnTimer(UINT nIDEvent) 
{
	// Get disk space and continue if no changes
	ULARGE_INTEGER ulAvailable, ulTotal, ulFree;
	GetDiskFreeSpaceEx((LPCTSTR)m_strUNC, &ulAvailable, &ulTotal, &ulFree);
	if (m_iCurrent == ulAvailable.QuadPart && m_iCurrent != 0) return;

	// Update screen
	m_iCurrent = ulAvailable.QuadPart;
	UpdateCounters(IDC_CURRENT, IDC_CURRENT_KB, IDC_CURRENT_MB);
	if (m_iLow == 0 || m_iCurrent < m_iLow)
	{
		m_iLow = m_iCurrent;
		UpdateCounters(IDC_LOW, IDC_LOW_KB, IDC_LOW_MB);
	}
	if (m_iHigh == 0 || m_iCurrent > m_iHigh)
	{
		m_iHigh = m_iCurrent;
		UpdateCounters(IDC_HIGH, IDC_HIGH_KB, IDC_HIGH_MB);
	}
	FlashWindow(TRUE);
}
