// DiskSpaceDlg.h : header file
//

#if !defined(AFX_DISKSPACEDLG_H__338D5405_07B6_11D3_861E_00105A2DFCCD__INCLUDED_)
#define AFX_DISKSPACEDLG_H__338D5405_07B6_11D3_861E_00105A2DFCCD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CDiskSpaceDlg dialog

class CDiskSpaceDlg : public CDialog
{
// Construction
public:
	CDiskSpaceDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CDiskSpaceDlg)
	enum { IDD = IDD_DISKSPACE_DIALOG };
	CButton	m_btnAction;
	double	m_dInterval;
	CString	m_strUNC;
	BOOL	m_bStayOnTop;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDiskSpaceDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	UINT m_nTimer;
	bool m_bRunning;
	unsigned __int64 m_iHigh;
	unsigned __int64 m_iLow;
	unsigned __int64 m_iCurrent;

	void DoTimer();
	void UpdateCounters(UINT nID, UINT nIDKB, UINT nIDMB);
	
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CDiskSpaceDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnAction();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnKillfocusInterval();
	afx_msg void OnKillfocusUnc();
	afx_msg void OnStayontop();
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DISKSPACEDLG_H__338D5405_07B6_11D3_861E_00105A2DFCCD__INCLUDED_)
