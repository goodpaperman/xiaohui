// WindowStylerDlg.cpp : implementation file
//
/////////////////////////////////////////////////////////////////////////////
// Copyright (C) 1998 by Brian Stuart
// All rights reserved
//
// This is free software.
// You may redistribute it by any means providing it is not sold for profit
// without the authors written consent.
//
// No warrantee of any kind, expressed or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests to:
// 
//                  bstuart@magma.ca
//
/////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "WindowStyler.h"
#include "WindowStylerDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWindowStylerDlg dialog

CWindowStylerDlg::CWindowStylerDlg(CWnd* pParent /*=NULL*/)
	: CBitmapDialog(CWindowStylerDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CWindowStylerDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_pStyledWnd = NULL;
	m_bIsTopMost = AfxGetApp()->GetProfileInt("Settings", "IsTopMost", FALSE);
	m_bIsParent = AfxGetApp()->GetProfileInt("Settings", "IsParent", FALSE);
	m_bEnableToolTips = AfxGetApp()->GetProfileInt("Settings", "ToolTips", TRUE);
}

void CWindowStylerDlg::DoDataExchange(CDataExchange* pDX)
{
	CBitmapDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWindowStylerDlg)
	DDX_Control(pDX, IDC_OPTIONS, m_button_Options);
	DDX_Control(pDX, IDC_ABOUT, m_button_About);
	DDX_Control(pDX, ID_HELP, m_button_Help);
	DDX_Control(pDX, IDC_MODIFY_STYLE, m_button_ModStyle);
	DDX_Control(pDX, IDC_MODIFY_EX_STYLE, m_button_ModExStyle);
	DDX_Control(pDX, IDC_CLOSE_WINDOW, m_button_Close_Wnd);
	DDX_Control(pDX, IDC_CREATE_EX, m_button_CreateEx);
	DDX_Control(pDX, IDC_STYLES, m_lbSTYLES);
	DDX_Control(pDX, IDC_EX_STYLES, m_lbEX_STYLES);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CWindowStylerDlg, CBitmapDialog)
	//{{AFX_MSG_MAP(CWindowStylerDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_DESTROY()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_CREATE_EX, OnCreateEx)
	ON_BN_CLICKED(IDC_CLOSE_WINDOW, OnCloseWindow)
	ON_BN_CLICKED(IDC_MODIFY_STYLE, OnModifyStyle)
	ON_BN_CLICKED(IDC_MODIFY_EX_STYLE, OnModifyExStyle)
	ON_BN_CLICKED(IDC_ABOUT, OnAbout)
	ON_BN_CLICKED(IDC_OPTIONS, OnOptions)
	ON_WM_HELPINFO()
	ON_WM_PARENTNOTIFY()
	ON_WM_RBUTTONDOWN()
	//}}AFX_MSG_MAP
	ON_NOTIFY_EX( TTN_NEEDTEXT, 0, ToolTipsHandler)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWindowStylerDlg message handlers

BOOL CWindowStylerDlg::OnInitDialog()
{
	CBitmapDialog::OnInitDialog();
 
	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
			pSysMenu->RemoveMenu(4, MF_BYPOSITION);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	//sets the back ground to bitmap
	SetBitmap(IDB_BM_SKIN1, CBitmapDialog::BITMAP_TILE);

	//make this wimdow topmost if option is set
	SetOnTop();
	//removes the WS_EX_NOPARENTNOTIFY style so they will send notify messages 
	//(default has this style wheather or not it's selected in the propertys dlg box).
	m_lbSTYLES.ModifyStyleEx(WS_EX_NOPARENTNOTIFY, NULL);
	m_lbEX_STYLES.ModifyStyleEx(WS_EX_NOPARENTNOTIFY, NULL);
	m_button_ModStyle.ModifyStyleEx(WS_EX_NOPARENTNOTIFY, NULL);
	m_button_ModExStyle.ModifyStyleEx(WS_EX_NOPARENTNOTIFY, NULL);
	m_button_Close_Wnd.ModifyStyleEx(WS_EX_NOPARENTNOTIFY, NULL);
	m_button_CreateEx.ModifyStyleEx(WS_EX_NOPARENTNOTIFY, NULL);
	m_button_Options.ModifyStyleEx(WS_EX_NOPARENTNOTIFY, NULL);
	//m_button_Exit.ModifyStyleEx(WS_EX_NOPARENTNOTIFY, NULL);
	m_button_About.ModifyStyleEx(WS_EX_NOPARENTNOTIFY, NULL);
	m_button_Help.ModifyStyleEx(WS_EX_NOPARENTNOTIFY, NULL);

	EnableToolTips(m_bEnableToolTips);

	m_button_Help.SetFocus();
	return FALSE;  // return TRUE  unless you set the focus to a control
}

void CWindowStylerDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CBitmapDialog::OnSysCommand(nID, lParam);
	}
}

void CWindowStylerDlg::OnDestroy()
{
	WinHelp(0L, HELP_QUIT);
	CBitmapDialog::OnDestroy();
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CWindowStylerDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CBitmapDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CWindowStylerDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CWindowStylerDlg::OnCreateEx() 
{
	if(m_pStyledWnd==NULL)
		if(m_pStyledWnd = new CStyledWnd)//gets deleted in CStyledWnd::PostNcDestroy();
		{
			if(m_pStyledWnd->CreateEx(m_lbEX_STYLES.GetSelExStyles()
									,"Styled Window"
									, m_lbSTYLES.GetSelStyles()
									,this
									,m_bIsParent))
			{
				GetWindowStyles(m_pStyledWnd);
				GetWindowExStyles(m_pStyledWnd);
				m_pStyledWnd->Invalidate();
				m_pStyledWnd->SetWndStylesText(MakeAllStylesString());
				
				m_button_CreateEx.EnableWindow(FALSE);
				m_button_Close_Wnd.EnableWindow(TRUE);
				m_button_ModStyle.EnableWindow(TRUE);
				m_button_ModExStyle.EnableWindow(TRUE);
				SetFocus();
			}
			else
			{
				AfxMessageBox("Failed to CreateEx window for Styled Window");
				delete m_pStyledWnd;
				m_pStyledWnd = NULL;
			}
		}
		else AfxMessageBox("Failed to allocate  memory for Styled Window");
}

void CWindowStylerDlg::OnCloseWindow() 
{
	if(m_pStyledWnd)
	{
		m_pStyledWnd->PostMessage(WM_CLOSE);
		m_pStyledWnd = NULL;//ok cus it gets deleted in CStyledWnd::PostNcDestroy();
		UnSelectAll();
	}
}

void CWindowStylerDlg::OnModifyStyle() 
{
	if(m_pStyledWnd)
	{
		if(m_pStyledWnd->ModifyStyle(GetdwStylesToRemove(), GetdwStylesToAdd(),0))
		{
			GetWindowExStyles(m_pStyledWnd);
			GetWindowStyles(m_pStyledWnd);
	
			//change size 1 pixel then back to get it to redraw
			CRect r;
			m_pStyledWnd->GetWindowRect(&r);
			r.InflateRect(0,0,1,1);
			m_pStyledWnd->MoveWindow(r);
			r.InflateRect(0,0,-1,-1);
			m_pStyledWnd->MoveWindow(r);
			m_pStyledWnd->SetWndStylesText(MakeAllStylesString());			
		}
		else
		{
			AfxMessageBox("Unable to modify Window styles");
			GetWindowExStyles(m_pStyledWnd);
			GetWindowStyles(m_pStyledWnd);
		}
	}	
}

void CWindowStylerDlg::OnModifyExStyle() 
{
	if(m_pStyledWnd)
	{
		if(m_pStyledWnd->ModifyStyleEx(GetdwExStylesToRemove(), GetdwExStylesToAdd(),SWP_NOMOVE))
		{
			GetWindowStyles(m_pStyledWnd);
			GetWindowExStyles(m_pStyledWnd);

			//change size 1 pixel then back to get it to redraw
			CRect r;
			m_pStyledWnd->GetWindowRect(&r);
			r.InflateRect(0,0,1,1);
			m_pStyledWnd->MoveWindow(r);
			r.InflateRect(0,0,-1,-1);
			m_pStyledWnd->MoveWindow(r);
			m_pStyledWnd->SetWndStylesText(MakeAllStylesString());
		}
		else
		{
			AfxMessageBox("Unable to modify Extended Window styles");
			GetWindowExStyles(m_pStyledWnd);
			GetWindowStyles(m_pStyledWnd);
		}
	}

}

void CWindowStylerDlg::PostNcDestroy() 
{
	//if(m_pStyledWnd)m_pStyledWnd->SendMessage(WM_CLOSE);
	CBitmapDialog::PostNcDestroy();
}

void CWindowStylerDlg::OnAbout() 
{
	CAboutDlg a;
	a.DoModal();
	
}

void CWindowStylerDlg::StyledWndClosed(CStyledWnd * pStyledWnd)
{
	m_pStyledWnd = NULL;//ok cus it's deleted in CStyledWnd::PostNcDestroy()
	UnSelectAll();
	m_button_CreateEx.EnableWindow(TRUE);
	m_button_Close_Wnd.EnableWindow(FALSE);
	m_button_ModStyle.EnableWindow(FALSE);
	m_button_ModExStyle.EnableWindow(FALSE);
}

void CWindowStylerDlg::GetWindowStyles(CStyledWnd * pStyledWnd)
{
	DWORD styles = 0,temp;
	int count = NULL;
	CString str = _T("");

	count = m_lbSTYLES.GetCount();
	styles = pStyledWnd->GetStyle();//::GetWindowLong(pStyledWnd->m_hWnd, GWL_STYLE);//get's the DWORD of all the ored window styles
	m_Wnd_HasStyles_Array.RemoveAll();

	for(int i=0;i<count;i++)
	{
		temp = 0;
		temp = styles|m_lbSTYLES.GetItemData(i);
		if(styles==temp)
		{
			m_lbSTYLES.SetSel(i, TRUE );
			m_lbSTYLES.GetText(i,str);
			m_Wnd_HasStyles_Array.Add(str);
		}
		else m_lbSTYLES.SetSel(i, FALSE);
	}
}


void CWindowStylerDlg::GetWindowExStyles(CStyledWnd * pStyledWnd)
{
	DWORD styles = 0,temp =0;
	int count = NULL;
	CString str = _T("");

	count = m_lbEX_STYLES.GetCount();
	styles = pStyledWnd->GetExStyle();//::GetWindowLong(pStyledWnd->m_hWnd, GWL_EXSTYLE);//get's the DWORD of all the ored window styles
	m_Wnd_HasExStyles_Array.RemoveAll();

	for(int i=0;i<count;i++)
	{
		temp = 0;
		temp = styles|m_lbEX_STYLES.GetItemData(i);
		if(styles==temp)
		{
			m_lbEX_STYLES.SetSel(i, TRUE );
			m_lbEX_STYLES.GetText(i,str);
			m_Wnd_HasExStyles_Array.Add(str);
		}
		else m_lbEX_STYLES.SetSel(i, FALSE);
	}
}

void CWindowStylerDlg::UnSelectAll()
{
	int count = m_lbSTYLES.GetCount();
	for(int i=0;i<count;i++)
		m_lbSTYLES.SetSel(i, FALSE);

	count = m_lbEX_STYLES.GetCount();	
	for(i=0;i<count;i++)
		m_lbEX_STYLES.SetSel(i, FALSE);
}

BOOL CWindowStylerDlg::DestroyWindow() 
{
	if(m_pStyledWnd)m_pStyledWnd->SendMessage(WM_CLOSE);
	return CBitmapDialog::DestroyWindow();
}



CString CWindowStylerDlg::MakeAllStylesString()
{
	CString str("This window has all the bits of the following styles:\n\n[WS_STYLES]\n");
	int countEx = m_Wnd_HasExStyles_Array.GetSize();
	int count = m_Wnd_HasStyles_Array.GetSize();
	for(int i=0;i<count;i++)
	{
		str += m_Wnd_HasStyles_Array[i];
		if(i+1<count)
			str += ", ";
	}
	
	str += "\n\n[WS_EX_STYLES]\n";
	
	for(i=0;i<countEx;i++)
	{
		str += m_Wnd_HasExStyles_Array[i];
		if(i+1<countEx)
			str += ", ";
	}

	return str;
}

DWORD CWindowStylerDlg::GetdwStylesToRemove()
{
	DWORD dw = NULL;
	CString str(_T(""));
	int count = m_lbSTYLES.GetCount();
	int size = m_Wnd_HasStyles_Array.GetSize();
	for(int i=0;i<count;i++)//check all styles
	{
		m_lbSTYLES.GetText(i, str);//get style i
		for(int x=0;x<size;x++)//check all m_Wnd_HasStyles_Array
			if(!m_lbSTYLES.GetSel(i))//if not selected
				if(m_Wnd_HasStyles_Array[x]==str)//if it allready has it
					dw = dw|m_lbSTYLES.GetItemData(i);//or it to dw			

	}
	return dw;
}

DWORD CWindowStylerDlg::GetdwExStylesToRemove()
{
	DWORD dw = NULL;
	CString str(_T(""));
	int count = m_lbEX_STYLES.GetCount();
	int size = m_Wnd_HasExStyles_Array.GetSize();
	for(int i=0;i<count;i++)//check all styles
	{
		m_lbEX_STYLES.GetText(i, str);//get style i
		for(int x=0;x<size;x++)//check all m_Wnd_HasExStyles_Array
			if(!m_lbEX_STYLES.GetSel(i))//if not selected
				if(m_Wnd_HasExStyles_Array[x]==str)//if it allready has it
					dw = dw|m_lbEX_STYLES.GetItemData(i);//or it to dw			

	}
	return dw;
}

DWORD CWindowStylerDlg::GetdwStylesToAdd()
{
	DWORD dw = NULL;
	BOOL found = FALSE;
	CString str(_T(""));
	int count = m_lbSTYLES.GetCount();
	int size = m_Wnd_HasStyles_Array.GetSize();
	for(int i=0;i<count;i++)//check all styles
	{
		m_lbSTYLES.GetText(i, str);//get string i
		if(m_lbSTYLES.GetSel(i))//if it is selected
		{

			for(int x=0;x<size;x++)//check all m_Wnd_HasStyles_Array
			{
				if(m_Wnd_HasStyles_Array[x]==str)//if it does allready have it
				{
					found = TRUE;
					break;
				}
			}
			if(!found)
			{
				dw = dw|m_lbSTYLES.GetItemData(i);//if not found or it to dw
			}
			else found = FALSE;
		}
	}
	return dw;
}

DWORD CWindowStylerDlg::GetdwExStylesToAdd()
{
	DWORD dw = NULL;
	BOOL found = FALSE;
	CString str(_T(""));
	int count = m_lbEX_STYLES.GetCount();
	int size = m_Wnd_HasExStyles_Array.GetSize();
	for(int i=0;i<count;i++)//check all styles
	{

		if(m_lbEX_STYLES.GetSel(i))//if it is selected
		{
			m_lbEX_STYLES.GetText(i, str);//get string i
			for(int x=0;x<size;x++)//check all m_Wnd_HasStyles_Array
			{
				if(m_Wnd_HasExStyles_Array[x]==str)//if it does allready have it
				{
					found = TRUE;
					break;
				}
			}
			if(!found)
			{
				dw = dw|m_lbEX_STYLES.GetItemData(i);//if not found or it to dw
			}
			else found = FALSE;
		}
	}
	return dw;
}

void CWindowStylerDlg::OnOptions() 
{
	COptionsDlg opt;
	if(opt.DoModal()==IDOK)
	{
		m_bIsTopMost = opt.m_bIs_Dlg_TopMost;
		m_bEnableToolTips = opt.m_bToolTips;
		AfxGetApp()->WriteProfileInt("Settings", "IsTopMost", m_bIsTopMost);
		AfxGetApp()->WriteProfileInt("Settings", "IsParent", m_bIsParent);
		AfxGetApp()->WriteProfileInt("Settings", "ToolTips", m_bEnableToolTips);
		SetOnTop();
//		SetStyledParent();
		EnableToolTips(m_bEnableToolTips);
	}
}

void CWindowStylerDlg::SetOnTop()
{
	if(m_bIsTopMost)
		SetWindowPos(&wndTopMost,0,0,0,0, SWP_NOSIZE|SWP_NOMOVE);
	else
		SetWindowPos(&wndNoTopMost,0,0,0,0, SWP_NOSIZE|SWP_NOMOVE);
}

void CWindowStylerDlg::SetStyledParent()
{
	if(m_pStyledWnd)
	{
		if(m_bIsParent)
			m_pStyledWnd->SetParent(this);
		else
			m_pStyledWnd->SetParent(NULL);
	}
}

BOOL CWindowStylerDlg::ToolTipsHandler( UINT id, NMHDR* pNMHDR, LRESULT* pResult )
{
	if(m_bEnableToolTips)
	{
		TOOLTIPTEXT *pTTT = (TOOLTIPTEXT *)pNMHDR;
		UINT nID =pNMHDR->idFrom;
		if (pTTT->uFlags & TTF_IDISHWND)
		{
			// idFrom is actually the HWND of the tool
			nID = ::GetDlgCtrlID((HWND)nID);
			if(nID)
			{
				//nID must be the same as the ID of the control
				pTTT->lpszText = MAKEINTRESOURCE(nID);
				pTTT->hinst = AfxGetResourceHandle();
				return(TRUE);
			}
		}
	}
    return FALSE;
}

/*typedef  struct  tagHELPINFO {  // hi 
    UINT     cbSize; 
    int      iContextType 
    int      iCtrlId; 
    HANDLE   hItemHandle; 
    DWORD    dwContextId; 
    POINT    MousePos; 
} HELPINFO, FAR *LPHELPINFO; */
 

BOOL CWindowStylerDlg::OnHelpInfo(HELPINFO* pHelpInfo) 
{

	switch(pHelpInfo->iCtrlId)
	{
	case IDOK:
		{
			AfxGetApp()->WinHelp(0x20000 + IDOK, HELP_CONTEXTPOPUP);
			return TRUE;
		}
	case ID_HELP:
		{
			AfxGetApp()->WinHelp(0x20000 + ID_HELP, HELP_CONTEXTPOPUP);
			return TRUE;
		}
	case IDC_ABOUT:
		{
			AfxGetApp()->WinHelp(0x20000 + IDC_ABOUT, HELP_CONTEXTPOPUP);
			return TRUE;
		}
	case IDC_OPTIONS:
		{
			AfxGetApp()->WinHelp(0x20000 + IDC_OPTIONS, HELP_CONTEXTPOPUP);
			return TRUE;
		}
	case IDC_CREATE_EX:
		{
			AfxGetApp()->WinHelp(0x20000 + IDC_CREATE_EX, HELP_CONTEXTPOPUP);
			return TRUE;
		}
	case IDC_CLOSE_WINDOW:
		{
			AfxGetApp()->WinHelp(0x20000 + IDC_CLOSE_WINDOW, HELP_CONTEXTPOPUP);
			return TRUE;
		}
	case IDC_MODIFY_STYLE:
		{
			AfxGetApp()->WinHelp(0x20000 + IDC_MODIFY_STYLE, HELP_CONTEXTPOPUP);
			return TRUE;
		}
	case IDC_MODIFY_EX_STYLE:
		{
			AfxGetApp()->WinHelp(0x20000 + IDC_MODIFY_EX_STYLE, HELP_CONTEXTPOPUP);
			return TRUE;
		}
	case IDC_STYLES:
		{
			BOOL bOutSide;
			CPoint p(pHelpInfo->MousePos);
			m_lbSTYLES.ScreenToClient(&p);
			UINT item = m_lbSTYLES.ItemFromPoint(p , bOutSide);
			if(!bOutSide)
			{
				DWORD dw = 0x20000 + IDC_STYLES+(0x1000*(item+1));
				AfxGetApp()->WinHelp(dw, HELP_CONTEXTPOPUP);
				return TRUE;
			}
		}
	case IDC_EX_STYLES:
		{
			BOOL bOutSide;
			CPoint p(pHelpInfo->MousePos);
			m_lbEX_STYLES.ScreenToClient(&p);
			UINT item = m_lbEX_STYLES.ItemFromPoint(p , bOutSide);
			if(!bOutSide)
			{
				DWORD dw = 0x20000 + IDC_EX_STYLES+(0x1000*(item+1));
				AfxGetApp()->WinHelp(dw, HELP_CONTEXTPOPUP);
				return TRUE;
			}
		}
	}
	
	return CBitmapDialog::OnHelpInfo(pHelpInfo);
}

void CWindowStylerDlg::OnParentNotify(UINT message, LPARAM lParam) 
{
	CBitmapDialog::OnParentNotify(message, lParam);

	//puts the app in context help mode with a ?cursor last paramater should be the cur pos
	if(message==WM_RBUTTONDOWN)
		PostMessage(WM_SYSCOMMAND,SC_CONTEXTHELP,lParam);
}

void CWindowStylerDlg::OnRButtonDown(UINT nFlags, CPoint point) 
{
	//puts the app in context help mode with a ?cursor last paramater should be the cur pos
	PostMessage(WM_SYSCOMMAND,SC_CONTEXTHELP,0);
	CBitmapDialog::OnRButtonDown(nFlags, point);
}

/*typedef struct tagMSG {     // msg  
    HWND   hwnd;       
    UINT   message;
    WPARAM wParam;
    LPARAM lParam;
    DWORD  time;
    POINT  pt;
} MSG;*/


BOOL CWindowStylerDlg::PreTranslateMessage(MSG* pMsg) 
{
	if(pMsg->message == WM_KEYDOWN&&(pMsg->wParam == VK_ESCAPE || pMsg->wParam == VK_CANCEL))
		return TRUE;
	return CBitmapDialog::PreTranslateMessage(pMsg);
}



