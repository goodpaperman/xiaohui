// WndStyleListBox.cpp : implementation file
//
/////////////////////////////////////////////////////////////////////////////
// Copyright (C) 1998 by Brian Stuart
// All rights reserved
//
// This is free software.
// You may redistribute it by any means providing it is not sold for profit
// without the authors written consent.
//
// No warrantee of any kind, expressed or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests to:
// 
//                  bstuart@magma.ca
//
/////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "WindowStyler.h"
#include "WndStyleListBox.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWndStyleListBox

CWndStyleListBox::CWndStyleListBox()
{

}

CWndStyleListBox::~CWndStyleListBox()
{
}


BEGIN_MESSAGE_MAP(CWndStyleListBox, CListBox)
	//{{AFX_MSG_MAP(CWndStyleListBox)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWndStyleListBox message handlers

void CWndStyleListBox::FillListBox()
{
	//fills the list box with style text and coresponding DWORD value
	AddString("WS_BORDER");
	SetItemData(0, WS_BORDER);
	AddString("WS_CAPTION");
	SetItemData(1, WS_CAPTION);
	AddString("WS_CHILD");
	SetItemData(2, WS_CHILD);
	AddString("WS_CLIPCHILDREN");
	SetItemData(3, WS_CLIPCHILDREN);
	AddString("WS_CLIPSIBLINGS");
	SetItemData(4, WS_CLIPSIBLINGS);
	AddString("WS_DISABLED");
	SetItemData(5, WS_DISABLED);
	AddString("WS_DLGFRAME");
	SetItemData(6, WS_DLGFRAME);
	AddString("WS_GROUP");
	SetItemData(7, WS_GROUP);
	AddString("WS_HSCROLL");
	SetItemData(8, WS_HSCROLL);
	AddString("WS_MAXIMIZE");
	SetItemData(9, WS_MAXIMIZE);
	AddString("WS_MAXIMIZEBOX");
	SetItemData(10, WS_MAXIMIZEBOX);
	AddString("WS_MINIMIZE");
	SetItemData(11, WS_MINIMIZE);
	AddString("WS_MINIMIZEBOX");
	SetItemData(12, WS_MINIMIZEBOX);
	AddString("WS_OVERLAPPED");
	SetItemData(13, WS_OVERLAPPED);
	AddString("WS_OVERLAPPEDWINDOW");
	SetItemData(14, WS_OVERLAPPEDWINDOW);
	AddString("WS_POPUP");
	SetItemData(15, WS_POPUP);
	AddString("WS_POPUPWINDOW");
	SetItemData(16, WS_POPUPWINDOW);
	AddString("WS_SYSMENU");
	SetItemData(17, WS_SYSMENU);
	AddString("WS_TABSTOP");
	SetItemData(18, WS_TABSTOP);
	AddString("WS_THICKFRAME");
	SetItemData(19, WS_THICKFRAME);
	AddString("WS_VISIBLE");
	SetItemData(20, WS_VISIBLE);
	AddString("WS_VSCROLL");
	SetItemData(21, WS_VSCROLL);
}

DWORD CWndStyleListBox::GetSelStyles()
{
	/*LPINT pint;
	DWORD dw = NULL;
	int count = GetSelCount();
	pint = new int[count];
	GetSelItems(count, pint );
	for(int i=0;i<count;i++)
	{
		dw = dw|GetItemData(pint[i]); 
	}
	delete pint;

	return dw;*/

	DWORD dw = NULL;
	int count = GetCount();
	for(int i=0;i<count;i++)
	{
		if(GetSel(i))
			dw = dw|GetItemData(i); 
	}
	return dw;
}



void CWndStyleListBox::PreSubclassWindow() 
{
	FillListBox();	
	CListBox::PreSubclassWindow();
}

DWORD CWndStyleListBox::GetUnSelStyles()
{
	DWORD dw = NULL;
	int count = GetCount();
	for(int i=0;i<count;i++)
	{
		if(!GetSel(i))
			dw = dw|GetItemData(i); 
	}
	return dw;
}

BOOL CWndStyleListBox::PreTranslateMessage(MSG* pMsg) 
{
	if(pMsg->message == WM_KEYDOWN&&(pMsg->wParam == VK_RETURN))
	{
		int index = GetCaretIndex();
		
		if(GetSel(index))
			SetSel(index,FALSE);
		else
			SetSel(index,TRUE);
		return TRUE;
	}
	return CListBox::PreTranslateMessage(pMsg);
}
