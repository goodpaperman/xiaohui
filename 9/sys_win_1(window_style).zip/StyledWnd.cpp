// StyledWnd.cpp : implementation file
//
/////////////////////////////////////////////////////////////////////////////
// Copyright (C) 1998 by Brian Stuart
// All rights reserved
//
// This is free software.
// You may redistribute it by any means providing it is not sold for profit
// without the authors written consent.
//
// No warrantee of any kind, expressed or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests to:
// 
//                  bstuart@magma.ca
//
/////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "WindowStyler.h"
#include "StyledWnd.h"
#include "WindowStylerDlg.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CStyledWnd

CStyledWnd::CStyledWnd()
{
	m_pStylerDlg = NULL;
	m_WindowText = "No text set";
}

CStyledWnd::~CStyledWnd()
{
}


BEGIN_MESSAGE_MAP(CStyledWnd, CWnd)
	//{{AFX_MSG_MAP(CStyledWnd)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CStyledWnd message handlers

BOOL CStyledWnd::CreateEx(DWORD dwExStyle, LPCTSTR lpszWindowName, DWORD dwStyle, CWnd* pStylerDlg, BOOL makeparent)
{
	int x,y;
	BOOL b = FALSE;
	m_pStylerDlg = pStylerDlg;
	x=::GetSystemMetrics(SM_CXSCREEN)/6;
	y=::GetSystemMetrics(SM_CYSCREEN)/6;
	CRect rect(0, 0,x,y);
	
	b = CWnd::CreateEx(dwExStyle
		,::AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW, NULL, static_cast<HBRUSH>(::GetStockObject(BLACK_BRUSH))
		,::AfxGetApp()->LoadIcon(IDI_STYLED))
		,lpszWindowName
		, dwStyle
		,rect
		,makeparent?pStylerDlg:NULL
		, NULL);

	return b;
}

void CStyledWnd::PostNcDestroy() 
{
	((CWindowStylerDlg*)m_pStylerDlg)->StyledWndClosed(this);
	delete this;
}

void CStyledWnd::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	CRect r;
	GetClientRect(&r);
	//dc.FillSolidRect(rect,RGB(0,0,0));
	//dc.SetBkMode(OPAQUE);
	dc.SetBkColor(RGB(0,0,0));
	dc.SetTextColor(RGB(0,200,220));
	dc.DrawText(m_WindowText, r, DT_LEFT|DT_WORDBREAK);
	//CWnd::OnPaint();// do not call for painting messages
}

void CStyledWnd::SetWndStylesText(CString text)
{
	if(!text.IsEmpty())
	{
		CClientDC dc(this);
		CRect wr,cr;


		m_WindowText = text;
		GetWindowRect(&wr);
		GetClientRect(&cr);

		ClientToScreen(&cr);
		CRect difr(0,0,(wr.right-cr.right)+(cr.left-wr.left),(wr.bottom-cr.bottom)+(cr.top-wr.top));

		GetClientRect(&cr);
		dc.DrawText(m_WindowText, cr, DT_LEFT|DT_WORDBREAK|DT_CALCRECT);
		
		cr+=difr;

		if(!(GetStyle()&WS_MAXIMIZE))
			MoveWindow(wr.left,wr.top,cr.right,cr.bottom);
	}

}


