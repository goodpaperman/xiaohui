// WindowStyler.cpp : Defines the class behaviors for the application.
//
/////////////////////////////////////////////////////////////////////////////
// Copyright (C) 1998 by Brian Stuart
// All rights reserved
//
// This is free software.
// You may redistribute it by any means providing it is not sold for profit
// without the authors written consent.
//
// No warrantee of any kind, expressed or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests to:
// 
//                  bstuart@magma.ca
//
/////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "WindowStyler.h"
#include "WindowStylerDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWindowStylerApp

BEGIN_MESSAGE_MAP(CWindowStylerApp, CWinApp)
	//{{AFX_MSG_MAP(CWindowStylerApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG

    // Global help commands
   // ON_COMMAND(ID_HELP_FINDER, CWinApp::OnHelpFinder)
   // ON_COMMAND(ID_CONTEXT_HELP, CWinApp::OnContextHelp)
   // ON_COMMAND(ID_DEFAULT_HELP, CWinApp::OnHelpFinder)
      ON_COMMAND(ID_HELP, CWindowStylerApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWindowStylerApp construction

CWindowStylerApp::CWindowStylerApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CWindowStylerApp object

CWindowStylerApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CWindowStylerApp initialization

BOOL CWindowStylerApp::InitInstance()
{
	AfxEnableControlContainer();
	SetRegistryKey("Almonte Software");

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	CWindowStylerDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{

	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}

void CWindowStylerApp::OnHelp()
{
	WinHelp(0, HELP_FINDER);
}


