// WindowStylerDlg.h : header file
//
/////////////////////////////////////////////////////////////////////////////
// Copyright (C) 1998 by Brian Stuart
// All rights reserved
//
// This is free software.
// You may redistribute it by any means providing it is not sold for profit
// without the authors written consent.
//
// No warrantee of any kind, expressed or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests to:
// 
//                  bstuart@magma.ca
//
/////////////////////////////////////////////////////////////////////////////
#if !defined(AFX_GAMEDLG_H__6F597A25_8C9F_11D3_9A99_F6D644D1BA12__INCLUDED_)
#define AFX_GAMEDLG_H__6F597A25_8C9F_11D3_9A99_F6D644D1BA12__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// CWindowStylerDlg dialog
#include "WndStyleListBox.h"
#include "WndExStyleListBox.h"
#include "StyledWnd.h"
#include <afxtempl.h>
#include "OptionsDlg.h"
#include "BitmapDialog.h"

class CWindowStylerDlg : public CBitmapDialog
{
// Construction
public:
	void GetWindowStyles(CStyledWnd* pStyledWnd);
	void StyledWndClosed(CStyledWnd* pStyledWnd);
	CWindowStylerDlg(CWnd* pParent = NULL);	// standard constructor
	
// Dialog Data
	//{{AFX_DATA(CWindowStylerDlg)
	enum { IDD = IDD_WND_STYLER };
	CButton	m_button_Options;
	CButton	m_button_About;
	CButton	m_button_Help;
	CButton	m_button_ModStyle;
	CButton	m_button_ModExStyle;
	CButton	m_button_Close_Wnd;
	CButton	m_button_CreateEx;
	CWndStyleListBox	m_lbSTYLES;
	CWndExStyleListBox	m_lbEX_STYLES;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWindowStylerDlg)
	public:
	virtual BOOL DestroyWindow();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	virtual void PostNcDestroy();
	//}}AFX_VIRTUAL

// Implementation
protected:
	BOOL m_bEnableToolTips;
	void SetStyledParent();
	BOOL m_bIsParent;
	void SetOnTop();
	BOOL m_bIsTopMost;
	DWORD GetdwExStylesToAdd();
	DWORD GetdwStylesToAdd();
	DWORD GetdwExStylesToRemove();
	DWORD GetdwStylesToRemove();
	CString MakeAllStylesString();
	void UnSelectAll();
	void GetWindowExStyles(CStyledWnd* pStyledWnd);
	CArray<CString, CString&> m_Wnd_HasStyles_Array;
	CArray<CString, CString&> m_Wnd_HasExStyles_Array;
	HICON m_hIcon;
	CStyledWnd* m_pStyledWnd;
	BOOL ToolTipsHandler( UINT id, NMHDR* pNMHDR, LRESULT* pResult );
	// Generated message map functions
	//{{AFX_MSG(CWindowStylerDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnDestroy();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnCreateEx();
	afx_msg void OnCloseWindow();
	afx_msg void OnModifyStyle();
	afx_msg void OnModifyExStyle();
	afx_msg void OnAbout();
	afx_msg void OnOptions();
	afx_msg BOOL OnHelpInfo(HELPINFO* pHelpInfo);
	afx_msg void OnParentNotify(UINT message, LPARAM lParam);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GAMEDLG_H__6F597A25_8C9F_11D3_9A99_F6D644D1BA12__INCLUDED_)
