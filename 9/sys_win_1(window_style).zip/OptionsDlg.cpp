// OptionsDlg.cpp : implementation file
//
/////////////////////////////////////////////////////////////////////////////
// Copyright (C) 1998 by Brian Stuart
// All rights reserved
//
// This is free software.
// You may redistribute it by any means providing it is not sold for profit
// without the authors written consent.
//
// No warrantee of any kind, expressed or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests to:
// 
//                  bstuart@magma.ca
//
/////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "windowstyler.h"
#include "OptionsDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COptionsDlg dialog


COptionsDlg::COptionsDlg(CWnd* pParent /*=NULL*/)
	: CDialog(COptionsDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(COptionsDlg)
	m_bIs_Dlg_TopMost = AfxGetApp()->GetProfileInt("Settings", "IsTopMost", FALSE);
	m_bToolTips = AfxGetApp()->GetProfileInt("Settings", "ToolTips", TRUE);;
	//}}AFX_DATA_INIT
}


void COptionsDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COptionsDlg)
	DDX_Control(pDX, IDC_CK_TOOLTIPS, m_button_ToolTips);
	DDX_Check(pDX, IDC_IS_DLG_TOPMOST, m_bIs_Dlg_TopMost);
	DDX_Check(pDX, IDC_CK_TOOLTIPS, m_bToolTips);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(COptionsDlg, CDialog)
	//{{AFX_MSG_MAP(COptionsDlg)
	ON_BN_CLICKED(IDC_CK_TOOLTIPS, OnCkTooltips)
	//}}AFX_MSG_MAP
	ON_NOTIFY_EX( TTN_NEEDTEXT, 0, ToolTipsHandler)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COptionsDlg message handlers

BOOL COptionsDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	EnableToolTips(TRUE);
	
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL COptionsDlg::ToolTipsHandler( UINT id, NMHDR* pNMHDR, LRESULT* pResult )
{
	if(m_bToolTips)
	{
		TOOLTIPTEXT *pTTT = (TOOLTIPTEXT *)pNMHDR;
		UINT nID =pNMHDR->idFrom;
		if (pTTT->uFlags & TTF_IDISHWND)
		{
			// idFrom is actually the HWND of the tool
			nID = ::GetDlgCtrlID((HWND)nID);
			if(nID)
			{
				//nID must be the same as the ID of the control
				pTTT->lpszText = MAKEINTRESOURCE(nID);
				pTTT->hinst = AfxGetResourceHandle();
				return TRUE;
			}
		}
	}
    return(FALSE);
}

void COptionsDlg::OnCkTooltips() 
{
	UpdateData(TRUE);
}
