#if !defined(AFX_WNDSTLYELISTBOX_H__0CFF2DC1_8D26_11D3_9A99_EA06119CC411__INCLUDED_)
#define AFX_WNDSTLYELISTBOX_H__0CFF2DC1_8D26_11D3_9A99_EA06119CC411__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// WndStlyeListBox.h : header file
//
/////////////////////////////////////////////////////////////////////////////
// Copyright (C) 1998 by Brian Stuart
// All rights reserved
//
// This is free software.
// You may redistribute it by any means providing it is not sold for profit
// without the authors written consent.
//
// No warrantee of any kind, expressed or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests to:
// 
//                  bstuart@magma.ca
//
/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
// CWndStyleListBox window

class CWndStyleListBox : public CListBox
{
// Construction
public:
	CWndStyleListBox();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWndStyleListBox)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
	DWORD GetUnSelStyles();
	DWORD GetSelStyles();
	virtual ~CWndStyleListBox();

	// Generated message map functions
protected:
	//{{AFX_MSG(CWndStyleListBox)
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
private:
	void FillListBox();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WNDSTLYELISTBOX_H__0CFF2DC1_8D26_11D3_9A99_EA06119CC411__INCLUDED_)
