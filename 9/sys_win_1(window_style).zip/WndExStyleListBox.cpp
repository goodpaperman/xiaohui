// WndExStyleListBox.cpp : implementation file
//
/////////////////////////////////////////////////////////////////////////////
// Copyright (C) 1998 by Brian Stuart
// All rights reserved
//
// This is free software.
// You may redistribute it by any means providing it is not sold for profit
// without the authors written consent.
//
// No warrantee of any kind, expressed or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests to:
// 
//                  bstuart@magma.ca
//
/////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "WindowStyler.h"
#include "WndExStyleListBox.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWndExStyleListBox

CWndExStyleListBox::CWndExStyleListBox()
{

}

CWndExStyleListBox::~CWndExStyleListBox()
{
}


BEGIN_MESSAGE_MAP(CWndExStyleListBox, CListBox)
	//{{AFX_MSG_MAP(CWndExStyleListBox)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWndExStyleListBox message handlers

void CWndExStyleListBox::FillListBox()
{
 	//fill the  list box with style text and coresponding DWORD value
	AddString("WS_EX_ACCEPTFILES");
	SetItemData(0, WS_EX_ACCEPTFILES);
	AddString("WS_EX_CLIENTEDGE");
	SetItemData(1, WS_EX_CLIENTEDGE);
	AddString("WS_EX_CONTEXTHELP");
	SetItemData(2, WS_EX_CONTEXTHELP);
	AddString("WS_EX_CONTROLPARENT");
	SetItemData(3, WS_EX_CONTROLPARENT);
	AddString("WS_EX_DLGMODALFRAME");
	SetItemData(4, WS_EX_DLGMODALFRAME);
	AddString("WS_EX_LEFT");
	SetItemData(5, WS_EX_LEFT);
	AddString("WS_EX_LEFTSCROLLBAR");
	SetItemData(6, WS_EX_LEFTSCROLLBAR);
	AddString("WS_EX_LTRREADING");
	SetItemData(7, WS_EX_LTRREADING);
	AddString("WS_EX_MDICHILD");
	SetItemData(8, WS_EX_MDICHILD);
	AddString("WS_EX_NOPARENTNOTIFY");
	SetItemData(9, WS_EX_NOPARENTNOTIFY);
	AddString("WS_EX_OVERLAPPEDWINDOW");
	SetItemData(10, WS_EX_OVERLAPPEDWINDOW);
	AddString("WS_EX_PALETTEWINDOW");
	SetItemData(11, WS_EX_PALETTEWINDOW);
	AddString("WS_EX_RIGHT");
	SetItemData(12, WS_EX_RIGHT);
	AddString("WS_EX_RIGHTSCROLLBAR");
	SetItemData(13, WS_EX_RIGHTSCROLLBAR);
	AddString("WS_EX_RTLREADING");
	SetItemData(14, WS_EX_RTLREADING);
	AddString("WS_EX_STATICEDGE");
	SetItemData(15, WS_EX_STATICEDGE);
	AddString("WS_EX_TOOLWINDOW");
	SetItemData(16, WS_EX_TOOLWINDOW);
	AddString("WS_EX_TOPMOST");
	SetItemData(17, WS_EX_TOPMOST);
	AddString("WS_EX_TRANSPARENT");
	SetItemData(18, WS_EX_TRANSPARENT);
	AddString("WS_EX_WINDOWEDGE");
	SetItemData(19, WS_EX_WINDOWEDGE);
}

DWORD CWndExStyleListBox::GetSelExStyles()
{
	/*LPINT pint;
	DWORD dw = NULL;
	int count = GetSelCount();
	pint = new int[count];
	GetSelItems(count, pint );
	for(int i=0;i<count;i++)
	{
		dw = dw|GetItemData(pint[i]); 
	}
	delete pint;

	return dw;*/

	DWORD dw = NULL;
	int count = GetCount();
	for(int i=0;i<count;i++)
	{
		if(GetSel(i))
			dw = dw|GetItemData(i); 
	}
	return dw;
}

void CWndExStyleListBox::PreSubclassWindow() 
{
	FillListBox();
	
	CListBox::PreSubclassWindow();
}


DWORD CWndExStyleListBox::GetUnSelExStyles()
{
	DWORD dw = NULL;
	int count = GetCount();
	for(int i=0;i<count;i++)
	{
		if(!GetSel(i))
			dw = dw|GetItemData(i); 
	}
	return dw;
}

BOOL CWndExStyleListBox::PreTranslateMessage(MSG* pMsg) 
{
	if(pMsg->message == WM_KEYDOWN&&(pMsg->wParam == VK_RETURN))
	{
		int index = GetCaretIndex();
		
		if(GetSel(index))
			SetSel(index,FALSE);
		else
			SetSel(index,TRUE);
		return TRUE;
	}
	return CListBox::PreTranslateMessage(pMsg);
}
