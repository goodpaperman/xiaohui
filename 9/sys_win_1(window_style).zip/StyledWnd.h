#if !defined(AFX_GAMEWND_H__6F597A31_8C9F_11D3_9A99_F6D644D1BA12__INCLUDED_)
#define AFX_GAMEWND_H__6F597A31_8C9F_11D3_9A99_F6D644D1BA12__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// StyledWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CStyledWnd window

class CStyledWnd : public CWnd
{
// Construction
public:
	CStyledWnd();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CStyledWnd)
	protected:
	virtual void PostNcDestroy();
	//}}AFX_VIRTUAL

// Implementation
public:
	void SetWndStylesText(CString text = "");
	BOOL CreateEx(DWORD dwExStyle, LPCTSTR lpszWindowName, DWORD dwStyle, CWnd* pStylerDlg, BOOL makeparent = FALSE);
	virtual ~CStyledWnd();

	// Generated message map functions
protected:
	CString m_WindowText;
	void* m_pStylerDlg;
	//{{AFX_MSG(CStyledWnd)
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GAMEWND_H__6F597A31_8C9F_11D3_9A99_F6D644D1BA12__INCLUDED_)
