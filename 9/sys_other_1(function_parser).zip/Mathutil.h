///////////////////////////////////////////////////////////////////////////////
//                                                                           //
// Dateiname: MATHUTIL.H                                                     //
//                                                                           //
// Autor:     Andreas J�ger, Friedrich-Schiller-Universit�t Jena             //
//                                                                           //
// System:    WIN_RWPM.EXE und WINLRWPM.EXE                                  //
//                                                                           //
// Beschreibung: Mathematische Routinen                                      //
//                                                                           //
// Hinweise:                                                                 //
//                                                                           //
///////////////////////////////////////////////////////////////////////////////
#define PI 3.14159265358979323846L
#define PI_ 3.1415926535897932

//////////////////////////////////////////////////////////////////////////
// abs-Funktion f�r long double
//////////////////////////////////////////////////////////////////////////
//inline abs(long double x) {return fabsl(x);};

//////////////////////////////////////////////////////////////////////////
// Konvertieren von Zahlen in Strings
//////////////////////////////////////////////////////////////////////////
inline CString mcvt(long double x)
{
	char buffer[255+1];
	sprintf(buffer,"%Lg",x);
	return CString(buffer);
}

inline CString mcvt(int x)
{
	char buffer[255+1];
	sprintf(buffer,"%d",x);
	return CString(buffer);
}

inline CString mcvt(long x)
{
	char buffer[255+1];
	sprintf(buffer,"%ld",x);
	return CString(buffer);
}


//////////////////////////////////////////////////////////////////////////
// besondere Mathematik-Routinen
//////////////////////////////////////////////////////////////////////////

// Konvertiert eine reelle Zahl in die rationale Form x/y
bool Rational(long double x, long maxtest, long double TOL, long& zaehler, long& nenner);

// Hilfsfunktionen ggT und kgV
long ggT(long x, long y);
long kgV(long x, long y);

// Potenzen
inline long double sqrl(long double x)    { return x*x;}
inline long double kubl(long double x)    { return x*x*x;}
inline long double quadl(long double x)   { return x*x*x*x;}
inline long double pentl(long double x)   { return x*x*x*x*x;}
inline long double sixtl(long double x)   { return x*x*x*x*x*x;}
inline long double septl(long double x)   { return x*x*x*x*x*x*x;}
inline long double octl(long double x)    { return x*x*x*x*x*x*x*x;}

inline double sqr(double x)    { return x*x;}
inline double kub(double x)    { return x*x*x;}
inline double quad(double x)   { return x*x*x*x;}
inline double pent(double x)   { return x*x*x*x*x;}
inline double sixt(double x)   { return x*x*x*x*x*x;}
inline double sept(double x)   { return x*x*x*x*x*x*x;}
inline double oct(double x)    { return x*x*x*x*x*x*x*x;}

// Vorzeichen als long double
inline long double signl(long double x)
{
	if (x > 0.0L) return 1.0L;
	if (x < 0.0L) return -1.0L;
	return 0.0L;
}

inline double sign(double x)
{
	if (x > 0.0) return 1.0;
	if (x < 0.0) return -1.0;
	return 0.0;
}

// Fakult�t
long Fak(long x);
// Binomialkoeffizient (n �ber k)
long BinKoeff(long n, long k);
long double BinKoeffEx(long double ny, long k);

// Ganzzahldivision, Rest
inline int Div(int x, int y)          		{ return div(x,y).quot;};
inline int Mod(int x, int y)          		{ return div(x,y).rem;};
inline long lDiv(long x, long y)      		{ return ldiv(x,y).quot;};
inline long lMod(long x, long y)      		{ return ldiv(x,y).rem;};

// Fibonacci-Zahlen
long double Fibonacci(int n);

// Hilfsfunktionen, liefern "runde" Zahlen zwischen x1 und x2
long double NichtKrumm(long double x1, long double x2);
long double NichtKrumm1(long double x1, long double x2);

////////////////////////////////////////////////////////////
long double ArSinhl(long double x);
long double ArCoshl(long double x);
long double ArTanhl(long double x);
long double ArCothl(long double x);

double ArSinh(double x);
double ArCosh(double x);
double ArTanh(double x);
double ArCoth(double x);

//long double FBessel(long double n, long double x);
inline long double FEulerl()  {return 2.71828182845905L;};
long double FGammal(long double x);

inline double FEuler()  {return 2.71828182845905;};
double FGamma(double x);
