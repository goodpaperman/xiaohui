///////////////////////////////////////////////////////////////////////////////
//                                                                           //
// Dateiname: MATHSTR.CPP                                                    //
//                                                                           //
// Autor:     Andreas J�ger, Friedrich-Schiller-Universit�t Jena             //
//                                                                           //
// System:    WIN_RWPM.EXE und WINLRWPM.EXE                                  //
//                                                                           //
// Beschreibung: String-Klasse, die komfortabel mit Zahlen, Vektoren und     //
//            Matrizen umgehen kann                                          //
//                                                                           //
// Hinweise:                                                                 //
//                                                                           //
///////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include <fstream.h>
#include <math.h>
#include <locale.h>

#include "mathutil.h"
#include "Vektor.h"
#include "MathStr.h"
#include "FktParser.h"

// Konstruktor, der aus einer long double-Zahl einen String macht
// Funktioniert zur Zeit nur f�r den double-Wertebereich.
CMathString::CMathString(long double t, int ndig, bool /*scientific*/, int /*acceptpotenz*/) : CString()
{
	char buffer[40];
	sprintf(buffer, _T("%.*lG"), ndig, t);
	// Kommas in Punkte verwandeln (sollte eleganter gehen)
	for (unsigned int i=0; i<strlen(buffer); i++)
	{
		if (buffer[i]==',') buffer[i]='.';
	}
	*this = CString(buffer);
}

CMathString::CMathString(const CVektor& x, int ndig, bool scientific, char* delimiter,
	char* prefix, char* suffix) : CString(prefix)
{
	for (int i=1;i<=x.Dim;i++)
	{
		CString str = CMathString(x[i], ndig, scientific);
		*this += CMathString(x[i], ndig, scientific);
		if (i<x.Dim) 
		{
			*this += delimiter;
		}
	}
	*this += suffix;
}

CMathString::CMathString(const CMatrix& A, int ndig, bool scientific, char* delimiter,
	char* prefix, char* suffix, char* newline) : CString()
{
	for (int i=1;i<=A.Zeilen();i++)
	{
		*this += prefix;
		for (int j=1;j<=A.Spalten();j++)
		{
			*this += CMathString(A(i,j), ndig, scientific);
			*this += CString(j<A.Spalten() ? delimiter : suffix);
		}
		if (i<A.Zeilen()) 
		{
			*this += newline;
		}
	}
}

CMathString::CMathString(const CPoint& p) 
{
	Format(_T("(%d,%d)"), p.x, p.y);
}

bool CMathString::Replace(int pos, int len, /*CString&*/const char* str)
{
	*this = Left(pos) + str + Mid(pos + len);
	return true;
};

/*
bool CMathString::Replace(int pos, int len, const char* str)
{
	return Replace(pos, len, str);
};
*/

/*
int CMathString::Replace_All(const char* findstring, const char* Replacestring, int _tf)
{
	return Replace_All(CString(findstring), CString(Replacestring), _tf);
}
*/

int CMathString::Replace_All(const char* findstring, const char* Replacestring, int /*_tf*/)
{
	int anz = 0;
	//int tf = get_case_sensitive_flag();
	//set_case_sensitive(_tf);
	int op1 = Find(findstring);
	int op = op1;
	while (op1 != -1)
	{
		Replace(op, strlen(findstring), Replacestring);
		anz++;
		op += strlen(Replacestring);
		CString rest = Mid(op);
		if (rest.IsEmpty() || anz==10) return anz;
		op1 = rest.Find(findstring);
		op += op1;
	}
	//set_case_sensitive(tf);
	return anz;
}

long double CMathString::Value()
{
	CFunction<long double>* fkt = CFunction<long double>::Parse(*this);
	if (fkt)
	{
		long double y = fkt->Execute(0.0);
		delete fkt;
		return y;
	}
	else
		return 0.0;
}

/*
long double CMathString::Value()
{
	long double x1 = 0.0L;
	long double x2 = 1.0L;

	// Suche Minus
	int op = Find(_T("-"));
	if (op != -1 && op > 0 && toupper(GetAt(op-1)) != 'E')
	{
		CMathString s1 = Left(op);
		CMathString s2 = Mid(op + 1);
		x1 = s1.Value();
		x2 = s2.Value();
		return x1 - x2;
	}

	// Suche Plus
	op = Find(_T("+"));
	if (op != -1 && op > 0 && toupper(GetAt(op-1)) != 'E')
	{
		CMathString s1 = Left(op);
		CMathString s2 = Mid(op + 1);
		x1 = s1.Value();
		x2 = s2.Value();
		return x1 + x2;
	}

	// Suche Bruchstrich
	op = Find(_T("/"));
	if (op != -1)
	{
		CMathString s1 = Left(op);
		CMathString s2 = Mid(op + 1);
		x1 = s1.Value();
		x2 = s2.Value();
		if (fabsl(x2) > 1E-18L)
		{
			return x1 / x2;
		}
		else return x1;
	}

	// Suche Mal
	op = Find(_T("*"));
	if (op != -1)
	{
		CMathString s1 = Left(op);
		CMathString s2 = Mid(op + 1);
		x1 = s1.Value();
		x2 = s2.Value();
		return x1 * x2;
	}

	// Suche Potenz
	op = Find(_T("^"));
	if (op != -1)
	{
		CMathString s1 = Left(op);
		CMathString s2 = Mid(op + 1);
		x1 = s1.Value();
		x2 = s2.Value();
		return powl(x1,x2);
	}

	struct lconv* lc = localeconv();
	//AfxMessageBox(lc->decimal_point);

	Replace_All(_T("M_E"),        _T("2.71828182845904523536"));
	Replace_All(_T("M_LOG2E"),    _T("1.44269504088896340736"));
	Replace_All(_T("M_LOG10E"),   _T("0.434294481903251827651"));
	Replace_All(_T("M_LN2"),      _T("0.693147180559945309417"));
	Replace_All(_T("M_LN10"),     _T("2.30258509299404568402"));
	Replace_All(_T("M_PI_2"),     _T("1.57079632679489661923"));
	Replace_All(_T("M_PI_4"),     _T("0.785398163397448309616"));
	Replace_All(_T("M_PI"),       _T("3.14159265358979323846"));
	Replace_All(_T("M_1_PI"),     _T("0.318309886183790671538"));
	Replace_All(_T("M_2_PI"),     _T("0.636619772367581343076"));
	Replace_All(_T("M_1_SQRTPI"), _T("0.564189583547756286948"));
	Replace_All(_T("M_2_SQRTPI"), _T("1.12837916709551257390"));
	Replace_All(_T("M_SQRT2"),    _T("1.41421356237309504880"));
	Replace_All(_T("M_SQRT_2"),   _T("0.707106781186547524401"));
	Replace_All(_T("PI"),         _T("3.14159265358979323846"));
	Replace_All(_T("pi"),         _T("3.14159265358979323846"));
	Replace_All(_T("Pi"),         _T("3.14159265358979323846"));
	Replace_All(_T("."), lc->decimal_point);

	return strtod(*this, 0);
}
*/

long double CMathString::Value(const char* str)
{
	CMathString mstr(str);
	return mstr.Value();
}

CString CMathString::rational(long double x, long maxtest, long double TOL)
{
	char a[35];
#pragma warning ( disable : 4244 )
	long y = x;
#pragma warning ( default : 4244 )
	CString str;
	if (fabsl(y - x) < TOL)
	{
		str = CString(ltoa(y, a, 10));
		return str;
	}
	for (long p=2; p<=maxtest; p++)
	{
#pragma warning ( disable : 4244 )
		y = x*p;
#pragma warning ( default : 4244 )
		if (fabsl(y - p*x) < TOL)
		{
			str = CString(ltoa(y, a, 10));
			str += _T("/");
			str += CString(ltoa(p, a, 10));
			return str;
		}
	}
	return CMathString(x, 20);
}

CString CMathString::rationalTeX(long double x, long maxtest, long double TOL)
{
	char a[35];
#pragma warning ( disable : 4244 )
	long y = x;
#pragma warning ( default : 4244 )
	CString str;
	if (fabsl(y - x) < TOL)
	{
		str = CString(ltoa(y, a, 10));
		return str;
	}
	for (long p=2; p<=maxtest; p++)
	{
#pragma warning ( disable : 4244 )
		y = x*p;
#pragma warning ( default : 4244 )
		if (fabsl(y - p*x) < TOL)
		{
			str = _T("\\frac{");
			str += CString(ltoa(y, a, 10));
			str += _T("}{");
			str += CString(ltoa(p, a, 10));
			str += _T("}");
			return str;
		}
	}
	return CMathString(x, 20);
}

/*
int CMathString::Replace_All(CString& str, const char* findstring, const char* replacestring, int _tf)
{
	return CMathString::Replace_All(str, CString(findstring), CString(replacestring), _tf);
}
*/

int  CMathString::Replace_All(CString& str, /*CString&*/const char* findstring, /*CString&*/const char* replacestring, int /*_tf*/)
{
	int anz = 0;
	//int tf = get_case_sensitive_flag();
	//set_case_sensitive(_tf);
	int op1 = str.Find(findstring);
	int op = op1;
	while (op1 != -1)
	{
		Replace(str, op, strlen(findstring), replacestring);
		anz++;
		op += strlen(replacestring);
		CString rest = str.Mid(op);
		if (rest.IsEmpty() || anz==10) return anz;
		op1 = rest.Find(findstring);
		op += op1;
	}
	//set_case_sensitive(tf);
	return anz;
}

bool CMathString::Replace(CString& str, int pos, int len, /*CString&*/const char* replstr)
{
	str = str.Left(pos) + replstr + str.Mid(pos + len);
	return true;
}

/*
bool CMathString::Replace(CString& str, int pos, int len, const char* replstr)
{
	return Replace(str, pos, len, CString(replstr));
}
*/

void CMathString::MakeUpper1()
{
	MakeUpper1(*this);
}

void CMathString::MakeLower1()
{
	MakeLower1(*this);
}

void CMathString::MakeUpper1(CString& str)
{
	str.MakeUpper();
	Replace_All(str, _T("�"), _T("�"));
	Replace_All(str, _T("�"), _T("�"));
	Replace_All(str, _T("�"), _T("�"));
	Replace_All(str, _T("�"), _T("SS"));
}

void CMathString::MakeLower1(CString& str)
{
	str.MakeUpper();
	Replace_All(str, _T("�"), _T("�"));
	Replace_All(str, _T("�"), _T("�"));
	Replace_All(str, _T("�"), _T("�"));
}

CString CVektor::AsString()
{
	return CMathString(*this, 10, true);
}

CString CLinePoint::AsString()
{
	return CMathString(CVektor(*this), 10, true);
}

CString CMatrix::AsString()
{
	return CMathString(*this, 10, true);
}

