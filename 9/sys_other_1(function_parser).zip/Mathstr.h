///////////////////////////////////////////////////////////////////////////////
//                                                                           //
// Dateiname: MATHSTR.H                                                      //
//                                                                           //
// Autor:     Andreas J�ger, Friedrich-Schiller-Universit�t Jena             //
//                                                                           //
// System:    WIN_RWPM.EXE und WINLRWPM.EXE                                  //
//                                                                           //
// Beschreibung: String-Klasse, die komfortabel mit Zahlen, Vektoren und     //
//            Matrizen umgehen kann                                          //
//                                                                           //
// Hinweise:                                                                 //
//                                                                           //
///////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
// Klasse, die die Konvertierung von Zahlen, Vektoren, Matrizen usw. in
// Strings managt. Zus�tzlich kann ein String als long double interpretiert
// werden, wobei sowohl Konstanten wie PI, M_E usw. als auch mathematische
// Operatoren wie *, /, ^ korrekt verarbeitet werden
//////////////////////////////////////////////////////////////////////////
#ifndef __MATHSTRING__H
#define __MATHSTRING__H

class CMathString : public CString
{
public:
	enum CNumberStyle {
		Normal,
		Scientific,
		Rational
	};

	// ndig: Dezimalstellen der Mantisse
	// scientific == true: Exponential-Darstellung
	// acceptpotenz: z.B == 2: Zahlen 1E-2 bis 9.999..E+2 werden nicht in E-Darstellung ausgegeben
	CMathString(long double t, int ndig = 6, bool scientific = false, int acceptpotenz = 0);
	CMathString(const CVektor& x, int ndig = 6, bool scientific = false, char* delimiter = _T(","), char* prefix = _T("["), char* suffix = _T("]"));
	CMathString(const CMatrix& A, int ndig = 6, bool scientific = false, char* delimiter = _T(","), char* prefix = _T("["), char* suffix = _T("]"), char* newline = _T("\n"));
	CMathString(const CPoint& p);
	
	CMathString() : CString() {};
	CMathString(const CString &s) : CString(s) {};

	long double Value();
	//int  Replace_All(CString& findstring, CString& replacestring, int _tf = 0);
	int  Replace_All(const char* findstring, const char* replacestring, int _tf = 0);
	//bool Replace(int pos, int len, CString& str);
	bool Replace(int pos, int len, const char* str);

	void MakeUpper1();
	void MakeLower1();

	static long double Value(const char* str);
	static CString rational(long double x, long maxtest = 10000L, long double TOL = 1E-14L);
	static CString rationalTeX(long double x, long maxtest = 10000L, long double TOL = 1E-14L);
	//static int  Replace_All(CString& str, CString& findstring, CString& replacestring, int _tf = 0);
	static int Replace_All(CString& str, const char* findstring, const char* replacestring, int _tf = 0);
	//static bool Replace(CString& str, int pos, int len, CString& replstr);
	static bool Replace(CString& str, int pos, int len, const char* replstr);

	static void MakeUpper1(CString& str);
	static void MakeLower1(CString& str);

	virtual void Serialize(CArchive& /*ar*/)  {};
};

#endif // #ifndef __MATHSTRING__H
