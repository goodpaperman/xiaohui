class CVektor;
class CLinePoint;
class CMatrix;
//class CVektorList;
//class CVektorListIterator;
//class CMatrixList;
//class CMatrixListIterator;

#define infty -1

void DDX_Vektor(CDataExchange* pDX, CListCtrl& control, CVektor& v, const char* Title = NULL, bool trans = false);
void DDX_Matrix(CDataExchange* pDX, CListCtrl& control, CMatrix& M, const char* Title = NULL);

class CLinePoint : public CObject
{
friend CVektor;
public:

//private:
	
	float* hadr;
	int  Dim;    		// Dimension

public:
	// Konstruktor(en) und Standard-Konstruktor (dim-dimensionaler Vektor)
	CLinePoint(int dim = 1);   	// Transponierter Vektor
	CLinePoint(const CVektor& v);                   		// Kopier-Konstruktor
	CLinePoint(long double t, const CVektor& x);
	CLinePoint(const CLinePoint& v);                   		// Kopier-Konstruktor
	CLinePoint(long double t, const CLinePoint& x);
	
	// Destructor
	virtual ~CLinePoint();

	// Dimension
	int  GetDim() const            {return Dim;};
	void SetDim(int dim);

	// Element-Manipulatoren
	float  GetC(int i) const;
	void SetC(int i, float Val);
	
	float& operator ()(int i)      {return hadr[i-1];};
	float& operator [](int i)      {return hadr[i-1];};

	float operator ()(int i) const {return hadr[i-1];};
	float operator [](int i) const {return hadr[i-1];};

	void Clear();

	// Zuweisungsoperator
	CLinePoint&  operator  =(const CLinePoint v);
	
	// CLinePoint wird in String konvertiert
	CString AsString();

	// Serialization
	virtual void Serialize(CArchive& ar);

	// Stream-Operationen
	friend ostream& operator <<( ostream& os, CLinePoint& v);
	friend istream& operator >>( istream& is, CLinePoint& v);
}; // class TLinePoint

//////////////////////////////////////////////////////////////////////////
// Vektoren
//////////////////////////////////////////////////////////////////////////
class CVektor : public CObject
{
friend CMatrix;
public:
	enum CStatus {
		Invalid = 0,
		SpaltenVektor,
		ZeilenVektor
	};
//private:
	long double* hadr;

	CStatus Status;    // �bernimmt die Funktion von int CVektor::valid und int CVektor::trans
	int   Dim;    		// Dimension
	short sub;    		// = 1 hei�t Subvektor
	CString Name;

public:
	// Automatische Dimensionsbestimmung
	short Test; // = 1  hei�t indirekte Dimensionsbestimmung, sonst 0 f�r normal
	int   TDim;

public:
	// Konstruktor(en) und Standard-Konstruktor
	CVektor(int dim = 1, const char* name = _T("(unbenannt)"), bool t = false);   	// Transponierter Vektor
	CVektor(long double a);										// ein-dimensionaler Vektor
	CVektor(long double a, long double b);
	CVektor(long double a, long double b, long double c);									
	CVektor(long double a, long double b, long double c, long double d);
	CVektor(int dim, short s,bool t,long double *z); 		// "Kopier"-Konstruktor
	CVektor(const CVektor& v);                   		// Kopier-Konstruktor
	CVektor(const CMatrix& M);                   		// Einspaltige oder einzeilige Matrix wird in Vektor konvertiert
	CVektor(long double t, const CVektor& x);
	CVektor(long double t, const CLinePoint& x);
	CVektor(const CLinePoint& x);
	//CVektor(TList<long double> & list);
	// Destructor
	virtual ~CVektor();

	void Define_Vektor/* 0*/();
	void Define_Vektor/* 1*/(long double x1);
	void Define_Vektor/* 2*/(long double x1, long double x2);
	void Define_Vektor/* 3*/(long double x1, long double x2, long double x3);
	void Define_Vektor/* 4*/(long double x1, long double x2, long double x3, long double x4);
	void Define_Vektor/* 5*/(long double x1, long double x2, long double x3, long double x4, long double x5);
	void Define_Vektor/* 6*/(long double x1, long double x2, long double x3, long double x4, long double x5, long double x6);
	void Define_Vektor/* 7*/(long double x1, long double x2, long double x3, long double x4, long double x5, long double x6, long double x7);
	void Define_Vektor/* 8*/(long double x1, long double x2, long double x3, long double x4, long double x5, long double x6, long double x7, long double x8);
	void Define_Vektor/* 9*/(long double x1, long double x2, long double x3, long double x4, long double x5, long double x6, long double x7, long double x8, long double x9);
	void Define_Vektor/*10*/(long double x1, long double x2, long double x3, long double x4, long double x5, long double x6, long double x7, long double x8, long double x9, long double x10);
	void Define_Vektor/*11*/(long double x1, long double x2, long double x3, long double x4, long double x5, long double x6, long double x7, long double x8, long double x9, long double x10, long double x11);
	void Define_Vektor/*12*/(long double x1, long double x2, long double x3, long double x4, long double x5, long double x6, long double x7, long double x8, long double x9, long double x10, long double x11, long double x12);
	void Define_Vektor/*13*/(long double x1, long double x2, long double x3, long double x4, long double x5, long double x6, long double x7, long double x8, long double x9, long double x10, long double x11, long double x12, long double x13);
	void Define_Vektor/*14*/(long double x1, long double x2, long double x3, long double x4, long double x5, long double x6, long double x7, long double x8, long double x9, long double x10, long double x11, long double x12, long double x13, long double x14);
	void Define_Vektor/*15*/(long double x1, long double x2, long double x3, long double x4, long double x5, long double x6, long double x7, long double x8, long double x9, long double x10, long double x11, long double x12, long double x13, long double x14, long double x15);

	CString GetName() const {return Name.IsEmpty() ? _T("Vektor (unbenannt)") : Name;}
	CVektor& EinheitsVektor(int);

	// Status-�berpr�fung
	bool IsValid() const                           {return (Status != Invalid) || (Dim == 0 && hadr == NULL);};
	bool IsZeile() const                           {return Status == ZeilenVektor;};
	bool IsSpalte() const                          {return Status == SpaltenVektor;};

	// Dimension
	int  GetDim() const                            {return Dim;};
	void SetDim(int dim);
	void ForceDimension(int dim);

	// Vektor transponieren
	void SetTrans(bool t = false);
	void Transpose();
	friend CVektor operator !(const CVektor& v);                   // Vektor wird transponiert

	// Element-Manipulatoren
	long double  GetC(int i) const;
	long double& GetC(int i);
	void SetC(int i, long double Val);
	long double& operator ()(int i);
	long double& operator [](int i);
	CMatrix Diag() const;

	long double operator ()(int i) const;
	long double operator [](int i) const;

	void Clear();

	// Zuweisungsoperator
	CVektor&  operator=(const CVektor& v);
	CVektor&  operator=(long double a);
	CVektor&  operator=(const CString& s);
	
	// Operatoren
	CVektor&  operator +=(const CVektor& v);
	CVektor&  operator -=(const CVektor& v);
	CVektor&  operator *=(long double  a);
	CVektor&  operator /=(long double  a);
	CVektor&  operator  =(const CMatrix& M);
	CVektor   operator ()(int i,int j);	// Sub-Vektor
	CVektor   GetSubVektor(int i,int j) const;	// Sub-Vektor

    friend int operator==(const CVektor& v, const CVektor& w);
    friend int operator!=(const CVektor& v, const CVektor& w);

	// Gibt den CVektor in einen String aus
	CString AsString();

	// Normen
	long double Norm(int n = 2) const;
	long double SqrNorm2() const;    // Quadrat der euklid. Norm

	friend long double Norm(const CVektor& v, int n = 2);
	friend long double Norm(const CVektor& v1, const CVektor& v2, int n = 2);
	friend long double SqrNorm2(const CVektor& v);    // Quadrat der euklid. Norm
	friend long double SqrNorm2(const CVektor& v1, const CVektor& v2);    // Quadrat der euklid. Norm

	// Elementweise Manipulation
	void sin();
	void cos();
	void tan();
	void cot();
	void abs();
	void UserFunction(const char* FunktionsTerm, const char* Variable = _T("x"));

		// Komponentenweise Funktionen
	friend CVektor sin(const CVektor& v);
	friend CVektor cos(const CVektor& v);
	friend CVektor tan(const CVektor& v);
	friend CVektor cot(const CVektor& v);
	friend CVektor abs(const CVektor& v);
	friend CVektor UserFunction(const CVektor& v, const char* FunktionsTerm, const char* Variable = _T("x"));

	// Spezielle Vektoren
	void NullVektor()                              {Clear();};
	void EinsVektor();
	void Random();

	friend CVektor NullVektor(int dim);
	friend CVektor EinheitsVektor(int dim, int k);
	friend CVektor EinsVektor(int dim);

	friend CMatrix Diag(const CVektor& v);

	// Vektorraum-Operationen
	friend  CVektor operator +(const CVektor& v,const CVektor& w);
	friend  CVektor operator -(const CVektor& v,const CVektor& w);
	friend  CVektor operator *(const long double a,const CVektor& v);
	friend  CVektor operator *(const CVektor& v,const long double a);
	friend  CVektor operator /(const CVektor& v,const CVektor& w);   // komponentenweise
	friend  CVektor operator /(const CVektor& v,const long double a);
	friend  CMatrix operator *(const CVektor& v,const CVektor& w);

	friend long double Skalarprodukt(const CVektor& v, const CVektor& w);
	friend CVektor Kreuzprodukt(const CVektor& v, const CVektor& w);
	friend long double SpatProdukt(const CVektor& u, const CVektor& v, const CVektor& w);

	// addiert c*x2
	void Saxpy(long double c, const CVektor& x2);
	void Saxpy(long double a1,long double a2, const CVektor& v2);
	void Saxpy(long double a1,long double a2, const CVektor& v2,long double a3, const CVektor& v3);
	void Saxpy(long double a1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4);
	void Saxpy(long double a1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5);
	void Saxpy(long double a1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6);
	void Saxpy(long double a1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,long double a7, const CVektor& v7);
	void Saxpy(long double a1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,long double a7, const CVektor& v7,long double a8, const CVektor& v8);
	void Saxpy(long double a1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,long double a7, const CVektor& v7,long double a8, const CVektor& v8,long double a9, const CVektor& v9);
	void Saxpy(long double a1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,long double a7, const CVektor& v7,long double a8, const CVektor& v8,long double a9, const CVektor& v9,long double a10, const CVektor& v10);
	void Saxpy(long double a1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,long double a7, const CVektor& v7,long double a8, const CVektor& v8,long double a9, const CVektor& v9,long double a10, const CVektor& v10,long double a11, const CVektor& v11);
	void Saxpy(long double a1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,long double a7, const CVektor& v7,long double a8, const CVektor& v8,long double a9, const CVektor& v9,long double a10, const CVektor& v10,long double a11, const CVektor& v11,long double a12, const CVektor& v12);
	void Saxpy(long double a1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,long double a7, const CVektor& v7,long double a8, const CVektor& v8,long double a9, const CVektor& v9,long double a10, const CVektor& v10,long double a11, const CVektor& v11,long double a12, const CVektor& v12,long double a13, const CVektor& v13);
	void Saxpy(long double a1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,long double a7, const CVektor& v7,long double a8, const CVektor& v8,long double a9, const CVektor& v9,long double a10, const CVektor& v10,long double a11, const CVektor& v11,long double a12, const CVektor& v12,long double a13, const CVektor& v13,long double a14, const CVektor& v14);

	// berechnet x1 + c2*x2
	friend  CVektor Saxpy(const CVektor& x1, long double c2, const CVektor& x2);

	friend  CVektor  lc(long double a1, const CVektor& v1);
	friend  CVektor  lc(long double a1, const CVektor& v1,long double a2, const CVektor& v2);
	friend  CVektor  lc(long double a1, const CVektor& v1,long double a2, const CVektor& v2,long double a3, const CVektor& v3);
	friend  CVektor  lc(long double a1, const CVektor& v1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4);
	friend  CVektor  lc(long double a1, const CVektor& v1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5);
	friend  CVektor  lc(long double a1, const CVektor& v1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6);
	friend  CVektor  lc(long double a1, const CVektor& v1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,long double a7, const CVektor& v7);
	friend  CVektor  lc(long double a1, const CVektor& v1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,long double a7, const CVektor& v7,long double a8, const CVektor& v8);
	friend  CVektor  lc(long double a1, const CVektor& v1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,long double a7, const CVektor& v7,long double a8, const CVektor& v8,long double a9, const CVektor& v9);
	friend  CVektor  lc(long double a1, const CVektor& v1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,long double a7, const CVektor& v7,long double a8, const CVektor& v8,long double a9, const CVektor& v9,long double a10, const CVektor& v10);
	friend  CVektor  lc(long double a1, const CVektor& v1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,long double a7, const CVektor& v7,long double a8, const CVektor& v8,long double a9, const CVektor& v9,long double a10, const CVektor& v10,long double a11, const CVektor& v11);
	friend  CVektor  lc(long double a1, const CVektor& v1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,long double a7, const CVektor& v7,long double a8, const CVektor& v8,long double a9, const CVektor& v9,long double a10, const CVektor& v10,long double a11, const CVektor& v11,long double a12, const CVektor& v12);
	friend  CVektor  lc(long double a1, const CVektor& v1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,long double a7, const CVektor& v7,long double a8, const CVektor& v8,long double a9, const CVektor& v9,long double a10, const CVektor& v10,long double a11, const CVektor& v11,long double a12, const CVektor& v12,long double a13, const CVektor& v13);

	friend  void  lc(long double a1, const CVektor& v1,CVektor& t);
	friend  void  lc(long double a1, const CVektor& v1,long double a2, const CVektor& v2,CVektor& t);
	friend  void  lc(long double a1, const CVektor& v1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,CVektor& t);
	friend  void  lc(long double a1, const CVektor& v1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,CVektor& t);
	friend  void  lc(long double a1, const CVektor& v1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,CVektor& t);
	friend  void  lc(long double a1, const CVektor& v1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,CVektor& t);
	friend  void  lc(long double a1, const CVektor& v1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,long double a7, const CVektor& v7,CVektor& t);
	friend  void  lc(long double a1, const CVektor& v1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,long double a7, const CVektor& v7,long double a8, const CVektor& v8,CVektor& t);
	friend  void  lc(long double a1, const CVektor& v1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,long double a7, const CVektor& v7,long double a8, const CVektor& v8,long double a9, const CVektor& v9,CVektor& t);
	friend  void  lc(long double a1, const CVektor& v1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,long double a7, const CVektor& v7,long double a8, const CVektor& v8,long double a9, const CVektor& v9,long double a10, const CVektor& v10,CVektor& t);
	friend  void  lc(long double a1, const CVektor& v1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,long double a7, const CVektor& v7,long double a8, const CVektor& v8,long double a9, const CVektor& v9,long double a10, const CVektor& v10,long double a11, const CVektor& v11,CVektor& t);
	friend  void  lc(long double a1, const CVektor& v1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,long double a7, const CVektor& v7,long double a8, const CVektor& v8,long double a9, const CVektor& v9,long double a10, const CVektor& v10,long double a11, const CVektor& v11,long double a12, const CVektor& v12,CVektor& t);
	friend  void  lc(long double a1, const CVektor& v1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,long double a7, const CVektor& v7,long double a8, const CVektor& v8,long double a9, const CVektor& v9,long double a10, const CVektor& v10,long double a11, const CVektor& v11,long double a12, const CVektor& v12,long double a13, const CVektor& v13,CVektor& t);

	friend  CVektor  Saxpy(const CVektor& v1,long double a1,long double a2, const CVektor& v2);
	friend  CVektor  Saxpy(const CVektor& v1,long double a1,long double a2, const CVektor& v2,long double a3, const CVektor& v3);
	friend  CVektor  Saxpy(const CVektor& v1,long double a1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4);
	friend  CVektor  Saxpy(const CVektor& v1,long double a1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5);
	friend  CVektor  Saxpy(const CVektor& v1,long double a1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6);
	friend  CVektor  Saxpy(const CVektor& v1,long double a1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,long double a7, const CVektor& v7);
	friend  CVektor  Saxpy(const CVektor& v1,long double a1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,long double a7, const CVektor& v7,long double a8, const CVektor& v8);
	friend  CVektor  Saxpy(const CVektor& v1,long double a1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,long double a7, const CVektor& v7,long double a8, const CVektor& v8,long double a9, const CVektor& v9);
	friend  CVektor  Saxpy(const CVektor& v1,long double a1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,long double a7, const CVektor& v7,long double a8, const CVektor& v8,long double a9, const CVektor& v9,long double a10, const CVektor& v10);
	friend  CVektor  Saxpy(const CVektor& v1,long double a1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,long double a7, const CVektor& v7,long double a8, const CVektor& v8,long double a9, const CVektor& v9,long double a10, const CVektor& v10,long double a11, const CVektor& v11);
	friend  CVektor  Saxpy(const CVektor& v1,long double a1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,long double a7, const CVektor& v7,long double a8, const CVektor& v8,long double a9, const CVektor& v9,long double a10, const CVektor& v10,long double a11, const CVektor& v11,long double a12, const CVektor& v12);
	friend  CVektor  Saxpy(const CVektor& v1,long double a1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,long double a7, const CVektor& v7,long double a8, const CVektor& v8,long double a9, const CVektor& v9,long double a10, const CVektor& v10,long double a11, const CVektor& v11,long double a12, const CVektor& v12,long double a13, const CVektor& v13);

	friend  void  Saxpy(const CVektor& v1,long double a1,long double a2, const CVektor& v2,CVektor& t);
	friend  void  Saxpy(const CVektor& v1,long double a1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,CVektor& t);
	friend  void  Saxpy(const CVektor& v1,long double a1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,CVektor& t);
	friend  void  Saxpy(const CVektor& v1,long double a1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,CVektor& t);
	friend  void  Saxpy(const CVektor& v1,long double a1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,CVektor& t);
	friend  void  Saxpy(const CVektor& v1,long double a1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,long double a7, const CVektor& v7,CVektor& t);
	friend  void  Saxpy(const CVektor& v1,long double a1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,long double a7, const CVektor& v7,long double a8, const CVektor& v8,CVektor& t);
	friend  void  Saxpy(const CVektor& v1,long double a1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,long double a7, const CVektor& v7,long double a8, const CVektor& v8,long double a9, const CVektor& v9,CVektor& t);
	friend  void  Saxpy(const CVektor& v1,long double a1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,long double a7, const CVektor& v7,long double a8, const CVektor& v8,long double a9, const CVektor& v9,long double a10, const CVektor& v10,CVektor& t);
	friend  void  Saxpy(const CVektor& v1,long double a1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,long double a7, const CVektor& v7,long double a8, const CVektor& v8,long double a9, const CVektor& v9,long double a10, const CVektor& v10,long double a11, const CVektor& v11,CVektor& t);
	friend  void  Saxpy(const CVektor& v1,long double a1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,long double a7, const CVektor& v7,long double a8, const CVektor& v8,long double a9, const CVektor& v9,long double a10, const CVektor& v10,long double a11, const CVektor& v11,long double a12, const CVektor& v12,CVektor& t);
	friend  void  Saxpy(const CVektor& v1,long double a1,long double a2, const CVektor& v2,long double a3, const CVektor& v3,long double a4, const CVektor& v4,long double a5, const CVektor& v5,long double a6, const CVektor& v6,long double a7, const CVektor& v7,long double a8, const CVektor& v8,long double a9, const CVektor& v9,long double a10, const CVektor& v10,long double a11, const CVektor& v11,long double a12, const CVektor& v12,long double a13, const CVektor& v13,CVektor& t);

	// Serialization
	virtual void Serialize(CArchive& ar);

	// Stream-Operationen
	friend ostream&  operator <<(ostream& os, CVektor& v);
	friend istream&  operator >>(istream& is, CVektor& v);

	virtual ostream&  SaveBinary(ostream& os);
	virtual istream&  LoadBinary(istream& is);

	friend istream&  Read (istream& is, CVektor& v);

	void SaveMATLAB(ostream& os, const char* name = NULL);

	// Ausgabe in einen Ger�tekontext
	void Draw(CDC* dc, CRect& rect);
}; // class CVektor

//////////////////////////////////////////////////////////////////////////
// Matrizen
//////////////////////////////////////////////////////////////////////////
class CMatrix : public CObject
{
friend CVektor;
public:
	long double** hadr;
	int           xDim;
	int           yDim;
	int           sub;
	CString       Name;

private:
	int   RSN;   // Zahl der Zeilenvertauschungen, z.B. bei der Determinante verwendet

public:
	enum CStatus {
			Invalid,
			Normal,
			LU_Faktorisiert,
			QR_Faktorisiert,
			GG_Faktorisiert,
			Hessenbergform,
			QR_Bidiagonalisiert
	};
	CMatrix(int d1,int d2, const char* name = _T("(unbenannt)"));
	CMatrix();
	CMatrix(int d1,int d2,int s);
	CMatrix(const CMatrix& M);
	CMatrix(const CVektor& v);
	// Zeilenweise oder spaltenweises Konstruieren (Standard: spaltenweise)
	CMatrix(const CVektor& v1, const CVektor& v2, bool zeile = false);
	CMatrix(const CVektor& v1, const CVektor& v2, const CVektor& v3, bool zeile = false);
	CMatrix(const CVektor& v1, const CVektor& v2, const CVektor& v3, const CVektor& v4, bool zeile = false);

	//CMatrix(TCVektorList  & L);
	// Konstruktoren f�r kleine quadratische Matrizen
	CMatrix(long double a11);
	CMatrix(long double a11, long double a12, long double a21, long double a22);
	CMatrix(long double a11, long double a12, long double a13, long double a21, long double a22, long double a23, long double a31, long double a32, long double a33);
	CMatrix(long double a11, long double a12, long double a13, long double a14, long double a21, long double a22, long double a23, long double a24, long double a31, long double a32, long double a33, long double a34, long double a41, long double a42, long double a43, long double a44);
	// Destruktor
	virtual ~CMatrix();

	void Define_Matrix(int d1, ...);
	void Define_UMatrix(int d1, ...);

	CString GetName() const {return Name.IsEmpty() ? _T("Matrix (unbenannt)") : Name;}

	int GetxDim() const {return xDim;};
	int GetyDim() const {return yDim;};
	int Zeilen () const {return xDim;};
	int Spalten() const {return yDim;};
	void SetDim(int d1,int d2);
	void ForceDimension(int d1,int d2);

	long double  GetC(int i,int j) const;
	long double& GetC(int i,int j);
	void SetC(int i,int j,long double Val);
	long double& operator ()(int i,int j);
	long double operator ()(int i,int j) const;
	CVektor GetRow(int row) const;
	CVektor GetCol(int col) const;
	CVektor ZeilenSummen() const;
	CVektor SpaltenSummen() const;
	CVektor Diag() const;

	// Spezielle Matrizen
	void Clear();
	void EinheitsMatrix();
	void EinsMatrix();
	void NegEinheitsMatrix();
	void OberesDreieck();
	void UnteresDreieck();
	void Random();

	friend CMatrix SquareRoot(const CMatrix& A);
	friend CMatrix Exp(const CMatrix& A);

	friend CMatrix NullMatrix(const CMatrix& M);
	friend CMatrix NullMatrix(int dim);
	friend CMatrix NullMatrix(int zeilen, int spalten);

	friend CMatrix EinheitsMatrix(const CMatrix& M);
	friend CMatrix EinheitsMatrix(int dim);
	friend CMatrix EinheitsMatrix(int zeilen, int spalten);

	friend CMatrix NegEinheitsMatrix(const CMatrix& M);
	friend CMatrix NegEinheitsMatrix(int dim);
	friend CMatrix NegEinheitsMatrix(int zeilen, int spalten);

	friend CMatrix OberesDreieck(const CMatrix& M);
	friend CMatrix UnteresDreieck(const CMatrix& M);

	friend CVektor Diag(const CMatrix& M);

	// Gaxpy-Operation
	friend CVektor Gaxpy(const CMatrix& A, const CVektor& x, const CVektor& y);

	void ResizeRows(int zeilen);

protected:
	CStatus Status;

public:
	CMatrix& operator  =(const CMatrix& M);
	CMatrix& operator  =(const CVektor& v);
	CMatrix& operator  =(long double x);
	CMatrix& operator +=(const CMatrix& M);
	CMatrix& operator -=(const CMatrix& M);
	CMatrix& operator *=(long double  a);
	CMatrix& operator /=(long double  a);
	CMatrix  operator ()(int i,int j,int k,int l);
	CMatrix  GetSubMatrix(int i,int j,int k,int l) const;

    friend int operator==(const CMatrix& A, const CMatrix& B);
    friend int operator!=(const CMatrix& A, const CMatrix& B);

	CString AsString();

	void Error(char* str)  {AfxMessageBox(str);};

	friend CMatrix  operator !(const CMatrix& M);				// Transponieren
	friend CMatrix  operator +(const CMatrix& M, const CMatrix& N);
	friend CMatrix  operator -(const CMatrix& M, const CMatrix& N);
	friend CMatrix  operator *(long double a, const CMatrix& M);
	friend CMatrix  operator *(const CMatrix& M, long double a);
	friend CMatrix  operator /(const CMatrix& M, long double a);
	friend CMatrix  operator *(const CMatrix& M, const CMatrix& N);
	friend CVektor  operator *(const CMatrix& M, const CVektor& v);
	friend CVektor  operator *(const CVektor& v, const CMatrix& M);

	void sin();
	void cos();
	void tan();
	void cot();
	void abs();
	void UserFunction(const char* FunktionsTerm, const char* Variable = _T("x"));

	// Komponentenweise Funktionen
	friend CMatrix sin(const CMatrix& M);
	friend CMatrix cos(const CMatrix& M);
	friend CMatrix tan(const CMatrix& M);
	friend CMatrix cot(const CMatrix& M);
	friend CMatrix abs(const CMatrix& M);
	friend CMatrix UserFunction(const CMatrix& M, const char* FunktionsTerm, const char* Variable = _T("x"));

	// Serialization
	virtual void Serialize(CArchive& ar);

	friend ostream&  operator <<(ostream& os, CMatrix& M);
	friend istream&  operator >>(istream& is, CMatrix& M);

	virtual ostream&  SaveBinary(ostream& os);
	virtual istream&  LoadBinary(istream& is);

	friend istream&  Read (istream& is, CMatrix& M);

	void RowSwap(int a,int b);

	CStatus GetStatus() const                  {return Status;};
	void SetStatus(CStatus status)             {Status = status;};
	bool IsValid() const                       {return Status != Invalid;};
	// Faktorisierungen
	bool LU(bool ignorestatus = false);
	friend  bool LU(CMatrix& A, CMatrix& L, CMatrix& U, bool ignorestatus = false);
	friend  bool LU(CMatrix& A, bool ignorestatus = false) {return A.LU(ignorestatus);};
	bool QR(CMatrix* Q = NULL, bool ignorestatus = false)    //Abk�rzung f�r Householder_QR(...)
	{
		return Householder_QR(Q, ignorestatus);
	};
	bool Householder_QR(CMatrix* Q = NULL, bool ignorestatus = false);
	friend  bool QR (CMatrix& A,CMatrix& Q,CMatrix& R, bool ignorestatus = false);
	friend  bool GG (CMatrix& A, bool ignorestatus = false);
	friend  bool GG (CMatrix& A,CMatrix& G, bool ignorestatus = false);

	// Transformationen
	friend  bool _QR   (CMatrix& A, bool ignorestatus = false);                       // evtl. nur noch eine Funktion
	bool _QR(bool ignorestatus = false) {return ::_QR(*this, ignorestatus);};
	friend  bool _QR   (CMatrix& A,CMatrix* Q,CMatrix* R = NULL, bool ignorestatus = false);
	bool _QR(CMatrix* Q,CMatrix* R = NULL, bool ignorestatus = false)  {return ::_QR(*this, Q, R, ignorestatus);};

	friend  bool HQR   (CMatrix& A);
	friend  bool HQR   (CMatrix& A, CMatrix& Q, CMatrix& R);
	friend  bool QRH   (CMatrix& A);
	friend  bool QRH   (CMatrix& A, CMatrix& Q, CMatrix& R);
	friend  bool BIQR  (CMatrix& A);
	friend  bool BIQR  (CMatrix& A, CMatrix& U, CMatrix& B, CMatrix& V);

	friend  void house    (CVektor& x, CVektor& v);
	friend 	void rowhouse (CMatrix& A, const CVektor& v);
	friend 	void rowhouse (CVektor& a, const CVektor& v);
	friend 	void colhouse (CMatrix& A, const CVektor& v);
	friend 	void givens   (long double  a,long double b, long double  & c,long double  & s);
	friend 	void rowgivens(CMatrix& A, long double c, long double s);
	friend 	void colgivens(CMatrix& A, long double c, long double s);

	friend 	void eiggiv   (CMatrix& A);
	friend 	void giv      (CMatrix& A, long double c ,long double s);
	friend 	void rebidiag (CMatrix& A);
	// Gleichungssysteme
	// Vorw�rtssubstitution, untere DreicksMatrix
	friend  bool Vorw_Subst_(CMatrix& A, const CVektor& b, CVektor& x, bool ignorestatus = false);
	// Vorw�rtssubstitution, untere 1-DreicksMatrix (f�r LU usw.)
	friend  bool Vorw_Subst1(CMatrix& A, const CVektor& b, CVektor& x, bool ignorestatus = false);
	friend  bool Rueckw_Subst(CMatrix& A, const CVektor& b, CVektor& x, bool ignorestatus = false);
	friend  bool LU_Loesung(CMatrix& A, const CVektor& b, CVektor& x, bool ignorestatus = false)
	{
		return A.LU(ignorestatus) && Vorw_Subst1(A, b, x, ignorestatus) && Rueckw_Subst(A, b, x, ignorestatus);
	};
	friend CVektor LU_Loesung(CMatrix& A, const CVektor& b, bool ignorestatus = false);
	friend bool QR_Solve (CMatrix& A, const CVektor& b, CVektor& x, long double TOL = 1E-6L);
	friend bool GG_Solve (CMatrix& A, const CVektor& b, CVektor& x, long double TOL = 1E-6L);
	friend CMatrix inv(CMatrix& A);

	// Eigenwerte

	// Normen
	long double FrobeniusNorm() const;
	long double ZeilensummenNorm() const;
	long double SpaltensummenNorm() const;
	long double GesamtNorm() const;
	long double SpektralNorm() const;

	friend long double FrobeniusNorm(const CMatrix& A);
	friend long double ZeilensummenNorm(const CMatrix& A);
	friend long double SpaltensummenNorm(const CMatrix& A);
	friend long double GesamtNorm(const CMatrix& A);
	friend long double SpektralNorm(const CMatrix& A);

	// Determinante
	friend 	long double Det   (CMatrix& A);
	long double Det();

	// Singul�rwerte
	friend 	bool SVD (CMatrix& A, CVektor& v, long double TOL = 1E-6L);
	bool SVD(CVektor& v, long double TOL = 1E-6L)  {return ::SVD(*this, v, TOL);};
	bool Cholesky_SVD();

private:
	int* perm;   // Bei der LU-Faktorisierung als PermutaionsMatrix mi�braucht

	// Ausgabe in einen Ger�tekontext
	void Draw(CDC* dc, CRect& rect);
};

//////////////////////////////////////////////////////////////////////////
// Makros zum Definieren von Vektoren und CMatrixrizen
//////////////////////////////////////////////////////////////////////////
inline void CVektor::Define_Vektor()
{
	SetDim(0);
};

inline void CVektor::Define_Vektor(long double x1)
{
	SetDim(1);
	hadr[ 0] = x1;
};

inline void CVektor::Define_Vektor/* 2*/(long double x1, long double x2)
{
	SetDim(2);
	hadr[ 0] = x1;
	hadr[ 1] = x2;
};

inline void CVektor::Define_Vektor/* 3*/(long double x1, long double x2, long double x3)
{
	SetDim(3);
	hadr[ 0] = x1;
	hadr[ 1] = x2;
	hadr[ 2] = x3;
};

inline void CVektor::Define_Vektor/* 4*/(long double x1, long double x2, long double x3, long double x4)
{
	SetDim(4);
	hadr[ 0] = x1;
	hadr[ 1] = x2;
	hadr[ 2] = x3;
	hadr[ 3] = x4;
};

inline void CVektor::Define_Vektor/* 5*/(long double x1, long double x2, long double x3, long double x4, long double x5)
{
	SetDim(5);
	hadr[ 0] = x1;
	hadr[ 1] = x2;
	hadr[ 2] = x3;
	hadr[ 3] = x4;
	hadr[ 4] = x5;
};

inline void CVektor::Define_Vektor/* 6*/(long double x1, long double x2, long double x3, long double x4, long double x5, long double x6)
{
	SetDim(6);
	hadr[ 0] = x1;
	hadr[ 1] = x2;
	hadr[ 2] = x3;
	hadr[ 3] = x4;
	hadr[ 4] = x5;
	hadr[ 5] = x6;
};

inline void CVektor::Define_Vektor/* 7*/(long double x1, long double x2, long double x3, long double x4, long double x5, long double x6, long double x7)
{
	SetDim(7);
	hadr[ 0] = x1;
	hadr[ 1] = x2;
	hadr[ 2] = x3;
	hadr[ 3] = x4;
	hadr[ 4] = x5;
	hadr[ 5] = x6;
	hadr[ 6] = x7;
};

inline void CVektor::Define_Vektor/* 8*/(long double x1, long double x2, long double x3, long double x4, long double x5, long double x6, long double x7, long double x8)
{
	SetDim(8);
	hadr[ 0] = x1;
	hadr[ 1] = x2;
	hadr[ 2] = x3;
	hadr[ 3] = x4;
	hadr[ 4] = x5;
	hadr[ 5] = x6;
	hadr[ 6] = x7;
	hadr[ 7] = x8;
};

inline void CVektor::Define_Vektor/* 9*/(long double x1, long double x2, long double x3, long double x4, long double x5, long double x6, long double x7, long double x8, long double x9)
{
	SetDim(9);
	hadr[ 0] = x1;
	hadr[ 1] = x2;
	hadr[ 2] = x3;
	hadr[ 3] = x4;
	hadr[ 4] = x5;
	hadr[ 5] = x6;
	hadr[ 6] = x7;
	hadr[ 7] = x8;
	hadr[ 8] = x9;
};

inline void CVektor::Define_Vektor/*10*/(long double x1, long double x2, long double x3, long double x4, long double x5, long double x6, long double x7, long double x8, long double x9, long double x10)
{
	SetDim(10);
	hadr[ 0] = x1;
	hadr[ 1] = x2;
	hadr[ 2] = x3;
	hadr[ 3] = x4;
	hadr[ 4] = x5;
	hadr[ 5] = x6;
	hadr[ 6] = x7;
	hadr[ 7] = x8;
	hadr[ 8] = x9;
	hadr[ 9] = x10;
};

inline void CVektor::Define_Vektor/*11*/(long double x1, long double x2, long double x3, long double x4, long double x5, long double x6, long double x7, long double x8, long double x9, long double x10, long double x11)
{
	SetDim(11);
	hadr[ 0] = x1;
	hadr[ 1] = x2;
	hadr[ 2] = x3;
	hadr[ 3] = x4;
	hadr[ 4] = x5;
	hadr[ 5] = x6;
	hadr[ 6] = x7;
	hadr[ 7] = x8;
	hadr[ 8] = x9;
	hadr[ 9] = x10;
	hadr[10] = x11;
};

inline void CVektor::Define_Vektor/*12*/(long double x1, long double x2, long double x3, long double x4, long double x5, long double x6, long double x7, long double x8, long double x9, long double x10, long double x11, long double x12)
{
	SetDim(12);
	hadr[ 0] = x1;
	hadr[ 1] = x2;
	hadr[ 2] = x3;
	hadr[ 3] = x4;
	hadr[ 4] = x5;
	hadr[ 5] = x6;
	hadr[ 6] = x7;
	hadr[ 7] = x8;
	hadr[ 8] = x9;
	hadr[ 9] = x10;
	hadr[10] = x11;
	hadr[11] = x12;
};

inline void CVektor::Define_Vektor/*13*/(long double x1, long double x2, long double x3, long double x4, long double x5, long double x6, long double x7, long double x8, long double x9, long double x10, long double x11, long double x12, long double x13)
{
	SetDim(13);
	hadr[ 0] = x1;
	hadr[ 1] = x2;
	hadr[ 2] = x3;
	hadr[ 3] = x4;
	hadr[ 4] = x5;
	hadr[ 5] = x6;
	hadr[ 6] = x7;
	hadr[ 7] = x8;
	hadr[ 8] = x9;
	hadr[ 9] = x10;
	hadr[10] = x11;
	hadr[11] = x12;
	hadr[12] = x13;
};

inline void CVektor::Define_Vektor/*14*/(long double x1, long double x2, long double x3, long double x4, long double x5, long double x6, long double x7, long double x8, long double x9, long double x10, long double x11, long double x12, long double x13, long double x14)
{
	SetDim(14);
	hadr[ 0] = x1;
	hadr[ 1] = x2;
	hadr[ 2] = x3;
	hadr[ 3] = x4;
	hadr[ 4] = x5;
	hadr[ 5] = x6;
	hadr[ 6] = x7;
	hadr[ 7] = x8;
	hadr[ 8] = x9;
	hadr[ 9] = x10;
	hadr[10] = x11;
	hadr[11] = x12;
	hadr[12] = x13;
	hadr[13] = x14;
};

inline void CVektor::Define_Vektor/*15*/(long double x1, long double x2, long double x3, long double x4, long double x5, long double x6, long double x7, long double x8, long double x9, long double x10, long double x11, long double x12, long double x13, long double x14, long double x15)
{
	SetDim(15);
	hadr[ 0] = x1;
	hadr[ 1] = x2;
	hadr[ 2] = x3;
	hadr[ 3] = x4;
	hadr[ 4] = x5;
	hadr[ 5] = x6;
	hadr[ 6] = x7;
	hadr[ 7] = x8;
	hadr[ 8] = x9;
	hadr[ 9] = x10;
	hadr[10] = x11;
	hadr[11] = x12;
	hadr[12] = x13;
	hadr[13] = x14;
	hadr[14] = x15;
};



#if 0
#define DEFINE_VEKTOR0(x) \
	{ \
		(x).SetDim(0);\
	};

#define DEFINE_VEKTOR1(x, x1) \
	{ \
		(x).SetDim(1);\
		(x)[1] = x1;\
	};

#define DEFINE_VEKTOR2(x, x1, x2) \
	{ \
		(x).SetDim(2);\
		(x)[1] = x1;\
		(x)[2] = x2;\
	};

#define DEFINE_VEKTOR3(x, x1, x2, x3) \
	{ \
		(x).SetDim(3);\
		(x)[1] = x1;\
		(x)[2] = x2;\
		(x)[3] = x3;\
	};

#define DEFINE_VEKTOR4(x, x1, x2, x3, x4) \
	{ \
		(x).SetDim(4);\
		(x)[1] = x1;\
		(x)[2] = x2;\
		(x)[3] = x3;\
		(x)[4] = x4;\
	};

#define DEFINE_VEKTOR5(x, x1, x2, x3, x4, x5) \
	{ \
		(x).SetDim(5);\
		(x)[1] = x1;\
		(x)[2] = x2;\
		(x)[3] = x3;\
		(x)[4] = x4;\
		(x)[5] = x5;\
	};

#define DEFINE_VEKTOR6(x, x1, x2, x3, x4, x5, x6) \
	{ \
		(x).SetDim(6);\
		(x)[1] = x1;\
		(x)[2] = x2;\
		(x)[3] = x3;\
		(x)[4] = x4;\
		(x)[5] = x5;\
		(x)[6] = x6;\
	};

#define DEFINE_VEKTOR7(x, x1, x2, x3, x4, x5, x6, x7) \
	{ \
		(x).SetDim(7);\
		(x)[1] = x1;\
		(x)[2] = x2;\
		(x)[3] = x3;\
		(x)[4] = x4;\
		(x)[5] = x5;\
		(x)[6] = x6;\
		(x)[7] = x7;\
	};

#define DEFINE_VEKTOR8(x, x1, x2, x3, x4, x5, x6, x7, x8) \
	{ \
		(x).SetDim(8);\
		(x)[1] = x1;\
		(x)[2] = x2;\
		(x)[3] = x3;\
		(x)[4] = x4;\
		(x)[5] = x5;\
		(x)[6] = x6;\
		(x)[7] = x7;\
		(x)[8] = x8;\
	};

#define DEFINE_VEKTOR9(x, x1, x2, x3, x4, x5, x6, x7, x8, x9) \
	{ \
		(x).SetDim(9);\
		(x)[1] = x1;\
		(x)[2] = x2;\
		(x)[3] = x3;\
		(x)[4] = x4;\
		(x)[5] = x5;\
		(x)[6] = x6;\
		(x)[7] = x7;\
		(x)[8] = x8;\
		(x)[9] = x9;\
	};

#define DEFINE_VEKTOR10(x, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10) \
	{ \
		(x).SetDim(10);\
		(x)[1] = x1;\
		(x)[2] = x2;\
		(x)[3] = x3;\
		(x)[4] = x4;\
		(x)[5] = x5;\
		(x)[6] = x6;\
		(x)[7] = x7;\
		(x)[8] = x8;\
		(x)[9] = x9;\
		(x)[10] = x10;\
	};

#define DEFINE_VEKTOR11(x, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11) \
	{ \
		(x).SetDim(11);\
		(x)[1] = x1;\
		(x)[2] = x2;\
		(x)[3] = x3;\
		(x)[4] = x4;\
		(x)[5] = x5;\
		(x)[6] = x6;\
		(x)[7] = x7;\
		(x)[8] = x8;\
		(x)[9] = x9;\
		(x)[10] = x10;\
		(x)[11] = x11;\
	};

#define DEFINE_VEKTOR12(x, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12) \
	{ \
		(x).SetDim(12);\
		(x)[1] = x1;\
		(x)[2] = x2;\
		(x)[3] = x3;\
		(x)[4] = x4;\
		(x)[5] = x5;\
		(x)[6] = x6;\
		(x)[7] = x7;\
		(x)[8] = x8;\
		(x)[9] = x9;\
		(x)[10] = x10;\
		(x)[11] = x11;\
		(x)[12] = x12;\
	};

#define DEFINE_VEKTOR13(x, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13) \
	{ \
		(x).SetDim(13);\
		(x)[1] = x1;\
		(x)[2] = x2;\
		(x)[3] = x3;\
		(x)[4] = x4;\
		(x)[5] = x5;\
		(x)[6] = x6;\
		(x)[7] = x7;\
		(x)[8] = x8;\
		(x)[9] = x9;\
		(x)[10] = x10;\
		(x)[11] = x11;\
		(x)[12] = x12;\
		(x)[13] = x13;\
	};

#define DEFINE_MATRIX1(A, a11) \
	{ \
		A.SetDim(1, 1);\
		A(1, 1) = a11;\
	};

#define DEFINE_UMATRIX1(A) \
	{ \
		A.SetDim(1, 1);\
	};

#define DEFINE_MATRIX2(A, a11, a12, \
									a21, a22) \
	{ \
		A.SetDim(2, 2);\
		A(1, 1) = a11;		A(1, 2) = a12;\
		A(2, 1) = a21;		A(2, 2) = a22;\
	};

#define DEFINE_UMATRIX2(A,  \
									a21) \
	{ \
		A.SetDim(2, 2);\
		A(2, 1) = a21;\
	};

#define DEFINE_MATRIX3(A, a11, a12, a13, \
									a21, a22, a23, \
									a31, a32, a33) \
	{ \
		A.SetDim(3, 3);\
		A(1, 1) = a11;		A(1, 2) = a12;		A(1, 3) = a13;\
		A(2, 1) = a21;		A(2, 2) = a22;		A(2, 3) = a23;\
		A(3, 1) = a31;		A(3, 2) = a32;		A(3, 3) = a33;\
	};

#define DEFINE_UMATRIX3(A,  \
									a21, \
									a31, a32) \
	{ \
		A.SetDim(3, 3);\
		A(2, 1) = a21;\
		A(3, 1) = a31;		A(3, 2) = a32;\
	};

#define DEFINE_MATRIX4(A, a11, a12, a13, a14, \
									a21, a22, a23, a24, \
									a31, a32, a33, a34, \
									a41, a42, a43, a44) \
	{ \
		A.SetDim(4, 4);\
		A(1, 1) = a11;		A(1, 2) = a12;		A(1, 3) = a13;		A(1, 4) = a14;\
		A(2, 1) = a21;		A(2, 2) = a22;		A(2, 3) = a23;		A(2, 4) = a24;\
		A(3, 1) = a31;		A(3, 2) = a32;		A(3, 3) = a33;		A(3, 4) = a34;\
		A(4, 1) = a41;		A(4, 2) = a42;		A(4, 3) = a43;		A(4, 4) = a44;\
	};

#define DEFINE_UMATRIX4(A, \
									a21, \
									a31, a32, \
									a41, a42, a43) \
	{ \
		A.SetDim(4, 4);\
		A(2, 1) = a21;\
		A(3, 1) = a31;		A(3, 2) = a32;\
		A(4, 1) = a41;		A(4, 2) = a42;		A(4, 3) = a43;\
	};

#define DEFINE_MATRIX5(A, a11, a12, a13, a14, a15, \
									a21, a22, a23, a24, a25, \
									a31, a32, a33, a34, a35, \
									a41, a42, a43, a44, a45, \
									a51, a52, a53, a54, a55) \
	{ \
		A.SetDim(5, 5);\
		A(1, 1) = a11;		A(1, 2) = a12;		A(1, 3) = a13;		A(1, 4) = a14;		A(1, 5) = a15;\
		A(2, 1) = a21;		A(2, 2) = a22;		A(2, 3) = a23;		A(2, 4) = a24;		A(2, 5) = a25;\
		A(3, 1) = a31;		A(3, 2) = a32;		A(3, 3) = a33;		A(3, 4) = a34;		A(3, 5) = a35;\
		A(4, 1) = a41;		A(4, 2) = a42;		A(4, 3) = a43;		A(4, 4) = a44;		A(4, 5) = a45;\
		A(5, 1) = a51;		A(5, 2) = a52;		A(5, 3) = a53;		A(5, 4) = a54;		A(5, 5) = a55;\
	};

#define DEFINE_UMATRIX5(A, \
									a21,\
									a31, a32,\
									a41, a42, a43,\
									a51, a52, a53, a54)\
	{ \
		A.SetDim(5, 5);\
		A(2, 1) = a21;\
		A(3, 1) = a31;		A(3, 2) = a32;\
		A(4, 1) = a41;		A(4, 2) = a42;		A(4, 3) = a43;\
		A(5, 1) = a51;		A(5, 2) = a52;		A(5, 3) = a53;		A(5, 4) = a54;\
	};

#define DEFINE_MATRIX6(A, a11, a12, a13, a14, a15, a16, \
									a21, a22, a23, a24, a25, a26, \
									a31, a32, a33, a34, a35, a36, \
									a41, a42, a43, a44, a45, a46, \
									a51, a52, a53, a54, a55, a56, \
									a61, a62, a63, a64, a65, a66) \
	{ \
		A.SetDim(6, 6);\
		A(1, 1) = a11;		A(1, 2) = a12;		A(1, 3) = a13;		A(1, 4) = a14;		A(1, 5) = a15;		A(1, 6) = a16;\
		A(2, 1) = a21;		A(2, 2) = a22;		A(2, 3) = a23;		A(2, 4) = a24;		A(2, 5) = a25;		A(2, 6) = a26;\
		A(3, 1) = a31;		A(3, 2) = a32;		A(3, 3) = a33;		A(3, 4) = a34;		A(3, 5) = a35;		A(3, 6) = a36;\
		A(4, 1) = a41;		A(4, 2) = a42;		A(4, 3) = a43;		A(4, 4) = a44;		A(4, 5) = a45;		A(4, 6) = a46;\
		A(5, 1) = a51;		A(5, 2) = a52;		A(5, 3) = a53;		A(5, 4) = a54;		A(5, 5) = a55;		A(5, 6) = a56;\
		A(6, 1) = a61;		A(6, 2) = a62;		A(6, 3) = a63;		A(6, 4) = a64;		A(6, 5) = a65;		A(6, 6) = a66;\
	};

#define DEFINE_UMATRIX6(A, \
									a21,\
									a31, a32,\
									a41, a42, a43,\
									a51, a52, a53, a54,\
									a61, a62, a63, a64, a65) \
	{ \
		A.SetDim(6, 6);\
		A(2, 1) = a21;\
		A(3, 1) = a31;		A(3, 2) = a32;\
		A(4, 1) = a41;		A(4, 2) = a42;		A(4, 3) = a43;\
		A(5, 1) = a51;		A(5, 2) = a52;		A(5, 3) = a53;		A(5, 4) = a54;\
		A(6, 1) = a61;		A(6, 2) = a62;		A(6, 3) = a63;		A(6, 4) = a64;		A(6, 5) = a65;\
	};

#define DEFINE_MATRIX7(A, a11, a12, a13, a14, a15, a16, a17, \
									a21, a22, a23, a24, a25, a26, a27, \
									a31, a32, a33, a34, a35, a36, a37, \
									a41, a42, a43, a44, a45, a46, a47, \
									a51, a52, a53, a54, a55, a56, a57, \
									a61, a62, a63, a64, a65, a66, a67, \
									a71, a72, a73, a74, a75, a76, a77) \
	{ \
		A.SetDim(7, 7);\
		A(1, 1) = a11;		A(1, 2) = a12;		A(1, 3) = a13;		A(1, 4) = a14;		A(1, 5) = a15;		A(1, 6) = a16;		A(1, 7) = a17;\
		A(2, 1) = a21;		A(2, 2) = a22;		A(2, 3) = a23;		A(2, 4) = a24;		A(2, 5) = a25;		A(2, 6) = a26;		A(2, 7) = a27;\
		A(3, 1) = a31;		A(3, 2) = a32;		A(3, 3) = a33;		A(3, 4) = a34;		A(3, 5) = a35;		A(3, 6) = a36;		A(3, 7) = a37;\
		A(4, 1) = a41;		A(4, 2) = a42;		A(4, 3) = a43;		A(4, 4) = a44;		A(4, 5) = a45;		A(4, 6) = a46;		A(4, 7) = a47;\
		A(5, 1) = a51;		A(5, 2) = a52;		A(5, 3) = a53;		A(5, 4) = a54;		A(5, 5) = a55;		A(5, 6) = a56;		A(5, 7) = a57;\
		A(6, 1) = a61;		A(6, 2) = a62;		A(6, 3) = a63;		A(6, 4) = a64;		A(6, 5) = a65;		A(6, 6) = a66;		A(6, 7) = a67;\
		A(7, 1) = a71;		A(7, 2) = a72;		A(7, 3) = a73;		A(7, 4) = a74;		A(7, 5) = a75;		A(7, 6) = a76;		A(7, 7) = a77;\
	};

#define DEFINE_UMATRIX7(A, \
									a21,\
									a31, a32,\
									a41, a42, a43,\
									a51, a52, a53, a54,\
									a61, a62, a63, a64, a65,\
									a71, a72, a73, a74, a75, a76) \
	{ \
		A.SetDim(7, 7);\
		A(2, 1) = a21;\
		A(3, 1) = a31;		A(3, 2) = a32;\
		A(4, 1) = a41;		A(4, 2) = a42;		A(4, 3) = a43;\
		A(5, 1) = a51;		A(5, 2) = a52;		A(5, 3) = a53;		A(5, 4) = a54;\
		A(6, 1) = a61;		A(6, 2) = a62;		A(6, 3) = a63;		A(6, 4) = a64;		A(6, 5) = a65;\
		A(7, 1) = a71;		A(7, 2) = a72;		A(7, 3) = a73;		A(7, 4) = a74;		A(7, 5) = a75;		A(7, 6) = a76;\
	};


#define DEFINE_MATRIX8(A, a11, a12, a13, a14, a15, a16, a17, a18, \
									a21, a22, a23, a24, a25, a26, a27, a28, \
									a31, a32, a33, a34, a35, a36, a37, a38, \
									a41, a42, a43, a44, a45, a46, a47, a48, \
									a51, a52, a53, a54, a55, a56, a57, a58, \
									a61, a62, a63, a64, a65, a66, a67, a68, \
									a71, a72, a73, a74, a75, a76, a77, a78, \
									a81, a82, a83, a84, a85, a86, a87, a88) \
	{ \
		A.SetDim(8, 8);\
		A(1, 1) = a11;		A(1, 2) = a12;		A(1, 3) = a13;		A(1, 4) = a14;		A(1, 5) = a15;		A(1, 6) = a16;		A(1, 7) = a17;		A(1, 8) = a18;\
		A(2, 1) = a21;		A(2, 2) = a22;		A(2, 3) = a23;		A(2, 4) = a24;		A(2, 5) = a25;		A(2, 6) = a26;		A(2, 7) = a27;		A(3, 8) = a28;\
		A(3, 1) = a31;		A(3, 2) = a32;		A(3, 3) = a33;		A(3, 4) = a34;		A(3, 5) = a35;		A(3, 6) = a36;		A(3, 7) = a37;		A(3, 8) = a38;\
		A(4, 1) = a41;		A(4, 2) = a42;		A(4, 3) = a43;		A(4, 4) = a44;		A(4, 5) = a45;		A(4, 6) = a46;		A(4, 7) = a47;		A(4, 8) = a48;\
		A(5, 1) = a51;		A(5, 2) = a52;		A(5, 3) = a53;		A(5, 4) = a54;		A(5, 5) = a55;		A(5, 6) = a56;		A(5, 7) = a57;		A(5, 8) = a58;\
		A(6, 1) = a61;		A(6, 2) = a62;		A(6, 3) = a63;		A(6, 4) = a64;		A(6, 5) = a65;		A(6, 6) = a66;		A(6, 7) = a67;		A(6, 8) = a68;\
		A(7, 1) = a71;		A(7, 2) = a72;		A(7, 3) = a73;		A(7, 4) = a74;		A(7, 5) = a75;		A(7, 6) = a76;		A(7, 7) = a77;		A(7, 8) = a78;\
		A(8, 1) = a81;		A(8, 2) = a82;		A(8, 3) = a83;		A(8, 4) = a84;		A(8, 5) = a85;		A(8, 6) = a86;		A(8, 7) = a87;		A(8, 8) = a88;\
	};

#define DEFINE_UMATRIX8(A, \
									a21,\
									a31, a32,\
									a41, a42, a43,\
									a51, a52, a53, a54,\
									a61, a62, a63, a64, a65,\
									a71, a72, a73, a74, a75, a76,\
									a81, a82, a83, a84, a85, a86, a87) \
	{ \
		A.SetDim(8, 8);\
		A(2, 1) = a21;\
		A(3, 1) = a31;		A(3, 2) = a32;\
		A(4, 1) = a41;		A(4, 2) = a42;		A(4, 3) = a43;\
		A(5, 1) = a51;		A(5, 2) = a52;		A(5, 3) = a53;		A(5, 4) = a54;\
		A(6, 1) = a61;		A(6, 2) = a62;		A(6, 3) = a63;		A(6, 4) = a64;		A(6, 5) = a65;\
		A(7, 1) = a71;		A(7, 2) = a72;		A(7, 3) = a73;		A(7, 4) = a74;		A(7, 5) = a75;		A(7, 6) = a76;\
		A(8, 1) = a81;		A(8, 2) = a82;		A(8, 3) = a83;		A(8, 4) = a84;		A(8, 5) = a85;		A(8, 6) = a86;		A(8, 7) = a87;\
	};

#define DEFINE_MATRIX9(A, a11, a12, a13, a14, a15, a16, a17, a18, a19, \
									a21, a22, a23, a24, a25, a26, a27, a28, a29, \
									a31, a32, a33, a34, a35, a36, a37, a38, a39, \
									a41, a42, a43, a44, a45, a46, a47, a48, a49, \
									a51, a52, a53, a54, a55, a56, a57, a58, a59, \
									a61, a62, a63, a64, a65, a66, a67, a68, a69, \
									a71, a72, a73, a74, a75, a76, a77, a78, a79, \
									a81, a82, a83, a84, a85, a86, a87, a88, a89,\
									a91, a92, a93, a94, a95, a96, a97, a98, a99) \
	{ \
		A.SetDim(9, 9);\
		A(1, 1) = a11;		A(1, 2) = a12;		A(1, 3) = a13;		A(1, 4) = a14;		A(1, 5) = a15;		A(1, 6) = a16;		A(1, 7) = a17;		A(1, 8) = a18;		A(1, 9) = a19;\
		A(2, 1) = a21;		A(2, 2) = a22;		A(2, 3) = a23;		A(2, 4) = a24;		A(2, 5) = a25;		A(2, 6) = a26;		A(2, 7) = a27;		A(3, 8) = a28;		A(2, 9) = a29;\
		A(3, 1) = a31;		A(3, 2) = a32;		A(3, 3) = a33;		A(3, 4) = a34;		A(3, 5) = a35;		A(3, 6) = a36;		A(3, 7) = a37;		A(3, 8) = a38;		A(3, 9) = a39;\
		A(4, 1) = a41;		A(4, 2) = a42;		A(4, 3) = a43;		A(4, 4) = a44;		A(4, 5) = a45;		A(4, 6) = a46;		A(4, 7) = a47;		A(4, 8) = a48;		A(4, 9) = a49;\
		A(5, 1) = a51;		A(5, 2) = a52;		A(5, 3) = a53;		A(5, 4) = a54;		A(5, 5) = a55;		A(5, 6) = a56;		A(5, 7) = a57;		A(5, 8) = a58;		A(5, 9) = a59;\
		A(6, 1) = a61;		A(6, 2) = a62;		A(6, 3) = a63;		A(6, 4) = a64;		A(6, 5) = a65;		A(6, 6) = a66;		A(6, 7) = a67;		A(6, 8) = a68;		A(6, 9) = a69;\
		A(7, 1) = a71;		A(7, 2) = a72;		A(7, 3) = a73;		A(7, 4) = a74;		A(7, 5) = a75;		A(7, 6) = a76;		A(7, 7) = a77;		A(7, 8) = a78;		A(7, 9) = a79;\
		A(8, 1) = a81;		A(8, 2) = a82;		A(8, 3) = a83;		A(8, 4) = a84;		A(8, 5) = a85;		A(8, 6) = a86;		A(8, 7) = a87;		A(8, 8) = a88;		A(8, 9) = a89;\
		A(9, 1) = a91;		A(9, 2) = a92;		A(9, 3) = a93;		A(9, 4) = a94;		A(9, 5) = a95;		A(9, 6) = a96;		A(9, 7) = a97;		A(9, 8) = a98;		A(9, 9) = a99;\
	};

#define DEFINE_UMATRIX9(A, \
									a21,\
									a31, a32,\
									a41, a42, a43,\
									a51, a52, a53, a54,\
									a61, a62, a63, a64, a65,\
									a71, a72, a73, a74, a75, a76,\
									a81, a82, a83, a84, a85, a86, a87,\
									a91, a92, a93, a94, a95, a96, a97, a98) \
	{ \
		A.SetDim(9, 9);\
		A(2, 1) = a21;\
		A(3, 1) = a31;		A(3, 2) = a32;\
		A(4, 1) = a41;		A(4, 2) = a42;		A(4, 3) = a43;\
		A(5, 1) = a51;		A(5, 2) = a52;		A(5, 3) = a53;		A(5, 4) = a54;\
		A(6, 1) = a61;		A(6, 2) = a62;		A(6, 3) = a63;		A(6, 4) = a64;		A(6, 5) = a65;\
		A(7, 1) = a71;		A(7, 2) = a72;		A(7, 3) = a73;		A(7, 4) = a74;		A(7, 5) = a75;		A(7, 6) = a76;\
		A(8, 1) = a81;		A(8, 2) = a82;		A(8, 3) = a83;		A(8, 4) = a84;		A(8, 5) = a85;		A(8, 6) = a86;		A(8, 7) = a87;\
		A(9, 1) = a91;		A(9, 2) = a92;		A(9, 3) = a93;		A(9, 4) = a94;		A(9, 5) = a95;		A(9, 6) = a96;		A(9, 7) = a97;		A(9, 8) = a98;\
	};

#define DEFINE_MATRIX10(A, a11, a12, a13, a14, a15, a16, a17, a18, a19, a1A, \
									a21, a22, a23, a24, a25, a26, a27, a28, a29, a2A, \
									a31, a32, a33, a34, a35, a36, a37, a38, a39, a3A, \
									a41, a42, a43, a44, a45, a46, a47, a48, a49, a4A, \
									a51, a52, a53, a54, a55, a56, a57, a58, a59, a5A, \
									a61, a62, a63, a64, a65, a66, a67, a68, a69, a6A, \
									a71, a72, a73, a74, a75, a76, a77, a78, a79, a7A, \
									a81, a82, a83, a84, a85, a86, a87, a88, a89, a8A, \
									a91, a92, a93, a94, a95, a96, a97, a98, a99, a9A, \
									aA1, aA2, aA3, aA4, aA5, aA6, aA7, aA8, aA9, aAA) \
	{ \
		A.SetDim(10, 10);\
		A(1, 1) = a11;		A(1, 2) = a12;		A(1, 3) = a13;		A(1, 4) = a14;		A(1, 5) = a15;		A(1, 6) = a16;		A(1, 7) = a17;		A(1, 8) = a18;		A(1, 9) = a19;		A(1,10) = a1A;\
		A(2, 1) = a21;		A(2, 2) = a22;		A(2, 3) = a23;		A(2, 4) = a24;		A(2, 5) = a25;		A(2, 6) = a26;		A(2, 7) = a27;		A(3, 8) = a28;		A(2, 9) = a29;		A(2,10) = a2A;\
		A(3, 1) = a31;		A(3, 2) = a32;		A(3, 3) = a33;		A(3, 4) = a34;		A(3, 5) = a35;		A(3, 6) = a36;		A(3, 7) = a37;		A(3, 8) = a38;		A(3, 9) = a39;		A(3,10) = a3A;\
		A(4, 1) = a41;		A(4, 2) = a42;		A(4, 3) = a43;		A(4, 4) = a44;		A(4, 5) = a45;		A(4, 6) = a46;		A(4, 7) = a47;		A(4, 8) = a48;		A(4, 9) = a49;		A(4,10) = a4A;\
		A(5, 1) = a51;		A(5, 2) = a52;		A(5, 3) = a53;		A(5, 4) = a54;		A(5, 5) = a55;		A(5, 6) = a56;		A(5, 7) = a57;		A(5, 8) = a58;		A(5, 9) = a59;		A(5,10) = a5A;\
		A(6, 1) = a61;		A(6, 2) = a62;		A(6, 3) = a63;		A(6, 4) = a64;		A(6, 5) = a65;		A(6, 6) = a66;		A(6, 7) = a67;		A(6, 8) = a68;		A(6, 9) = a69;		A(6,10) = a6A;\
		A(7, 1) = a71;		A(7, 2) = a72;		A(7, 3) = a73;		A(7, 4) = a74;		A(7, 5) = a75;		A(7, 6) = a76;		A(7, 7) = a77;		A(7, 8) = a78;		A(7, 9) = a79;		A(7,10) = a7A;\
		A(8, 1) = a81;		A(8, 2) = a82;		A(8, 3) = a83;		A(8, 4) = a84;		A(8, 5) = a85;		A(8, 6) = a86;		A(8, 7) = a87;		A(8, 8) = a88;		A(8, 9) = a89;		A(8,10) = a8A;\
		A(9, 1) = a91;		A(9, 2) = a92;		A(9, 3) = a93;		A(9, 4) = a94;		A(9, 5) = a95;		A(9, 6) = a96;		A(9, 7) = a97;		A(9, 8) = a98;		A(9, 9) = a99;		A(9,10) = a9A;\
		A(10,1) = aA1;		A(10,2) = aA2;		A(10,3) = aA3;		A(10,4) = aA4;		A(10,5) = aA5;		A(10,6) = aA6;		A(10,7) = aA7;		A(10,8) = aA8;		A(10,9) = aA9;		A(10,10) = aAA;\
	};

#define DEFINE_UMATRIX10(A, \
									a21,\
									a31, a32,\
									a41, a42, a43,\
									a51, a52, a53, a54,\
									a61, a62, a63, a64, a65,\
									a71, a72, a73, a74, a75, a76,\
									a81, a82, a83, a84, a85, a86, a87,\
									a91, a92, a93, a94, a95, a96, a97, a98,\
									aA1, aA2, aA3, aA4, aA5, aA6, aA7, aA8, aA9) \
	{ \
		A.SetDim(10, 10);\
		A(2, 1) = a21;\
		A(3, 1) = a31;		A(3, 2) = a32;\
		A(4, 1) = a41;		A(4, 2) = a42;		A(4, 3) = a43;\
		A(5, 1) = a51;		A(5, 2) = a52;		A(5, 3) = a53;		A(5, 4) = a54;\
		A(6, 1) = a61;		A(6, 2) = a62;		A(6, 3) = a63;		A(6, 4) = a64;		A(6, 5) = a65;\
		A(7, 1) = a71;		A(7, 2) = a72;		A(7, 3) = a73;		A(7, 4) = a74;		A(7, 5) = a75;		A(7, 6) = a76;\
		A(8, 1) = a81;		A(8, 2) = a82;		A(8, 3) = a83;		A(8, 4) = a84;		A(8, 5) = a85;		A(8, 6) = a86;		A(8, 7) = a87;\
		A(9, 1) = a91;		A(9, 2) = a92;		A(9, 3) = a93;		A(9, 4) = a94;		A(9, 5) = a95;		A(9, 6) = a96;		A(9, 7) = a97;		A(9, 8) = a98;\
		A(10,1) = aA1;		A(10,2) = aA2;		A(10,3) = aA3;		A(10,4) = aA4;		A(10,5) = aA5;		A(10,6) = aA6;		A(10,7) = aA7;		A(10,8) = aA8;		A(10,9) = aA9;\
	};

#define DEFINE_MATRIX11(A, a11, a12, a13, a14, a15, a16, a17, a18, a19, a1A, a1B,\
									a21, a22, a23, a24, a25, a26, a27, a28, a29, a2A, a2B, \
									a31, a32, a33, a34, a35, a36, a37, a38, a39, a3A, a3B, \
									a41, a42, a43, a44, a45, a46, a47, a48, a49, a4A, a4B, \
									a51, a52, a53, a54, a55, a56, a57, a58, a59, a5A, a5B, \
									a61, a62, a63, a64, a65, a66, a67, a68, a69, a6A, a6B, \
									a71, a72, a73, a74, a75, a76, a77, a78, a79, a7A, a7B, \
									a81, a82, a83, a84, a85, a86, a87, a88, a89, a8A, a8B, \
									a91, a92, a93, a94, a95, a96, a97, a98, a99, a9A, a9B, \
									aA1, aA2, aA3, aA4, aA5, aA6, aA7, aA8, aA9, aAA, aAB, \
									aB1, aB2, aB3, aB4, aB5, aB6, aB7, aB8, aB9, aBA, aBB) \
	{ \
		A.SetDim(11, 11);\
		A(1, 1) = a11;		A(1, 2) = a12;		A(1, 3) = a13;		A(1, 4) = a14;		A(1, 5) = a15;		A(1, 6) = a16;		A(1, 7) = a17;		A(1, 8) = a18;		A(1, 9) = a19;		A(1,10) = a1A;		A(1,11) = a1B;\
		A(2, 1) = a21;		A(2, 2) = a22;		A(2, 3) = a23;		A(2, 4) = a24;		A(2, 5) = a25;		A(2, 6) = a26;		A(2, 7) = a27;		A(3, 8) = a28;		A(2, 9) = a29;		A(2,10) = a2A;		A(2,11) = a2B;\
		A(3, 1) = a31;		A(3, 2) = a32;		A(3, 3) = a33;		A(3, 4) = a34;		A(3, 5) = a35;		A(3, 6) = a36;		A(3, 7) = a37;		A(3, 8) = a38;		A(3, 9) = a39;		A(3,10) = a3A;		A(3,11) = a3B;\
		A(4, 1) = a41;		A(4, 2) = a42;		A(4, 3) = a43;		A(4, 4) = a44;		A(4, 5) = a45;		A(4, 6) = a46;		A(4, 7) = a47;		A(4, 8) = a48;		A(4, 9) = a49;		A(4,10) = a4A;		A(4,11) = a4B;\
		A(5, 1) = a51;		A(5, 2) = a52;		A(5, 3) = a53;		A(5, 4) = a54;		A(5, 5) = a55;		A(5, 6) = a56;		A(5, 7) = a57;		A(5, 8) = a58;		A(5, 9) = a59;		A(5,10) = a5A;		A(5,11) = a5B;\
		A(6, 1) = a61;		A(6, 2) = a62;		A(6, 3) = a63;		A(6, 4) = a64;		A(6, 5) = a65;		A(6, 6) = a66;		A(6, 7) = a67;		A(6, 8) = a68;		A(6, 9) = a69;		A(6,10) = a6A;		A(6,11) = a6B;\
		A(7, 1) = a71;		A(7, 2) = a72;		A(7, 3) = a73;		A(7, 4) = a74;		A(7, 5) = a75;		A(7, 6) = a76;		A(7, 7) = a77;		A(7, 8) = a78;		A(7, 9) = a79;		A(7,10) = a7A;		A(7,11) = a7B;\
		A(8, 1) = a81;		A(8, 2) = a82;		A(8, 3) = a83;		A(8, 4) = a84;		A(8, 5) = a85;		A(8, 6) = a86;		A(8, 7) = a87;		A(8, 8) = a88;		A(8, 9) = a89;		A(8,10) = a8A;		A(8,11) = a8B;\
		A(9, 1) = a91;		A(9, 2) = a92;		A(9, 3) = a93;		A(9, 4) = a94;		A(9, 5) = a95;		A(9, 6) = a96;		A(9, 7) = a97;		A(9, 8) = a98;		A(9, 9) = a99;		A(9,10) = a9A;		A(9,11) = a9B;\
		A(10,1) = aA1;		A(10,2) = aA2;		A(10,3) = aA3;		A(10,4) = aA4;		A(10,5) = aA5;		A(10,6) = aA6;		A(10,7) = aA7;		A(10,8) = aA8;		A(10,9) = aA9;		A(10,10) = aAA;		A(10,11) = aAB;\
		A(11,1) = aB1;		A(11,2) = aB2;		A(11,3) = aB3;		A(11,4) = aB4;		A(11,5) = aB5;		A(11,6) = aB6;		A(11,7) = aB7;		A(11,8) = aB8;		A(11,9) = aB9;		A(11,10) = aBA;		A(11,11) = aBB;\
	};

#define DEFINE_UMATRIX11(A, \
									a21,\
									a31, a32,\
									a41, a42, a43,\
									a51, a52, a53, a54,\
									a61, a62, a63, a64, a65,\
									a71, a72, a73, a74, a75, a76,\
									a81, a82, a83, a84, a85, a86, a87,\
									a91, a92, a93, a94, a95, a96, a97, a98,\
									aA1, aA2, aA3, aA4, aA5, aA6, aA7, aA8, aA9,\
									aB1, aB2, aB3, aB4, aB5, aB6, aB7, aB8, aB9, aBA) \
	{ \
		A.SetDim(11, 11);\
		A(2, 1) = a21;\
		A(3, 1) = a31;		A(3, 2) = a32;\
		A(4, 1) = a41;		A(4, 2) = a42;		A(4, 3) = a43;\
		A(5, 1) = a51;		A(5, 2) = a52;		A(5, 3) = a53;		A(5, 4) = a54;\
		A(6, 1) = a61;		A(6, 2) = a62;		A(6, 3) = a63;		A(6, 4) = a64;		A(6, 5) = a65;\
		A(7, 1) = a71;		A(7, 2) = a72;		A(7, 3) = a73;		A(7, 4) = a74;		A(7, 5) = a75;		A(7, 6) = a76;\
		A(8, 1) = a81;		A(8, 2) = a82;		A(8, 3) = a83;		A(8, 4) = a84;		A(8, 5) = a85;		A(8, 6) = a86;		A(8, 7) = a87;\
		A(9, 1) = a91;		A(9, 2) = a92;		A(9, 3) = a93;		A(9, 4) = a94;		A(9, 5) = a95;		A(9, 6) = a96;		A(9, 7) = a97;		A(9, 8) = a98;\
		A(10,1) = aA1;		A(10,2) = aA2;		A(10,3) = aA3;		A(10,4) = aA4;		A(10,5) = aA5;		A(10,6) = aA6;		A(10,7) = aA7;		A(10,8) = aA8;		A(10,9) = aA9;\
		A(11,1) = aB1;		A(11,2) = aB2;		A(11,3) = aB3;		A(11,4) = aB4;		A(11,5) = aB5;		A(11,6) = aB6;		A(11,7) = aB7;		A(11,8) = aB8;		A(11,9) = aB9;		A(11,10) = aBA;\
	};

#define DEFINE_MATRIX12(A, a11, a12, a13, a14, a15, a16, a17, a18, a19, a1A, a1B, a1C, \
									a21, a22, a23, a24, a25, a26, a27, a28, a29, a2A, a2B, a2C, \
									a31, a32, a33, a34, a35, a36, a37, a38, a39, a3A, a3B, a3C, \
									a41, a42, a43, a44, a45, a46, a47, a48, a49, a4A, a4B, a4C, \
									a51, a52, a53, a54, a55, a56, a57, a58, a59, a5A, a5B, a5C, \
									a61, a62, a63, a64, a65, a66, a67, a68, a69, a6A, a6B, a6C, \
									a71, a72, a73, a74, a75, a76, a77, a78, a79, a7A, a7B, a7C, \
									a81, a82, a83, a84, a85, a86, a87, a88, a89, a8A, a8B, a8C, \
									a91, a92, a93, a94, a95, a96, a97, a98, a99, a9A, a9B, a9C, \
									aA1, aA2, aA3, aA4, aA5, aA6, aA7, aA8, aA9, aAA, aAB, aAC, \
									aB1, aB2, aB3, aB4, aB5, aB6, aB7, aB8, aB9, aBA, aBB, aBC, \
									aC1, aC2, aC3, aC4, aC5, aC6, aC7, aC8, aC9, aCA, aCB, aCC) \
	{ \
		A.SetDim(12, 12);\
		A(1, 1) = a11;		A(1, 2) = a12;		A(1, 3) = a13;		A(1, 4) = a14;		A(1, 5) = a15;		A(1, 6) = a16;		A(1, 7) = a17;		A(1, 8) = a18;		A(1, 9) = a19;		A(1,10) = a1A;		A(1,11) = a1B;		A(1,12) = a1C;\
		A(2, 1) = a21;		A(2, 2) = a22;		A(2, 3) = a23;		A(2, 4) = a24;		A(2, 5) = a25;		A(2, 6) = a26;		A(2, 7) = a27;		A(3, 8) = a28;		A(2, 9) = a29;		A(2,10) = a2A;		A(2,11) = a2B;		A(2,12) = a2C;\
		A(3, 1) = a31;		A(3, 2) = a32;		A(3, 3) = a33;		A(3, 4) = a34;		A(3, 5) = a35;		A(3, 6) = a36;		A(3, 7) = a37;		A(3, 8) = a38;		A(3, 9) = a39;		A(3,10) = a3A;		A(3,11) = a3B;		A(3,12) = a3C;\
		A(4, 1) = a41;		A(4, 2) = a42;		A(4, 3) = a43;		A(4, 4) = a44;		A(4, 5) = a45;		A(4, 6) = a46;		A(4, 7) = a47;		A(4, 8) = a48;		A(4, 9) = a49;		A(4,10) = a4A;		A(4,11) = a4B;		A(4,12) = a4C;\
		A(5, 1) = a51;		A(5, 2) = a52;		A(5, 3) = a53;		A(5, 4) = a54;		A(5, 5) = a55;		A(5, 6) = a56;		A(5, 7) = a57;		A(5, 8) = a58;		A(5, 9) = a59;		A(5,10) = a5A;		A(5,11) = a5B;		A(5,12) = a5C;\
		A(6, 1) = a61;		A(6, 2) = a62;		A(6, 3) = a63;		A(6, 4) = a64;		A(6, 5) = a65;		A(6, 6) = a66;		A(6, 7) = a67;		A(6, 8) = a68;		A(6, 9) = a69;		A(6,10) = a6A;		A(6,11) = a6B;		A(6,12) = a6C;\
		A(7, 1) = a71;		A(7, 2) = a72;		A(7, 3) = a73;		A(7, 4) = a74;		A(7, 5) = a75;		A(7, 6) = a76;		A(7, 7) = a77;		A(7, 8) = a78;		A(7, 9) = a79;		A(7,10) = a7A;		A(7,11) = a7B;		A(7,12) = a7C;\
		A(8, 1) = a81;		A(8, 2) = a82;		A(8, 3) = a83;		A(8, 4) = a84;		A(8, 5) = a85;		A(8, 6) = a86;		A(8, 7) = a87;		A(8, 8) = a88;		A(8, 9) = a89;		A(8,10) = a8A;		A(8,11) = a8B;		A(8,12) = a8C;\
		A(9, 1) = a91;		A(9, 2) = a92;		A(9, 3) = a93;		A(9, 4) = a94;		A(9, 5) = a95;		A(9, 6) = a96;		A(9, 7) = a97;		A(9, 8) = a98;		A(9, 9) = a99;		A(9,10) = a9A;		A(9,11) = a9B;		A(9,12) = a9C;\
		A(10,1) = aA1;		A(10,2) = aA2;		A(10,3) = aA3;		A(10,4) = aA4;		A(10,5) = aA5;		A(10,6) = aA6;		A(10,7) = aA7;		A(10,8) = aA8;		A(10,9) = aA9;		A(10,10) = aAA;		A(10,11) = aAB;		A(10,12) = aAC;\
		A(11,1) = aB1;		A(11,2) = aB2;		A(11,3) = aB3;		A(11,4) = aB4;		A(11,5) = aB5;		A(11,6) = aB6;		A(11,7) = aB7;		A(11,8) = aB8;		A(11,9) = aB9;		A(11,10) = aBA;		A(11,11) = aBB;		A(11,12) = aBC;\
		A(12,1) = aC1;		A(12,2) = aC2;		A(12,3) = aC3;		A(12,4) = aC4;		A(12,5) = aC5;		A(12,6) = aC6;		A(12,7) = aC7;		A(12,8) = aC8;		A(12,9) = aC9;		A(12,10) = aCA;		A(12,11) = aCB;		A(12,12) = aCC;\
	};

#define DEFINE_UMATRIX12(A, \
									a21,\
									a31, a32,\
									a41, a42, a43,\
									a51, a52, a53, a54,\
									a61, a62, a63, a64, a65,\
									a71, a72, a73, a74, a75, a76,\
									a81, a82, a83, a84, a85, a86, a87,\
									a91, a92, a93, a94, a95, a96, a97, a98,\
									aA1, aA2, aA3, aA4, aA5, aA6, aA7, aA8, aA9,\
									aB1, aB2, aB3, aB4, aB5, aB6, aB7, aB8, aB9, aBA,\
									aC1, aC2, aC3, aC4, aC5, aC6, aC7, aC8, aC9, aCA, aCB) \
	{ \
		A.SetDim(12, 12);\
		A(2, 1) = a21;\
		A(3, 1) = a31;		A(3, 2) = a32;\
		A(4, 1) = a41;		A(4, 2) = a42;		A(4, 3) = a43;\
		A(5, 1) = a51;		A(5, 2) = a52;		A(5, 3) = a53;		A(5, 4) = a54;\
		A(6, 1) = a61;		A(6, 2) = a62;		A(6, 3) = a63;		A(6, 4) = a64;		A(6, 5) = a65;\
		A(7, 1) = a71;		A(7, 2) = a72;		A(7, 3) = a73;		A(7, 4) = a74;		A(7, 5) = a75;		A(7, 6) = a76;\
		A(8, 1) = a81;		A(8, 2) = a82;		A(8, 3) = a83;		A(8, 4) = a84;		A(8, 5) = a85;		A(8, 6) = a86;		A(8, 7) = a87;\
		A(9, 1) = a91;		A(9, 2) = a92;		A(9, 3) = a93;		A(9, 4) = a94;		A(9, 5) = a95;		A(9, 6) = a96;		A(9, 7) = a97;		A(9, 8) = a98;\
		A(10,1) = aA1;		A(10,2) = aA2;		A(10,3) = aA3;		A(10,4) = aA4;		A(10,5) = aA5;		A(10,6) = aA6;		A(10,7) = aA7;		A(10,8) = aA8;		A(10,9) = aA9;\
		A(11,1) = aB1;		A(11,2) = aB2;		A(11,3) = aB3;		A(11,4) = aB4;		A(11,5) = aB5;		A(11,6) = aB6;		A(11,7) = aB7;		A(11,8) = aB8;		A(11,9) = aB9;		A(11,10) = aBA;\
		A(12,1) = aC1;		A(12,2) = aC2;		A(12,3) = aC3;		A(12,4) = aC4;		A(12,5) = aC5;		A(12,6) = aC6;		A(12,7) = aC7;		A(12,8) = aC8;		A(12,9) = aC9;		A(12,10) = aCA;		A(12,11) = aCB;\
	};

#define DEFINE_MATRIX13(A, a11, a12, a13, a14, a15, a16, a17, a18, a19, a1A, a1B, a1C, a1D, \
									a21, a22, a23, a24, a25, a26, a27, a28, a29, a2A, a2B, a2C, a2D, \
									a31, a32, a33, a34, a35, a36, a37, a38, a39, a3A, a3B, a3C, a3D, \
									a41, a42, a43, a44, a45, a46, a47, a48, a49, a4A, a4B, a4C, a4D, \
									a51, a52, a53, a54, a55, a56, a57, a58, a59, a5A, a5B, a5C, a5D, \
									a61, a62, a63, a64, a65, a66, a67, a68, a69, a6A, a6B, a6C, a6D, \
									a71, a72, a73, a74, a75, a76, a77, a78, a79, a7A, a7B, a7C, a7D, \
									a81, a82, a83, a84, a85, a86, a87, a88, a89, a8A, a8B, a8C, a8D, \
									a91, a92, a93, a94, a95, a96, a97, a98, a99, a9A, a9B, a9C, a9D, \
									aA1, aA2, aA3, aA4, aA5, aA6, aA7, aA8, aA9, aAA, aAB, aAC, aAD, \
									aB1, aB2, aB3, aB4, aB5, aB6, aB7, aB8, aB9, aBA, aBB, aBC, aBD, \
									aC1, aC2, aC3, aC4, aC5, aC6, aC7, aC8, aC9, aCA, aCB, aCC, aCD, \
									aD1, aD2, aD3, aD4, aD5, aD6, aD7, aD8, aD9, aDA, aDB, aDC, aDD) \
	{ \
		A.SetDim(13, 13);\
		A(1, 1) = a11;		A(1, 2) = a12;		A(1, 3) = a13;		A(1, 4) = a14;		A(1, 5) = a15;		A(1, 6) = a16;		A(1, 7) = a17;		A(1, 8) = a18;		A(1, 9) = a19;		A(1,10) = a1A;		A(1,11) = a1B;		A(1,12) = a1C;		A(1,13) = a1D;\
		A(2, 1) = a21;		A(2, 2) = a22;		A(2, 3) = a23;		A(2, 4) = a24;		A(2, 5) = a25;		A(2, 6) = a26;		A(2, 7) = a27;		A(3, 8) = a28;		A(2, 9) = a29;		A(2,10) = a2A;		A(2,11) = a2B;		A(2,12) = a2C;		A(2,13) = a2D;\
		A(3, 1) = a31;		A(3, 2) = a32;		A(3, 3) = a33;		A(3, 4) = a34;		A(3, 5) = a35;		A(3, 6) = a36;		A(3, 7) = a37;		A(3, 8) = a38;		A(3, 9) = a39;		A(3,10) = a3A;		A(3,11) = a3B;		A(3,12) = a3C;		A(3,13) = a3D;\
		A(4, 1) = a41;		A(4, 2) = a42;		A(4, 3) = a43;		A(4, 4) = a44;		A(4, 5) = a45;		A(4, 6) = a46;		A(4, 7) = a47;		A(4, 8) = a48;		A(4, 9) = a49;		A(4,10) = a4A;		A(4,11) = a4B;		A(4,12) = a4C;		A(4,13) = a4D;\
		A(5, 1) = a51;		A(5, 2) = a52;		A(5, 3) = a53;		A(5, 4) = a54;		A(5, 5) = a55;		A(5, 6) = a56;		A(5, 7) = a57;		A(5, 8) = a58;		A(5, 9) = a59;		A(5,10) = a5A;		A(5,11) = a5B;		A(5,12) = a5C;		A(5,13) = a5D;\
		A(6, 1) = a61;		A(6, 2) = a62;		A(6, 3) = a63;		A(6, 4) = a64;		A(6, 5) = a65;		A(6, 6) = a66;		A(6, 7) = a67;		A(6, 8) = a68;		A(6, 9) = a69;		A(6,10) = a6A;		A(6,11) = a6B;		A(6,12) = a6C;		A(6,13) = a6D;\
		A(7, 1) = a71;		A(7, 2) = a72;		A(7, 3) = a73;		A(7, 4) = a74;		A(7, 5) = a75;		A(7, 6) = a76;		A(7, 7) = a77;		A(7, 8) = a78;		A(7, 9) = a79;		A(7,10) = a7A;		A(7,11) = a7B;		A(7,12) = a7C;		A(7,13) = a7D;\
		A(8, 1) = a81;		A(8, 2) = a82;		A(8, 3) = a83;		A(8, 4) = a84;		A(8, 5) = a85;		A(8, 6) = a86;		A(8, 7) = a87;		A(8, 8) = a88;		A(8, 9) = a89;		A(8,10) = a8A;		A(8,11) = a8B;		A(8,12) = a8C;		A(8,13) = a8D;\
		A(9, 1) = a91;		A(9, 2) = a92;		A(9, 3) = a93;		A(9, 4) = a94;		A(9, 5) = a95;		A(9, 6) = a96;		A(9, 7) = a97;		A(9, 8) = a98;		A(9, 9) = a99;		A(9,10) = a9A;		A(9,11) = a9B;		A(9,12) = a9C;		A(9,13) = a9D;\
		A(10,1) = aA1;		A(10,2) = aA2;		A(10,3) = aA3;		A(10,4) = aA4;		A(10,5) = aA5;		A(10,6) = aA6;		A(10,7) = aA7;		A(10,8) = aA8;		A(10,9) = aA9;		A(10,10) = aAA;		A(10,11) = aAB;		A(10,12) = aAC;		A(10,13) = aAD;\
		A(11,1) = aB1;		A(11,2) = aB2;		A(11,3) = aB3;		A(11,4) = aB4;		A(11,5) = aB5;		A(11,6) = aB6;		A(11,7) = aB7;		A(11,8) = aB8;		A(11,9) = aB9;		A(11,10) = aBA;		A(11,11) = aBB;		A(11,12) = aBC;		A(11,13) = aBD;\
		A(12,1) = aC1;		A(12,2) = aC2;		A(12,3) = aC3;		A(12,4) = aC4;		A(12,5) = aC5;		A(12,6) = aC6;		A(12,7) = aC7;		A(12,8) = aC8;		A(12,9) = aC9;		A(12,10) = aCA;		A(12,11) = aCB;		A(12,12) = aCC;		A(12,13) = aCD;\
		A(13,1) = aD1;		A(13,2) = aD2;		A(13,3) = aD3;		A(13,4) = aD4;		A(13,5) = aD5;		A(13,6) = aD6;		A(13,7) = aD7;		A(13,8) = aD8;		A(13,9) = aD9;		A(13,10) = aDA;		A(13,11) = aDB;		A(13,12) = aDC;		A(13,13) = aDD;\
	};

#define DEFINE_UMATRIX13(A, \
									a21,\
									a31, a32,\
									a41, a42, a43,\
									a51, a52, a53, a54,\
									a61, a62, a63, a64, a65,\
									a71, a72, a73, a74, a75, a76,\
									a81, a82, a83, a84, a85, a86, a87,\
									a91, a92, a93, a94, a95, a96, a97, a98,\
									aA1, aA2, aA3, aA4, aA5, aA6, aA7, aA8, aA9,\
									aB1, aB2, aB3, aB4, aB5, aB6, aB7, aB8, aB9, aBA,\
									aC1, aC2, aC3, aC4, aC5, aC6, aC7, aC8, aC9, aCA, aCB,\
									aD1, aD2, aD3, aD4, aD5, aD6, aD7, aD8, aD9, aDA, aDB, aDC) \
	{ \
		A.SetDim(13, 13);\
		A(2, 1) = a21;\
		A(3, 1) = a31;		A(3, 2) = a32;\
		A(4, 1) = a41;		A(4, 2) = a42;		A(4, 3) = a43;\
		A(5, 1) = a51;		A(5, 2) = a52;		A(5, 3) = a53;		A(5, 4) = a54;\
		A(6, 1) = a61;		A(6, 2) = a62;		A(6, 3) = a63;		A(6, 4) = a64;		A(6, 5) = a65;\
		A(7, 1) = a71;		A(7, 2) = a72;		A(7, 3) = a73;		A(7, 4) = a74;		A(7, 5) = a75;		A(7, 6) = a76;\
		A(8, 1) = a81;		A(8, 2) = a82;		A(8, 3) = a83;		A(8, 4) = a84;		A(8, 5) = a85;		A(8, 6) = a86;		A(8, 7) = a87;\
		A(9, 1) = a91;		A(9, 2) = a92;		A(9, 3) = a93;		A(9, 4) = a94;		A(9, 5) = a95;		A(9, 6) = a96;		A(9, 7) = a97;		A(9, 8) = a98;\
		A(10,1) = aA1;		A(10,2) = aA2;		A(10,3) = aA3;		A(10,4) = aA4;		A(10,5) = aA5;		A(10,6) = aA6;		A(10,7) = aA7;		A(10,8) = aA8;		A(10,9) = aA9;\
		A(11,1) = aB1;		A(11,2) = aB2;		A(11,3) = aB3;		A(11,4) = aB4;		A(11,5) = aB5;		A(11,6) = aB6;		A(11,7) = aB7;		A(11,8) = aB8;		A(11,9) = aB9;		A(11,10) = aBA;\
		A(12,1) = aC1;		A(12,2) = aC2;		A(12,3) = aC3;		A(12,4) = aC4;		A(12,5) = aC5;		A(12,6) = aC6;		A(12,7) = aC7;		A(12,8) = aC8;		A(12,9) = aC9;		A(12,10) = aCA;		A(12,11) = aCB;\
		A(13,1) = aD1;		A(13,2) = aD2;		A(13,3) = aD3;		A(13,4) = aD4;		A(13,5) = aD5;		A(13,6) = aD6;		A(13,7) = aD7;		A(13,8) = aD8;		A(13,9) = aD9;		A(13,10) = aDA;		A(13,11) = aDB;		A(13,12) = aDC;\
	};
#endif // if 0
