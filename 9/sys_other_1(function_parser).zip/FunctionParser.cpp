// FunctionParser.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <math.h>
#include <fstream.h>
#include "FunctionParser.h"

#include "Collect.h"
#include "mathutil.h"
#include "Vektor.h"
#include "FktParser.h"
#include "Mathstr.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// The one and only application object

CWinApp theApp;

using namespace std;

int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
	int nRetCode = 0;

	// initialize MFC and print and error on failure
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		// TODO: change error code to suit your needs
		std::cerr << _T("Fatal Error: MFC initialization failed") << endl;
		nRetCode = 1;
	}
	else
	{
		CString strResult;

		// Read in a valid expression (math. term)
		CString Expression;
		char buffer[255];
		std::cout << "f(x)=";
		std::cin >> buffer;
		Expression = buffer;
		// Parse it and get the function tree
		CFunction<long double>* fkt = CFunction<long double>::Parse(Expression);
		if (fkt)
		{
			// Read in the argument
			long double x;
			std::cout << "x=";
			std::cin >> x;

			// Display results
			long double y = fkt->Execute(x);
			strResult.Format("Expression=%s  f(%Lf)=%Lf", (LPCTSTR)Expression, x, y);
			std::cout << (LPCTSTR)strResult << endl;
			CString ExpressionParsed = fkt->GetName();
			strResult.Format("Expression (parsed)=%s", (LPCTSTR)ExpressionParsed);
			std::cout << (LPCTSTR)strResult << endl;
			CFunction<long double>* df = fkt->GetDerivate();
			if (df)
			{
				long double dy = df->Execute(x);
				CString ExpressionDerived = df->GetName();
				strResult.Format("Expression (derivate)=%s  f'(%Lf)=%Lf", (LPCTSTR)ExpressionDerived, x, dy);
				std::cout << (LPCTSTR)strResult << endl;
				delete df;
			}
		}
		else
		{
			strResult.Format("Expression=%s  Error", (LPCTSTR)Expression);
			std::cout << (LPCTSTR)strResult << endl;
		}
	}

	return nRetCode;
}


