#if !defined(AFX_MERGETHREAD_H__E7DEDBAC_581D_11D4_96E8_00C04F796AE5__INCLUDED_)
#define AFX_MERGETHREAD_H__E7DEDBAC_581D_11D4_96E8_00C04F796AE5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MergeThread.h : header file
//

class CProgMergeDlg;

/////////////////////////////////////////////////////////////////////////////
// CMergeThread thread

class CMergeThread : public CWinThread
{
	DECLARE_DYNAMIC(CMergeThread)
	CMergeThread(CProgMergeDlg *pWnd);           // protected constructor used by dynamic creation

// Attributes
public:

// Operations
public:
	int m_len;
	BOOL m_bErrResult;
	CProgMergeDlg *m_pDlg;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMergeThread)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMergeThread();

	// Generated message map functions
	//{{AFX_MSG(CMergeThread)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
protected:
	BOOL m_check;
	CFile m_SourceFile;
	void MergeMe();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MERGETHREAD_H__E7DEDBAC_581D_11D4_96E8_00C04F796AE5__INCLUDED_)
