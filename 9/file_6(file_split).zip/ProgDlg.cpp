// ProgDlg.cpp : implementation file
//

#include "stdafx.h"
#include "splitme.h"
#include "ProgDlg.h"
#include "SplitMeDlg.h"
#include "SplitThread.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CProgDlg dialog


CProgDlg::CProgDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CProgDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CProgDlg)
	m_parts = _T("");
	m_pThread = NULL;
	//}}AFX_DATA_INIT
}


void CProgDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CProgDlg)
	DDX_Control(pDX, IDC_ANIMATE1, m_avi);
	DDX_Text(pDX, IDC_PARTS, m_parts);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CProgDlg, CDialog)
	//{{AFX_MSG_MAP(CProgDlg)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CProgDlg message handlers


BOOL CProgDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_pParent = (CSplitMeDlg*)GetParent();
	m_checkSplit = FALSE;

	SplitMe(m_pParent);

	return FALSE;  
}

void CProgDlg::OnDestroy() 
{
	if (m_pThread) {
		m_pThread = NULL;
		delete m_pThread;
	}
	CDialog::OnDestroy();
}

void CProgDlg::SplitMe(CSplitMeDlg *pDlg)
{

	// constructing these file objects
	CFile destFile;
	// we'll use a CFileException object to get error information
	CFileException ex;

	UINT nCount = 140000;
	double newlen = 1400000;
	char b [20];
	long l = 1;
	CString name;

	UpdateData(TRUE);

	m_checkSplit = pDlg->m_checkSplit.GetState();

	if (m_checkSplit)
		GetDlgItem(IDCANCEL)->EnableWindow(FALSE);

	if (!pDlg->m_path.IsEmpty()) {
		if (!m_SourceFile.Open(pDlg->m_path, CFile::modeRead | CFile::shareDenyNone | CFile::typeBinary, &ex)) {
			TCHAR szError[1024];
			ex.GetErrorMessage(szError, 1024);
      		::AfxMessageBox(szError);
			pDlg->m_edit.SetFocus();
			pDlg->m_edit.SetSel(0, -1);
			OnCancel();
			return ;
		}
	}
	else {
		MessageBox(_T("Please select source file."), _T("QuickSplit"), MB_ICONEXCLAMATION);
		OnCancel();
		return ;
	}
	if (pDlg->m_targetpath.IsEmpty()) {
		MessageBox(_T("Please select target folder."), _T("QuickSplit"), MB_ICONEXCLAMATION);
		OnCancel();
		return ;
	}
	m_len = m_SourceFile.GetLength();
	if (m_len < 1452001) {
		CString length = _itoa(m_len, b, 10);
		MessageBox(_T("File is " + length + " bytes long. Splitting is not necessary."), _T("QuickSplit"), MB_ICONEXCLAMATION);
		m_SourceFile.Close();
		m_path = _T("");
		pDlg->m_filename = _T("");
		UpdateData(FALSE);
		OnCancel();
		return ;
	}
	m_filename = pDlg->m_filename;
	m_path = pDlg->m_targetpath;

	StartSplitThread();

}

void CProgDlg::StartSplitThread()
{
	m_pThread = new CSplitThread(this);


	m_pThread->m_len = m_len;

	if (m_pThread == NULL)
		return;

	ASSERT_VALID(m_pThread);
	m_pThread->m_pThreadParams = NULL;

	// Create Thread in a suspended state so we can set the Priority
	// before it starts getting away from us
	if (!m_pThread->CreateThread(CREATE_SUSPENDED))
	{
		delete m_pThread;
		return;
	}
	// If you want to make the sample more sprightly, set the thread priority here
	// a little higher. It has been set at idle priority to keep from bogging down
	// other apps that may also be running.
	VERIFY(m_pThread->SetThreadPriority(THREAD_PRIORITY_IDLE));
	// Now the thread can run wild
	m_pThread->ResumeThread();

}

void CProgDlg::OnCancel() 
{

	if (m_pThread) {
		m_pThread->SuspendThread();
	}
	CDialog::OnCancel();
}

