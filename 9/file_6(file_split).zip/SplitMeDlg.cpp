// SplitMeDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SplitMe.h"
#include "SplitMeDlg.h"
#include "DirDialog.h"
#include "HyperLink.h"
#include "SplitThread.h"
#include "ProgDlg.h"
#include "ProgMergeDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	CHyperLink	m_MailButton;
	CString	m_edit;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	m_edit = _T("");
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	DDX_Control(pDX, IDC_HYPER, m_MailButton);
	DDX_Text(pDX, IDC_EDIT1, m_edit);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSplitMeDlg dialog

CSplitMeDlg::CSplitMeDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSplitMeDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSplitMeDlg)
	m_path = _T("");
	m_targetpath = _T("");
	m_split = TRUE;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSplitMeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSplitMeDlg)
	DDX_Control(pDX, IDC_BUTT_SPLIT, m_buttSplit);
	DDX_Control(pDX, IDC_BROWSE2, m_Browse2);
	DDX_Control(pDX, IDC_BROWSE, m_Browse);
	DDX_Control(pDX, IDC_PATH, m_edit);
	DDX_Control(pDX, IDC_CHECK2, m_checkSplit);
	DDX_Control(pDX, IDC_RADIO3, m_RadioSplit);
	DDX_Control(pDX, IDC_CHECK, m_check);
	DDX_Text(pDX, IDC_PATH, m_path);
	DDX_Text(pDX, IDC_PATH2, m_targetpath);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSplitMeDlg, CDialog)
	//{{AFX_MSG_MAP(CSplitMeDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTT_SPLIT, OnButtSplit)
	ON_BN_CLICKED(IDC_UNSPLIT, OnMerge)
	ON_BN_CLICKED(IDC_BROWSE, OnBrowse)
	ON_BN_CLICKED(IDC_RADIO4, OnRadioMerge)
	ON_BN_CLICKED(IDC_RADIO3, OnRadioSplit)
	ON_EN_CHANGE(IDC_PATH, OnChangePath)
	ON_BN_CLICKED(IDC_BROWSE2, OnBrowse2)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSplitMeDlg message handlers

BOOL CSplitMeDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	if (m_split) 
		m_RadioSplit.SetCheck(1);

	CButton *pButtonMerge = (CButton*)(GetDlgItem(IDC_UNSPLIT));
	pButtonMerge->EnableWindow(FALSE);

	m_path =_T("");
	m_filename =_T("");
	m_checkSplit.SetCheck(1);

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	HICON hIconBrowse;
	hIconBrowse = AfxGetApp()->LoadIcon(IDI_ICON_FOLDER);

	// Set the icon of the button to be the system question mark icon.
	m_Browse.SetIcon(hIconBrowse); 
	m_Browse2.SetIcon(hIconBrowse);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CSplitMeDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSplitMeDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSplitMeDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CSplitMeDlg::OnButtSplit() 
{
	SplitMe();
}

void CSplitMeDlg::OnMerge() 
{
	MergeMe();

}

int CSplitMeDlg::MergeMe() 
{
	UpdateData(TRUE);
	CProgMergeDlg dlg;
	dlg.DoModal();

	return 0;
}

void CSplitMeDlg::SplitMe() 
{
	UpdateData(TRUE);

	CProgDlg dlg;
	dlg.DoModal();
}


void CSplitMeDlg::OnBrowse() 
{
	static char BASED_CODE szSplitFilter[] = _T("All Files (*.*)|*.*||");
	static char BASED_CODE szMergeFilter[] = _T("All Files (1_*.*)|1_*.*||");

	CString filter;
	if (!m_split)
		filter = szMergeFilter;
	else 
		filter = szSplitFilter;

	CFileDialog dlg(TRUE,
					NULL, 
					NULL, 
					OFN_HIDEREADONLY	| 
					OFN_OVERWRITEPROMPT | 
					OFN_FILEMUSTEXIST,
					filter,
					0);

	if (dlg.DoModal() == IDOK) {
		m_path = dlg.GetPathName();
		m_filename = dlg.GetFileName();
		UpdateData(FALSE);
	}
}

void CSplitMeDlg::OnRadioMerge() 
{
	CButton *pCheck = (CButton*)(GetDlgItem(IDC_CHECK));
	CButton *pCheckSplit = (CButton*)(GetDlgItem(IDC_CHECK2));
	CButton *pButtonMerge = (CButton*)(GetDlgItem(IDC_UNSPLIT));
	CButton *pButtonSplit = (CButton*)(GetDlgItem(IDC_BUTT_SPLIT));

	pCheck->EnableWindow(TRUE);
	pButtonSplit->EnableWindow(FALSE);
	pCheckSplit->EnableWindow(FALSE);
	pButtonMerge->EnableWindow(TRUE);
	m_split = FALSE;
	m_path = _T("");
	UpdateData(FALSE);

}

void CSplitMeDlg::OnRadioSplit() 
{
	CButton *pCheck = (CButton*)(GetDlgItem(IDC_CHECK));
	CButton *pButtonMerge = (CButton*)(GetDlgItem(IDC_UNSPLIT));
	CButton *pButtonSplit = (CButton*)(GetDlgItem(IDC_BUTT_SPLIT));
	CButton *pCheckSplit = (CButton*)(GetDlgItem(IDC_CHECK2));

	pCheck->EnableWindow(FALSE);
	pButtonSplit->EnableWindow(TRUE);
	pCheckSplit->EnableWindow(TRUE);
	pButtonMerge->EnableWindow(FALSE);
	m_split = TRUE;
	m_path = _T("");
	UpdateData(FALSE);
}

void CSplitMeDlg::OnChangePath() 
{
		
}

void CSplitMeDlg::OnBrowse2() 
{
	CDirDialog	dlg;
	if (dlg.DoBrowse(this) == IDOK) {
		m_targetpath = dlg.m_strPath;
		UpdateData(FALSE);
	}
}

void CSplitMeDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
}

BOOL CAboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_MailButton.SetURL(_T("mailto:dmitriy_okunev@hotmail.com"));
	m_MailButton.SetColours(m_MailButton.GetLinkColour(),m_MailButton.GetLinkColour());

	return TRUE;  
}

void CAboutDlg::OnOK() 
{
	// TODO: Add extra validation here
	
	CDialog::OnOK();
}



