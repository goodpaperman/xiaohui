// MergeThread.cpp : implementation file
//

#include "stdafx.h"
#include "splitme.h"
#include "MergeThread.h"
#include "ProgMergeDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

class CProgMergeDlg;

/////////////////////////////////////////////////////////////////////////////
// CMergeThread

IMPLEMENT_DYNAMIC(CMergeThread, CWinThread)

CMergeThread::CMergeThread(CProgMergeDlg *pWnd)
{
	m_pDlg = pWnd;
	m_bErrResult = TRUE;
}

CMergeThread::~CMergeThread()
{
}

BOOL CMergeThread::InitInstance()
{
	m_bAutoDelete = TRUE;
	m_check = FALSE;
	MergeMe();
	return TRUE;
}

int CMergeThread::ExitInstance()
{
	// TODO:  perform any per-thread cleanup here
	return CWinThread::ExitInstance();
}

void CMergeThread::MergeMe()
{
	BYTE buffer[140000];
	DWORD dwRead;
	UINT nCount = 140000;
	UINT newlen = 1400000;
	char buff [20];
	long l = 1;
	CString name;
	CString pref;
	CString newpath;

	CProgressCtrl *pProgress = (CProgressCtrl*) m_pDlg->GetDlgItem(IDC_PROGRESS1);
	m_check = m_pDlg->m_check;

	m_pDlg->m_avi.Open(IDR_AVI);
	m_pDlg->m_avi.Play(0, -1, -1);

	// we'll use a CFileException object to get error information
	CFileException ex;

	//do merge
	do {
		//constuct a new name
		pref = _ltoa(l, buff, 10);
		pref += _T("_");
		
		if (!m_pDlg->m_SourceFile.Open(newpath + pref + m_pDlg->m_filename,  
			CFile::modeRead		| 
			CFile::shareExclusive	| 
			CFile::typeBinary, &ex)) {
			TCHAR szError[1024];
			ex.GetErrorMessage(szError, 1024);
			m_pDlg->m_destFile.Close();
			m_pDlg->m_path = _T("");
			m_pDlg->m_filename = _T("");
			newpath = _T("");
			m_pDlg->GetDlgItem(IDC_PARTS)->SetWindowText((LPCTSTR)_T(""));
			m_pDlg->GetDlgItem(IDCANCEL)->EnableWindow(TRUE);
			m_pDlg->SendMessage(WM_CLOSE);
			m_bErrResult = 0;
			return;
		}
		else
			name = _T(newpath + pref + m_pDlg->m_filename);
		do  {
			dwRead = m_pDlg->m_SourceFile.Read(buffer, nCount);
			m_pDlg->m_destFile.Write(buffer, dwRead);
		}
		while (dwRead > 0);

		m_pDlg->m_SourceFile.Close();

		if (m_check == 1)
			m_SourceFile.Remove(name);

		// Set the range to be 0 to 100.
		pProgress->SetRange(0, 500);
		// Set the position
		for (int i = 0; i < 500; i++)
			pProgress->SetPos(i);

		m_pDlg->m_parts = _ltoa(l, buff, 10);
		m_pDlg->m_parts += _T(" Files are merged");
		m_pDlg->GetDlgItem(IDC_PARTS)->SetWindowText((LPCTSTR)m_pDlg->m_parts);
		l++;
	}
	while (l < 500);
	m_pDlg->m_avi.Close();

}
BEGIN_MESSAGE_MAP(CMergeThread, CWinThread)
	//{{AFX_MSG_MAP(CMergeThread)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMergeThread message handlers
