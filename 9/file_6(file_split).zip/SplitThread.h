#if !defined(AFX_SPLITTHREAD_H__EB68C691_52A9_11D4_96D5_00C04F796AE5__INCLUDED_)
#define AFX_SPLITTHREAD_H__EB68C691_52A9_11D4_96D5_00C04F796AE5__INCLUDED_

#include "SplitMeDlg.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SplitThread.h : header file
//

class CProgDlg;

/////////////////////////////////////////////////////////////////////////////
// CSplitThread thread

class CSplitThread : public CWinThread
{
public:
	DECLARE_DYNAMIC(CSplitThread)
	CSplitThread(CProgDlg *pWnd);           // protected constructor used by dynamic creation

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSplitThread)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation
public:
	int m_len;
	BOOL m_bErrResult;
	CProgDlg *m_pDlg;
	virtual ~CSplitThread();

	// Generated message map functions
	//{{AFX_MSG(CSplitThread)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
protected:
	BOOL m_check;
	void SplitMe();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SPLITTHREAD_H__EB68C691_52A9_11D4_96D5_00C04F796AE5__INCLUDED_)
