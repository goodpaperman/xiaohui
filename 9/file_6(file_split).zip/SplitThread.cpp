// SplitThread.cpp : implementation file
//

#include "stdafx.h"
#include "splitme.h"
#include "SplitThread.h"
#include "ProgDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSplitThread

IMPLEMENT_DYNAMIC(CSplitThread, CWinThread)

CSplitThread::CSplitThread(CProgDlg *pWnd)
{
	m_pDlg = pWnd;
	m_bErrResult = TRUE;
}

CSplitThread::~CSplitThread()
{
}

BOOL CSplitThread::InitInstance()
{
	m_bAutoDelete = TRUE;
	SplitMe();
	return TRUE;
}

int CSplitThread::ExitInstance()
{
	// TODO:  perform any per-thread cleanup here
	return CWinThread::ExitInstance();
}

BEGIN_MESSAGE_MAP(CSplitThread, CWinThread)
	//{{AFX_MSG_MAP(CSplitThread)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSplitThread message handlers

void CSplitThread::SplitMe()
{
	// constructing these file objects
	CFile destFile;
	// we'll use a CFileException object to get error information
	CFileException ex;

	BYTE buffer[140000];
	DWORD dwRead;
	UINT nCount = 140000;
	double newlen = 1400000;
	char buff [20];
	long l = 1;
	CString name;

	//get progress control 
	CProgressCtrl *pProgress = (CProgressCtrl*) m_pDlg->GetDlgItem(IDC_PROGRESS1);

	//start AVI
	m_pDlg->m_avi.Open(IDR_AVI);
	m_pDlg->m_avi.Play(0, -1, -1);

	//do split
	do {
		//constuct a new name
		name = _ltoa(l, buff, 10);
		name += _T("_");
		CString newpath = m_pDlg->m_path + _T("\\");
		if (!destFile.Open(newpath + name + m_pDlg->m_SourceFile.GetFileName(),  
			CFile::modeWrite		| 
			CFile::shareExclusive	| 
			CFile::typeBinary		|
			CFile::modeCreate, &ex)) {
			TCHAR szError[1024];
			ex.GetErrorMessage(szError, 1024);
			::AfxMessageBox(szError);
			m_pDlg->m_SourceFile.Close();
			m_bErrResult = 1;
			m_pDlg->GetDlgItem(IDCANCEL)->EnableWindow(TRUE);
			m_pDlg->SendMessage(WM_CLOSE);
			return ;
		}
		do {
			dwRead = m_pDlg->m_SourceFile.Read(buffer, nCount);
			destFile.Write(buffer, dwRead);
		}
		while (dwRead > 0 && destFile.GetLength() < newlen); 
		destFile.Close();

		// Set the range
		pProgress->SetRange(0, m_len / 1400000);
		// Set the position
		pProgress->SetPos(l);

		m_pDlg->m_parts = _ltoa(l + 1, buff, 10);
		m_pDlg->m_parts += _T(" Files are generated");
		m_pDlg->GetDlgItem(IDC_PARTS)->SetWindowText((LPCTSTR)m_pDlg->m_parts);
		l++;
		m_pDlg->UpdateWindow();
	}
	while (dwRead > 0);
		// close source
		m_pDlg->m_SourceFile.Close();

	if (m_pDlg->m_checkSplit)
		m_pDlg->m_SourceFile.Remove(m_pDlg->m_filename);

	m_pDlg->m_path = _T("");
	m_pDlg->m_filename = _T("");
	m_pDlg->m_parts = _T("");
	m_pDlg->m_avi.Stop();
	m_pDlg->m_avi.Close();
	pProgress->SetPos(0);
	m_pDlg->GetDlgItem(IDC_PARTS)->SetWindowText((LPCTSTR)m_pDlg->m_parts);
	m_pDlg->GetDlgItem(IDCANCEL)->EnableWindow(TRUE);
	m_pDlg->SendMessage(WM_CLOSE);
	m_bErrResult = 0;
	return ;
}

