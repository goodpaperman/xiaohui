// ProgMergeDlg.cpp : implementation file
//

#include "stdafx.h"
#include "splitme.h"
#include "ProgMergeDlg.h"
#include "SplitMeDlg.h"
#include "MergeThread.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CProgMergeDlg dialog


CProgMergeDlg::CProgMergeDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CProgMergeDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CProgMergeDlg)
	m_parts = _T("");
	m_pThread = NULL;
	//}}AFX_DATA_INIT
}


void CProgMergeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CProgMergeDlg)
	DDX_Control(pDX, IDC_ANIMATE2, m_avi);
	DDX_Text(pDX, IDC_PARTS, m_parts);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CProgMergeDlg, CDialog)
	//{{AFX_MSG_MAP(CProgMergeDlg)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CProgMergeDlg message handlers

BOOL CProgMergeDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_pParent = (CSplitMeDlg*)GetParent();

	MergeMe(m_pParent);
	
	return FALSE;  
}

void CProgMergeDlg::MergeMe(CSplitMeDlg *pDlg)
{

	// we'll use a CFileException object to get error information
	CFileException ex;

	UINT nCount = 140000;
	UINT newlen = 1400000;
	long l = 1;
	CString name;
	CString pref;
	CString newpath;
	LPCTSTR s;
		
	UpdateData(TRUE);

	m_path = pDlg->m_path;
	
	m_check = pDlg->m_check.GetState();
	if (m_check)
		GetDlgItem(IDCANCEL)->EnableWindow(FALSE);

	if (!m_path.IsEmpty()) {
		if (!m_SourceFile.Open(pDlg->m_path, CFile::modeRead | CFile::shareDenyNone | CFile::typeBinary, &ex)) {
			TCHAR szError[1024];
			ex.GetErrorMessage(szError, 1024);
      		::AfxMessageBox(szError);
			pDlg->m_edit.SetFocus();
			pDlg->m_edit.SetSel(0, -1);
			OnCancel();
			return;
		}
		m_filename = m_path.Right((m_path.GetLength() - m_path.ReverseFind('\\')) - 1);
		s = m_filename;
		m_SourceFile.Close();
	}

	//constuct a new name
	newpath = m_path.Left(m_path.GetLength() - m_filename.GetLength());

	if (!pDlg->m_targetpath.IsEmpty()) {
		if (!m_filename.IsEmpty() && m_filename.Left(2) != _T("1_")) {
			m_filename = m_filename.Left(2);
			s = m_filename;
			::AfxMessageBox(_T("Play smart..."), MB_ICONERROR);
			OnCancel();
			return;
		}
		else if(m_filename.IsEmpty()) {
			MessageBox(_T("Please select source file."), _T("QuickSplit"), MB_ICONEXCLAMATION);
			OnCancel();
			return;
		}
		m_filename = m_filename.Right(m_filename.GetLength() - 2);
		m_path = pDlg->m_targetpath + _T("\\") + m_filename;
		s = m_path;
		//constuct a new name
		if (!m_destFile.Open(m_path,  
			CFile::modeWrite		| 
			CFile::shareExclusive	| 
			CFile::typeBinary		| 
			CFile::modeCreate, &ex)) {
			TCHAR szError[1024];
			ex.GetErrorMessage(szError, 1024);
			::AfxMessageBox(szError);
			OnCancel();
			return;
		}
	}
	else {
		MessageBox(_T("Please select target folder."), _T("QuickSplit"), MB_ICONEXCLAMATION);
		OnCancel();
		return;
	}
	if (pDlg->m_targetpath.IsEmpty()) {
		MessageBox(_T("Please select target folder."), _T("QuickSplit"), MB_ICONEXCLAMATION);
		OnCancel();
		return;
	}

	StartMergeThread();

}

void CProgMergeDlg::StartMergeThread()
{
	m_pThread = new CMergeThread(this);


	m_pThread->m_len = m_len;

	if (m_pThread == NULL)
		return;

	ASSERT_VALID(m_pThread);
	m_pThread->m_pThreadParams = NULL;

	// Create Thread in a suspended state so we can set the Priority
	// before it starts getting away from us
	if (!m_pThread->CreateThread(CREATE_SUSPENDED))
	{
		delete m_pThread;
		return;
	}
	// If you want to make the sample more sprightly, set the thread priority here
	// a little higher. It has been set at idle priority to keep from bogging down
	// other apps that may also be running.
	VERIFY(m_pThread->SetThreadPriority(THREAD_PRIORITY_IDLE));
	// Now the thread can run wild
	m_pThread->ResumeThread();


}


void CProgMergeDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	if (m_pThread) {
		m_pThread = NULL;
		delete m_pThread;
	}
	
}

void CProgMergeDlg::OnCancel() 
{
	if (m_pThread) {
		m_pThread->SuspendThread();
	}	
	CDialog::OnCancel();
}
