#if !defined(AFX_PROGDLG_H__85069C16_52B8_11D4_96D7_00C04F796AE5__INCLUDED_)
#define AFX_PROGDLG_H__85069C16_52B8_11D4_96D7_00C04F796AE5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ProgDlg.h : header file
//

class CSplitThread;
class CSplitMeDlg;

/////////////////////////////////////////////////////////////////////////////
// CProgDlg dialog

class CProgDlg : public CDialog
{
// Construction
public:
	CString m_path;
	CProgDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CProgDlg)
	enum { IDD = IDD_PROG_DLG };
	CAnimateCtrl	m_avi;
	CString	m_parts;
	//}}AFX_DATA

public:
	int m_len;
	BOOL m_checkSplit;
	CString m_filename;
	CSplitThread *m_pThread;
	void StartSplitThread();
	CSplitMeDlg *m_pParent;
	void SplitMe(CSplitMeDlg *pDlg);
	CFile m_SourceFile;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CProgDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CProgDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROGDLG_H__85069C16_52B8_11D4_96D7_00C04F796AE5__INCLUDED_)
