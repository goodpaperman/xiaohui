#if !defined(AFX_PROGMERGEDLG_H__E7DEDBAB_581D_11D4_96E8_00C04F796AE5__INCLUDED_)
#define AFX_PROGMERGEDLG_H__E7DEDBAB_581D_11D4_96E8_00C04F796AE5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ProgMergeDlg.h : header file
//

class CMergeThread;
class CSplitMeDlg;

/////////////////////////////////////////////////////////////////////////////
// CProgMergeDlg dialog

class CProgMergeDlg : public CDialog
{
// Construction
public:
	CString m_path;
	CProgMergeDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CProgMergeDlg)
	enum { IDD = IDD_PROG_MERGE };
	CAnimateCtrl	m_avi;
	CString	m_parts;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CProgMergeDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
public:
	BOOL m_check;
	CFile m_destFile;
	int m_len;
	BOOL m_checkSplit;
	CString m_filename;
	CMergeThread *m_pThread;
	void StartMergeThread();
	CSplitMeDlg *m_pParent;
	void MergeMe(CSplitMeDlg *pDlg);
	CFile m_SourceFile;

	// Generated message map functions
	//{{AFX_MSG(CProgMergeDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROGMERGEDLG_H__E7DEDBAB_581D_11D4_96E8_00C04F796AE5__INCLUDED_)
