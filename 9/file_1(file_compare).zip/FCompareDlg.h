/**
 * @doc FCOMPARE
 * @module FCompareDlg.h - Interface for the FCompare dialog class application |
 * This application is a sample of CFileInfo and CFileInfoArray usage
 *
 * <cp> Codeguru & friends
 * Coded by Antonio Tejada Lacaci. 1999<nl>
 * atejada@espanet.com<nl>
 * 
 * Updates:<nl>
 *  1999-4-30 ATL: Corrected a bug when setting timers: requested timer was id 0 and MSDN help states
 *                 that the timer id must be greater than 0. This bug was pointed out to me by 
 *                 Javier Maura (�although the timer _does_ work even if its id is 0!!!).
 *                 The user is also warned about progress not being reported if SetTimer fails.
 *
 * Keep this comment if you redistribute this file. And credit where credit's due!
 */

#if !defined(AFX_FCOMPAREDLG_H__00F8A567_CFF8_11D2_AA42_A54123628E22__INCLUDED_)
#define AFX_FCOMPAREDLG_H__00F8A567_CFF8_11D2_AA42_A54123628E22__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FileInfo.h"

#define WM_SEARCH_FINISHED (WM_USER+1)
#define WM_COMPARE_FINISHED (WM_USER+2)

/////////////////////////////////////////////////////////////////////////////
// CFCompareDlg dialog

typedef struct {
   CFileInfo* pfinSource;
   CFileInfo* pfinTarget;
} MATCHSTRUCT;

class CFCompareDlg : public CDialog {
// Construction
public:
	CFCompareDlg(CWnd* pParent = NULL);	// standard constructor

   void UpdateCounters();
   BOOL CompareContents(CFileInfo* pfinSrc, CFileInfo* pfinDest, const DWORD dwUpTo, 
      volatile BOOL bAbort);
// Dialog Data
	// Dialog Data
	//{{AFX_DATA(CFCompareDlg)
	enum { IDD = DLG_FCOMPARE };
	CStatic	m_lblStatus;
	CStatic	m_lblTargetFiles;
	CStatic	m_lblSourceFiles;
	CStatic	m_lblMatchedFiles;
	CListCtrl	m_lstMatchedFiles;
	CTabCtrl	m_tabAction;
	CListCtrl	m_lstTargetFiles;
	CListCtrl	m_lstSourceFiles;
	CProgressCtrl	m_prgProgress;
	BOOL	m_bRecurse;
	int		m_nMatchCriteria;
	DWORD	m_dwUpto;
	CString	m_strAllowedMasks;
	CString	m_strDirectory;
	BOOL	m_bCompareDuplicates;
	//}}AFX_DATA

   CFileInfoArray m_fiaTargetInfos;
   CFileInfoArray m_fiaSourceInfos;
   CFileInfoArray* m_pfiaInfos; // Array where search thread will add FileInfos
   CListCtrl* m_plstFiles;      // ListView where search thread will add files
   CArray<MATCHSTRUCT, MATCHSTRUCT&> m_msaMatchedInfos;

   // Flags for thread communication
   volatile BOOL m_bAbort;
   volatile BOOL m_bExit;
   volatile BOOL m_bAddInProgress;
   volatile BOOL m_bCompareInProgress;
   volatile BOOL m_bFillInProgress;
   volatile ULONG m_ulProgress;
   volatile ULONG m_ulProgressMax;

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFCompareDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

   // Busy state
   enum { BS_IDLE, BS_SEARCHING, BS_COMPARING};
   // Property pages
   enum {PPG_SEARCH, PPG_COMPARE };

   int m_bsState;  // Busy state 
   void SetBusyState(int bsState);

	// Generated message map functions
	//{{AFX_MSG(CFCompareDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnMatchContents();
	afx_msg void OnMatchCriteria();
	afx_msg void OnCompare();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnGetdispinfoSearchFiles(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnExit();
	afx_msg void OnSelchangeAction(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnGetdispinfoMatchedFiles(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnExploreDirectory();
	afx_msg void OnAddSourceFiles();
	afx_msg void OnAddTargetFiles();
	afx_msg void OnClearSourceFiles();
	afx_msg void OnClearTargetFiles();
	afx_msg void OnClose();
	afx_msg void OnExport();
	//}}AFX_MSG
   afx_msg LONG OnSearchFinished(WPARAM wparam, LPARAM lparam);
   afx_msg LONG OnCompareFinished(WPARAM wparam, LPARAM lparam);
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FCOMPAREDLG_H__00F8A567_CFF8_11D2_AA42_A54123628E22__INCLUDED_)
