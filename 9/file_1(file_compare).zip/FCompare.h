// FCompare.h : main header file for the FCOMPARE application
//

#if !defined(AFX_FCOMPARE_H__00F8A565_CFF8_11D2_AA42_A54123628E22__INCLUDED_)
#define AFX_FCOMPARE_H__00F8A565_CFF8_11D2_AA42_A54123628E22__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CFCompareApp:
// See FCompare.cpp for the implementation of this class
//

class CFCompareApp : public CWinApp {
public:
	CFCompareApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFCompareApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CFCompareApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FCOMPARE_H__00F8A565_CFF8_11D2_AA42_A54123628E22__INCLUDED_)
