//
// The following example funtion shows how to use the CShellFileOp class.
//  
//  Tim Johnson, '98
//

long CCopyMoveDlg::DoCopyMoveOp(CString sThisFolder)
{
	CShellFileOp shOp;
	long lNameLength;
	int i, iCount;
	CString sDestDir, sSrcDir;
	CString sCache;

	sSrcDir = sThisFolder;

	shOp.SetParent(m_hWnd);
	shOp.SetFlags(FOF_FILESONLY | FOF_RENAMEONCOLLISION | FOF_NOCONFIRMMKDIR | FOF_MULTIDESTFILES);

	iCount = m_lstFiles.GetItemCount();
   
	//create the string of filenames to do: fname + NULL +fname
	sCache = ((CCacheApp *)AfxGetApp())->sCacheDir;

	//calc number of chars in total string
	lNameLength = 0;
	for (i = 0; i < iCount; i++)
	{
		lNameLength += m_lstFiles.GetItemText(i, 1).GetLength() + 1;	//+1 for null char
	}
	lNameLength += iCount * (sCache.GetLength() + 1);	//+1 for the \
	//set max count to prevent lots of re'allocs
	shOp.SetMaxCount(SH_SRC_FILE, lNameLength);

	//now add in all the strings
	for (i = 0; i < iCount; i++)
	{
		shOp.AddFile(SH_SRC_FILE, 
			sCache +
			"\\" +
			m_lstFiles.GetItemText(i, 1));
	}

	//now add destination directory
	shOp.AddFile(SH_DEST_FILE, 
		sThisFolder +
		"\\";
		

	//now do the operation
	return shOp.CopyFiles();
}	

