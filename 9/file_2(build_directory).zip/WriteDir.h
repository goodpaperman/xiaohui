//////////////////////////////////////////////////////////////
//  Source Code WriteDir()									//
//  Written by Brad Guttilla								//
//  BrickWall Software										//
//  PO Box 2438												//
//  La Mesa CA 91943										//
//															//
//  http://members.home.net/brickwall						//
//															//
//  Contributed to www.codeguru.com							//
//															//
//  Feel Free to use as you wish							//
//															//
//////////////////////////////////////////////////////////////



BOOL WriteDirectory(CString dd);
