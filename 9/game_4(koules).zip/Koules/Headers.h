
#include <AfxWin.h>
#include <AfxExt.h>
#include <AfxTempl.h>
#include <fstream.h>
#include <math.h>
#include <ddraw.h>
#include <dinput.h>
#include "resource.h"
#include "mmsystem.h"
#pragma	comment(lib,"winmm.lib")