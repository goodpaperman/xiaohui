//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Koules.rc
//
#define IDS_CHINASTR                    1
#define KOULES_VERSION_INFO             1
#define IDS_REGSUB                      2
#define IDS_MOUSEREG                    3
#define IDI_ICON                        101
#define IDR_MAINMENU                    102
#define IDR_ASCIIFONT                   106
#define IDD_ABOUT_DIALOG                107
#define IDR_KOULES                      114
#define IDR_RAWD2                       115
#define IDR_RAWCR1                      116
#define IDR_RAWCR2                      117
#define IDR_RAWD1                       118
#define IDR_RAWCO                       119
#define IDR_RAWE                        120
#define IDR_RAWS                        121
#define IDB_KOULESBITMAP                122
#define IDC_TIME                        1001
#define IDC_STATICINFO                  1004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        124
#define _APS_NEXT_COMMAND_VALUE         40014
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
