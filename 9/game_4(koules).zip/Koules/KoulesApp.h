#ifndef KOULESAPP_H
#define KOULESAPP_H


#include "DirectDrawApp.h"

class KoulesApp : public DirectDrawApp
{
public:
	BOOL  InitInstance();
protected:
	//{{AFX_MSG(KoulesApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


#endif
