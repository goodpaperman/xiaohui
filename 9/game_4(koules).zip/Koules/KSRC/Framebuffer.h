/***********************************************************
*  framebuffer.h   interface for framebuffer               *
***********************************************************/

extern void     create_bitmap ();
extern void     drawbackground ();
extern void     drawstarbackground ();
extern	void	createbackground ();
