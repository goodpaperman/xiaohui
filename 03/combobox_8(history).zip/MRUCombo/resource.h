//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MRUComboTest.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MRUCOMBOTEST_DIALOG         102
#define IDR_MAINFRAME                   128
#define IDD_SET_MRU_PARAMS              129
#define IDC_COMBO1                      1000
#define IDC_BROWSE                      1001
#define IDC_FILESIZE                    1002
#define IDC_CHANGE_MRU                  1006
#define IDC_REG_KEY                     1008
#define IDC_REG_VALUE                   1009
#define IDC_MRU_SIZE                    1010
#define IDC_SPIN1                       1011
#define IDC_CLEAR_MRU                   1012

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
