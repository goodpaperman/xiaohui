//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PushPinSheet.rc
//
#define IDD_PUSHPINSHEET_DIALOG         102
#define IDS_PROPSHT_CAPTION             103
#define IDD_PROPPAGE1                   104
#define IDD_PROPPAGE2                   105
#define IDR_MAINFRAME                   128
#define IDB_UNPINNEDEDGE_BITMAP         131
#define IDB_PINNEDEDGE_BITMAP           132
#define IDB_UNPINNED_BITMAP             133
#define IDB_PINNED_BITMAP               134
#define IDC_BUTTON1                     1000
#define IDC_RADIO1                      1001
#define IDC_RADIO2                      1002
#define IDC_RADIO3                      1003
#define IDC_TAB1                        1004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           106
#endif
#endif
