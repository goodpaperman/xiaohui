//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Eureka.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_EUREKA_DIALOG               102
#define IDR_MAINFRAME                   128
#define IDI_MAG_GLASS_BLANK             130
#define IDC_MAG_GLASS                   140
#define IDI_MAG_GLASS                   141
#define IDC_EDT_XYPOS                   1000
#define IDC_STC_MAG_GLASS               1002
#define IDC_EDT_WND_CLASS               1003
#define IDC_EDT_HWND                    1004
#define IDC_EDT_IS_PASSWORD             1005
#define IDC_EDT_PASSWORD                1006
#define IDC_BTN_ALWAYS_ON_TOP           1007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        142
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
