// stdafx.cpp : source file that includes just the standard includes
//	DualListDemo.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information
// MFC generated code: no changes necessary

#include "stdafx.h"



