#if !defined(AFX_PROPPAGEADD_H__BCF3E7E2_EC5A_11D4_AE2A_0000E2334E4D__INCLUDED_)
#define AFX_PROPPAGEADD_H__BCF3E7E2_EC5A_11D4_AE2A_0000E2334E4D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PropPageAdd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPropPageAdd dialog

class CPropPageAdd : public CPropertyPage
{
	DECLARE_DYNCREATE(CPropPageAdd)

// Construction
public:
	void Reset();
	BOOL Execute();
	CPropPageAdd();
	~CPropPageAdd();

// Dialog Data
	//{{AFX_DATA(CPropPageAdd)
	enum { IDD = IDD_PROPPAGE_ADDRECORD };
	long	m_ID;
	CString		m_strWorkUnit;
	CString		m_strLinkMan;
	CString		m_strTelNumber;
	CString		m_strWorkPosition;
	CString		m_strWorkContent;
	CString		m_strWorkAmount;
	COleDateTime	m_oletWorkDate;
	CString		m_strWorkGroup;
	COleCurrency	m_olecExpense;
	COleDateTime	m_oletDataTime;
	CString		m_strDataPosition;
	CString		m_strRemark;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPropPageAdd)
	public:
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPropPageAdd)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROPPAGEADD_H__BCF3E7E2_EC5A_11D4_AE2A_0000E2334E4D__INCLUDED_)
