// PropPageQuery.cpp : implementation file
//

#include "stdafx.h"
#include "IMS.h"
#include "PropPageQuery.h"
#include "IMSDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropPageQuery property page

IMPLEMENT_DYNCREATE(CPropPageQuery, CPropertyPage)

CPropPageQuery::CPropPageQuery() : CPropertyPage(CPropPageQuery::IDD)
{
	//{{AFX_DATA_INIT(CPropPageQuery)
	m_bExpense = FALSE;
	m_bWorkDate = FALSE;
	m_bWorkGroup = FALSE;
	m_bWorkPosition = FALSE;
	m_oletEndWork = COleDateTime::GetCurrentTime();
	m_oletStartWork = COleDateTime::GetCurrentTime();
	m_strWorkGroup = _T("");
	m_nExpense = 0;
	m_strWorkPosition = _T("");
	m_bDataTime = FALSE;
	m_bLinkMan = FALSE;
	m_bTelNumber = FALSE;
	m_bWorkContent = FALSE;
	m_bWorkUnit = FALSE;
	m_strLinkMan = _T("");
	m_strTelNumber = _T("");
	m_strWorkContent = _T("");
	m_strWorkUnit = _T("");
	m_oletEndDataTime = COleDateTime::GetCurrentTime();
	m_oletStartDataTime = COleDateTime::GetCurrentTime();
	//}}AFX_DATA_INIT
}

CPropPageQuery::~CPropPageQuery()
{
}

void CPropPageQuery::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropPageQuery)
	DDX_Check(pDX, IDC_CHECK_EXPENSES, m_bExpense);
	DDX_Check(pDX, IDC_CHECK_WORKDATE, m_bWorkDate);
	DDX_Check(pDX, IDC_CHECK_WORKGROUP, m_bWorkGroup);
	DDX_Check(pDX, IDC_CHECK_WORKPOSITION, m_bWorkPosition);
	DDX_DateTimeCtrl(pDX, IDC_ENDWORKDATE, m_oletEndWork);
	DDX_DateTimeCtrl(pDX, IDC_STARTWORKDATE, m_oletStartWork);
	DDX_CBString(pDX, IDC_WORKGROUP, m_strWorkGroup);
	DDX_CBIndex(pDX, IDC_EXPENSES, m_nExpense);
	DDX_Text(pDX, IDC_WORKPOSITION, m_strWorkPosition);
	DDX_Check(pDX, IDC_CHECK_DATATIME, m_bDataTime);
	DDX_Check(pDX, IDC_CHECK_LINKMAN, m_bLinkMan);
	DDX_Check(pDX, IDC_CHECK_TELNUMBER, m_bTelNumber);
	DDX_Check(pDX, IDC_CHECK_WORKCONTENT, m_bWorkContent);
	DDX_Check(pDX, IDC_CHECK_WORKUNIT, m_bWorkUnit);
	DDX_Text(pDX, IDC_LINKMAN, m_strLinkMan);
	DDX_Text(pDX, IDC_TELNUMBER, m_strTelNumber);
	DDX_CBString(pDX, IDC_WORKCONTENT, m_strWorkContent);
	DDX_Text(pDX, IDC_WORKUNIT, m_strWorkUnit);
	DDX_DateTimeCtrl(pDX, IDC_ENDDATATIME, m_oletEndDataTime);
	DDX_DateTimeCtrl(pDX, IDC_STARTDATATIME, m_oletStartDataTime);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPropPageQuery, CPropertyPage)
	//{{AFX_MSG_MAP(CPropPageQuery)
	ON_BN_CLICKED(IDC_CHECK_WORKPOSITION, OnCheckWorkposition)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropPageQuery message handlers

BOOL CPropPageQuery::OnSetActive() 
{
	nActivePage = 1;		
	CIMSDlg *pCIMDlg = (CIMSDlg *)(AfxGetApp( )->m_pMainWnd);
	CWnd *pWnd = pCIMDlg->GetDlgItem(IDC_EXECUTE);
	pWnd->SetWindowText("��ѯ��¼(&F)");
	return CPropertyPage::OnSetActive();
}

BOOL CPropPageQuery::Execute()
{

	CString strFilter = "";
	BOOL bFirstSQLOperand =	TRUE;
	// Update to get the status of the filter parameters
	UpdateData(TRUE);

	if ( m_bWorkUnit ) {
		if ( bFirstSQLOperand ) {
			strFilter += CString ( "[���赥λ] Like '" ) + m_strWorkUnit + CString ( "'" );
			bFirstSQLOperand = FALSE;
		}
		else
			strFilter += CString ( " AND [���赥λ] Like '" ) + m_strWorkUnit + CString ( "'" );
	}
	if ( m_bLinkMan ) {
		if ( bFirstSQLOperand ) {
			strFilter += CString ( "[��ϵ��] Like '" ) + m_strLinkMan + CString ( "'" );
			bFirstSQLOperand = FALSE;
		}
		else
			strFilter += CString ( " AND [��ϵ��] Like '" ) + m_strLinkMan + CString ( "'" );
	}
	if ( m_bTelNumber ) {
		if ( bFirstSQLOperand ) 
		{
			strFilter += CString ( "[��ϵ�绰] Like '" ) + m_strTelNumber + CString ( "'" );
			bFirstSQLOperand = FALSE;
		}
		else
			strFilter += CString ( " AND [��ϵ�绰] Like '" ) + m_strTelNumber + CString ( "'" );
	}
	if ( m_bExpense ) {
		if( m_nExpense == 1 )
		{
			if ( bFirstSQLOperand )
			{
				strFilter += CString ( "[�շ�] > 0" );
				bFirstSQLOperand = FALSE;
			}
			else
				strFilter += CString ( " AND [�շ�] >0" );
		}
		else if( m_nExpense == 0 )
		{
			if ( bFirstSQLOperand )
			{
				strFilter += CString ( "[�շ�] = 0" );
				bFirstSQLOperand = FALSE;
			}
			else
				strFilter += CString ( " AND [�շ�] = 0" );
		}
	}
	if ( m_bWorkPosition ) {
		if ( bFirstSQLOperand ) {
			strFilter += CString ( "[���̵ص�] Like '" ) + m_strWorkPosition + CString ( "'" );
			bFirstSQLOperand = FALSE;
		}
		else
			strFilter += CString ( " AND [���̵ص�] Like '" ) + m_strWorkPosition + CString ( "'" );
	}
	if ( m_bWorkGroup ) {
		if ( bFirstSQLOperand ) {
			strFilter += CString ( "[��������] Like '" ) + m_strWorkGroup + CString ( "'" );
			bFirstSQLOperand = FALSE;
		}
		else
			strFilter += CString ( " AND [��������] Like '" ) + m_strWorkGroup + CString ( "'" );
	}
	if ( m_bDataTime ) {
		CString strStartDataTime = m_oletStartDataTime.Format(_T("%m-%d-%Y") );
		CString strEndDataTime = m_oletEndDataTime.Format(_T("%m-%d-%Y") );

		if ( bFirstSQLOperand ) {
			strFilter += CString ( "[��������] between #" ) + strStartDataTime + CString ( "# and #" ) + strEndDataTime +CString ( "#" );
			bFirstSQLOperand = FALSE;
		}
		else
			strFilter += CString ( " AND [��������] between #" ) + strStartDataTime + CString ( "# and #" ) + strEndDataTime +CString ( "#" );
	}
	if ( m_bWorkContent ) {
		if ( bFirstSQLOperand ) {
			strFilter += CString ( "[��ҵ����] Like '" ) + m_strWorkPosition + CString ( "'" );
			bFirstSQLOperand = FALSE;
		}
		else
			strFilter += CString ( " AND [��ҵ����] Like '" ) + m_strWorkPosition + CString ( "'" );
	}
	if ( m_bWorkDate ) {
		CString strStartWork = m_oletStartWork.Format(_T("%m-%d-%Y") );
		CString strEndWork = m_oletEndWork.Format(_T("%m-%d-%Y") );

		if ( bFirstSQLOperand ) {
			strFilter += CString ( "[��������] between #" ) + strStartWork + CString ( "# and #" ) + strEndWork +CString ( "#" );
			bFirstSQLOperand = FALSE;
		}
		else
			strFilter += CString ( " AND [��������] between #" ) + strStartWork + CString ( "# and #" ) + strEndWork +CString ( "#" );
	}

	daoRecordset . m_strFilter = strFilter;
	return TRUE;
}

void CPropPageQuery::OnCheckWorkposition() 
{
	UpdateData(TRUE);
	if( m_bWorkPosition	)
		m_bWorkPosition = FALSE;
	else
		m_bWorkPosition = TRUE;
}
