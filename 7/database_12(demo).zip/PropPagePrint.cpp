// PropPagePrint.cpp : implementation file
//

#include "stdafx.h"
#include "IMS.h"
#include "PropPagePrint.h"
#include "IMSDlg.h"
#include "math.h"
#include "PrintingDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropPagePrint property page

IMPLEMENT_DYNCREATE(CPropPagePrint, CPropertyPage)

CPropPagePrint::CPropPagePrint() : CPropertyPage(CPropPagePrint::IDD)
{
	//{{AFX_DATA_INIT(CPropPagePrint)
	m_strTitle = _T("����������Ϣϵͳ���޹�˾");
	m_strPrinterName = _T("");
	m_nFromPage = 0;
	m_nToPage = 0;
	m_nTotalPage = 0;
	m_nRatioRange = 0;
	m_strPaperSize = _T("");
	//}}AFX_DATA_INIT
}

CPropPagePrint::~CPropPagePrint()
{
}

void CPropPagePrint::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropPagePrint)
	DDX_Text(pDX, IDC_EDIT_TITLE, m_strTitle);
	DDV_MaxChars(pDX, m_strTitle, 30);
	DDX_CBString(pDX, IDC_COMBO_PRINTERNAME, m_strPrinterName);
	DDX_Text(pDX, IDC_EDIT_FROMPAGE, m_nFromPage);
	DDX_Text(pDX, IDC_EDIT_TOPAGE, m_nToPage);
	DDX_Text(pDX, IDC_EDIT_TOTALPAGE, m_nTotalPage);
	DDX_Radio(pDX, IDC_RADIO_RANG, m_nRatioRange);
	DDX_CBString(pDX, IDC_COMBO_PAPERSIZE, m_strPaperSize);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPropPagePrint, CPropertyPage)
	//{{AFX_MSG_MAP(CPropPagePrint)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropPagePrint message handlers

BOOL CPropPagePrint::OnSetActive() 
{
	nActivePage = 4;		
	CIMSDlg *pCIMDlg = (CIMSDlg *)(AfxGetApp( )->m_pMainWnd);
	CWnd *pWnd = pCIMDlg->GetDlgItem(IDC_EXECUTE);
	pWnd->SetWindowText("��ӡ��¼(&P)");
	return CPropertyPage::OnSetActive();
}

BOOL CPropPagePrint::Execute()
{
	UpdateData(TRUE);
	UINT nStartPage, nEndPage;

	PreparePrinting();

	if( m_nRatioRange == 0 )
	{
		nStartPage = 1;
		nEndPage = m_nTotalPage;
	}
	else
	{
		if( m_nFromPage < 1 || m_nToPage > m_nTotalPage ||
			m_nToPage < 1 || m_nFromPage > m_nTotalPage ||
			m_nToPage < m_nFromPage)
		{
			AfxMessageBox("��ӡҳ��ѡ���д���,\n  ������ѡ��");
			return FALSE;
		}
		nStartPage = m_nFromPage;
		nEndPage = m_nToPage;
	}

	// set abort
	dcPrint.SetAbortProc(AbortProc);

	// disable main window while printing & init printing status dialog
	AfxGetMainWnd()->EnableWindow(FALSE);
	CPrintingDialog dlgPrintStatus(this);

	dlgPrintStatus.ShowWindow(SW_SHOW);
	dlgPrintStatus.UpdateWindow();


	// start printing process, if it fails, complain and exit gracefully
	DOCINFO docInfo;
	memset(&docInfo, 0, sizeof(docInfo));
	docInfo.cbSize = sizeof(docInfo);
	docInfo.lpszDocName = _T("����в��Ժ��������");
	if(dcPrint.StartDoc(&docInfo) == SP_ERROR)
	{
		// enable main window before proceeding
		AfxGetMainWnd()->EnableWindow(TRUE);

		// cleanup and show error message
		dlgPrintStatus.DestroyWindow();
		dcPrint.Detach();   // will be cleaned up by CPrintInfo destructor
		AfxMessageBox(AFX_IDP_FAILED_TO_START_PRINT);
		return FALSE;
	}
   
	// begin page printing loop

	BOOL bError = FALSE;
	for (UINT nCurrentPage = nStartPage; nCurrentPage <= nEndPage; nCurrentPage++ )
	{
		// attempt to start the current page
		if (dcPrint.StartPage() < 0)
		{
			bError = TRUE;
			break;
		}

		// page successfully started, so now render the page
		PrintPage(nCurrentPage);
		
		// attempt to end the current page
		if (dcPrint.EndPage() < 0 || !AbortProc(dcPrint.m_hDC, 0))
		{
			bError = TRUE;
			break;
		}
	}

	// end printing process
	if (!bError)
		dcPrint.EndDoc();
	else
		dcPrint.AbortDoc();
	
	AfxGetMainWnd()->EnableWindow();		// enable main window
	dlgPrintStatus.DestroyWindow();
	dcPrint.Detach();						// will be cleaned up by CPrintInfo destructor
	return TRUE;
}

void CPropPagePrint::PrintPage( UINT nCurrentPage)
{
	// print title
	LOGFONT lf;
	memset(&lf, 0, sizeof(LOGFONT));       // zero out structure
	lf.lfHeight = m_rectDraw.bottom / 50;  // request a 75-pixel-height font
	lf.lfWeight = 700;					   // bold
	strcpy(lf.lfFaceName, "Arial");        // request a face name "Arial"

	CFont HeaderFont;
	CFont *pOldFont = NULL;
	if( HeaderFont.CreateFontIndirect(&lf) )  // create the font
		pOldFont = dcPrint.SelectObject(&HeaderFont);
	
	dcPrint.SetTextAlign(TA_CENTER);
	dcPrint.TextOut( m_rectDraw.right / 2, m_rectDraw.bottom/10, m_strTitle);
	
	if(pOldFont != NULL)
		dcPrint.SelectObject(&pOldFont);
	// Done with the font. Delete the font object.
	HeaderFont.DeleteObject();
	
	// print item name
	CFont ItemHeadFont;
	lf.lfHeight = m_rectDraw.bottom / 80; 
	if( ItemHeadFont.CreateFontIndirect(&lf) )  // create the font
		pOldFont = dcPrint.SelectObject(&ItemHeadFont);
	
	// compute the item position
	int     nRowPos = m_rectDraw.bottom/10 + m_rectDraw.bottom/20;
	int     nRowStep = m_rectDraw.bottom/50;
	int     nIDPos = m_rectDraw.right / 20;
	int		nWorkUnitPos = nIDPos + dcPrint.GetOutputTextExtent("���#").cx;
	int		nLinkManPos = nWorkUnitPos + dcPrint.GetOutputTextExtent("����в��Ժ").cx;
	int		nTelNumberPos = nLinkManPos + dcPrint.GetOutputTextExtent("��־��#").cx;
	int		nWorkPositionPos = nTelNumberPos + dcPrint.GetOutputTextExtent("02229850545").cx;
	int		nWorkContentPos = nWorkPositionPos + dcPrint.GetOutputTextExtent("�Ͽ�������̨·").cx;
	int		nWorkAmountPos = nWorkContentPos + dcPrint.GetOutputTextExtent("����̽��#").cx;
	int		nWorkDatePos = nWorkAmountPos + dcPrint.GetOutputTextExtent("����1.2����").cx;
	int		nWorkGroupPos = nWorkDatePos + dcPrint.GetOutputTextExtent("2001-01-01#").cx;
	int		nExpensePos = nWorkGroupPos + dcPrint.GetOutputTextExtent("���ϰ칫��").cx;
	int		nDataTimePos = nExpensePos + dcPrint.GetOutputTextExtent("1000.00").cx;
	int		nDataPositionPos = nDataTimePos + dcPrint.GetOutputTextExtent("2001-01-01#").cx;
	
	
	dcPrint.SetTextAlign(TA_LEFT);
	dcPrint.MoveTo(nIDPos, nRowPos);
	dcPrint.LineTo(m_rectDraw.right - m_rectDraw.right / 20, nRowPos);
	nRowPos += 50;
	dcPrint.TextOut( nIDPos, nRowPos, "���");
	dcPrint.TextOut( nWorkUnitPos, nRowPos, "���赥λ");
	dcPrint.TextOut( nLinkManPos, nRowPos, "��ϵ��");
	dcPrint.TextOut( nTelNumberPos, nRowPos,"��ϵ�绰" );
	dcPrint.TextOut( nWorkPositionPos, nRowPos, "���̵ص�");
	dcPrint.TextOut( nWorkContentPos, nRowPos, "��ҵ����");
	dcPrint.TextOut( nWorkAmountPos, nRowPos, "��ҵ����");
	dcPrint.TextOut( nWorkDatePos, nRowPos, "��������");
	dcPrint.TextOut( nWorkGroupPos, nRowPos, "��������");
	dcPrint.TextOut( nExpensePos, nRowPos, "�շ�");
	dcPrint.TextOut( nDataTimePos, nRowPos, "��������");
	dcPrint.TextOut( nDataPositionPos, nRowPos, "���ϵص�");
	
	nRowPos += 2 * nRowStep;
	CIMSDlg *pCIMDlg = (CIMSDlg *)(AfxGetApp( )->m_pMainWnd);
	CListBoxCtrl *pRecordset = &(pCIMDlg->m_lcRecordset);

	CString strItem;
	int nCurrentItem = (nCurrentPage - 1) * nLinesPerPage;
	for( int i = 0; i < nLinesPerPage; i++, nCurrentItem++ )
	{
		if( nCurrentItem == nItemNumber)
			break;
		strItem = pRecordset->GetItemText( nCurrentItem , 0) ;
		dcPrint.TextOut( nIDPos, nRowPos, strItem);
		strItem = pRecordset->GetItemText(nCurrentItem , 1) ;
		dcPrint.TextOut( nWorkUnitPos, nRowPos, strItem);
		strItem = pRecordset->GetItemText(nCurrentItem , 2) ;
		dcPrint.TextOut( nLinkManPos, nRowPos, strItem);
		strItem = pRecordset->GetItemText(nCurrentItem , 3) ;
		dcPrint.TextOut( nTelNumberPos, nRowPos,strItem );
		strItem = pRecordset->GetItemText(nCurrentItem , 4) ;
		dcPrint.TextOut( nWorkPositionPos, nRowPos, strItem);
		strItem = pRecordset->GetItemText(nCurrentItem , 5) ;
		dcPrint.TextOut( nWorkContentPos, nRowPos, strItem);
		strItem = pRecordset->GetItemText(nCurrentItem , 6) ;
		dcPrint.TextOut( nWorkAmountPos, nRowPos, strItem);
		strItem = pRecordset->GetItemText(nCurrentItem , 7) ;
		dcPrint.TextOut( nWorkDatePos, nRowPos, strItem);
		strItem = pRecordset->GetItemText(nCurrentItem , 8) ;
		dcPrint.TextOut( nWorkGroupPos, nRowPos, strItem);
		strItem = pRecordset->GetItemText(nCurrentItem , 9) ;
		dcPrint.TextOut( nExpensePos, nRowPos, strItem);
		strItem = pRecordset->GetItemText(nCurrentItem , 10) ;
		dcPrint.TextOut( nDataTimePos, nRowPos, strItem);
		strItem = pRecordset->GetItemText(nCurrentItem , 11) ;
		dcPrint.TextOut( nDataPositionPos, nRowPos, strItem);
		nRowPos += nRowStep;
	}

	if(pOldFont != NULL)
		dcPrint.SelectObject(&pOldFont);
	// Done with the font. Delete the font object.
	ItemHeadFont.DeleteObject();

}

void CPropPagePrint::PreparePrinting()
{
	// get the default printer
	CPrintDialog dlg(FALSE);
	if (!dlg.GetDefaults())
		AfxMessageBox(_T("You have no default printer!"));
	else
	{
		CIMSDlg *pCIMDlg = (CIMSDlg *)(AfxGetApp( )->m_pMainWnd);
		CListBoxCtrl *pRecordset = &(pCIMDlg->m_lcRecordset);

		nItemNumber = pRecordset->GetItemCount();
		
		m_nTotalPage = (int)((double)nItemNumber / nLinesPerPage );
 		if( fmod( (double)nItemNumber, (double)nLinesPerPage ) > 0.00001 )
			m_nTotalPage ++;		

		// initial the print page
		LPDEVMODE lpDeviceMode = dlg.GetDevMode( ) ;
		m_strPrinterName = lpDeviceMode->dmDeviceName;
		switch( lpDeviceMode->dmPaperSize )
		{
		case DMPAPER_A4:
			m_strPaperSize = _T("A4(Ĭ��)");
			break;
		default :

			break;
		}

		m_nFromPage = 1;
		m_nToPage = m_nTotalPage;
		
		UpdateData(FALSE);

		// create a CDC and attach it to the default printer
		dcPrint.Attach(dlg.m_pd.hDC);
		m_rectDraw.SetRect(0, 0,
				dcPrint.GetDeviceCaps(HORZRES),
				dcPrint.GetDeviceCaps(VERTRES));
		dcPrint.DPtoLP(&m_rectDraw);

	}
}

BOOL CPropPagePrint::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	// prepare for printing: initial the print page and get pDC
	nLinesPerPage = 35;
	CPrintDialog dlg(FALSE);
	if (!dlg.GetDefaults())
		AfxMessageBox(_T("You have no default printer!"));
	else
	{
		CIMSDlg *pCIMDlg = (CIMSDlg *)(AfxGetApp( )->m_pMainWnd);
		CListBoxCtrl *pRecordset = &(pCIMDlg->m_lcRecordset);

		nItemNumber = pRecordset->GetItemCount();
		
		m_nTotalPage = (int)((double)nItemNumber / nLinesPerPage );
 		if( fmod( (double)nItemNumber, (double)nLinesPerPage ) > 0.00001 )
			m_nTotalPage ++;		

		// initial the print page
		LPDEVMODE lpDeviceMode = dlg.GetDevMode( ) ;
		m_strPrinterName = lpDeviceMode->dmDeviceName;
		switch( lpDeviceMode->dmPaperSize )
		{
		case DMPAPER_A4:
			m_strPaperSize = _T("A4(Ĭ��)");
			break;
		default :

			break;
		}

		m_nFromPage = 1;
		m_nToPage = m_nTotalPage;
		
		UpdateData(FALSE);
	}	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
