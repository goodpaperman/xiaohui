#if !defined(AFX_PROPPAGEPRINT_H__BCF3E7E1_EC5A_11D4_AE2A_0000E2334E4D__INCLUDED_)
#define AFX_PROPPAGEPRINT_H__BCF3E7E1_EC5A_11D4_AE2A_0000E2334E4D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PropPagePrint.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPropPagePrint dialog

class CPropPagePrint : public CPropertyPage
{
	DECLARE_DYNCREATE(CPropPagePrint)

// Construction
public:
	CRect  m_rectDraw;
	int nLinesPerPage;
	int nItemNumber;
	int nTotalPrintPage;
	void PreparePrinting();
	void PrintPage(UINT nCurrentPage);
	BOOL Execute();
	CPropPagePrint();
	~CPropPagePrint();
	CDC dcPrint;
// Dialog Data
	//{{AFX_DATA(CPropPagePrint)
	enum { IDD = IDD_PROPPAGE_PRINTRECORD };
	CString	m_strTitle;
	CString	m_strPrinterName;
	UINT	m_nFromPage;
	UINT	m_nToPage;
	UINT	m_nTotalPage;
	int		m_nRatioRange;
	CString	m_strPaperSize;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPropPagePrint)
	public:
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPropPagePrint)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROPPAGEPRINT_H__BCF3E7E1_EC5A_11D4_AE2A_0000E2334E4D__INCLUDED_)
