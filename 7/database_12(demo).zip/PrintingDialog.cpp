// PrintingDialog.cpp : implementation file
//

#include "stdafx.h"
#include "IMS.h"
#include "PrintingDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPrintingDialog dialog

BOOL bUserAbort;

CPrintingDialog::CPrintingDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CPrintingDialog::IDD, pParent)
{
	Create(CPrintingDialog::IDD, pParent);      // modeless !
	bUserAbort = FALSE;
	//{{AFX_DATA_INIT(CPrintingDialog)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

BOOL CALLBACK AbortProc(HDC, int)
{

	MSG msg;
	while (!bUserAbort &&
		::PeekMessage(&msg, NULL, NULL, NULL, PM_NOREMOVE))
	{
		if (!AfxGetThread()->PumpMessage())
			return FALSE;   // terminate if WM_QUIT received
	}
	return !bUserAbort;
}

void CPrintingDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPrintingDialog)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPrintingDialog, CDialog)
	//{{AFX_MSG_MAP(CPrintingDialog)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPrintingDialog message handlers

BOOL CPrintingDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
//	SetWindowText(AfxGetAppName());
	CenterWindow();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
void CPrintingDialog::OnCancel()
{
	bUserAbort = TRUE;  // flag that user aborted print
	CDialog::OnCancel();
};

