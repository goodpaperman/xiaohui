#if !defined(AFX_PRINTINGDIALOG_H__3BC5A261_FACB_11D4_AE2A_0000E2334E4D__INCLUDED_)
#define AFX_PRINTINGDIALOG_H__3BC5A261_FACB_11D4_AE2A_0000E2334E4D__INCLUDED_

//#include "afxstat_.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PrintingDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPrintingDialog dialog
extern BOOL CALLBACK AbortProc(HDC, int);

class CPrintingDialog : public CDialog
{
// Construction
public:
	CPrintingDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CPrintingDialog)
	enum { IDD = IDD_PRINTDLG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPrintingDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CPrintingDialog)
	virtual BOOL OnInitDialog();
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PRINTINGDIALOG_H__3BC5A261_FACB_11D4_AE2A_0000E2334E4D__INCLUDED_)

