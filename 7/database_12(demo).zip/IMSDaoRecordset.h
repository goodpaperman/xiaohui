#if !defined(AFX_IMSDAORECORDSET_H__1B19388F_EC55_11D4_AE2A_0000E2334E4D__INCLUDED_)
#define AFX_IMSDAORECORDSET_H__1B19388F_EC55_11D4_AE2A_0000E2334E4D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// IMSDaoRecordset.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CIMSDaoRecordset DAO recordset

class CIMSDaoRecordset : public CDaoRecordset
{
public:
	CIMSDaoRecordset(CDaoDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CIMSDaoRecordset)

// Field/Param Data
	//{{AFX_FIELD(CIMSDaoRecordset, CDaoRecordset)
	long	m_ID;
	CString		m_strWorkUnit;
	CString		m_strLinkMan;
	CString		m_strTelNumber;
	CString		m_strWorkPosition;
	CString		m_strWorkContent;
	CString		m_strWorkAmount;
	COleDateTime	m_oletWorkDate;
	CString		m_strWorkGroup;
	COleCurrency	m_olecExpense;
	COleDateTime	m_oletDataTime;
	CString		m_strDataPosition;
	CString		m_strRemark;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIMSDaoRecordset)
	public:
	virtual CString GetDefaultDBName();		// Default database name
	virtual CString GetDefaultSQL();		// Default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IMSDAORECORDSET_H__1B19388F_EC55_11D4_AE2A_0000E2334E4D__INCLUDED_)
