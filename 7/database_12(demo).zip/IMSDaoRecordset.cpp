// IMSDaoRecordset.cpp : implementation file
//

#include "stdafx.h"
#include "IMS.h"
#include "IMSDaoRecordset.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CIMSDaoRecordset

IMPLEMENT_DYNAMIC(CIMSDaoRecordset, CDaoRecordset)

CIMSDaoRecordset::CIMSDaoRecordset(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CIMSDaoRecordset)
	m_ID = 0;
	m_strWorkUnit = _T("");
	m_strLinkMan = _T("");
	m_strTelNumber = _T("");
	m_strWorkPosition = _T("");
	m_strWorkContent = _T("");
	m_strWorkAmount = _T("");
	m_oletWorkDate = (DATE)0;
	m_strWorkGroup = _T("");
	m_oletDataTime = (DATE)0;
	m_strDataPosition = _T("");
	m_strRemark = _T("");
	m_nFields = 13;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenDynaset;
}


CString CIMSDaoRecordset::GetDefaultDBName()
{
	return _T("IMS.mdb");
}

CString CIMSDaoRecordset::GetDefaultSQL()
{
	return _T("[������]");
}

void CIMSDaoRecordset::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CIMSDaoRecordset)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_Long(pFX, _T("[ID]"), m_ID);
	DFX_Text(pFX, _T("[���赥λ]"), m_strWorkUnit);
	DFX_Text(pFX, _T("[��ϵ��]"), m_strLinkMan);
	DFX_Text(pFX, _T("[��ϵ�绰]"), m_strTelNumber);
	DFX_Text(pFX, _T("[���̵ص�]"), m_strWorkPosition);
	DFX_Text(pFX, _T("[��ҵ����]"), m_strWorkContent);
	DFX_Text(pFX, _T("[��ҵ����]"), m_strWorkAmount);
	DFX_DateTime(pFX, _T("[��������]"), m_oletWorkDate);
	DFX_Text(pFX, _T("[��������]"), m_strWorkGroup);
	DFX_Currency(pFX, _T("[�շ�]"), m_olecExpense);
	DFX_DateTime(pFX, _T("[��������]"), m_oletDataTime);
	DFX_Text(pFX, _T("[���ϵص�]"), m_strDataPosition);
	DFX_Text(pFX, _T("[��ע]"), m_strRemark);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CIMSDaoRecordset diagnostics

#ifdef _DEBUG
void CIMSDaoRecordset::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void CIMSDaoRecordset::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG
