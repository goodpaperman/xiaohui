//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by IMS.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_IMS_DIALOG                  102
#define IDD_PROPPAGE_ADDRECORD          107
#define IDR_MAINFRAME                   128
#define IDR_POPMENU                     130
#define IDD_PROPPAGE_DELETERECORD       131
#define IDD_PROPPAGE_EDITRECORD         132
#define IDD_PROPPAGE_PRINTRECORD        134
#define IDD_PROPPAGE_QUERYRECORD        136
#define IDI_LIST                        137
#define IDB_SPLASH                      140
#define IDB_TELNUMBER                   143
#define IDB_BACK                        144
#define IDB_WORKCONTENT                 146
#define IDB_DATAPOSITION                147
#define IDB_WORKPOSITION                148
#define IDB_COCK                        149
#define IDB_LINKMAN                     150
#define IDB_WORKAMOUNT                  151
#define IDB_EXPENSE                     153
#define IDB_REMARK                      154
#define IDB_WORKGROUP                   156
#define IDB_PRINTER                     157
#define IDB_WORKUNIT                    158
#define IDD_PRINTDLG                    158
#define IDI_QUERY                       161
#define IDI_EYECLOSE                    166
#define IDI_EYEOPEN                     169
#define IDC_LISTCONTROL_RECORD          1000
#define IDC_DATAPOSITION                1001
#define IDC_EXECUTE                     1001
#define IDC_RADIO1                      1002
#define IDC_RADIO_RANG                  1002
#define IDC_WORKDATE                    1003
#define IDC_RADIO2                      1003
#define IDC_DATATIME                    1004
#define IDC_EDIT1                       1005
#define IDC_EDIT_FROMPAGE               1005
#define IDC_WORKGROUP                   1006
#define IDC_EDIT2                       1006
#define IDC_EDIT_TOPAGE                 1006
#define IDC_WORKCONTENT                 1007
#define IDC_LIST1                       1007
#define IDC_EDIT_TOTALPAGE              1008
#define IDC_WORKUNIT                    1009
#define IDC_COMBO1                      1009
#define IDC_COMBO_PRINTERNAME           1009
#define IDC_LINKMAN                     1010
#define IDC_WORKPOSITION                1011
#define IDC_COMBO2                      1011
#define IDC_COMBO_PAPERSIZE             1011
#define IDC_TELNUMBER                   1014
#define IDC_WORKAMOUNT                  1015
#define IDC_EXPENSES                    1018
#define IDC_STARTWORKDATE               1019
#define IDC_ENDWORKDATE                 1021
#define IDC_CHECK_EXPENSES              1022
#define IDC_CHECK_WORKGROUP             1023
#define IDC_CHECK_WORKPOSITION          1024
#define IDC_CHECK_WORKDATE              1025
#define IDC_DATETIMEPICKER1             1026
#define IDC_ENDDATATIME                 1026
#define IDC_CHECK_WORKUNIT              1028
#define IDC_CHECK_LINKMAN               1029
#define IDC_CHECK_TELNUMBER             1030
#define IDC_CHECK_WORKCONTENT           1031
#define IDC_CHECK_DATATIME              1032
#define IDC_STARTDATATIME               1033
#define IDC_EDIT_TITLE                  1034
#define IDC_STATIC_STATE                1036
#define IDC_STATIC_TYPE                 1037
#define IDC_REMARK                      1039
#define IDC_SHOWMAIN                    32771
#define IDC_HIDEMAIN                    32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        171
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1038
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
