#if !defined(AFX_PROPPAGEQUERY_H__BCF3E7E4_EC5A_11D4_AE2A_0000E2334E4D__INCLUDED_)
#define AFX_PROPPAGEQUERY_H__BCF3E7E4_EC5A_11D4_AE2A_0000E2334E4D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PropPageQuery.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPropPageQuery dialog

class CPropPageQuery : public CPropertyPage
{
	DECLARE_DYNCREATE(CPropPageQuery)

// Construction
public:
	BOOL Execute();
	CPropPageQuery();
	~CPropPageQuery();

// Dialog Data
	//{{AFX_DATA(CPropPageQuery)
	enum { IDD = IDD_PROPPAGE_QUERYRECORD };
	BOOL	m_bExpense;
	BOOL	m_bWorkDate;
	BOOL	m_bWorkGroup;
	BOOL	m_bWorkPosition;
	COleDateTime	m_oletEndWork;
	COleDateTime	m_oletStartWork;
	CString	m_strWorkGroup;
	int		m_nExpense;
	CString	m_strWorkPosition;
	BOOL	m_bDataTime;
	BOOL	m_bLinkMan;
	BOOL	m_bTelNumber;
	BOOL	m_bWorkContent;
	BOOL	m_bWorkUnit;
	CString	m_strLinkMan;
	CString	m_strTelNumber;
	CString	m_strWorkContent;
	CString	m_strWorkUnit;
	COleDateTime	m_oletEndDataTime;
	COleDateTime	m_oletStartDataTime;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPropPageQuery)
	public:
	virtual BOOL OnSetActive();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPropPageQuery)
	afx_msg void OnCheckWorkposition();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROPPAGEQUERY_H__BCF3E7E4_EC5A_11D4_AE2A_0000E2334E4D__INCLUDED_)
