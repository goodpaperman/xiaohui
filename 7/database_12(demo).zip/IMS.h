// IMS.h : main header file for the IMS application
//

#if !defined(AFX_IMS_H__1B193885_EC55_11D4_AE2A_0000E2334E4D__INCLUDED_)
#define AFX_IMS_H__1B193885_EC55_11D4_AE2A_0000E2334E4D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CIMSApp:
// See IMS.cpp for the implementation of this class
//

class CIMSApp : public CWinApp
{
public:
	CIMSApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIMSApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CIMSApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IMS_H__1B193885_EC55_11D4_AE2A_0000E2334E4D__INCLUDED_)
