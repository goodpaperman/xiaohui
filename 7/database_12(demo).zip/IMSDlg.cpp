// IMSDlg.cpp : implementation file
//

#include "stdafx.h"
#include "IMS.h"
#include "IMSDlg.h"
#include "Splash1.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


int nActivePage;
CIMSDaoRecordset daoRecordset;

#define WM_TRAYNOTIFY WM_USER + 100
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIMSDlg dialog

CIMSDlg::CIMSDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CIMSDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CIMSDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDI_EYEOPEN);
	m_hMainIco1 =  AfxGetApp()->LoadIcon(IDI_EYEOPEN);
	m_hMainIco2 =  AfxGetApp()->LoadIcon(IDI_EYECLOSE);
	m_nTimeCount = 0;
}

void CIMSDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIMSDlg)
	DDX_Control(pDX, IDC_LISTCONTROL_RECORD, m_lcRecordset);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CIMSDlg, CDialog)
	//{{AFX_MSG_MAP(CIMSDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_CREATE()
	ON_COMMAND(IDC_HIDEMAIN, OnHidemain)
	ON_COMMAND(IDC_SHOWMAIN, OnShowmain)
	ON_NOTIFY(LVN_COLUMNCLICK, IDC_LISTCONTROL_RECORD, OnColumnclickListcontrolRecord)
	ON_NOTIFY(NM_CLICK, IDC_LISTCONTROL_RECORD, OnClickListcontrolRecord)
	ON_BN_CLICKED(IDC_EXECUTE, OnExecute)
	ON_WM_CLOSE()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
	ON_MESSAGE ( WM_TRAYNOTIFY, OnTrayNotify ) // tray icon notification
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIMSDlg message handlers

BOOL CIMSDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// set up the property page
	m_propSheet.AddPage( &m_proppageAdd );
	m_propSheet.AddPage( &m_proppageQuery );
 	m_propSheet.AddPage( &m_proppageEdit );
	m_propSheet.AddPage( &m_proppageDelete );
	m_propSheet.AddPage( &m_proppagePrint );

	m_propSheet.Create(this,WS_CHILD|WS_VISIBLE,0);
	m_propSheet.ModifyStyleEx(0,WS_EX_CONTROLPARENT);
	m_propSheet.ModifyStyle(0,WS_TABSTOP);

	CRect rect;
	this->GetWindowRect(&rect);
	ScreenToClient(&rect);
	m_propSheet.SetWindowPos(NULL,rect.left + 15,rect.top + 35,
		0,0,SWP_NOZORDER|SWP_NOSIZE|SWP_NOACTIVATE);

	// set up main list box image list
	m_largIcon . Create ( 32, 32, FALSE, 2, 0 );
	m_smallIcon . Create ( 16, 16, FALSE, 2, 0 );
	m_largIcon . Add ( ::LoadIcon ( AfxGetInstanceHandle (), MAKEINTRESOURCE ( IDI_LIST )) );
	m_smallIcon . Add	( ::LoadIcon ( AfxGetInstanceHandle (), MAKEINTRESOURCE ( IDI_LIST )) ) ;
	m_lcRecordset . SetImageList ( &m_largIcon, LVSIL_NORMAL );
	m_lcRecordset . SetImageList ( &m_smallIcon, LVSIL_SMALL );

	// set up main list box columns
	m_lcRecordset . InsertColumn ( 0, "ID", LVCFMT_CENTER, 50 );
	m_lcRecordset . InsertColumn ( 1, "���赥λ", LVCFMT_LEFT, 59 );
	m_lcRecordset . InsertColumn ( 2, "��ϵ��", LVCFMT_LEFT, 60 );
	m_lcRecordset . InsertColumn ( 3, "��ϵ�绰", LVCFMT_LEFT, 65 );
	m_lcRecordset . InsertColumn ( 4, "���̵ص�", LVCFMT_LEFT, 60 );
	m_lcRecordset . InsertColumn ( 5, "��ҵ����", LVCFMT_LEFT, 60 );
	m_lcRecordset . InsertColumn ( 6, "��ҵ����", LVCFMT_LEFT, 65 );
	m_lcRecordset . InsertColumn ( 7, "��������", LVCFMT_LEFT, 75 );
	m_lcRecordset . InsertColumn ( 8, "��������", LVCFMT_LEFT, 68 );
	m_lcRecordset . InsertColumn ( 9, "�շ�(��Ԫ)", LVCFMT_LEFT, 70 );
	m_lcRecordset . InsertColumn ( 10, "��������", LVCFMT_LEFT, 75 );
	m_lcRecordset . InsertColumn ( 11, "���ϵص�", LVCFMT_LEFT, 75 );

	// initial the selected item;
	m_nItemSelected = -1;
	nActivePage = 0;

	// load the record list
	LoadRecordset();

	// show the splash screen
	CSplashWnd::ShowSplashScreen ( this );
	SetTimer(1,100,NULL);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CIMSDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else if ( nID == SC_MINIMIZE )
	{
		OnHidemain (); // get into tray and don't leave task bar button
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CIMSDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CIMSDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


/////////////////////////////////////////////////////////////////////////////////////////////////////
//																							   @@
//		these codes below are used to show the tray icon by using class CTrayNotifyIcon		   @@
//

// this does some necessary setup with the tray icon object.
int CIMSDlg::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// assign a menu, icon, tooltip, and handler to the tray icon.
	if ( ! m_TrayNotifyIcon . Create ( this, IDR_POPMENU, "����в��Ժ������Ϣ����ϵͳ", AfxGetApp () -> LoadIcon ( IDR_MAINFRAME ), WM_TRAYNOTIFY ) ) {
		AfxMessageBox ( "Failure Creating Tray Icon", MB_ICONSTOP );
		return -1;
	}	
	
	return 0;
}

// pass the tray notification message to the tray icon object for handling.
LRESULT CIMSDlg::OnTrayNotify ( WPARAM wParam, LPARAM lParam ) 
{
  return m_TrayNotifyIcon . OnTrayNotification ( wParam, lParam );
}

// show the main window.  the tray icon object shows the popup menu 'IDR_POPUP' which
// has a command for calling this handler
void CIMSDlg::OnShowmain() 
{
	ShowWindow ( SW_SHOW );	
}

// show the main window.  the tray icon object shows the popup menu 'IDR_POPUP' which
// has a command for calling this handler
void CIMSDlg::OnHidemain() 
{
	ShowWindow ( SW_HIDE );	
}

/////////////////////////////////////////////////////////////////////////////////////////////////////
//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//@@																							   @@
//@@	these codes below are used to load the data into list control based on some conditons      @@
//@@																							   @@

// set the database data from daorecordset into List Control data 
void CIMSDlg::LoadRecordset( )
{
	BeginWaitCursor(); 
	char szBuffer [ 256 ] ; // idiot buffer needed by the runtime library calls

	// clear out the listbox
	m_lcRecordset . DeleteAllItems ();
	
	try {
		if ( !daoRecordset . IsOpen () )	// if the recordset isn't already open...
			daoRecordset . Open ();	// open it
		for ( int nListEntry = 0 ; ! daoRecordset . IsEOF () ; nListEntry ++ )// for each entry int the database...
		{ 
			// make an entry in the listbox from the recordset contents
			m_lcRecordset . InsertItem  ( nListEntry, LPCTSTR ( ltoa ( daoRecordset . m_ID, szBuffer, 10 ) ), 0 );
			m_lcRecordset . SetItemText ( nListEntry, 1,  LPCTSTR ( daoRecordset . m_strWorkUnit ) );
			m_lcRecordset . SetItemText ( nListEntry, 2,  LPCTSTR ( daoRecordset . m_strLinkMan ) );      
			m_lcRecordset . SetItemText ( nListEntry, 3,  LPCTSTR ( daoRecordset . m_strTelNumber ) );
			m_lcRecordset . SetItemText ( nListEntry, 4,  LPCTSTR ( daoRecordset . m_strWorkPosition ) );
			m_lcRecordset . SetItemText ( nListEntry, 5,  LPCTSTR ( daoRecordset . m_strWorkContent ) );
			m_lcRecordset . SetItemText ( nListEntry, 6,  LPCTSTR ( daoRecordset . m_strWorkAmount ) );
			m_lcRecordset . SetItemText ( nListEntry, 7,  LPCTSTR ( (daoRecordset . m_oletWorkDate).Format(_T("'%y-%m-%d") )) );
			m_lcRecordset . SetItemText ( nListEntry, 8,  LPCTSTR ( daoRecordset . m_strWorkGroup ) );
			m_lcRecordset . SetItemText ( nListEntry, 9,  LPCTSTR ( (daoRecordset . m_olecExpense).Format(0, MAKELCID(MAKELANGID(LANG_CHINESE,SUBLANG_CHINESE_SINGAPORE), SORT_DEFAULT))));
			m_lcRecordset . SetItemText ( nListEntry, 10, LPCTSTR ( daoRecordset . m_oletDataTime.Format(_T("'%y-%m-%d") )) );
			m_lcRecordset . SetItemText ( nListEntry, 11, LPCTSTR ( daoRecordset . m_strDataPosition ) );
			daoRecordset . MoveNext (); // cause the recordset to retrieve the next record from the database for the next loop
		}
		daoRecordset . Close (); // done with the recordset
	}

	catch ( CDaoException* e ) { // catch exceptions thrown by the MFC DAO classes
		char szBuffer [ 256 ];
		CString strExceptDesc =
			CString ( "���ݿ����淢������:\n\n �����: " ) +
			CString ( ltoa ( e -> m_pErrorInfo -> m_lErrorCode, szBuffer, 10 ) ) +
			CString ( "\n����: " ) +
			CString ( e -> m_pErrorInfo -> m_strDescription );
		AfxMessageBox ( strExceptDesc, MB_ICONEXCLAMATION );
		daoRecordset . Close (); // at least try to close the recordset
		EndWaitCursor(); 
		return;
	}
	EndWaitCursor(); 
}

void CIMSDlg::LoadSortRecordset(CString &strSortBy)
{
	// clear out the listbox
	m_lcRecordset . DeleteAllItems ();
	
	daoRecordset . m_strSort = strSortBy; // set the recordset's sort parameter
	LoadRecordset (); // re-load the database contents
}

void CIMSDlg::OnColumnclickListcontrolRecord(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	// sort based on column that was clicked

	switch ( pNMListView -> iSubItem ) {
		case 0:
			LoadSortRecordset ( CString ( "[ID]" ) );
			break;
		case 1:
			LoadSortRecordset ( CString ( "[���赥λ]" ) );
			break;
		case 2:
			LoadSortRecordset ( CString ( "[��ϵ��]" ) );
			break;
		case 3:
			LoadSortRecordset ( CString ( "[��ϵ�绰]" ) );
			break;
		case 4:
			LoadSortRecordset ( CString ( "[���̵ص�]" ) );
			break;
		case 5:
			LoadSortRecordset ( CString ( "[��ҵ����]" ) );
			break;
		case 6:
			LoadSortRecordset ( CString ( "[��ҵ����]" ) );
			break;
		case 7:
			LoadSortRecordset ( CString ( "[��������]" ) );
			break;
		case 8:
			LoadSortRecordset ( CString ( "[��������]" ) );
			break;
		case 9:
			LoadSortRecordset ( CString ( "[�շ�]" ) );
			break;
		case 10:
			LoadSortRecordset ( CString ( "[��������]" ) );
			break;
		case 11:
			LoadSortRecordset ( CString ( "[���ϵص�]" ) );
			break;
		default:
			LoadSortRecordset ( CString ( "" ) ); 
			break;
	}		
	*pResult = 0;
}



void CIMSDlg::OnClickListcontrolRecord(NMHDR* pNMHDR, LRESULT* pResult) 
{
	switch ( nActivePage ) {
		case 2:
			m_proppageEdit.OnSetActive( );
			break;
		case 3:
			m_proppageDelete.OnSetActive( );
			break;
		default:
			break;
	}	
	
	*pResult = 0;
}

void CIMSDlg::OnExecute() 
{
	switch ( nActivePage ) {
		case 0:
			m_proppageAdd.Execute( );
			LoadRecordset();
			break;
		case 1:
			m_proppageQuery.Execute( );
			LoadRecordset();
			break;
		case 2:
			m_proppageEdit.Execute( );
			LoadRecordset();
			break;
		case 3:
			m_proppageDelete.Execute( );
			LoadRecordset();
			break;
		case 4:
			m_proppagePrint.Execute( );
			break;
		default:
			break;
	}		
}

void CIMSDlg::LoadFilterRecordset(CString &strFilterBy)
{
		// clear out the listbox
	m_lcRecordset . DeleteAllItems ();
	
	daoRecordset . m_strFilter = strFilterBy; // set the recordset's filter parameter
	LoadRecordset (); // re-load the database contents
}

void CIMSDlg::OnOK() 
{
	if( AfxMessageBox( "��ȷ��Ҫ�˳�ϵͳ��",MB_OKCANCEL) == IDOK)   
	{
		CDialog::OnOK();
	}	
}

void CIMSDlg::OnClose() 
{
	if( AfxMessageBox( "��ȷ��Ҫ�˳�ϵͳ��",MB_OKCANCEL) == IDOK)   
	{
		CDialog::OnClose();
	}	
}

// dispaly the animated icon
void CIMSDlg::OnTimer(UINT nIDEvent) 
{
    m_nTimeCount++;
	HICON hIcon = NULL;

	if(m_nTimeCount == 10)
	{
		AfxGetMainWnd()->SetIcon(m_hMainIco2,FALSE);
		m_nTimeCount = 20;
	}
	else if(m_nTimeCount == 25)
	{
		AfxGetMainWnd()->SetIcon(m_hMainIco1,FALSE);
		m_nTimeCount = 0;
	}	
	CDialog::OnTimer(nIDEvent);
}
