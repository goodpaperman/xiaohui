// IMSDlg.h : header file
//

#if !defined(AFX_IMSDLG_H__1B193887_EC55_11D4_AE2A_0000E2334E4D__INCLUDED_)
#define AFX_IMSDLG_H__1B193887_EC55_11D4_AE2A_0000E2334E4D__INCLUDED_

// Added by yzy
#include "ntray.h"
#include "PropPageAdd.h"
#include "PropPageEdit.h"
#include "PropPageDelete.h"
#include "PropPageQuery.h"
#include "PropPagePrint.h"
#include "IMSDaoRecordset.h"


#ifndef _LBCTRL_H
#include "lbctrl.h"
#endif

extern int nActivePage;
extern CIMSDaoRecordset daoRecordset;

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CIMSDlg dialog

class CIMSDlg : public CDialog
{
// Construction
public:
	CIMSDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CIMSDlg)
	enum { IDD = IDD_IMS_DIALOG };
	CListBoxCtrl	m_lcRecordset;
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIMSDlg)
	public:
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	HICON m_hMainIco1,m_hMainIco2; // inorder to display the animated icon 

	// Generated message map functions
	//{{AFX_MSG(CIMSDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnHidemain();
	afx_msg void OnShowmain();
	afx_msg void OnColumnclickListcontrolRecord(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnClickListcontrolRecord(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnExecute();
	virtual void OnOK();
	afx_msg void OnClose();
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	afx_msg LRESULT OnTrayNotify ( WPARAM, LPARAM ); // this message map to the trayicon
	DECLARE_MESSAGE_MAP()

public:
	// defined three function to load different recordset
	void LoadRecordset( );								// load 					
	void LoadFilterRecordset( CString& strFilterBy );
	void LoadSortRecordset ( CString& strSortBy );

private:
	int m_nItemSelected;
	int					m_nTimeCount;
	CPropertySheet		m_propSheet;
	CPropPageAdd		m_proppageAdd;
	CPropPageEdit		m_proppageEdit;
	CPropPageDelete		m_proppageDelete;
	CPropPageQuery		m_proppageQuery;
	CPropPagePrint		m_proppagePrint;
	CTrayNotifyIcon		m_TrayNotifyIcon;
	CImageList			m_largIcon;
	CImageList			m_smallIcon;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IMSDLG_H__1B193887_EC55_11D4_AE2A_0000E2334E4D__INCLUDED_)
