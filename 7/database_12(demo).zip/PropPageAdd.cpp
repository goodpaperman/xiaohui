// PropPageAdd.cpp : implementation file
//

#include "stdafx.h"
#include "IMS.h"
#include "PropPageAdd.h"
#include "IMSDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropPageAdd property page

IMPLEMENT_DYNCREATE(CPropPageAdd, CPropertyPage)

CPropPageAdd::CPropPageAdd() : CPropertyPage(CPropPageAdd::IDD)
{
	//{{AFX_DATA_INIT(CPropPageAdd)
	m_strDataPosition = _T("");
	m_olecExpense = COleCurrency(0, 0);
	m_strLinkMan = _T("");
	m_strRemark = _T("");
	m_strTelNumber = _T("");
	m_strWorkAmount = _T("");
	m_strWorkContent = _T("");
	m_strWorkGroup = _T("");
	m_strWorkPosition = _T("");
	m_oletDataTime = COleDateTime::GetCurrentTime();
	m_oletWorkDate = COleDateTime::GetCurrentTime();
	m_strWorkUnit = _T("");
	//}}AFX_DATA_INIT
}

CPropPageAdd::~CPropPageAdd()
{
}

void CPropPageAdd::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropPageAdd)
	DDX_Text(pDX, IDC_DATAPOSITION, m_strDataPosition);
	DDX_Text(pDX, IDC_EXPENSES, m_olecExpense);
	DDX_Text(pDX, IDC_LINKMAN, m_strLinkMan);
	DDX_Text(pDX, IDC_REMARK, m_strRemark);
	DDX_Text(pDX, IDC_TELNUMBER, m_strTelNumber);
	DDX_Text(pDX, IDC_WORKAMOUNT, m_strWorkAmount);
	DDX_CBString(pDX, IDC_WORKCONTENT, m_strWorkContent);
	DDX_CBString(pDX, IDC_WORKGROUP, m_strWorkGroup);
	DDX_Text(pDX, IDC_WORKPOSITION, m_strWorkPosition);
	DDX_DateTimeCtrl(pDX, IDC_DATATIME, m_oletDataTime);
	DDX_DateTimeCtrl(pDX, IDC_WORKDATE, m_oletWorkDate);
	DDX_Text(pDX, IDC_WORKUNIT, m_strWorkUnit);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPropPageAdd, CPropertyPage)
	//{{AFX_MSG_MAP(CPropPageAdd)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropPageAdd message handlers

BOOL CPropPageAdd::OnSetActive() 
{
	// TODO: Add your specialized code here and/or call the base class
	nActivePage = 0;	
	daoRecordset . m_strFilter = "";
	CIMSDlg *pCIMDlg = (CIMSDlg *)(AfxGetApp( )->m_pMainWnd);
	CWnd *pWnd = pCIMDlg->GetDlgItem(IDC_EXECUTE);
	pWnd->SetWindowText("���Ӽ�¼(&A)");
	pCIMDlg->LoadRecordset();

	return CPropertyPage::OnSetActive();
}

BOOL CPropPageAdd::Execute()
{

	// all fields MUST contain a value
	try {
		if ( ! daoRecordset . IsOpen () ) // if the recordset isn't already open..
			daoRecordset . Open (); // open it
		daoRecordset . AddNew (); // begin the add
		UpdateData(TRUE);
		daoRecordset . m_strDataPosition = m_strDataPosition;
		daoRecordset . m_olecExpense = m_olecExpense;
		daoRecordset . m_strLinkMan = m_strLinkMan;
		daoRecordset . m_strRemark = m_strRemark;
		daoRecordset . m_strTelNumber = m_strTelNumber;
		daoRecordset . m_strWorkAmount = m_strWorkAmount;
		daoRecordset . m_strWorkContent = m_strWorkContent;
		daoRecordset . m_strWorkGroup = m_strWorkGroup;
		daoRecordset . m_strWorkPosition = m_strWorkPosition;
		daoRecordset . m_oletDataTime = m_oletDataTime;
		daoRecordset . m_oletWorkDate = m_oletWorkDate;
		daoRecordset . m_strWorkUnit = m_strWorkUnit;
		daoRecordset . Update (); // complete the add by doing an update
		daoRecordset . Close (); // close the recordset
	}
	catch ( CDaoException* e ) { // catch DAO exceptions
		char szBuffer [ 256 ];
		CString strExceptDesc =
			CString ( "JET Database Engine Error:\n\n Error Code: " ) +
			CString ( ltoa ( e -> m_pErrorInfo -> m_lErrorCode, szBuffer, 10 ) ) +
			CString ( "\nDescription: " ) +
			CString ( e -> m_pErrorInfo -> m_strDescription );
		AfxMessageBox ( strExceptDesc, MB_ICONEXCLAMATION );
		daoRecordset . Close ();
		return FALSE;
	}

	// after the user "adds" a record, re-set the form for another "add"
	Reset ();

	return TRUE;
}

void CPropPageAdd::Reset()
{
	m_strDataPosition = _T("");
	m_olecExpense = COleCurrency(0, 0);
	m_strLinkMan = _T("");
	m_strRemark = _T("");
	m_strTelNumber = _T("");
	m_strWorkAmount = _T("");
	m_strWorkContent = _T("");
	m_strWorkGroup = _T("");
	m_strWorkPosition = _T("");
	m_oletDataTime = COleDateTime::GetCurrentTime();
	m_oletWorkDate = COleDateTime::GetCurrentTime();
	m_strWorkUnit = _T("");
	UpdateData(FALSE);
}
