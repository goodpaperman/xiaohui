// DataBuffer.cpp

#include "stdafx.h"
#include "Message.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


CMessage::CMessageData::CDataBuffer::CDataBuffer()
{
	m_pData = NULL;
	m_length = 0;
}


CMessage::CMessageData::CDataBuffer::CDataBuffer(LPVOID pData, unsigned long length)
{
	if (length == 0)
	{
		m_pData = NULL;
		m_length = 0;
	}
	else
	{
		m_pData = malloc(length);
		m_length = length;
		memcpy(m_pData, pData, length);
	}
}


CMessage::CMessageData::CDataBuffer::~CDataBuffer()
{
	if (m_pData)
		free(m_pData);
}


void CMessage::CMessageData::CDataBuffer::Serialize(CArchive &ar)
{
	if (ar.IsStoring())
	{
		ar << m_length;
		ar.Write(m_pData, m_length);
	}
	else
	{
		if (m_pData != NULL)
			free(m_pData);

		ar >> m_length;

		m_pData = malloc(m_length);

		ar.Read(m_pData, m_length);
	}	
}


unsigned long CMessage::CMessageData::CDataBuffer::GetLength() const
{
	return m_length;
}


LPVOID CMessage::CMessageData::CDataBuffer::GetBuffer() const
{
	return m_pData;
}


const CMessage::CMessageData::CDataBuffer & CMessage::CMessageData::CDataBuffer::operator=(const CDataBuffer &dt)
{
	if (&dt == this)
		return *this;

	if (m_pData != NULL)
		free(m_pData);

	m_length = dt.m_length;
	m_pData = malloc(m_length);

	memcpy(m_pData, dt.m_pData, m_length);

	return *this;
}

