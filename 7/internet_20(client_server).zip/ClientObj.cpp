// ClientObj.cpp

#include "stdafx.h"
#include "ClientObj.h"
#include "Ip.h"
#include "Message.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


const int NORMAL = NB_DISCONNECTIONS_TYPE + 1;


CClientObj::CClientObj()
{
	m_pClientSocket = NULL;
	m_pFile = NULL;
	m_pArchiveIn = NULL;
	m_pArchiveOut = NULL;
}


CClientObj::~CClientObj()
{
	if (m_pClientSocket != NULL)
	{
		m_pClientSocket->Close();
	
		delete m_pClientSocket;
	}

	if (m_pFile != NULL)
		delete m_pFile;

	if (m_pArchiveIn != NULL)
		delete m_pArchiveIn;

	if (m_pArchiveOut != NULL)
		delete m_pArchiveOut;
}


BOOL CClientObj::OpenConnection(const CIp &serverIp, int port)
{
	if (!AfxSocketInit())
		return FALSE;

	if (m_pClientSocket != NULL)
		CloseConnection(NORMAL);

	m_pClientSocket = new CClientSocket();

	m_pClientSocket->Init(this);

	if (!m_pClientSocket->Create())
	{
		delete m_pClientSocket;
		m_pClientSocket = NULL;

		return FALSE;
	}

	if (!m_pClientSocket->Connect(serverIp.GetIp(), port))
	{
		delete m_pClientSocket;
		m_pClientSocket = NULL;
		
		return FALSE;
	}

	m_pFile = new CSocketFile(m_pClientSocket);

	TRY
	{
		m_pArchiveIn = new CArchive(m_pFile, CArchive::load);
	}
	CATCH(CArchiveException, e)
	{
		delete m_pClientSocket;
		m_pClientSocket = NULL;
		
		delete m_pFile;
		m_pFile = NULL;

		delete m_pArchiveIn;
		m_pArchiveIn = NULL;

		return FALSE;
	}
	CATCH(CFileException, e)
	{
		delete m_pClientSocket;
		m_pClientSocket = NULL;
		
		delete m_pFile;
		m_pFile = NULL;

		delete m_pArchiveIn;
		m_pArchiveIn = NULL;

		return FALSE;
	}
	END_CATCH

	TRY
	{
		m_pArchiveOut = new CArchive(m_pFile, CArchive::store);
	}
	CATCH(CArchiveException, e)
	{
		delete m_pClientSocket;
		m_pClientSocket = NULL;
		
		delete m_pFile;
		m_pFile = NULL;

		delete m_pArchiveIn;
		m_pArchiveIn = NULL;

		delete m_pArchiveOut;
		m_pArchiveOut = NULL;

		return FALSE;
	}
	CATCH(CFileException, e)
	{
		delete m_pClientSocket;
		m_pClientSocket = NULL;
		
		delete m_pFile;
		m_pFile = NULL;

		delete m_pArchiveIn;
		m_pArchiveIn = NULL;

		delete m_pArchiveOut;
		m_pArchiveOut = NULL;

		return FALSE;
	}
	END_CATCH

	return TRUE;
}


void CClientObj::CloseConnection()
{
	CloseConnection(NORMAL);
}


BOOL CClientObj::GetIpAndPort(CIp &ip, UINT &port) const
{
	CString address;

	if (m_pClientSocket == NULL)
		return FALSE;
	
	if (!m_pClientSocket->GetSockName(address, port))
		return FALSE;

	ip.SetIp(address);

	return TRUE;
}


BOOL CClientObj::SendMessage(CMessage &msg)
{
	if (m_pClientSocket == NULL || m_pArchiveOut == NULL)
		return FALSE;

	TRY
	{
		msg.Serialize(*m_pArchiveOut);
		m_pArchiveOut->Flush();
	}
	CATCH(CFileException, e)
	{
		m_pArchiveOut->Abort();
		
		CloseConnection(ERROR_SENDING_DATA);

		return FALSE;
	}
	END_CATCH

	return TRUE;
}


void CClientObj::ProcessPendingRead(int errorCode)
{
	CMessage msg;

	if (errorCode != 0)
	{
		m_pArchiveOut->Abort();

		CloseConnection(ERROR_RECEIVING_DATA);

		return;
	}

	do
	{
		TRY
		{
			msg.Serialize(*m_pArchiveIn);

			OnMessage(msg);
		}
		CATCH(CFileException, e)
		{
			m_pArchiveOut->Abort();

			CloseConnection(ERROR_RECEIVING_DATA);

			return;
		}
		END_CATCH

		if (m_pArchiveIn == NULL)
			break;
	} while (!m_pArchiveIn->IsBufferEmpty());
}


void CClientObj::CloseConnection(int typeClose)
{
	if (typeClose != NORMAL)
		OnDisconnect((EDisconnectionType)typeClose);

	if (m_pClientSocket != NULL)
		m_pClientSocket->Close();

	if (m_pArchiveOut != NULL)
	{
		delete m_pArchiveOut;
		m_pArchiveOut = NULL;
	}

	if (m_pArchiveIn != NULL)
	{
		delete m_pArchiveIn;
		m_pArchiveIn = NULL;
	}

	if (m_pFile != NULL)
	{
		delete m_pFile;
		m_pFile = NULL;
	}

	if (m_pClientSocket != NULL)
	{
		delete m_pClientSocket;
		m_pClientSocket = NULL;
	}
}