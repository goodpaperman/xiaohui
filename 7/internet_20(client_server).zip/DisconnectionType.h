// EDisconnectType


//////////////////////////////////////////////////////////
//                                                      //
// NDK (Network Development Kit) 1.0                    //
//                                                      //
// Authors : Sebastien Lachance                         //
//           Yannick Letourneau                         //
//                                                      //
// Email :   netblitz@rocler.qc.ca                      //
//                                                      //
// Permission to use, copy, modify, and distribute this //
// software for any purpose and without fee is hereby   //
// granted.  This is no guarantee about the use of this //
// software.  For any comments, bugs or thanks, please  //
// email us.                                            //
//                                                      //
// Platform targeted : Windows 95/98/NT                 //
//                                                      //
// Compiled with :     Visual C++ 5/6                   //
//                                                      //
// Date :              April 1999                       //
//                                                      //
// History : 1- First release of this file              //
//                                                      //
//////////////////////////////////////////////////////////


#ifndef DISCONNECTIONTYPE_H
#define DISCONNECTIONTYPE_H

enum EDisconnectionType
{ 
	ERROR_SENDING_DATA, 
	ERROR_RECEIVING_DATA,
	NB_DISCONNECTIONS_TYPE
};

#endif