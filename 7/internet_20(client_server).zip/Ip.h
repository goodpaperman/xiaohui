// CIp


//////////////////////////////////////////////////////////
//                                                      //
// NDK (Network Development Kit) 1.0                    //
//                                                      //
// Authors : Sebastien Lachance                         //
//           Yannick Letourneau                         //
//                                                      //
// Email :   netblitz@rocler.qc.ca                      //
//                                                      //
// Permission to use, copy, modify, and distribute this //
// software for any purpose and without fee is hereby   //
// granted.  This is no guarantee about the use of this //
// software.  For any comments, bugs or thanks, please  //
// email us.                                            //
//                                                      //
// Platform targeted : Windows 95/98/NT                 //
//                                                      //
// Compiled with :     Visual C++ 5/6                   //
//                                                      //
// Date :              April 1999                       //
//                                                      //
// History : 1- First release of this file              //
//                                                      //
//////////////////////////////////////////////////////////


#ifndef IP_H
#define IP_H

#if _MSC_VER >= 1000
#pragma once
#endif 


////////////////////////////////////////////////////
//
// class CIp (concrete class)
//
// Purpose:
//
// Encapsulates an IP address.
//
////////////////////////////////////////////////////
class CIp  
{
public:

//////////////////////////////
// Public Interface
//////////////////////////////

	// Construction
	CIp();

	// Copy Constructor
	CIp(const CIp &ip);

	// Destruction
	virtual ~CIp();

	// Sets the IP given a string
	// in the xxx.xxx.xxx.xxx format
	void SetIp(const CString &ip);

	// Returns the IP in a formatted
	// string (xxx.xxx.xxx.xxx)
	CString GetIp() const;

	// Operator overloading
	const CIp & operator=(const CIp &ip);

	// Tests the validity of an IP
	// address format.
	static BOOL IsValid(const CString &ip);

//////////////////////////////
// End Of Public Interface
//////////////////////////////

private:
	static IsValidNumber(const CString &);

private:
	unsigned char m_ip[4];
};

#endif
