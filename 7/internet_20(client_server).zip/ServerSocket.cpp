// ServerSocket.cpp 

#include "stdafx.h"
#include "ServerObj.h"
#include "Message.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


CServerObj::CServerSocket::CServerSocket()
{
	m_pServerObj = NULL;
	m_pFile = NULL;
	m_pArchiveIn = NULL;
	m_pArchiveOut = NULL;
	m_nbMessages = 0;
}


CServerObj::CServerSocket::~CServerSocket()
{
	if (m_pArchiveOut != NULL)
		delete m_pArchiveOut;
	
	if (m_pArchiveIn != NULL)
		delete m_pArchiveIn;
	
	if (m_pFile != NULL)
		delete m_pFile;
}


BOOL CServerObj::CServerSocket::Init(CServerObj* pServerObj)
{
	m_pFile = new CSocketFile(this);

	TRY
	{
		m_pArchiveIn = new CArchive(m_pFile, CArchive::load);
	}
	CATCH(CArchiveException, e)
	{
		delete m_pFile;
		m_pFile = NULL;

		delete m_pArchiveIn;
		m_pArchiveIn = NULL;

		return FALSE;
	}
	CATCH(CFileException, e)
	{
		delete m_pFile;
		m_pFile = NULL;

		delete m_pArchiveIn;
		m_pArchiveIn = NULL;

		return FALSE;
	}
	END_CATCH

	TRY
	{
		m_pArchiveOut = new CArchive(m_pFile, CArchive::store);
	}
	CATCH(CArchiveException, e)
	{
		delete m_pFile;
		m_pFile = NULL;

		delete m_pArchiveIn;
		m_pArchiveIn = NULL;

		delete m_pArchiveOut;
		m_pArchiveOut = NULL;

		return FALSE;
	}
	CATCH(CFileException, e)
	{
		delete m_pFile;
		m_pFile = NULL;

		delete m_pArchiveIn;
		m_pArchiveIn = NULL;

		delete m_pArchiveOut;
		m_pArchiveOut = NULL;

		return FALSE;
	}
	END_CATCH

	m_pServerObj = pServerObj;

	return TRUE;
}


void CServerObj::CServerSocket::Abort()
{
	if (m_pArchiveOut != NULL)
	{
		m_pArchiveOut->Abort();
		
		delete m_pArchiveOut;
		m_pArchiveOut = NULL;
	}
}


void CServerObj::CServerSocket::SendMessage(CMessage &msg)
{
	if (m_pArchiveOut != NULL)
	{
		msg.Serialize(*m_pArchiveOut);
		
		m_pArchiveOut->Flush();
	}
}


void CServerObj::CServerSocket::ReceiveMessage(CMessage &msg)
{
	msg.Serialize(*m_pArchiveIn);
}


BOOL CServerObj::CServerSocket::IsBufferEmpty() const
{
	return m_pArchiveIn->IsBufferEmpty();
}


void CServerObj::CServerSocket::OnReceive(int nErrorCode) 
{
	CSocket::OnReceive(nErrorCode);

	m_pServerObj->ProcessPendingRead(this, nErrorCode);
}
