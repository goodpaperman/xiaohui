// ServerType


//////////////////////////////////////////////////////////
//                                                      //
// NDK (Network Development Kit) 1.0                    //
//                                                      //
// Authors : Sebastien Lachance                         //
//           Yannick Letourneau                         //
//                                                      //
// Email :   netblitz@rocler.qc.ca                      //
//                                                      //
// Permission to use, copy, modify, and distribute this //
// software for any purpose and without fee is hereby   //
// granted.  This is no guarantee about the use of this //
// software.  For any comments, bugs or thanks, please  //
// email us.                                            //
//                                                      //
// Platform targeted : Windows 95/98/NT                 //
//                                                      //
// Compiled with :     Visual C++ 5/6                   //
//                                                      //
// Date :              April 1999                       //
//                                                      //
// History : 1- First release of this file              //
//                                                      //
//////////////////////////////////////////////////////////


#ifndef SERVERTYPE_H
#define SERVERTYPE_H

typedef UINT ID;

#endif