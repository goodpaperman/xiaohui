// ListeningSocket.cpp

#include "stdafx.h"
#include "ServerObj.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


CServerObj::CListeningSocket::CListeningSocket()
{
	m_pServerObj = NULL;
}


CServerObj::CListeningSocket::~CListeningSocket()
{
}


void CServerObj::CListeningSocket::Init(CServerObj* pServerObj)
{
	m_pServerObj = pServerObj;
}


void CServerObj::CListeningSocket::OnAccept(int nErrorCode) 
{
	CSocket::OnAccept(nErrorCode);

	m_pServerObj->ProcessPendingAccept(nErrorCode);
}