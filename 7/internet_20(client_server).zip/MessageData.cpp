// MessageData.cpp

#include "stdafx.h"
#include "Message.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


CMessage::CMessageData::CMessageData()
{
}


CMessage::CMessageData::CMessageData(const CMessageData &dt)
{
	m_union = dt.m_union;
	m_string = dt.m_string;
	m_rawData = dt.m_rawData;
	m_dataType = dt.m_dataType;
}


const CMessage::CMessageData & CMessage::CMessageData::operator=(const CMessageData &dt)
{
	if (&dt == this)
		return *this;

	m_union = dt.m_union;
	m_string = dt.m_string;
	m_rawData = dt.m_rawData;
	m_dataType = dt.m_dataType;

	return *this;
}