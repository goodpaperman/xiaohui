// User.cpp

#include "stdafx.h"
#include "ServerObj.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


CServerObj::CUserDatabase::CUser::CUser()
{
	m_id = 0;
	m_pServerSocket = NULL;
}


CServerObj::CUserDatabase::CUser::CUser(ID id, CServerSocket* pServerSocket)
{
	m_id = id;
	m_pServerSocket = pServerSocket;
}


CServerObj::CUserDatabase::CUser::~CUser()
{

}


ID CServerObj::CUserDatabase::CUser::GetID() const
{
	return m_id;
}


BOOL CServerObj::CUserDatabase::CUser::IsEqual(CServerSocket* pServerSocket) const
{
	return m_pServerSocket == pServerSocket;
}


BOOL CServerObj::CUserDatabase::CUser::SendMessage(CMessage &msg)
{
	BOOL ret = TRUE;

	TRY
	{
		m_pServerSocket->SendMessage(msg);
	}
	CATCH(CFileException, e)
	{
		m_pServerSocket->Abort();
		
		ret = FALSE;
	}
	END_CATCH

	return ret;
}


BOOL CServerObj::CUserDatabase::CUser::ReadMessage(CMessage &msg)
{
	BOOL ret = TRUE;

	TRY
	{
		m_pServerSocket->ReceiveMessage(msg);
	}
	CATCH(CFileException, e)
	{
		m_pServerSocket->Abort();

		ret = FALSE;
	}
	END_CATCH

	return ret;
}


BOOL CServerObj::CUserDatabase::CUser::IsBufferEmpty() const
{
	return m_pServerSocket->IsBufferEmpty();
}


void CServerObj::CUserDatabase::CUser::Close()
{
	m_id = 0;

	m_pServerSocket->ShutDown();

	m_pServerSocket->Close();

	delete m_pServerSocket;

	m_pServerSocket = NULL;
}
