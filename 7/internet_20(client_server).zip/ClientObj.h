// CClientObj


//////////////////////////////////////////////////////////
//                                                      //
// NDK (Network Development Kit) 1.0                    //
//                                                      //
// Authors : Sebastien Lachance                         //
//           Yannick Letourneau                         //
//                                                      //
// Email :   netblitz@rocler.qc.ca                      //
//                                                      //
// Permission to use, copy, modify, and distribute this //
// software for any purpose and without fee is hereby   //
// granted.  This is no guarantee about the use of this //
// software.  For any comments, bugs or thanks, please  //
// email us.                                            //
//                                                      //
// Platform targeted : Windows 95/98/NT                 //
//                                                      //
// Compiled with :     Visual C++ 5/6                   //
//                                                      //
// Date :              April 1999                       //
//                                                      //
// History : 1- First release of this file              //
//                                                      //
//////////////////////////////////////////////////////////


#ifndef CLIENTOBJ_H
#define CLIENTOBJ_H

#if _MSC_VER >= 1000
#pragma once
#endif 

#include <afxsock.h>
#include "DisconnectionType.h"

class CIp;
class CMessage;


//////////////////////////////////////////////////
//
// class CClientObj (abstract class)
//
// Purpose:
//
// This class implements the client side of the
// client-server architecture.  You must
// provide implementation for two pure virtual
// methods to suit your application.  These 
// functions are OnMessage and OnDisconnect.
//
//////////////////////////////////////////////////
class CClientObj  
{
public:

//////////////////////////////
// Public Interface
//////////////////////////////

	// Construction
	CClientObj();

	// Destruction
	virtual ~CClientObj();

	// Opens a connection to the server,
	// given its IP address and the port
	// number.
	BOOL OpenConnection(const CIp &ip, int port);

	// Closes an established connection
	// with the server.
	void CloseConnection();

	// Retreives the IP address and port number
	// of the client.
	BOOL GetIpAndPort(CIp &ip, UINT &port) const;

	// Sends a message through the network.
	BOOL SendMessage(CMessage &msg);

//////////////////////////////
// End Of Public Interface
//////////////////////////////

protected:

//////////////////////////////
// Protected Interface
//////////////////////////////

	// Callback method that gets called
	// when a message is received.
	// Override this to handle 
	// application-specific messages.
	virtual void OnMessage(CMessage &msg) = 0;

	// Callback method that gets called
	// whenever an unexpected disconnection 
	// occurs.  Override this to let your
	// application react to the event.
	virtual void OnDisconnect(EDisconnectionType reason) = 0;

//////////////////////////////
// End Of Protected Interface
//////////////////////////////

private:

	//////////////////
	// CClientSocket
	//////////////////
	class CClientSocket : public CSocket
	{
	public:
		CClientSocket();
		virtual ~CClientSocket();
		void Init(CClientObj*);

	public:
		//{{AFX_VIRTUAL(CClientSocket)
		public:
		virtual void OnReceive(int nErrorCode);
		//}}AFX_VIRTUAL

		//{{AFX_MSG(CClientSocket)
		//}}AFX_MSG

	private:
		CClientObj*		m_pClientObj;
	};
	
private:
	friend class CClientSocket;

	CClientObj(const CClientObj &) {};
	void operator=(const CClientObj &) {};

	void ProcessPendingRead(int);
	void CloseConnection(int);

private:
	CClientSocket*	m_pClientSocket;
	CSocketFile*	m_pFile;
	CArchive*		m_pArchiveIn;
	CArchive*		m_pArchiveOut;
};

#endif
