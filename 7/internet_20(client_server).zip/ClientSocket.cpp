// ClientSocket.cpp

#include "stdafx.h"
#include "ClientObj.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


CClientObj::CClientSocket::CClientSocket()
{
	m_pClientObj = NULL;
}


CClientObj::CClientSocket::~CClientSocket()
{
}


void CClientObj::CClientSocket::Init(CClientObj* pClientObj)
{
	m_pClientObj = pClientObj;
}


void CClientObj::CClientSocket::OnReceive(int nErrorCode) 
{
	CSocket::OnReceive(nErrorCode);

	m_pClientObj->ProcessPendingRead(nErrorCode);
}
