// Message.cpp

#include "stdafx.h"
#include "Message.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define DT_UNION 0x01
#define DT_STRING 0x02
#define DT_RAWDATA 0x03


CMessage::CMessage()
{
}


CMessage::CMessage(int identifier)
{
	m_id = identifier;
}


CMessage::~CMessage()
{
}


void CMessage::SetIdentifier(int identifier)
{ 
	m_id = identifier;
}


int CMessage::GetIdentifier() const
{ 
	return m_id; 
}


int CMessage::GetNbElements() const
{
	return m_arData.GetSize();
}


IMPLEMENT_SERIAL(CMessage, CObject, 1)
void CMessage::Serialize(CArchive &archive)
{	
	int				nbElements;
	CMessageData	dm;

	if (archive.IsStoring())
	{
		archive << m_id;

		nbElements = m_arData.GetSize();

		archive << nbElements;

		for (int i = 0; i < nbElements; i++)
		{
			dm = m_arData.GetAt(i);

			archive.Write(&dm.m_dataType, sizeof(dm.m_dataType));

			switch(dm.m_dataType)
			{
			case DT_UNION:
				archive.Write(&dm.m_union, sizeof(dm.m_union));
				break;
			case DT_STRING:
				archive << dm.m_string;
				break;
			case DT_RAWDATA:
				dm.m_rawData.Serialize(archive);
				break;
			}
		}
	}
	else
	{
		archive >> m_id;

		archive >> nbElements;

		m_arData.SetSize(nbElements);

		for (int i = 0; i < nbElements; i++)
		{
			archive.Read(&dm.m_dataType, sizeof(dm.m_dataType));

			switch(dm.m_dataType)
			{
			case DT_UNION:
				archive.Read(&dm.m_union, sizeof(dm.m_union));
				break;
			case DT_STRING:
				archive >> dm.m_string;
				break;
			case DT_RAWDATA:
				dm.m_rawData.Serialize(archive);
				break;
			}
		
			m_arData.SetAt(i, dm);
		}
	}
}


void CMessage::SetElementAt(int pos, unsigned char uc)
{
	CMessageData ds;

	ds.m_dataType = DT_UNION;
	ds.m_union.uc = uc;

	m_arData.SetAtGrow(pos, ds);
}


void CMessage::SetElementAt(int pos, char c)
{
	CMessageData ds;

	ds.m_dataType = DT_UNION;
	ds.m_union.c = c;

	m_arData.SetAtGrow(pos, ds);
}


void CMessage::SetElementAt(int pos, unsigned short us)
{
	CMessageData ds;

	ds.m_dataType = DT_UNION;
	ds.m_union.us = us;

	m_arData.SetAtGrow(pos, ds);
}


void CMessage::SetElementAt(int pos, short s)
{
	CMessageData ds;
	
	ds.m_dataType = DT_UNION;
	ds.m_union.s = s;

	m_arData.SetAtGrow(pos, ds);
}


void CMessage::SetElementAt(int pos, unsigned int ui)
{
	CMessageData ds;

	ds.m_dataType = DT_UNION;
	ds.m_union.ui = ui;

	m_arData.SetAtGrow(pos, ds);
}


void CMessage::SetElementAt(int pos, int i)
{
	CMessageData ds;

	ds.m_dataType = DT_UNION;
	ds.m_union.i = i;

	m_arData.SetAtGrow(pos, ds);
}


void CMessage::SetElementAt(int pos, unsigned long ul)
{
	CMessageData ds;

	ds.m_dataType = DT_UNION;
	ds.m_union.ul = ul;

	m_arData.SetAtGrow(pos, ds);
}


void CMessage::SetElementAt(int pos, long l)
{
	CMessageData ds;

	ds.m_dataType = DT_UNION;
	ds.m_union.l = l;

	m_arData.SetAtGrow(pos, ds);
}


void CMessage::SetElementAt(int pos, float f)
{
	CMessageData ds;

	ds.m_dataType = DT_UNION;
	ds.m_union.f = f;

	m_arData.SetAtGrow(pos, ds);
}


void CMessage::SetElementAt(int pos, double d)
{
	CMessageData ds;

	ds.m_dataType = DT_UNION;
	ds.m_union.d = d;

	m_arData.SetAtGrow(pos, ds);
}


void CMessage::SetElementAt(int pos, const CString &cs)
{
	CMessageData ds;

	ds.m_dataType = DT_STRING;
	ds.m_string = cs;

	m_arData.SetAtGrow(pos, ds);
}


void CMessage::SetElementAt(int pos, LPVOID pData, unsigned long length)
{
	CMessageData::CDataBuffer db(pData, length);

	CMessageData ds;

	ds.m_dataType = DT_RAWDATA;
	ds.m_rawData = db;

	m_arData.SetAtGrow(pos, ds);
}


void CMessage::GetElementAt(int pos, unsigned char &uc) const
{
	CMessageData ds = m_arData.GetAt(pos);

	uc = ds.m_union.uc;
}


void CMessage::GetElementAt(int pos, char &c) const
{
	CMessageData ds = m_arData.GetAt(pos);

	c = ds.m_union.c;
}


void CMessage::GetElementAt(int pos, unsigned short &us) const
{
	CMessageData ds = m_arData.GetAt(pos);

	us = ds.m_union.us;
}


void CMessage::GetElementAt(int pos, short &s) const
{
	CMessageData ds = m_arData.GetAt(pos);

	s = ds.m_union.s;
}


void CMessage::GetElementAt(int pos, unsigned int &ui) const
{
	CMessageData ds = m_arData.GetAt(pos);

	ui = ds.m_union.ui;
}


void CMessage::GetElementAt(int pos, int &i) const
{
	CMessageData ds = m_arData.GetAt(pos);

	i = ds.m_union.i;
}


void CMessage::GetElementAt(int pos, unsigned long &ul) const
{
	CMessageData ds = m_arData.GetAt(pos);

	ul = ds.m_union.ul;
}


void CMessage::GetElementAt(int pos, long &l) const
{
	CMessageData ds = m_arData.GetAt(pos);

	l = ds.m_union.l;
}


void CMessage::GetElementAt(int pos, float &f) const
{
	CMessageData ds = m_arData.GetAt(pos);

	f = ds.m_union.f;
}


void CMessage::GetElementAt(int pos, double &d) const
{
	CMessageData ds = m_arData.GetAt(pos);

	d = ds.m_union.d;
}


void CMessage::GetElementAt(int pos, CString &cs) const
{
	CMessageData ds = m_arData.GetAt(pos);

	cs = ds.m_string;
}


void CMessage::GetElementAt(int pos, LPVOID pData, unsigned long maxLength) const
{
	CMessageData ds = m_arData.GetAt(pos);

	memcpy(pData, ds.m_rawData.GetBuffer(), min(maxLength, ds.m_rawData.GetLength()));
}

