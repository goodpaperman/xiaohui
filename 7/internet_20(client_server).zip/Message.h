// CMessage


//////////////////////////////////////////////////////////
//                                                      //
// NDK (Network Development Kit) 1.0                    //
//                                                      //
// Authors : Sebastien Lachance                         //
//           Yannick Letourneau                         //
//                                                      //
// Email :   netblitz@rocler.qc.ca                      //
//                                                      //
// Permission to use, copy, modify, and distribute this //
// software for any purpose and without fee is hereby   //
// granted.  This is no guarantee about the use of this //
// software.  For any comments, bugs or thanks, please  //
// email us.                                            //
//                                                      //
// Platform targeted : Windows 95/98/NT                 //
//                                                      //
// Compiled with :     Visual C++ 5/6                   //
//                                                      //
// Date :              April 1999                       //
//                                                      //
// History : 1- First release of this file              //
//                                                      //
//////////////////////////////////////////////////////////


#ifndef MESSAGE_H
#define MESSAGE_H

#if _MSC_VER >= 1000
#pragma once
#endif 

#include <afxtempl.h>


////////////////////////////////////////////////////
//
// class CMessage (concrete class)
//
// Purpose :
//
// This class is the primitive object that can be
// sent through the client-server architecture. It
// can be seen as an array of elements of different
// type.  These types are all the C++ basic types
// as well as CString.  It also supports an 
// arbitrary length buffer of untyped data (LPVOID).
// The array grows automatically as needed.
// Elements within the array are zero-indexed.
//
// Each message type is identified with a unique
// int.
//
////////////////////////////////////////////////////
class CMessage : public CObject
{
public:

//////////////////////////////
// Public Interface
//////////////////////////////

	// Construction.
	CMessage();

	// Construction with a unique identifier.
	// Identifiers are unsigned shorts
	CMessage(int identifier);
	
	// Destruction.
	virtual ~CMessage();

	// Assigns a unique identifier to each message.
	// Identifiers are unsigned shorts.
	void SetIdentifier(int identifier);

	// Obtains the identifier of this message.
	int GetIdentifier() const;

	// Returns the number of elements in the array
	// of this message.
	int GetNbElements() const;

	// Serializes a CMessage object to a CArchive
	void Serialize(CArchive &archive);

	// The following methods are used to set
	// the elements of the internal array
	// of the CMessage to any value.
	// Elements are zero-indexed.
	void SetElementAt(int index, unsigned char data);
	void SetElementAt(int index, char data);
	void SetElementAt(int index, unsigned short data);
	void SetElementAt(int index, short data);
	void SetElementAt(int index, unsigned int data);
	void SetElementAt(int index, int data);
	void SetElementAt(int index, unsigned long data);
	void SetElementAt(int index, long data);
	void SetElementAt(int index, float data);
	void SetElementAt(int index, double data);
	void SetElementAt(int index, const CString &data);
	void SetElementAt(int index, LPVOID pData, unsigned long length);

	// The following methods are used to get
	// the elements of the internal array
	// of the CMessage.  The parameter
	// passed by reference will be filled
	// with the appropriate data.  The type
	// of data extracted must match the type
	// of data set with a previous call to
	// SetElementAt().
	// Elements are zero-indexed.
	void GetElementAt(int index, unsigned char &data) const;
	void GetElementAt(int index, char &data) const;
	void GetElementAt(int index, unsigned short &data) const;
	void GetElementAt(int index, short &data) const;
	void GetElementAt(int index, unsigned int &data) const;
	void GetElementAt(int index, int &data) const;
	void GetElementAt(int index, unsigned long &data) const;
	void GetElementAt(int index, long &data) const;
	void GetElementAt(int index, float &data) const;
	void GetElementAt(int index, double &data) const;
	void GetElementAt(int index, CString &data) const;
	void GetElementAt(int index, LPVOID pData, unsigned long length) const;

//////////////////////////////
// End Of Public Interface
//////////////////////////////

	DECLARE_SERIAL(CMessage)

private:

	//////////////////////
	// CMessageData
	//////////////////////
	class CMessageData
	{
	public:

		CMessageData();
		CMessageData(const CMessageData &);
		const CMessageData& operator=(const CMessageData &);

		//////////////////////
		// CDataBuffer
		//////////////////////
		class CDataBuffer
		{
		public:
			CDataBuffer();
			CDataBuffer(LPVOID, unsigned long);
			virtual ~CDataBuffer();
			void Serialize(CArchive &);
			unsigned long GetLength() const;
			LPVOID GetBuffer() const;
			const CDataBuffer & operator=(const CDataBuffer &);

		private:
			LPVOID			m_pData;
			unsigned long	m_length;
		};

		char m_dataType;

		union
		{
			unsigned char uc;
			char c;
			unsigned short us;
			short s;
			unsigned int ui;
			int i;
			unsigned long ul;
			long l;
			float f;
			double d;
		} m_union;

		CString		m_string;
		CDataBuffer m_rawData;
	};

private:
	int										m_id;
	CArray<CMessageData, CMessageData &>	m_arData;
};

#endif
