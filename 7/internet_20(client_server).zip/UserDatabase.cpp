// UserDatabase.cpp

#include "stdafx.h"
#include "ServerObj.h"
#include "Message.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


CServerObj::CUserDatabase::CUserDatabase(CServerObj* pServerObj)
{
	m_pServerObj = pServerObj;
	m_nextID = 1;
	m_iterationPos = NULL;
}


CServerObj::CUserDatabase::~CUserDatabase()
{
}


ID CServerObj::CUserDatabase::AddUser(CServerSocket* pServerSocket)
{
	CUser user(m_nextID, pServerSocket);

	m_userList.AddTail(user);
	
	return m_nextID++;
}


void CServerObj::CUserDatabase::RemoveUser(ID id)
{
	CUser*		pUser;
	POSITION	pos, temp;

	for (pos = m_userList.GetHeadPosition(); pos != NULL; )
	{
		temp = pos;

 		pUser = &m_userList.GetNext(pos);

		if (pUser->GetID() == id)
		{
			if (m_currentUser == id)
				m_currentUser = 0;

			pUser->Close();
			m_userList.RemoveAt(temp);
		}
	}
}


int CServerObj::CUserDatabase::GetNbUsers() const
{
	return m_userList.GetCount();
}


BOOL CServerObj::CUserDatabase::SendMessage(ID id, CMessage &msg)
{
	CUser*		pUser;
	POSITION	pos, temp;

	for (pos = m_userList.GetHeadPosition(); pos != NULL; )
	{
		temp = pos;

 		pUser = &m_userList.GetNext(pos);

		if (pUser->GetID() == id)
			return pUser->SendMessage(msg);
	}

	return FALSE;
}


CServerObj::CUserDatabase::CUser * CServerObj::CUserDatabase::GetUserFromSocket(CServerSocket* pServerSocket)
{
	CUser*		pUser;
	POSITION	pos;

	for (pos = m_userList.GetHeadPosition(); pos != NULL; )
	{
		pUser = &m_userList.GetNext(pos);

		if (pUser->IsEqual(pServerSocket))
			return pUser;
	}

	return NULL;
}


BOOL CServerObj::CUserDatabase::IsEmpty()
{
	return m_userList.IsEmpty();
}


void CServerObj::CUserDatabase::SetCurrentUser(ID id)
{
	m_currentUser = id;
}


BOOL CServerObj::CUserDatabase::IsCurrentUserClosed() const
{
	return m_currentUser == 0;
}


ID CServerObj::CUserDatabase::GetFirstID()
{
	m_iterationPos = m_userList.GetHeadPosition();

	return m_userList.GetNext(m_iterationPos).GetID();
}


ID CServerObj::CUserDatabase::GetNextID()
{
	return m_userList.GetNext(m_iterationPos).GetID();
}


BOOL CServerObj::CUserDatabase::IsLastID()
{
	return m_iterationPos == NULL;
}
