// Ip.cpp

#include "stdafx.h"
#include "Ip.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


CIp::CIp()
{
	for (int i = 0; i < 4; i++)
		m_ip[i] = 0;
}


CIp::CIp(const CIp &ip)
{
	for (int i = 0; i < 4; i++)
		m_ip[i] = ip.m_ip[i];
}


CIp::~CIp()
{
}


void CIp::SetIp(const CString &Ip)
{
	CString temp;
	int pos = 0;
			
	while (Ip[pos] != '.')
		temp += Ip[pos++];
	pos++;
	
	m_ip[0] = (unsigned char) atoi(temp);
	temp = "";
	

	while (Ip[pos] != '.')
		temp += Ip[pos++];
	pos++;
	
	m_ip[1] = (unsigned char) atoi(temp);
	temp = "";
	
	while (Ip[pos] != '.')
		temp += Ip[pos++];
	pos++;
	
	m_ip[2] = (unsigned char) atoi(temp);
	temp = "";

	while (pos != Ip.GetLength())
		temp += Ip[pos++];
		
	m_ip[3] = (unsigned char) atoi(temp);
}


CString CIp::GetIp() const
{
	CString ip;
	char temp[5];

	for (int i = 0; i < 3; i ++)
	{
		itoa((int) m_ip[i], temp, 10);
		ip += CString(temp) + ".";
	}

	itoa((int) m_ip[3], temp, 10);
	ip += CString(temp);

	return ip;
}


const CIp & CIp::operator=(const CIp &ip)
{
	if (&ip == this)
		return *this;

	for (int i = 0; i < 4; i++)
		m_ip[i] = ip.m_ip[i];

	return *this;
}


BOOL CIp::IsValid(const CString &ip)
{
	CString temp;
	CString token;
	int pos;

	temp = ip;

	temp.TrimLeft();
	temp.TrimRight();

	for (int i = 0; i < 3; i++)
	{
		pos = temp.Find(".");
	
		if (pos == -1)
			return FALSE;

		token = temp.Left(pos);
				
		if (!IsValidNumber(token))
			return FALSE;

		temp = temp.Right(temp.GetLength() - pos - 1);
	}

	if (!IsValidNumber(temp))
		return FALSE;

	return TRUE;
}


BOOL CIp::IsValidNumber(const CString &num)
{
	unsigned int number;

	for (int i = 0; i < num.GetLength(); i++)
		if (!(num[i] >= '0' && num[i] <= '9'))
			return FALSE;

	number = atoi(num);

	if (number < 0 || number > 255)
		return FALSE;

	return TRUE;
}
