//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ODBCClasses.rc
//
#define IDS_ERROR_SQLALLOCHANDLEHENV 50000
#define IDS_ERROR_SQLSETENVATTR 50001
#define IDS_ERROR_SQLALLOCHANDLEHDBC 50002
#define IDS_ERROR_SQLCONNECT 50003
#define IDS_ERROR_UNKNOWNCAUSE 50004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        3000
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         3000
#define _APS_NEXT_SYMED_VALUE           3000
#endif
#endif
