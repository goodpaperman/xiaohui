#pragma once

class AFX_EXT_CLASS CDBVariantEx : public CDBVariant
{
public:
	void GetStringValue(LPSTR lpsz);
	void GetStringValue(CString& rstrValue);
};
