// ODBCDynamicTestDlg.h : header file
//

#if !defined(AFX_ODBCDYNAMICTESTDLG_H__1BF4941D_93A3_11D1_AF24_6A914B000000__INCLUDED_)
#define AFX_ODBCDYNAMICTESTDLG_H__1BF4941D_93A3_11D1_AF24_6A914B000000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ODBCDynamic.hpp"

/////////////////////////////////////////////////////////////////////////////
// CODBCDynamicTestDlg dialog

class CODBCDynamicTestDlg : public CDialog
{
// Construction
public:
	CODBCDynamicTestDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CODBCDynamicTestDlg)
	enum { IDD = IDD_ODBCDYNAMICTEST_DIALOG };
	CListCtrl	m_lstData;
	CComboBox	m_cboDSNs;
	CString	m_strDSN;
	CString	m_strSql;
	CString m_strUser;
	CString m_strPassword;
	CString	m_strUserId;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CODBCDynamicTestDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

protected:
	SQLHENV m_henv;

protected:
	void FillDSNComboBox();
	void ExecuteSql();
	void ResetDataListControl();

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CODBCDynamicTestDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnAbout();
	virtual void OnOK();
	afx_msg void OnSelchangeCboDsns();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ODBCDYNAMICTESTDLG_H__1BF4941D_93A3_11D1_AF24_6A914B000000__INCLUDED_)
