#pragma once

class AFX_EXT_CLASS CODBCTypeInfo
{                           
public:
	CODBCTypeInfo(LPCSTR lpszDSN);
	~CODBCTypeInfo();

protected:
	CODBCDynamic* m_pODBCDynamic;
		
public:
	BOOL GetTypeInfo(UINT iDataType, CMapStringToOb*& rpMapDataAttrNameToDataAttrVal);
	BOOL GetTypeInfo(UINT iDataType, LPCSTR lpszColName, CDBVariantEx** ppvarValue);
public:
	CMapWordToOb m_mapDataTypeToDataAttrMap;
};
