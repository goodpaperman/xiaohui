// ODBCDynamicTestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ODBCDynamicTest.h"
#include "ODBCDynamicTestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg() : CDialog(IDD_ABOUTBOX) {}

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

void CAboutDlg::OnOK() 
{
	CWaitCursor wait;

	CString strURL;
	GetDlgItem(IDOK)->GetWindowText(strURL);
	if (!strURL.IsEmpty())
	{
		if (32 >= (int)ShellExecute(NULL, "open", strURL, NULL, NULL, SW_SHOWNORMAL))
		{
			AfxMessageBox("::ShellExecute failed to open this link!");
		}
	}
	else
	{
		AfxMessageBox("No URL defined on button!");
	}
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CODBCDynamicTestDlg dialog

CODBCDynamicTestDlg::CODBCDynamicTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CODBCDynamicTestDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CODBCDynamicTestDlg)
	m_strSql = _T("");
	m_strUserId = _T("");
	m_strPassword = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_henv = NULL;
}

void CODBCDynamicTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CODBCDynamicTestDlg)
	DDX_Control(pDX, IDC_LST_DATA, m_lstData);
	DDX_Control(pDX, IDC_CBO_DSNS, m_cboDSNs);
	DDX_CBString(pDX, IDC_CBO_DSNS, m_strDSN);
	DDX_Text(pDX, IDC_EDT_SQL, m_strSql);
	DDX_Text(pDX, IDC_EDT_USER_ID, m_strUserId);
	DDX_Text(pDX, IDC_EDT_PASSWORD, m_strPassword);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CODBCDynamicTestDlg, CDialog)
	//{{AFX_MSG_MAP(CODBCDynamicTestDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_ABOUT, OnAbout)
	ON_CBN_SELCHANGE(IDC_CBO_DSNS, OnSelchangeCboDsns)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CODBCDynamicTestDlg message handlers

void CODBCDynamicTestDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CODBCDynamicTestDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CODBCDynamicTestDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

BOOL CODBCDynamicTestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// set list control's style
	LONG lStyle = m_lstData.SendMessage(LVM_GETEXTENDEDLISTVIEWSTYLE);
	lStyle |= LVS_EX_FULLROWSELECT;
	m_lstData.SendMessage(LVM_SETEXTENDEDLISTVIEWSTYLE, 0, (LPARAM)lStyle);

	m_lstData.SetColumnWidth(0, LVSCW_AUTOSIZE);

	FillDSNComboBox();

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CODBCDynamicTestDlg::FillDSNComboBox()
{
	m_cboDSNs.ResetContent();

	SQLHENV henv;

	SQLRETURN rc;
	if (SQL_SUCCESS == (rc = ::SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &henv)))
	{
		if (SQL_SUCCESS == (rc = ::SQLSetEnvAttr(henv, SQL_ATTR_ODBC_VERSION, (SQLPOINTER) SQL_OV_ODBC3, SQL_IS_INTEGER)))
		{
			if (SQL_SUCCESS == (rc = ::SQLAllocEnv(&henv)))
			{
				UCHAR szDSN[SQL_MAX_DSN_LENGTH+1];
				UCHAR szDescription[512];                                                                                                                              
				SWORD swDescLen, swDSNLen;

				while (SQL_NO_DATA_FOUND != 
					(rc = ::SQLDataSources(henv, SQL_FETCH_NEXT, 
					szDSN, sizeof(szDSN), &swDSNLen, 
					szDescription, sizeof(szDescription), 
					&swDescLen)))
				{       
					m_cboDSNs.AddString(CString(szDSN));
				}		
				m_cboDSNs.SetCurSel(-1);
			}
		}
	}
}

void CODBCDynamicTestDlg::ResetDataListControl()
{
	m_lstData.DeleteAllItems();
	int iNbrOfColumns;
	CHeaderCtrl* pHeader = (CHeaderCtrl*)m_lstData.GetDlgItem(0);
	if (pHeader)
	{
		iNbrOfColumns = pHeader->GetItemCount();
	}
	for (int i = iNbrOfColumns; i >= 0; i--)
	{
		m_lstData.DeleteColumn(i);
	}
}

void CODBCDynamicTestDlg::ExecuteSql()
{
	ResetDataListControl();

	if (UpdateData()
	&& !m_strDSN.IsEmpty())
	{
		CClientDC dc(this);

		try
		{
			CODBCDynamic odbcDynamic(m_strDSN, m_strUserId, m_strPassword);
			odbcDynamic.ExecuteSQL(m_strSql);

			CODBCRecordArray* pODBCRecordArray = &odbcDynamic.m_ODBCRecordArray;

			for (int iRecord = 0; iRecord < pODBCRecordArray->GetSize(); iRecord++)
			{
				POSITION pos;
				CString strColName;
				CDBVariantEx* pvarValue;
				char szValue[255];

				int iCol = 0;
				CODBCRecord* pODBCRecord = (*pODBCRecordArray)[iRecord];
				for (pos = pODBCRecord->GetStartPosition(); pos != NULL;)
				{
					pODBCRecord->GetNextAssoc(pos, strColName, pvarValue);

					if (0 == iRecord)
					{
						CSize size = dc.GetTextExtent(strColName.GetBuffer(strColName.GetLength()));
						m_lstData.InsertColumn(iCol, strColName, LVCFMT_LEFT, size.cx, iCol);
					}

					if (pvarValue)
					{
						pvarValue->GetStringValue(szValue);
						if (0 < strlen(szValue))
						{
							if (0 == iCol)
							{
								iRecord = m_lstData.InsertItem(iRecord, szValue, iCol);
							}
							else
							{
								m_lstData.SetItemText(iRecord, iCol, szValue);
							}

							iCol++;
						}
					}
				}
			}
		}
		catch (CUserException* pe)
		{
			pe->ReportError();
			pe->Delete();
		}
	}
}

void CODBCDynamicTestDlg::OnAbout() 
{
	CAboutDlg().DoModal();
}

void CODBCDynamicTestDlg::OnOK() 
{
	ExecuteSql();		
}

void CODBCDynamicTestDlg::OnSelchangeCboDsns() 
{
	UpdateData(TRUE);
	m_strUserId = _T("");
	m_strPassword = _T("");
	m_strSql = _T("");
	ResetDataListControl();
	UpdateData(FALSE);
}
