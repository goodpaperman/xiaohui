#pragma once

#include "afxdb.h"
#include "DBVariantEx.h"
#include "ODBCDynamic.hpp"
#include "ODBCTypeInfo.h"
