#pragma once

#include "afxdb.h"
#include <afxtempl.h>
#include "DBVariantEx.h"
#include "ODBCDynamic.h"