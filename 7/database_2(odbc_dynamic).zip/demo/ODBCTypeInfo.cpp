#include "stdafx.h"
#include "ODBCTypeInfo.hpp"

#define MAX_COLNAME 50

CODBCTypeInfo::CODBCTypeInfo(LPCSTR lpszDSN)
{
	SQLRETURN rc;
	SQLHSTMT hstmt = NULL;

	int aiDataTypes[] = {
		SQL_CHAR,
		SQL_NUMERIC,
		SQL_DECIMAL,
		SQL_INTEGER,
		SQL_SMALLINT,
		SQL_FLOAT,
		SQL_REAL,
		SQL_DOUBLE,
#if (ODBCVER >= 0x0300)
		SQL_DATETIME,
#endif
		SQL_VARCHAR
	};

	m_pODBCDynamic = new CODBCDynamic(lpszDSN);

	// call sqlgettypeinfo for each member of the datatype struct defined above
	int nDataTypes = (sizeof(aiDataTypes) / sizeof(aiDataTypes[0]));
	for (int iCurrDataType = 0; iCurrDataType < nDataTypes; iCurrDataType++)
	{
		// for each type, create a column to data attr map
		CMapStringToPtr* pmapColNameToDataAttr = new CMapStringToPtr();

		m_mapDataTypeToDataAttrMap.SetAt(aiDataTypes[iCurrDataType], static_cast<CObject*>(pmapColNameToDataAttr));

		HSTMT hstmt;
		if (SQL_SUCCESS == (rc = ::SQLAllocHandle(SQL_HANDLE_STMT, m_pODBCDynamic->GetHDBC(), &hstmt)))
		{
			if (SQL_SUCCESS == (rc = ::SQLGetTypeInfo(hstmt, aiDataTypes[iCurrDataType])))
			{
				m_pODBCDynamic->FetchData(hstmt);
				CODBCRecordArray* pODBCRecordArray = &m_pODBCDynamic->m_ODBCRecordArray;

				for (int iRecord = 0; iRecord < pODBCRecordArray->GetSize(); iRecord++)
				{
					POSITION pos;
					CString strColName;
					CDBVariantEx* pvarValue;

					CODBCRecord* pODBCRecord = (*pODBCRecordArray)[iRecord];

					for (pos = pODBCRecord->GetStartPosition(); pos != NULL;)
					{
						pODBCRecord->GetNextAssoc(pos, strColName, pvarValue);
						if (GOOD_PTR(pvarValue, CDBVariant))
						{
							pmapColNameToDataAttr->SetAt(strColName, static_cast<void*>(pvarValue));
						}
					}
				}
			}
			::SQLFreeHandle(SQL_HANDLE_STMT, &hstmt);
		}
	}
}

CODBCTypeInfo::~CODBCTypeInfo()
{
	CMapStringToOb* pmapColNameToDataAttr;
	POSITION pos1;
	WORD wKey;
	for (pos1 = m_mapDataTypeToDataAttrMap.GetStartPosition(); pos1 != NULL;)
	{
		m_mapDataTypeToDataAttrMap.GetNextAssoc(pos1, wKey, (CObject*&)pmapColNameToDataAttr);
		if (GOOD_PTR(pmapColNameToDataAttr, CMapStringToOb))
		{
			POSITION pos;
			CString strKey;
			CDBVariantEx* pvarValue;

			int iCol = 0;
			for (pos = pmapColNameToDataAttr->GetStartPosition(); pos != NULL;)
			{
				pmapColNameToDataAttr->GetNextAssoc(pos, strKey, (CObject*&)pvarValue);

				if (GOOD_PTR(pvarValue, CDBVariantEx))
				{
					// delete pvarValue;
				}
				pmapColNameToDataAttr->RemoveKey(strKey);
			}
			LOG_ASSERT(0 == pmapColNameToDataAttr->GetCount());
			delete pmapColNameToDataAttr;
		}
		m_mapDataTypeToDataAttrMap.RemoveKey(wKey);
	}
	LOG_ASSERT(0 == m_mapDataTypeToDataAttrMap.GetCount());

	delete m_pODBCDynamic;
}

BOOL CODBCTypeInfo::GetTypeInfo(UINT iDataType, LPCSTR lpszColName, CDBVariantEx** ppvarValue)
{
	BOOL bSuccess = FALSE;

	CMapStringToOb* pmapColNameToDataAttr;
	if (m_mapDataTypeToDataAttrMap.Lookup(iDataType, (CObject*&)pmapColNameToDataAttr))
	{
		if (pmapColNameToDataAttr->Lookup(lpszColName, (CObject*&)*ppvarValue))
		{
			bSuccess = TRUE;
		}
	}

	return bSuccess;
}

BOOL CODBCTypeInfo::GetTypeInfo(UINT iDataType, CMapStringToOb*& rpMapDataAttrNameToDataAttrVal)
{
	return (m_mapDataTypeToDataAttrMap.Lookup(iDataType, (CObject*&)rpMapDataAttrNameToDataAttrVal));
}
