// AutoFillPpg.cpp : Implementation of the CAutoFillPropPage property page class.

#include "stdafx.h"
#include "AutoFill.h"
#include "AutoFillPpg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CAutoFillPropPage, COlePropertyPage)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CAutoFillPropPage, COlePropertyPage)
	//{{AFX_MSG_MAP(CAutoFillPropPage)
	// NOTE - ClassWizard will add and remove message map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CAutoFillPropPage, "AUTOFILL.AutoFillPropPage.1",
	0x17c8b9a6, 0x1121, 0x11d3, 0x90, 0xeb, 0, 0x80, 0xad, 0x30, 0xec, 0x75)


/////////////////////////////////////////////////////////////////////////////
// CAutoFillPropPage::CAutoFillPropPageFactory::UpdateRegistry -
// Adds or removes system registry entries for CAutoFillPropPage

BOOL CAutoFillPropPage::CAutoFillPropPageFactory::UpdateRegistry(BOOL bRegister)
{
	if (bRegister)
		return AfxOleRegisterPropertyPageClass(AfxGetInstanceHandle(),
			m_clsid, IDS_AUTOFILL_PPG);
	else
		return AfxOleUnregisterClass(m_clsid, NULL);
}


/////////////////////////////////////////////////////////////////////////////
// CAutoFillPropPage::CAutoFillPropPage - Constructor

CAutoFillPropPage::CAutoFillPropPage() :
	COlePropertyPage(IDD, IDS_AUTOFILL_PPG_CAPTION)
{
	//{{AFX_DATA_INIT(CAutoFillPropPage)
	// NOTE: ClassWizard will add member initialization here
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA_INIT
}


/////////////////////////////////////////////////////////////////////////////
// CAutoFillPropPage::DoDataExchange - Moves data between page and properties

void CAutoFillPropPage::DoDataExchange(CDataExchange* pDX)
{
	//{{AFX_DATA_MAP(CAutoFillPropPage)
	// NOTE: ClassWizard will add DDP, DDX, and DDV calls here
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA_MAP
	DDP_PostProcessing(pDX);
}


/////////////////////////////////////////////////////////////////////////////
// CAutoFillPropPage message handlers
