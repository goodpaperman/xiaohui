#if !defined(AFX_AUTOFILLCTL_H__17C8B9B2_1121_11D3_90EB_0080AD30EC75__INCLUDED_)
#define AFX_AUTOFILLCTL_H__17C8B9B2_1121_11D3_90EB_0080AD30EC75__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// AutoFillCtl.h : Declaration of the CAutoFillCtrl ActiveX Control class.

/////////////////////////////////////////////////////////////////////////////
// CAutoFillCtrl : See AutoFillCtl.cpp for implementation.

class CAutoFillCtrl : public COleControl
{
private:
   CString     m_Filename;
   CString     m_Section;

   int         NumCtrls;
   UINT        CtrlsID[200];

   CStdioFile  m_AFfile;


	DECLARE_DYNCREATE(CAutoFillCtrl)

// Constructor
public:
	CAutoFillCtrl();
   DWORD   FindSection (CString  FileName , CString  SecName);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAutoFillCtrl)
	public:
	virtual void OnDraw(CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid);
	virtual void DoPropExchange(CPropExchange* pPX);
	virtual void OnResetState();
	//}}AFX_VIRTUAL

// Implementation
protected:
	~CAutoFillCtrl();

	DECLARE_OLECREATE_EX(CAutoFillCtrl)    // Class factory and guid
	DECLARE_OLETYPELIB(CAutoFillCtrl)      // GetTypeInfo
	DECLARE_PROPPAGEIDS(CAutoFillCtrl)     // Property page IDs
	DECLARE_OLECTLTYPE(CAutoFillCtrl)		// Type name and misc status

// Message maps
	//{{AFX_MSG(CAutoFillCtrl)
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

// Dispatch maps
	//{{AFX_DISPATCH(CAutoFillCtrl)
	afx_msg void AddControl(short ControlID);
	afx_msg void FileName(LPCTSTR FileName);
	afx_msg void Section(LPCTSTR SectionName);
	afx_msg BOOL FillDialog();
	afx_msg void ClearControls();
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()

// Event maps
	//{{AFX_EVENT(CAutoFillCtrl)
	//}}AFX_EVENT
	DECLARE_EVENT_MAP()

// Dispatch and event IDs
public:
	enum {
	//{{AFX_DISP_ID(CAutoFillCtrl)
	dispidAddControl = 1L,
	dispidFileName = 2L,
	dispidSection = 3L,
	dispidFillDialog = 4L,
	dispidClearControls = 5L,
	//}}AFX_DISP_ID
	};
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_AUTOFILLCTL_H__17C8B9B2_1121_11D3_90EB_0080AD30EC75__INCLUDED)
