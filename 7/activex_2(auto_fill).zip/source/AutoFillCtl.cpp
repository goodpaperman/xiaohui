// AutoFillCtl.cpp : Implementation of the CAutoFillCtrl ActiveX Control class.

#include "stdafx.h"
#include "AutoFill.h"
#include "AutoFillCtl.h"
#include "AutoFillPpg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CAutoFillCtrl, COleControl)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CAutoFillCtrl, COleControl)
	//{{AFX_MSG_MAP(CAutoFillCtrl)
	ON_WM_LBUTTONUP()
	ON_WM_RBUTTONUP()
	//}}AFX_MSG_MAP
	ON_OLEVERB(AFX_IDS_VERB_PROPERTIES, OnProperties)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Dispatch map

BEGIN_DISPATCH_MAP(CAutoFillCtrl, COleControl)
	//{{AFX_DISPATCH_MAP(CAutoFillCtrl)
	DISP_FUNCTION(CAutoFillCtrl, "AddControl", AddControl, VT_EMPTY, VTS_I2)
	DISP_FUNCTION(CAutoFillCtrl, "FileName", FileName, VT_EMPTY, VTS_BSTR)
	DISP_FUNCTION(CAutoFillCtrl, "Section", Section, VT_EMPTY, VTS_BSTR)
	DISP_FUNCTION(CAutoFillCtrl, "FillDialog", FillDialog, VT_BOOL, VTS_NONE)
	DISP_FUNCTION(CAutoFillCtrl, "ClearControls", ClearControls, VT_EMPTY, VTS_NONE)
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()


/////////////////////////////////////////////////////////////////////////////
// Event map

BEGIN_EVENT_MAP(CAutoFillCtrl, COleControl)
	//{{AFX_EVENT_MAP(CAutoFillCtrl)
	// NOTE - ClassWizard will add and remove event map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_EVENT_MAP
END_EVENT_MAP()


/////////////////////////////////////////////////////////////////////////////
// Property pages

// TODO: Add more property pages as needed.  Remember to increase the count!
BEGIN_PROPPAGEIDS(CAutoFillCtrl, 1)
	PROPPAGEID(CAutoFillPropPage::guid)
END_PROPPAGEIDS(CAutoFillCtrl)


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CAutoFillCtrl, "AUTOFILL.AutoFillCtrl.1",
	0x17c8b9a5, 0x1121, 0x11d3, 0x90, 0xeb, 0, 0x80, 0xad, 0x30, 0xec, 0x75)


/////////////////////////////////////////////////////////////////////////////
// Type library ID and version

IMPLEMENT_OLETYPELIB(CAutoFillCtrl, _tlid, _wVerMajor, _wVerMinor)


/////////////////////////////////////////////////////////////////////////////
// Interface IDs

const IID BASED_CODE IID_DAutoFill =
		{ 0x17c8b9a3, 0x1121, 0x11d3, { 0x90, 0xeb, 0, 0x80, 0xad, 0x30, 0xec, 0x75 } };
const IID BASED_CODE IID_DAutoFillEvents =
		{ 0x17c8b9a4, 0x1121, 0x11d3, { 0x90, 0xeb, 0, 0x80, 0xad, 0x30, 0xec, 0x75 } };


/////////////////////////////////////////////////////////////////////////////
// Control type information

static const DWORD BASED_CODE _dwAutoFillOleMisc =
	OLEMISC_ACTIVATEWHENVISIBLE |
	OLEMISC_SETCLIENTSITEFIRST |
	OLEMISC_INSIDEOUT |
	OLEMISC_CANTLINKINSIDE |
	OLEMISC_RECOMPOSEONRESIZE;

IMPLEMENT_OLECTLTYPE(CAutoFillCtrl, IDS_AUTOFILL, _dwAutoFillOleMisc)


/////////////////////////////////////////////////////////////////////////////
// CAutoFillCtrl::CAutoFillCtrlFactory::UpdateRegistry -
// Adds or removes system registry entries for CAutoFillCtrl

BOOL CAutoFillCtrl::CAutoFillCtrlFactory::UpdateRegistry(BOOL bRegister)
{
	if (bRegister)
		return AfxOleRegisterControlClass(
			AfxGetInstanceHandle(),
			m_clsid,
			m_lpszProgID,
			IDS_AUTOFILL,
			IDB_AUTOFILL,
			afxRegApartmentThreading,
			_dwAutoFillOleMisc,
			_tlid,
			_wVerMajor,
			_wVerMinor);
	else
		return AfxOleUnregisterClass(m_clsid, m_lpszProgID);
}


/////////////////////////////////////////////////////////////////////////////
// CAutoFillCtrl::CAutoFillCtrl - Constructor

CAutoFillCtrl::CAutoFillCtrl()
{
   InitializeIIDs(&IID_DAutoFill, &IID_DAutoFillEvents);

   m_Filename = "" ;                                     // Reset the filename 
   m_Section = "";                                       // Reset the Section name.
   SetInitialSize (20, 20);                              // Set the init. size to 20 x 20.
   ClearControls  ();                                    // Clear the controls.
}


/////////////////////////////////////////////////////////////////////////////
// CAutoFillCtrl::~CAutoFillCtrl - Destructor

CAutoFillCtrl::~CAutoFillCtrl()
{
   ClearControls  ();                                    // Clear the controls.
}

/////////////////////////////////////////////////////////////////////////////
// CAutoFillCtrl::DoPropExchange - Persistence support

void CAutoFillCtrl::DoPropExchange(CPropExchange* pPX)
{
	ExchangeVersion(pPX, MAKELONG(_wVerMinor, _wVerMajor));
	COleControl::DoPropExchange(pPX);
}

/////////////////////////////////////////////////////////////////////////////
// CAutoFillCtrl::OnResetState - Reset control to default state

void CAutoFillCtrl::OnResetState()
{
	COleControl::OnResetState();                          // Resets defaults found in DoPropExchange
}

// ========================================================================
// =====        CAutoFillCtrl::OnDraw - Drawing function              =====                                                           =====
// ========================================================================

void CAutoFillCtrl::OnDraw(CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid)
{
   CBitmap  bitmap;                                      // BitMap to hold bitmap,
   CDC      dcDispMem;                                   // A DC in memory.

   bitmap.LoadBitmap (IDB_AUTOFILL);                     // Load the bitmap from Resources.
   dcDispMem.CreateCompatibleDC (pdc);                   // Create DC.
   dcDispMem.SelectObject (&bitmap);                     // Select the bitmap into DC.
   pdc->BitBlt (0,0,16,16,&dcDispMem,0,0,SRCCOPY);       // Put the icon on the Screen.
}

// ========================================================================
// =====        CAutoFillCtrl::Message Handlers Functions             =====                                                           =====
// ========================================================================

void CAutoFillCtrl::FileName(LPCTSTR FileName) 
{
   m_Filename = FileName;                                // Save the passed file name.
}

void CAutoFillCtrl::Section(LPCTSTR SectionName) 
{
   m_Section = SectionName;                              // Save the passed Section Name.
}

void CAutoFillCtrl::ClearControls() 
{
   for (int cnt = 0 ; cnt != 200 ; cnt++)                // Setup to loop thru all posible Ctrl.
      CtrlsID[cnt] = -1;                                 // Reset the Ctrl's value to -1 (Not Used)

   NumCtrls = 0;                                         // Reset the Control Count.
}

void CAutoFillCtrl::AddControl(short ControlID) 
{
   if (NumCtrls < 200)                                   // Check if New Control count < 200
      CtrlsID[NumCtrls++] = ControlID;                   // Yes Add the Control to array
   else                                                  // No Tell user to many controls.
     AfxMessageBox ("Only 200 Control may be added.",0,0);
}

void CAutoFillCtrl::OnLButtonUp(UINT nFlags, CPoint point) 
{
   if ((m_Filename != "" ) && (m_Section != ""))         // Check if the controll knows the section and file.
	   FillDialog();                                      // Fill the dialog's controls.

	COleControl::OnLButtonUp(nFlags, point);              // Handle Left button.
}

void CAutoFillCtrl::OnRButtonUp(UINT nFlags, CPoint point) 
{
   DWORD    Posn , nPosn;
   CString  Line , NewLine ;

   if ((m_Filename == "" ) || (m_Section == ""))         // Check if Filename And Section is valid.
   {
      COleControl::OnRButtonUp(nFlags, point);           // No Handle The Right mouse button.
      return ;                                           // Exit.
   }

   if ((Posn = FindSection (m_Filename , m_Section )) == -1 ) // Find the Position of Section.
   {
      CString  Error;                                    // Setup to display error message.
      Error.Format (" File Not Found \n %s ",m_Filename);// Load string with file name.
      AfxMessageBox (Error);                             // Display error.   
    	COleControl::OnRButtonUp(nFlags, point);           // Handle the right mouse button.
      return ;                                           // Exit.
   }
   else
   {
      NewLine.Format ("%05d ",1);                        // Load a string with line count of 1.
      nPosn = m_AFfile.Seek( Posn , CFile::begin );      // Gtoto the position where line count is.

      if (Posn == nPosn)                                 // Did it get there ?
         m_AFfile.Write(LPCTSTR (NewLine), 5 );          // Yes Write the line count tothe data file.

   m_AFfile.Close ();                                    // Close the file.
   }

	COleControl::OnRButtonUp(nFlags, point);              // Handle the right mouse button.
}

BOOL CAutoFillCtrl::FillDialog() 
{
   DWORD    Posn , nPosn;                                // The file position and New file position values.
   BOOL     ReadOK ;                                     // Read OK Flag.
   int      llc;                                         // Line counter.
   CString  Line , NewLine ;                             // String to line from file. And new line number.

   CWnd  *Wnd  = GetParent ();                           // Get the parent window where controls are.

   if ((m_Filename == "" ) || (m_Section == ""))         // Check if the filename & Section are known.
      return (FALSE);                                    // No. Exit and don't do any thing.

   if ((Posn = FindSection (m_Filename , m_Section )) == -1 ) // Open the file and find section.
      return (FALSE);                                    // File or section not found Exit and don't do any thing.     
   else
   {                                                     // File found and section was found.      
       ReadOK = m_AFfile.ReadString(Line);               // Get the Line Count from the file.
       llc = atoi (LPCTSTR ( Line ) );                   // get the line count into llc.

       for (int lc = 1 ; lc <= llc ; lc++)               // Setup to loop to the current line number.
       {
          ReadOK = m_AFfile.ReadString(Line);            // Read a line from the file (used line).
          if (Line.GetLength () == 0) break;             // If the line length is 0 reached end of section exit loop.
       } 
       
       if (Line.GetLength () > 0)                        // Check if the line length > 0
       {                                                 // Valid line.
          NewLine.Format ("%05d",llc+1);                 // Add 1 to the line counter.
          nPosn = m_AFfile.Seek( Posn , CFile::begin );  // Seek to Positon of line counter.
          if (Posn == nPosn)                             // Did it get there ?
          {
             m_AFfile.Write(LPCTSTR (NewLine), 5 );      // Yes write the new line number to file.
             m_AFfile.Close ();                          // whe have the line, Close the file.

             CString  retWord;                           // String to hold the field return from parser.

             for (int cnt = 0 ; cnt != NumCtrls ; cnt++) // Setup to read all the fields in line.
             {
                if (CtrlsID[cnt] != -1)                  // Check if the value of control is -1. (Not Used)
                {
                   CWnd  *cWnd = Wnd->GetDlgItem (CtrlsID[cnt]); // Get a pointer to CWnd for the control.
                   if (cWnd != NULL)                     // Check if valid window
                   {                                     // Yes !  Parse the string into fields
                      AfxExtractSubString (retWord , Line , cnt , ','); 

                      cWnd->SetFocus ();                 // Set the focus to the controls CWnd.
                      cWnd->SetWindowText (retWord);     // Load the window with the text from the field parser.
                   }
                }
             }                                           // Loop thru all the controls.
             return (TRUE);                              // Return when done.
          }
       }
   }
   m_AFfile.Close ();                                    // Close the file If end if data section.
   return  (FALSE);                                      // Return false 
}

// ========================================================================
// =====          Private Function to Find File Section.              =====                                                           =====
// ========================================================================

DWORD  CAutoFillCtrl::FindSection (CString  FileName , CString  SecName)
{
   BOOL     ReadOK;                                      // Flag for read line return.
   CString  Line ;                                       // String to store line from file.
   CString  Error;                                       // String to save error message in.

   CFileException e;                                     // File Exp handler.
                                                         // Open the File.
   if (!m_AFfile.Open (FileName, CFile::modeReadWrite | CFile::typeText , &e ) )
   {                                                     // Error openning the file.      
      Error.Format (" File Not Found \n %s ",FileName);  // Load the string with error message.
      AfxMessageBox (Error);                             // Tell the USer.
   }
   else                                                  // Else File open OK.
   {
      do                                                 // Setup to loop thru the file.
      {
         ReadOK = m_AFfile.ReadString(Line);             // Read a line from the file.
         if (ReadOK == TRUE)                             // Line read OK.
         {
            if (Line.GetLength() > 0)                    // Get the length of the line.   
            {                                            // If not a blank line 
               if (Line == "["+SecName+"]")              // Check if the line == the section name.
                  return (m_AFfile.GetPosition( ));      // Yes return the position into the file.
            }
         }
      }
      while (ReadOK == TRUE);                            // Read the whole file if needed.

      Error.Format (" Section Name not Found \n %s ",SecName); // Did not find the section name.
      AfxMessageBox (Error);                             // Tell the user.

      m_AFfile.Close ();                                 // Close the file.
   }
   return (-1);                                          // Return a -1 to indicate an error.
}


