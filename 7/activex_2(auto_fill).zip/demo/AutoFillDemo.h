// AutoFillDemo.h : main header file for the AUTOFILLDEMO application
//

#if !defined(AFX_AUTOFILLDEMO_H__73703085_146F_11D3_AA92_0080C81C2FF8__INCLUDED_)
#define AFX_AUTOFILLDEMO_H__73703085_146F_11D3_AA92_0080C81C2FF8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CAutoFillDemoApp:
// See AutoFillDemo.cpp for the implementation of this class
//

class CAutoFillDemoApp : public CWinApp
{
public:
	CAutoFillDemoApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAutoFillDemoApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CAutoFillDemoApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_AUTOFILLDEMO_H__73703085_146F_11D3_AA92_0080C81C2FF8__INCLUDED_)
