// AutoFillDemoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "AutoFillDemo.h"
#include "AutoFillDemoDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAutoFillDemoDlg dialog

CAutoFillDemoDlg::CAutoFillDemoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAutoFillDemoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAutoFillDemoDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CAutoFillDemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAutoFillDemoDlg)
	DDX_Control(pDX, IDC_AUTOFILLCTRL1, m_pAutoFill);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAutoFillDemoDlg, CDialog)
	//{{AFX_MSG_MAP(CAutoFillDemoDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAutoFillDemoDlg message handlers

BOOL CAutoFillDemoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
   m_pAutoFill.ClearControls ();
   m_pAutoFill.AddControl (IDC_NAME);
   m_pAutoFill.AddControl (IDC_ADDRESS1);
   m_pAutoFill.AddControl (IDC_ADDRESS2);
   m_pAutoFill.AddControl (IDC_CITY);
   m_pAutoFill.AddControl (IDC_STATE);

   m_pAutoFill.FileName   (".\\Debug\\TestFill.dat");
   m_pAutoFill.Section    ("Dialog1");
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}


void CAutoFillDemoDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CAutoFillDemoDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}
