// AutoFillDemoDlg.h : header file
//
//{{AFX_INCLUDES()
#include "autofill.h"
//}}AFX_INCLUDES

#if !defined(AFX_AUTOFILLDEMODLG_H__73703087_146F_11D3_AA92_0080C81C2FF8__INCLUDED_)
#define AFX_AUTOFILLDEMODLG_H__73703087_146F_11D3_AA92_0080C81C2FF8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CAutoFillDemoDlg dialog

class CAutoFillDemoDlg : public CDialog
{
// Construction
public:
	CAutoFillDemoDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CAutoFillDemoDlg)
	enum { IDD = IDD_AUTOFILLDEMO_DIALOG };
	CAutoFill	m_pAutoFill;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAutoFillDemoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CAutoFillDemoDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_AUTOFILLDEMODLG_H__73703087_146F_11D3_AA92_0080C81C2FF8__INCLUDED_)
