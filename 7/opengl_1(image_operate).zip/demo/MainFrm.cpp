/* ----------------------------------------------------------------------- *
 * M a i n F r m . c p p
 *
 * implementation of the CMainFrame class
 *
 * Copyright 1996 by Interface Technologies, Inc. All Rights Reserved.
 * GLSample2 Authored by N. Alan Oursland
 * ----------------------------------------------------------------------- */

#include "stdafx.h"
#include "GLSample2.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	
}

CMainFrame::~CMainFrame()
{
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
    m_strTitle="3-D illustration of the Polarize light ";
	cs.style &= ~(long) FWS_ADDTOTITLE;
	return CFrameWnd::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers


static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
};
int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_TOOLBAR1))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);
 if ( ! m_wndControlDlgBar.Create(this, IDD_DIALOGBAR1,
     CBRS_BOTTOM|CBRS_TOOLTIPS|CBRS_FLYBY, IDD_DIALOGBAR1) )
	{
		TRACE0("Failed to create dialog bar CViewAngleControlBar\n");
		return -1;		// fail to create
	}
 if ( ! m_wndControlDlgBar2.Create(this, IDD_DIALOGBAR2,
     CBRS_LEFT|CBRS_TOOLTIPS|CBRS_FLYBY, IDD_DIALOGBAR2) )
	{
		TRACE0("Failed to create dialog bar CViewAngleControlBar\n");
		return -1;		// fail to create
	}

//	m_wndControlDlgBar.EnableDocking(CBRS_ALIGN_BOTTOM );
//	DockControlBar(&m_wndControlDlgBar);
	((CSliderCtrl*)(m_wndControlDlgBar.GetDlgItem(IDC_SLIDER1)))->SetRange(0,360);
	((CSliderCtrl*)(m_wndControlDlgBar2.GetDlgItem(IDC_SLIDER3)))->SetRange(0,20);
	((CSliderCtrl*)(m_wndControlDlgBar2.GetDlgItem(IDC_SLIDER4)))->SetRange(0,20);

	return 0;
}
