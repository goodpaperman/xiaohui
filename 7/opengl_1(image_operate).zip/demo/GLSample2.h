/* ----------------------------------------------------------------------- *
 * G L S a m p l e 2 . h
 *
 * main header file for the GLSAMPLE2 application
 *
 * Copyright 1996 by Interface Technologies, Inc. All Rights Reserved.
 * GLSample2 Authored by N. Alan Oursland
 * ----------------------------------------------------------------------- */

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CGLSample2App:
// See GLSample2.cpp for the implementation of this class
//

class CGLSample2App : public CWinApp
{
public:
	CGLSample2App();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGLSample2App)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CGLSample2App)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////
