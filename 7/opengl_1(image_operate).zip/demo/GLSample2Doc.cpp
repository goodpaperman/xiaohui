/* ----------------------------------------------------------------------- *
 * G L S a m p l e 2 D o c . c p p
 *
 * implementation of the CGLSample2Doc class
 *
 * Copyright 1996 by Interface Technologies, Inc. All Rights Reserved.
 * GLSample2 Authored by N. Alan Oursland
 * ----------------------------------------------------------------------- */

#include "stdafx.h"
#include "GLSample2.h"

#include "GLSample2Doc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGLSample2Doc

IMPLEMENT_DYNCREATE(CGLSample2Doc, CDocument)

BEGIN_MESSAGE_MAP(CGLSample2Doc, CDocument)
	//{{AFX_MSG_MAP(CGLSample2Doc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGLSample2Doc construction/destruction

CGLSample2Doc::CGLSample2Doc()
{
	// TODO: add one-time construction code here

}

CGLSample2Doc::~CGLSample2Doc()
{
}

BOOL CGLSample2Doc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CGLSample2Doc serialization

void CGLSample2Doc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CGLSample2Doc diagnostics

#ifdef _DEBUG
void CGLSample2Doc::AssertValid() const
{
	CDocument::AssertValid();
}

void CGLSample2Doc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CGLSample2Doc commands
