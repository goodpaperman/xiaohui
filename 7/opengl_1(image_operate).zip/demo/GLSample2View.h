/* ----------------------------------------------------------------------- *
 * G L S a m p l e 2 V i e w . h
 *
 * interface of the CGLSample2View class
 *
 * Copyright 1996 by Interface Technologies, Inc. All Rights Reserved.
 * GLSample2 Authored by N. Alan Oursland
 * ----------------------------------------------------------------------- */
#include "..\base\Camera.h"
#include "..\base\PolarizeLight.h"

class CGLSample2View : public CView
{
protected: // create from serialization only
	HGLRC m_hGLContext;
	BOOL CreateViewGLContext(HDC hDC);
	int m_GLPixelIndex;
	BOOL SetWindowPixelFormat(HDC hDC);
	CGLSample2View();
	DECLARE_DYNCREATE(CGLSample2View)

// Attributes
public:
	CGLSample2Doc* GetDocument();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGLSample2View)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CGLSample2View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CGLSample2View)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnCameraPan();
	afx_msg void OnUpdateCameraPan(CCmdUI* pCmdUI);
	afx_msg void OnSELECTMODE();
	afx_msg void OnUpdateSELECTMODE(CCmdUI* pCmdUI);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnSceneRotate();
	afx_msg void OnUpdateSceneRotate(CCmdUI* pCmdUI);
	afx_msg void OnPaint();
	afx_msg void OnOrtho();
	afx_msg void OnUpdateOrtho(CCmdUI* pCmdUI);
	afx_msg void OnPerspective();
	afx_msg void OnUpdatePerspective(CCmdUI* pCmdUI);
	afx_msg void OnXView();
	afx_msg void OnYView();
	afx_msg void OnZView();
	afx_msg void OnFreeView();
	afx_msg void OnUpdateXView(CCmdUI* pCmdUI);
	afx_msg void OnUpdateYView(CCmdUI* pCmdUI);
	afx_msg void OnUpdateZView(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFreeView(CCmdUI* pCmdUI);
	afx_msg void OnShowCoordinateAxis();
	afx_msg void OnUpdateShowCoordinateAxis(CCmdUI* pCmdUI);
	afx_msg void OnReleasedcaptureSlider1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnReleasedcaptureSlider3(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnReleasedcaptureSlider4(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:

	//*********	here is our GL object,which will determine what our program do 
	CCamera    m_Camera;            //use to pan the scene 
    CScene     m_Scene;             //use to rotate the coordinate axis
	int        m_RotateAxis;        //determine the current rotate axis
	CPolarizeLightXZ* m_pPolarizeLight1;  //the PolarizeLight Object

	//********here is used to response to the user's action
	void CheckOrtho();              //Is it Ortho or Perspective Mode
	bool m_bBuildList;              //Has the DisplayList built,can speed up the display
	unsigned int ListID;            //DisplayList ID
	int m_Action;                   //determine what  going to do ,when the mouse move
	BOOL m_bShowCoordinateAxis;     //should we show the coordinate
	void SetViewMode();             //set X,Y,Z or Perspectiv view mode
	int m_ViewMode;                 //current view mode
	void InitOpenGL();              //initialize the necessary OpenGL environment
	float m_WHRatio;                //the ratio of the width and heigh of the window
	BOOL m_bOrtho;                  //current ortho mode
	CPoint m_OldPoint;              //save the previous mouse click point
};

#ifndef _DEBUG  // debug version in GLSample2View.cpp
inline CGLSample2Doc* CGLSample2View::GetDocument()
   { return (CGLSample2Doc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////
