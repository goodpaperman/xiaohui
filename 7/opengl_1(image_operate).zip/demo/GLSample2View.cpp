//------------------------------------------------------------------------
//       This is our main code about window

/* ----------------------------------------------------------------------- *
 * G L S a m p l e 2 V i e w . c p p 
 *
 * implementation of the CGLSample2View class
 *
 * Copyright 1996 by Interface Technologies, Inc. All Rights Reserved.
 * GLSample2 Authored by N. Alan Oursland
 * ----------------------------------------------------------------------- */

#include "stdafx.h"
#include "GLSample2.h"
#include "MainFrm.h"

#include "GLSample2Doc.h"
#include "GLSample2View.h"
#include <GL\glaux.h>
#include "..\base\CoordinateAxis.h"
#include "..\base\Geometry.h"
#include "..\base\Material.h"
#include "..\base\Ellipse.h"
#include "..\base\CommonFunc.h"
#include "..\base\Arrow.h"
#include "..\base\PolarizeLight.h"

#include <math.h>




#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//define the Action
#define CAMERA_PAN      0
#define SCENE_ROTATE    1
#define SELECT          9
//define the ViewMode
#define X_VIEW      1
#define Y_VIEW      2
#define Z_VIEW      3
#define FREE_VIEW   4
/////////////////////////////////////////////////////////////////////////////
// CGLSample2View

IMPLEMENT_DYNCREATE(CGLSample2View, CView)

BEGIN_MESSAGE_MAP(CGLSample2View, CView)
	//{{AFX_MSG_MAP(CGLSample2View)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_SIZE()
	ON_WM_TIMER()
	ON_WM_ERASEBKGND()
	ON_COMMAND(C_PAN, OnCameraPan)
	ON_UPDATE_COMMAND_UI(C_PAN, OnUpdateCameraPan)
	ON_COMMAND(SELECTMODE, OnSELECTMODE)
	ON_UPDATE_COMMAND_UI(SELECTMODE, OnUpdateSELECTMODE)
	ON_WM_MOUSEMOVE()
	ON_WM_KEYDOWN()
	ON_WM_LBUTTONDOWN()
	ON_WM_RBUTTONDOWN()
	ON_COMMAND(C_ROTATE, OnSceneRotate)
	ON_UPDATE_COMMAND_UI(C_ROTATE, OnUpdateSceneRotate)
	ON_WM_PAINT()
	ON_COMMAND(ID_ORTHO, OnOrtho)
	ON_UPDATE_COMMAND_UI(ID_ORTHO, OnUpdateOrtho)
	ON_COMMAND(ID_PERSPECTIVE, OnPerspective)
	ON_UPDATE_COMMAND_UI(ID_PERSPECTIVE, OnUpdatePerspective)
	ON_COMMAND(ID_X_VIEW, OnXView)
	ON_COMMAND(ID_Y_VIEW, OnYView)
	ON_COMMAND(ID_Z_VIEW, OnZView)
	ON_COMMAND(ID_FREE_VIEW, OnFreeView)
	ON_UPDATE_COMMAND_UI(ID_X_VIEW, OnUpdateXView)
	ON_UPDATE_COMMAND_UI(ID_Y_VIEW, OnUpdateYView)
	ON_UPDATE_COMMAND_UI(ID_Z_VIEW, OnUpdateZView)
	ON_UPDATE_COMMAND_UI(ID_FREE_VIEW, OnUpdateFreeView)
	ON_COMMAND(ID_SHOW_COORDINATE_AXIS, OnShowCoordinateAxis)
	ON_UPDATE_COMMAND_UI(ID_SHOW_COORDINATE_AXIS, OnUpdateShowCoordinateAxis)
	ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER1, OnReleasedcaptureSlider1)
	ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER3, OnReleasedcaptureSlider3)
	ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDER4, OnReleasedcaptureSlider4)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGLSample2View construction/destruction

CGLSample2View::CGLSample2View()
{   //here we initialize some member variable 
	m_hGLContext = NULL;
	m_GLPixelIndex = 0;
    m_Action=SELECT;
	m_RotateAxis=AXIS_Z;
	m_bBuildList=FALSE;
	m_bOrtho=FALSE;
	m_ViewMode=FREE_VIEW;
	m_bShowCoordinateAxis=TRUE;
	//create the Polarize Light object 
	m_pPolarizeLight1=new CPolarizeLightXZ(CVector(-2,0,0),CVector(0,0,0),1,0,2,2,40);
}

CGLSample2View::~CGLSample2View()
{
	delete m_pPolarizeLight1;     //delete polarize light object
}

BOOL CGLSample2View::PreCreateWindow(CREATESTRUCT& cs)
{
	cs.style |= (WS_CLIPCHILDREN | WS_CLIPSIBLINGS);
	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CGLSample2View drawing

void CGLSample2View::OnDraw(CDC* pDC)
{
	CGLSample2Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);


}

/////////////////////////////////////////////////////////////////////////////
// CGLSample2View diagnostics

#ifdef _DEBUG
void CGLSample2View::AssertValid() const
{
	CView::AssertValid();
}

void CGLSample2View::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CGLSample2Doc* CGLSample2View::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CGLSample2Doc)));
	return (CGLSample2Doc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CGLSample2View message handlers

BOOL CGLSample2View::SetWindowPixelFormat(HDC hDC)
{
	PIXELFORMATDESCRIPTOR pixelDesc;

	pixelDesc.nSize		= sizeof(PIXELFORMATDESCRIPTOR);
	pixelDesc.nVersion	= 1;

	pixelDesc.dwFlags	=PFD_DRAW_TO_WINDOW | 
						 PFD_SUPPORT_OPENGL |
	     				 PFD_STEREO_DONTCARE|
		    			 PFD_DOUBLEBUFFER;

	     

	pixelDesc.iPixelType		= PFD_TYPE_RGBA;
	pixelDesc.cColorBits		= 32;
	pixelDesc.cRedBits		= 8;
	pixelDesc.cRedShift		= 16;
	pixelDesc.cGreenBits		=8;
	pixelDesc.cGreenShift		=8;
	pixelDesc.cBlueBits		= 8;
	pixelDesc.cBlueShift		= 0;
	pixelDesc.cAlphaBits		= 0;
	pixelDesc.cAlphaShift		= 0;
	pixelDesc.cAccumBits		= 64;	
	pixelDesc.cAccumRedBits		= 16;
	pixelDesc.cAccumGreenBits	= 16;
	pixelDesc.cAccumBlueBits	= 16;
	pixelDesc.cAccumAlphaBits	= 0;
	pixelDesc.cDepthBits		= 32;
	pixelDesc.cStencilBits		= 8;
	pixelDesc.cAuxBuffers		= 0;
	pixelDesc.iLayerType		= PFD_MAIN_PLANE;
	pixelDesc.bReserved		= 0;
	pixelDesc.dwLayerMask		= 0;
	pixelDesc.dwVisibleMask		= 0;
	pixelDesc.dwDamageMask		= 0;

	m_GLPixelIndex = ChoosePixelFormat( hDC, &pixelDesc);
	if (m_GLPixelIndex==0) // Let's choose a default index.
	{
		m_GLPixelIndex = 1;	
		if (DescribePixelFormat(hDC, 
						m_GLPixelIndex, 
						sizeof(PIXELFORMATDESCRIPTOR), 
						&pixelDesc)==0)
		{
			return FALSE;
		}
	}

	if (SetPixelFormat( hDC, 
				  m_GLPixelIndex, 
				  &pixelDesc)==FALSE)
	{
		return FALSE;
	}

	return TRUE;
}

int CGLSample2View::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	

	HWND hWnd = GetSafeHwnd();
	HDC hDC = ::GetDC(hWnd);

	if (SetWindowPixelFormat(hDC)==FALSE)
		return 0;
	
	if (CreateViewGLContext(hDC)==FALSE)
		return 0;
	
	SetTimer(0,100,NULL);   //set the timer to make animation
	return 0;
}

BOOL CGLSample2View::CreateViewGLContext(HDC hDC)
{
	m_hGLContext = wglCreateContext(hDC);
	if (m_hGLContext == NULL)
	{
		return FALSE;
	}

	if (wglMakeCurrent(hDC, m_hGLContext)==FALSE)
	{
		return FALSE;
	}

	return TRUE;
}

void CGLSample2View::OnDestroy() 
{
	if(wglGetCurrentContext()!=NULL) 
	{
		// make the rendering context not current
		wglMakeCurrent(NULL, NULL) ;
	}
	
	if (m_hGLContext!=NULL)
	{
		wglDeleteContext(m_hGLContext);
		m_hGLContext = NULL;
	}

	// Now the associated DC can be released.
	CView::OnDestroy(); 
}

void CGLSample2View::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	GLsizei width, height;
	GLdouble aspect;
    
	width = cx;
	height = cy;

	if (cy==0)
		aspect = (GLdouble)width;
	else
		aspect = (GLdouble)width/(GLdouble)height;
    
	m_WHRatio=aspect;    //save it for further use.

	glViewport(0, 0, width, height);

    InitOpenGL();       //initialize the GL environment

}



void CGLSample2View::OnTimer(UINT nIDEvent) 
{
	CView::OnTimer(nIDEvent);
	
	Invalidate();        //redraw the scene to make animation
}


//override the  virtual function to prevent the window redraw the window client
BOOL CGLSample2View::OnEraseBkgnd(CDC* pDC) 
{
	return FALSE;   //direct return without call the default action;
}

void CGLSample2View::OnCameraPan() 
{
	  m_Action=CAMERA_PAN;     //when click the CameraPan menu item ,set the current action variable
}

//update the menu status
void CGLSample2View::OnUpdateCameraPan(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_Action==CAMERA_PAN);      
    pCmdUI->Enable(m_ViewMode==FREE_VIEW);

}

void CGLSample2View::OnSELECTMODE() 
{
     m_Action=SELECT;      
}

void CGLSample2View::OnUpdateSELECTMODE(CCmdUI* pCmdUI) 
{
     pCmdUI->SetCheck(m_Action==SELECT);
     pCmdUI->Enable(m_ViewMode==FREE_VIEW);
	
}

//according what is the action now ,we do something 
void CGLSample2View::OnMouseMove(UINT nFlags, CPoint point) 
{   
    if(nFlags==MK_LBUTTON)
	{int rx=point.x-m_OldPoint.x;
	 int ry=point.y-m_OldPoint.y;
		switch(m_Action)
		{ case CAMERA_PAN:
		       m_Camera.Offset(rx/100.0,-ry/100.0,0);    //pan the scene
			   break;        
		  case SCENE_ROTATE:
			   m_Scene.RotateRoundAxis(rx/10,m_RotateAxis);  //rotate round the axis
			   break;
		}
     m_OldPoint=point;
	 Invalidate();
	}
    if(nFlags==MK_RBUTTON)
	{int rx=point.x-m_OldPoint.x;
		switch(m_Action)
		{ case CAMERA_PAN:
		       m_Camera.Offset(0,0,rx/100.0);
			   break;
		}
     m_OldPoint=point;
	 Invalidate();
	}

	CView::OnMouseMove(nFlags, point);
}

void CGLSample2View::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	if(nChar==VK_TAB&&m_Action==SCENE_ROTATE)      
		 m_RotateAxis=(m_RotateAxis+1)%3;                //alternate the rotate axis

	CView::OnKeyDown(nChar, nRepCnt, nFlags);
}

void CGLSample2View::OnLButtonDown(UINT nFlags, CPoint point) 
{
	m_OldPoint=point;
	CView::OnLButtonDown(nFlags, point);
}

void CGLSample2View::OnRButtonDown(UINT nFlags, CPoint point) 
{
	m_OldPoint=point;
	CView::OnRButtonDown(nFlags, point);
}

void CGLSample2View::OnSceneRotate() 
{   m_Action=SCENE_ROTATE;
}

void CGLSample2View::OnUpdateSceneRotate(CCmdUI* pCmdUI) 
{     
      pCmdUI->SetCheck(m_Action==SCENE_ROTATE);
      pCmdUI->Enable(m_ViewMode==FREE_VIEW);

}



void CGLSample2View::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
		glLoadIdentity();
     glClearColor(0.5,0.5,0.5,1);
		glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
	
	CheckOrtho();
    SetViewMode();
    CMaterial().Apply();

/*    if(!m_bBuildList)
    {   
		glNewList(ListID,GL_COMPILE);
        
		 //  We can put some draw code here to speed up the drawing 
		 //  But in this case ,we don't use it for our drawing is varing.
		 //  In my other code ,I depend on it,so I reserve it here for further use
	    
		
		glEndList();
		m_bBuildList=TRUE;
	}
    glCallList(ListID);
 */ 
	//The main drawing of this program ,you can replace it with any othere drawing here.
	m_pPolarizeLight1->Display();  //drawing the object.
    
	//drawing the coodinate axis.
    if(m_bShowCoordinateAxis)
	{	glDisable(GL_DEPTH_TEST);       
		CCoordinateAxis(2,2,2).Display();
    	glEnable(GL_DEPTH_TEST);
	}
   
    //we should use this to avoid the flash on the screen.
	SwapBuffers(dc.m_ps.hdc);
	
}

//when click the ortho menu item
void CGLSample2View::OnOrtho()   
{
	if(m_bOrtho)
		return;
	else
	{m_bOrtho=TRUE;
	Invalidate();
	}
	
}

void CGLSample2View::OnUpdateOrtho(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_bOrtho);
}

void CGLSample2View::OnPerspective() 
{
	if(!m_bOrtho)
		return;
	else
	{m_bOrtho=FALSE;
	Invalidate();
	}

}

void CGLSample2View::OnUpdatePerspective(CCmdUI* pCmdUI) 
{
     pCmdUI->SetCheck(!m_bOrtho);

}

//do some initialization for the OpenGL
void CGLSample2View::InitOpenGL()
{	glColorMaterial(GL_FRONT,GL_DIFFUSE);
	glEnable(GL_COLOR_MATERIAL);
	glEnable(GL_LINE_SMOOTH);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
    glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);

	glDepthFunc(GL_LESS);
	glEnable(GL_DEPTH_TEST);
}

//X-VIEW Mode
void CGLSample2View::OnXView() 
{    
	m_ViewMode=X_VIEW;
	m_bOrtho=TRUE;
	Invalidate();
}

void CGLSample2View::OnYView() 
{
	m_ViewMode=Y_VIEW;
	m_bOrtho=TRUE;
	Invalidate();
	
}

void CGLSample2View::OnZView() 
{
	m_ViewMode=Z_VIEW;
	m_bOrtho=TRUE;
    Invalidate();
	
}

void CGLSample2View::OnFreeView() 
{
	m_ViewMode=FREE_VIEW;
	m_bOrtho=FALSE;
    Invalidate();
	
}

void CGLSample2View::OnUpdateXView(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_ViewMode==X_VIEW);

}

void CGLSample2View::OnUpdateYView(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_ViewMode==Y_VIEW);
	
}

void CGLSample2View::OnUpdateZView(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_ViewMode==Z_VIEW);
	
}

void CGLSample2View::OnUpdateFreeView(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_ViewMode==FREE_VIEW);
	
}

//set the viewmode in the OpenGL
void CGLSample2View::SetViewMode()
{
    glMatrixMode(GL_MODELVIEW);
	switch(m_ViewMode)
	{case X_VIEW:
        gluLookAt(100,0,0,0,0,0,0,0,1);
		break;
	case Y_VIEW:
		gluLookAt(0,100,0,0,0,0,0,0,1);
		break;
	case Z_VIEW:
		gluLookAt(0,0,100,0,0,0,0,1,0);
		break;
	case FREE_VIEW:
        m_Camera.Apply();                //set the camera transfer matrix
        gluLookAt(5,5,2,0,0,0,0,0,1);    //the initial view angle
        m_Scene.Apply();                 //set scene transfer matrix ,which I use as coordinate 
		break;
	}
}

//set ortho or perspective mode
void CGLSample2View::CheckOrtho()
{
	if(!m_bOrtho)
	{
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(35,m_WHRatio,1,1000);
	glMatrixMode(GL_MODELVIEW);
	}
	else
	{
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
    glOrtho(-3*m_WHRatio,3*m_WHRatio,-3,3,-1000,1000);
	glMatrixMode(GL_MODELVIEW);
	}
}

void CGLSample2View::OnShowCoordinateAxis() 
{
	m_bShowCoordinateAxis=!m_bShowCoordinateAxis;
	Invalidate();
}

void CGLSample2View::OnUpdateShowCoordinateAxis(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_bShowCoordinateAxis);
}

//set the properties of the polarize light
void CGLSample2View::OnReleasedcaptureSlider1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	CDialogBar* Bar=&(((CMainFrame*)AfxGetMainWnd())->m_wndControlDlgBar);
	CSliderCtrl* pSlider=(CSliderCtrl*)(Bar->GetDlgItem(IDC_SLIDER1));
	int pos=pSlider->GetPos();
	m_pPolarizeLight1->SetPhase(pos);
	CStatic* pDcree=(CStatic*)Bar->GetDlgItem(IDC_DCREE);
	char buffer[255];
	pDcree->SetWindowText(itoa(pos,buffer,10));
	*pResult = 0;
}
void CGLSample2View::OnReleasedcaptureSlider3(NMHDR* pNMHDR, LRESULT* pResult) 
{
	CDialogBar* Bar=&(((CMainFrame*)AfxGetMainWnd())->m_wndControlDlgBar2);
	CSliderCtrl* pSlider=(CSliderCtrl*)(Bar->GetDlgItem(IDC_SLIDER3));
	int pos=pSlider->GetPos();
	m_pPolarizeLight1->SetA1((20-pos)/10.0);
	*pResult = 0;
}
void CGLSample2View::OnReleasedcaptureSlider4(NMHDR* pNMHDR, LRESULT* pResult) 
{
	CDialogBar* Bar=&(((CMainFrame*)AfxGetMainWnd())->m_wndControlDlgBar2);
	CSliderCtrl* pSlider=(CSliderCtrl*)(Bar->GetDlgItem(IDC_SLIDER4));
	int pos=pSlider->GetPos();
	m_pPolarizeLight1->SetA2((20-pos)/10.0);
	*pResult = 0;
}
