/* ----------------------------------------------------------------------- *
 * stdafx.cpp
 *
 * source file that includes just the standard includes     
 * GLSample2.pch will be the pre-compiled header            
 * stdafx.obj will contain the pre-compiled type information
 *
 * Copyright 1996 by Interface Technologies, Inc. All Rights Reserved.
 * GLSample2 Authored by N. Alan Oursland
 * ----------------------------------------------------------------------- */

#include "stdafx.h"

