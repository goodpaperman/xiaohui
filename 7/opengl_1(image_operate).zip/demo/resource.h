//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by GLSample2.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_DIALOGBAR                   103
#define IDD_DIALOGBAR2                  103
#define IDD_DIALOGBAR1                  104
#define IDR_MAINFRAME                   128
#define IDR_GLSAMPTYPE                  129
#define IDR_TOOLBAR1                    134
#define IDC_SLIDER1                     1004
#define IDC_DCREE                       1005
#define IDC_SLIDER4                     1006
#define IDC_SLIDER3                     1007
#define C_PAN                           32771
#define SELECTMODE                      32772
#define C_ROTATE                        32773
#define ID_ORTHO                        32778
#define ID_PERSPECTIVE                  32779
#define ID_X_VIEW                       32780
#define ID_Y_VIEW                       32781
#define ID_Z_VIEW                       32782
#define ID_FREE_VIEW                    32783
#define ID_SHOW_COORDINATE_AXIS         32788

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        141
#define _APS_NEXT_COMMAND_VALUE         32789
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
