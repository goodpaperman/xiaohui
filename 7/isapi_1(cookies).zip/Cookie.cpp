// Cookie.cpp: implementation of the CCookie class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Cookie.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCookie::CCookie(CHttpServer* pServer, CHttpServerContext* pCtxt)
{
	m_pCtxt=pCtxt;
	m_pServer=pServer;
	m_IsExtension=true;
}
CCookie::CCookie(CHttpFilter* pFilter, CHttpFilterContext* pCtxt)
{
	m_pFCtxt=pCtxt;
	m_pFilter=pFilter;
	m_IsExtension=false;
}

CCookie::~CCookie()
{

}

int CCookie::EnumCookies(CStringArray &CookieNames, CStringArray &CookieValues)
{
	DWORD BuffSize=2048;
	void* Buffer=malloc(BuffSize);
	int CookiesFound=0; 
	if (m_IsExtension)
		m_pCtxt->GetServerVariable("ALL_HTTP",Buffer,&BuffSize);	// This will get all the parts of the header 
	else											        // that are not available using any other server variables.
		m_pFCtxt->GetServerVariable("ALL_HTTP",Buffer,&BuffSize);

	char* BuffAt=strtok((char*)Buffer, "\n");				// Find the first line feed (field seperator in header)
	
	char FoundName[256];
	char FoundValue[256];
	while (BuffAt)
	{
		if (strncmp("HTTP_COOKIE",BuffAt,11)==0)			// Is the current field a cookie?
		{
			BuffAt+=12;										// It Is!  Advance past HTTP_COOKIE (should be just past ':')
			int charat=0;
			while (true) //Loop through all cookies in this line
			{
				while (*BuffAt==' ')
				    BuffAt++;

				while (*BuffAt!='=')							// Get the cookie name (terminated by a '=')
				{
					FoundName[charat]=*BuffAt;
					BuffAt++;
					charat++;
				}
				FoundName[charat]='\0';
				BuffAt++;							//Advance over =
				charat=0;
				while (*BuffAt!='\n' && *BuffAt!=';' && (BuffAt<((char*)Buffer)+BuffSize))							// Now that we've got the cookie's name, let's get it's value
				{
					FoundValue[charat]=*BuffAt;
					BuffAt++;
					charat++;
				}
				FoundValue[charat]='\0';
				charat=0;
				BuffAt++;
			//	if (*BuffAt==' ')
			//		BuffAt++;

				CookieNames.Add(FoundName);
				CookieValues.Add(FoundValue);
				CookiesFound++;

				if (*(BuffAt-1)==';')
					continue;

				break;
			}

			
		}
			
		BuffAt=strtok(NULL,"\n");							// Ok, wasn't it.  Let's continue looking through the HTTP
															// header for another one.

		if (BuffAt>((char*)Buffer)+BuffSize)		// This line really shouldn't be necessary.
			break;								// I put it there because I'm paranoid...
	}
	free(Buffer);	
	return CookiesFound;

}

BOOL CCookie::GetCookie(LPCTSTR CookieName, CString &CookieValue)
{
	
	// Returns TRUE if cookie was found, with it's value in CookieValue.
	// Returns FALSE if cookie WAS NOT found.
	
	CStringArray Names;
	CStringArray Values;

	int Count=EnumCookies(Names, Values);
	for (int i=0; i<Count; i++)
	{
		CString ThisName=Names.GetAt(i);
		if (ThisName==CookieName)
		{
			CookieValue=Values.GetAt(i);
			return true;
		}
	}

	
	return false;


}

void CCookie::SetCookie(LPCTSTR CookieName, LPCTSTR CookieVal, BOOL SendOnlyWhenSecure)
{
		ISAPIASSERT(m_IsExtension);

		CString AddlHeader;
		AddlHeader.Format("Set-Cookie: %s=%s; path=/%s\r\n",CookieName, CookieVal, SendOnlyWhenSecure ? "; secure" : "");  //Construct the string we'll add to the header
		m_pServer->AddHeader(m_pCtxt,AddlHeader);
}

void CCookie::SetCookie(LPCTSTR CookieName, LPCTSTR CookieVal, CTime Expiration, BOOL SendOnlyWhenSecure)
{
	// Use this version if you want a cookie that has an expiration date
	// (those w/o exp dates will expire when the user closes their browser...)
	ISAPIASSERT(m_IsExtension);
	tm	ExpTime;
	Expiration.GetGmtTm(&ExpTime);
	char	DOWLkup[]="Sun\0Mon\0Tue\0Wed\0Thu\0Fri\0Sat\0";
	char	MonthLkup[]="Jan\0Feb\0Mar\0Apr\0May\0Jun\0Jul\0Aug\0Sep\0Oct\0Nov\0Dec\0";
	char	DOW[5];
	char	Mon[5];
	strcpy(DOW, DOWLkup+(ExpTime.tm_wday*4));
	strcpy(Mon, MonthLkup+(ExpTime.tm_mon*4));
	
	CString exp;
	exp.Format("%s, %02i-%s-%04i %02i:%02i:%02i GMT",DOW,ExpTime.tm_mday,Mon,ExpTime.tm_year+1900,ExpTime.tm_hour,ExpTime.tm_min,ExpTime.tm_sec);
	CString AddlHeader;
	AddlHeader.Format("Set-Cookie: %s=%s; expires=%s; path=/%s\r\n\r\n",CookieName, CookieVal, exp, SendOnlyWhenSecure ? "; secure" : "");  //Construct the string we'll add to the header
	if (m_IsExtension)
		m_pServer->AddHeader(m_pCtxt,AddlHeader);
	else
	{
		char HdrChar[1024];
		strcpy(HdrChar,AddlHeader);

		m_pFCtxt->AddResponseHeaders(HdrChar,0);
	}

	


	


}
