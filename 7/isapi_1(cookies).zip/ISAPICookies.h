#if !defined(AFX_ISAPICOOKIES_H__6458B26A_CEA0_11D3_9513_0090271B3880__INCLUDED_)
#define AFX_ISAPICOOKIES_H__6458B26A_CEA0_11D3_9513_0090271B3880__INCLUDED_

// ISAPICOOKIES.H - Header file for your Internet Server
//    ISAPICookies Extension

#include "resource.h"

class CISAPICookiesExtension : public CHttpServer
{
public:
	void SetACookie(CHttpServerContext* pCtxt, void* pVoid, DWORD dwBytes);
	void CookieForm(CHttpServerContext *pCtxt);
	CISAPICookiesExtension();
	~CISAPICookiesExtension();
	void ShowCookies(CHttpServerContext* pCtxt);
// Overrides
	// ClassWizard generated virtual function overrides
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//{{AFX_VIRTUAL(CISAPICookiesExtension)
	public:
	virtual BOOL GetExtensionVersion(HSE_VERSION_INFO* pVer);
	//}}AFX_VIRTUAL
	virtual BOOL TerminateExtension(DWORD dwFlags);

	// TODO: Add handlers for your commands here.
	// For example:

	void Default(CHttpServerContext* pCtxt);

	DECLARE_PARSE_MAP()

	//{{AFX_MSG(CISAPICookiesExtension)
	//}}AFX_MSG
};


//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ISAPICOOKIES_H__6458B26A_CEA0_11D3_9513_0090271B3880__INCLUDED)
