// Cookie.h: interface for the CCookie class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_COOKIE_H__8AFB613B_CF68_11D3_9515_0090271B3880__INCLUDED_)
#define AFX_COOKIE_H__8AFB613B_CF68_11D3_9515_0090271B3880__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CCookie  
{
public:
	BOOL m_IsExtension;
	void SetCookie(LPCTSTR CookieName, LPCTSTR CookieVal, CTime Expiration, BOOL SendOnlyWhenSecure=false);
	CHttpServer* m_pServer;
	CHttpServerContext* m_pCtxt;
	CHttpFilter* m_pFilter;
	CHttpFilterContext* m_pFCtxt;
	CCookie(CHttpServer* pServer,CHttpServerContext *pCtxt);
	CCookie(CHttpFilter* pServer,CHttpFilterContext *pCtxt);
	int EnumCookies(CStringArray &CookieNames, CStringArray &CookieValues);
	BOOL GetCookie(LPCTSTR CookieName, CString &CookieValue);
	void SetCookie(LPCTSTR CookieName, LPCTSTR CookieVal, BOOL SendOnlyWhenSecure=false);
	virtual ~CCookie();

};

#endif // !defined(AFX_COOKIE_H__8AFB613B_CF68_11D3_9515_0090271B3880__INCLUDED_)
