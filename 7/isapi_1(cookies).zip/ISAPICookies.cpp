// ISAPICOOKIES.CPP - Implementation file for your Internet Server
//    ISAPICookies Extension


#include "stdafx.h"
#include "ISAPICookies.h"
#include "Cookie.h"
#define HOSTADDR  "http://localhost/ISAPICookies.dll"

///////////////////////////////////////////////////////////////////////
// The one and only CWinApp object
// NOTE: You may remove this object if you alter your project to no
// longer use MFC in a DLL.

CWinApp theApp;

///////////////////////////////////////////////////////////////////////
// command-parsing map

BEGIN_PARSE_MAP(CISAPICookiesExtension, CHttpServer)
	// TODO: insert your ON_PARSE_COMMAND() and 
	// ON_PARSE_COMMAND_PARAMS() here to hook up your commands.
	// For example:

	ON_PARSE_COMMAND(ShowCookies, CISAPICookiesExtension, ITS_EMPTY)
	ON_PARSE_COMMAND(CookieForm,  CISAPICookiesExtension, ITS_EMPTY)
	ON_PARSE_COMMAND(SetACookie, CISAPICookiesExtension, ITS_RAW)
	ON_PARSE_COMMAND(Default, CISAPICookiesExtension, ITS_EMPTY)
	DEFAULT_PARSE_COMMAND(Default, CISAPICookiesExtension)
END_PARSE_MAP(CISAPICookiesExtension)


///////////////////////////////////////////////////////////////////////
// The one and only CISAPICookiesExtension object

CISAPICookiesExtension theExtension;


///////////////////////////////////////////////////////////////////////
// CISAPICookiesExtension implementation

CISAPICookiesExtension::CISAPICookiesExtension()
{
}

CISAPICookiesExtension::~CISAPICookiesExtension()
{
}

BOOL CISAPICookiesExtension::GetExtensionVersion(HSE_VERSION_INFO* pVer)
{
	// Call default implementation for initialization
	CHttpServer::GetExtensionVersion(pVer);

	// Load description string
	TCHAR sz[HSE_MAX_EXT_DLL_NAME_LEN+1];
	ISAPIVERIFY(::LoadString(AfxGetResourceHandle(),
			IDS_SERVER, sz, HSE_MAX_EXT_DLL_NAME_LEN));
	_tcscpy(pVer->lpszExtensionDesc, sz);
	return TRUE;
}

BOOL CISAPICookiesExtension::TerminateExtension(DWORD dwFlags)
{
	// extension is being terminated
	//TODO: Clean up any per-instance resources
	return TRUE;
}

///////////////////////////////////////////////////////////////////////
// CISAPICookiesExtension command handlers

void CISAPICookiesExtension::Default(CHttpServerContext* pCtxt)
{
	StartContent(pCtxt);
	WriteTitle(pCtxt);

	*pCtxt << _T("This default message was produced by the Internet");
	*pCtxt << _T(" Server DLL Wizard. Edit your CISAPICookiesExtension::Default()");
	*pCtxt << _T(" implementation to change it.\r\n");

	*pCtxt << "<BR><BR><a href=";
	*pCtxt << HOSTADDR;
	*pCtxt << "?CookieForm>Click Here to Set A Cookie</a href>";

	

	EndContent(pCtxt);
}







void CISAPICookiesExtension::ShowCookies(CHttpServerContext* pCtxt)
{
	CStringArray CookieNames;
	CStringArray CookieValues;
	CCookie	Cookie(this,pCtxt);

	StartContent(pCtxt);
	int CookieCount=Cookie.EnumCookies(CookieNames, CookieValues);
	CString tmp;
	tmp.Format("Cookies Found: %i<BR>",CookieCount);
	*pCtxt << tmp;

	for (int i=0; i<CookieCount; i++)
	{
		
			*pCtxt << "Cookie: ";
			*pCtxt << CookieNames.GetAt(i);
			*pCtxt << " = ";
			*pCtxt << CookieValues.GetAt(i);
			*pCtxt << "<BR>";
	}
	return;


}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CISAPICookiesExtension, CHttpServer)
	//{{AFX_MSG_MAP(CISAPICookiesExtension)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0



///////////////////////////////////////////////////////////////////////
// If your extension will not use MFC, you'll need this code to make
// sure the extension objects can find the resource handle for the
// module.  If you convert your extension to not be dependent on MFC,
// remove the comments arounn the following AfxGetResourceHandle()
// and DllMain() functions, as well as the g_hInstance global.

/****

static HINSTANCE g_hInstance;

HINSTANCE AFXISAPI AfxGetResourceHandle()
{
	return g_hInstance;
}

BOOL WINAPI DllMain(HINSTANCE hInst, ULONG ulReason,
					LPVOID lpReserved)
{
	if (ulReason == DLL_PROCESS_ATTACH)
	{
		g_hInstance = hInst;
	}

	return TRUE;
}

****/

void CISAPICookiesExtension::CookieForm(CHttpServerContext *pCtxt)
{
	StartContent(pCtxt);
	*pCtxt << "<form method=\"post\" action=\"";
	*pCtxt << HOSTADDR;
    *pCtxt << "?SetACookie\">";
	*pCtxt << "<p>Cookie Name: <input type=\"text\" name=\"Name\"> </p> <p>Cookie Value: <input type=\"text\" name=\"Value\"></p>";
	*pCtxt << "<input type=\"submit\" name=\"Submit\" value=\"Submit\">";
	*pCtxt << "</form>";
	

	EndContent(pCtxt);

}

void CISAPICookiesExtension::SetACookie(CHttpServerContext *pCtxt, void* pVoid, DWORD dwBytes)
{

	char* TokenAt;

	TokenAt=strtok((char*)pVoid,"=&");  // Here we'll get something like: Name=CookieName&Value=CookieValue&Submit=Submit
	CString VarName1=(char*)pVoid;		// Let's parse it
	TokenAt=strtok(NULL, "=&");
	CString Name=TokenAt;
	TokenAt=strtok(NULL, "=&");
	CString VarName2=TokenAt;
	TokenAt=strtok(NULL, "=&");
	CString Value=TokenAt;


	CCookie cookie(this, pCtxt);
	cookie.SetCookie(Name, Value);

//	StartContent(pCtxt);
	*pCtxt << "A Cookie Has Been Set!<BR>";
	*pCtxt << "Cookie Name: ";
	*pCtxt << Name;
	*pCtxt << "<BR>";
	*pCtxt << "Cookie Value: ";
	*pCtxt << Value;
	*pCtxt << "<BR>";
	*pCtxt << "<a href=\"";
	*pCtxt << HOSTADDR;
	*pCtxt << "?ShowCookies\">Show Cookies</a href>";
//	EndContent(pCtxt);

}


