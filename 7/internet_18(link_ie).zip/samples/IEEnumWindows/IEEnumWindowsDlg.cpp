// IEEnumWindowsDlg.cpp : implementation file
//

#include "stdafx.h"
#include "IEEnumWindows.h"
#include "IEEnumWindowsDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CIEEnumWindowsDlg dialog

CIEEnumWindowsDlg::CIEEnumWindowsDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CIEEnumWindowsDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CIEEnumWindowsDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	//
	// @Sample 
	// Enables CCmdTarget for event listner
	EnableConnections();
	EnableAutomation();
}

void CIEEnumWindowsDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIEEnumWindowsDlg)
	DDX_Control(pDX, IDC_INFO, m_Info);
	DDX_Control(pDX, IDC_LIST1, m_List);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CIEEnumWindowsDlg, CDialog)
	//{{AFX_MSG_MAP(CIEEnumWindowsDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_LBN_DBLCLK(IDC_LIST1, OnDblclkIEList)
	ON_BN_CLICKED(IDC_ACTIVATE, OnActivate)
	ON_BN_CLICKED(IDC_VS, OnVs)
	ON_LBN_SELCHANGE(IDC_LIST1, OnSelchangeList1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CIEEnumWindowsDlg message handlers

BOOL CIEEnumWindowsDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here

	SetWindowPos(CWnd::FromHandle(HWND_TOPMOST),0,0,0,0,SWP_NOMOVE|SWP_NOSIZE);

	ConnectToShell();
	OnOK();

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CIEEnumWindowsDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CIEEnumWindowsDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CIEEnumWindowsDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


//
// @Sample 
// Follwing entries allowes, CCmdTarget to invoke call back function when it notified
//	
BEGIN_DISPATCH_MAP(CIEEnumWindowsDlg, CCmdTarget)
	DISP_FUNCTION_ID(CIEEnumWindowsDlg, "WindowRegistered",0x000000c8,WindowRegistered,VT_EMPTY,VTS_I4)
	DISP_FUNCTION_ID(CIEEnumWindowsDlg, "WindowRevoked",0x000000c9,WindowRevoked,VT_EMPTY,VTS_I4)
END_DISPATCH_MAP()

/* I copied this from shdocvw.dll
dispinterface DShellWindowsEvents {
        properties:
        methods:
            [id(0x000000c8), helpstring("A new window was registered.")]
            void WindowRegistered([in] long lCookie);
            [id(0x000000c9), helpstring("A new window was revoked.")]
            void WindowRevoked([in] long lCookie);
    };
*/

static SHDocVw::IShellWindowsPtr m_spSHWinds; 

void CIEEnumWindowsDlg::ConnectToShell() {
	CoInitialize(NULL);

	if(m_spSHWinds == 0) {
		//
		// Create Instance ShellWindows
		//
		if(m_spSHWinds.CreateInstance(__uuidof(SHDocVw::ShellWindows)) == S_OK) {

			//
			// Sink for Events
			//
			LPCONNECTIONPOINTCONTAINER pConnPtCont;

			if ((m_spSHWinds != NULL) &&
				SUCCEEDED(m_spSHWinds->QueryInterface(IID_IConnectionPointContainer,
					(LPVOID*)&pConnPtCont)))
			{
				ASSERT(pConnPtCont != NULL);
				LPCONNECTIONPOINT pConnPt = NULL;
				DWORD dwCookie = 0;

				if (SUCCEEDED(pConnPtCont->FindConnectionPoint(__uuidof(SHDocVw::DShellWindowsEvents), &pConnPt)))
				{
					ASSERT(pConnPt != NULL);
					pConnPt->Advise( GetIDispatch(FALSE), &dwCookie);
					pConnPt->Release();
				}

				pConnPtCont->Release();
			}
		}
		else {
			AfxMessageBox("Shell Windows interface is not avilable");
		}
	}
}

void CIEEnumWindowsDlg::WindowRegistered(long lCookie) {
	OnOK() ;
}

void CIEEnumWindowsDlg::WindowRevoked(long lCookie) {
	OnOK() ;
}

void CIEEnumWindowsDlg::OnOK() 
{
	// TODO: Add extra validation here

	m_List.ResetContent();

	IDispatchPtr spDisp;
	long nCount = m_spSHWinds->GetCount();
	
	//
	// Enum all Shell Windows and list them
	//
	for (long i = 0; i < nCount; i++)
	{
		_variant_t va(i, VT_I4);
		spDisp = m_spSHWinds->Item(va);

		SHDocVw::IWebBrowser2Ptr spBrowser(spDisp);
		if (spBrowser != NULL)
		{
			_bstr_t str = spBrowser->GetLocationName();
			int index = m_List.AddString(str);
			spBrowser->AddRef();
			m_List.SetItemDataPtr(index,spBrowser);

		}
	}
}

//
// bring selected IE to front
//
void CIEEnumWindowsDlg::OnDblclkIEList() 
{
	// TODO: Add your control notification handler code here
	int index = m_List.GetCurSel();
	if(index != CB_ERR) {
		IWebBrowser2 *pBrowser = (IWebBrowser2 *)m_List.GetItemDataPtr(index);
		if(pBrowser) {
			HWND hWnd = 0;
			pBrowser->get_HWND((long*)&hWnd);
			if(hWnd) {
				::SetWindowPos(hWnd,HWND_TOP,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_SHOWWINDOW);
			}
		}
	}
}

void CIEEnumWindowsDlg::OnActivate() 
{
	// TODO: Add your control notification handler code here
	OnDblclkIEList	();
}


//
// On View Source, Get Body element and ask for Html content
//
void CIEEnumWindowsDlg::OnVs() 
{
	// TODO: Add your control notification handler code here
	int index = m_List.GetCurSel();
	if(index != CB_ERR) {
		IWebBrowser2 *pBrowser = (IWebBrowser2 *)m_List.GetItemDataPtr(index);
		if(pBrowser) {
			
			IDispatchPtr spDisp;
			if(pBrowser->get_Document(&spDisp) == S_OK && spDisp!= 0 ) {
				MSHTML::IHTMLDocument2Ptr spHtmlDocument(spDisp);
				MSHTML::IHTMLElementPtr spHtmlElement;
				spHtmlDocument->get_body(&spHtmlElement);
				if(spHtmlElement != 0) {
					BSTR bstr;
					spHtmlElement->get_outerHTML(&bstr);
					m_Info.SetWindowText(CString(bstr));
				}
	
			}
		}

	}
}

void CIEEnumWindowsDlg::OnSelchangeList1() 
{
	// TODO: Add your control notification handler code here
	int index = m_List.GetCurSel();
	if(index != CB_ERR) {
		IWebBrowser2 *pBrowser = (IWebBrowser2 *)m_List.GetItemDataPtr(index);
		if(pBrowser ) {
			CString str = "URL:";
			BSTR bstr;
			pBrowser->get_LocationURL(&bstr); 
			str += bstr;
			SysFreeString(bstr);
			str += "\r\nTITLE:";
			pBrowser->get_LocationName(&bstr);
			str += bstr;
			SysFreeString(bstr);
			m_Info.SetWindowText(str);
		}
	}
}
