// IEEnumWindows.h : main header file for the IEENUMWINDOWS application
//

#if !defined(AFX_IEENUMWINDOWS_H__B9A194E7_2603_11D4_9045_00C04FA13F84__INCLUDED_)
#define AFX_IEENUMWINDOWS_H__B9A194E7_2603_11D4_9045_00C04FA13F84__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CIEEnumWindowsApp:
// See IEEnumWindows.cpp for the implementation of this class
//

class CIEEnumWindowsApp : public CWinApp
{
public:
	CIEEnumWindowsApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIEEnumWindowsApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CIEEnumWindowsApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IEENUMWINDOWS_H__B9A194E7_2603_11D4_9045_00C04FA13F84__INCLUDED_)
