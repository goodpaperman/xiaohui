// IEEnumWindowsDlg.h : header file
//

#if !defined(AFX_IEENUMWINDOWSDLG_H__B9A194E9_2603_11D4_9045_00C04FA13F84__INCLUDED_)
#define AFX_IEENUMWINDOWSDLG_H__B9A194E9_2603_11D4_9045_00C04FA13F84__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CIEEnumWindowsDlg dialog

class CIEEnumWindowsDlg : public CDialog
{
// Construction
public:
	CIEEnumWindowsDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CIEEnumWindowsDlg)
	enum { IDD = IDD_IEENUMWINDOWS_DIALOG };
	CEdit	m_Info;
	CListBox	m_List;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIEEnumWindowsDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL
	
	public:

	//
	// @Sample
	// Shell Event's
	// Following dispatch map is used to listen to Shell Event's
	//
	DECLARE_DISPATCH_MAP()
	void WindowRegistered(long lCookie);
	void WindowRevoked(long lCookie);
	
	//
	// @Sample
	// Connect to Shell and Listen to it
	//
	void ConnectToShell();



// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CIEEnumWindowsDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();
	afx_msg void OnDblclkIEList();
	afx_msg void OnActivate();
	afx_msg void OnVs();
	afx_msg void OnSelchangeList1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IEENUMWINDOWSDLG_H__B9A194E9_2603_11D4_9045_00C04FA13F84__INCLUDED_)
