#include "stdafx.h"
#include "Pager.h"
#include "smtbeeper.h"
#include "mysock.h"

char*	ServerName[] = { "203.233.32.50",		// Seoul
						 "203.248.48.16",		// Naray
						 "www3.joongang.co.kr"	// JoongAng
		};
int		PortNo[] = { 2229,		// Seoul
					10711,		// Naray
					80,			// JoongAng
		};

int RecvSock(SOCKET Socket, char* rbuf, int pktsize, int timeout)
{
	CTime		curt, st;
	CTimeSpan	span(0, 0, 0, timeout);
	int			len;

	st = CTime().GetCurrentTime();
	for(;;) {
		if((len=recv(Socket, rbuf, pktsize, 0)) != -1)
			break;
		curt = CTime().GetCurrentTime();
		if(curt > (st+span))
			return 0;
	}
	return len;
}

int CPager::FindPrefix()
{
	// �������� ȯ������ ���� ������ �ְ� ��ĥ��...
	char pf[][20][7] = { 
		/*Seoul*/	{ "0151", "0152", "01545", "01583", "01585", "01577", "" },
		/*Naray*/	{ "0153", "01565", "0159", "01584", "01586", "" },
		/*SKT*/		{ "012", "" },
	};
	char	tmp[10];
	for(int i=0; i < PSERVERMAX; i++) {
		for(int j=0; pf[i][j][0]; j++) {
			memset(tmp, 0x00, sizeof(tmp));
			strncpy(tmp, m_PagerNo, strlen(pf[i][j]));
			if(!strcmp(tmp, pf[i][j]))
				return i;
		}
	}
	return 0xFFFF;
}

int CPager::Call(char* pno, char* amsg, char* nmsg, int timeout)
{
	int		ret;

	m_PagerNo = pno;
	m_AlpaMsg = amsg;
	m_NumMsg  = nmsg;
	m_TimeOut = timeout;
	switch(FindPrefix()) {
	case 0:
	case 1:
	case 2:
		ret = Seoul();
		break;
/*	case 1:
		ret = Naray();
		break;
	case 2:
		ret = SKT();
		break;
*/	default:
		ret = AnyCall();
		break;
	}
	return ret;
}

int CPager::SKT()
{
	return AnyCall();
}

int CPager::Naray()
{
	CString		str;//, tmp1, tmp2;
//	char		rbuf[1024*10];
	CMySocket		TextSocket;

	m_Server = ServerName[0];	// copy

	str.Format("SEOULCOM%s%s", CString(m_PagerNo).Mid(3, 8), CString(m_NumMsg).Mid(0, 15));

	if (!TextSocket.Create())
		return 1;

	TextSocket.m_nTimeOut = m_TimeOut;	//m_pMyApp->m_ConnTimeOut;
	
	if(!TextSocket.Connect(m_Server, PortNo[0])) { //ip, m_Port+702)) {
		return 1;
	}
	
	Sleep(1000);
	TextSocket.Send(str, str.GetLength(), 0);
//	Sleep(3000);
	return 0;
}

int CPager::Seoul()
{
	CString pno, nmsg, str;
	int     ret;

//	pno = m_PagerNo+3;
	pno = m_PagerNo;
	nmsg = m_NumMsg;
	pno.TrimRight();
	nmsg.TrimRight();
	strcpy(m_PagerNo, pno);
	strcpy(m_NumMsg, nmsg);
//	ret = smtCall(m_PagerNo, m_AlpaMsg, m_NumMsg, m_TimeOut);
//	ret = smtGlobalCall(m_PagerNo, m_NumMsg, m_TimeOut);

	CMySocket	sock;
	char		rbuf[1024];

	if (!sock.Create())
		return ERR_SOCK_OPEN;

	sock.m_nTimeOut = m_TimeOut;	//m_pMyApp->m_ConnTimeOut;
	
	if(!sock.Connect(ServerName[0], PortNo[0]))
		return ERR_SOCK_CONN;

	Sleep(500);
	if(!RecvSock(sock.m_hSocket, rbuf, sizeof(rbuf), 30))
		return ERR_SOCK_TIME;
	if(rbuf[0] != '+')
		goto CALLEXIT;

	str.Format("PROG CTI\r\n");
	sock.Send(str, str.GetLength(), 0);
	if(!RecvSock(sock.m_hSocket, rbuf, sizeof(rbuf), 30))
		return ERR_SOCK_TIME;
	if(rbuf[0] != '+')
		goto CALLEXIT;

	str.Format("QUERY %s\r\n", m_PagerNo);
	sock.Send(str, str.GetLength(), 0);
	if(!RecvSock(sock.m_hSocket, rbuf, sizeof(rbuf), 30))
		return ERR_SOCK_TIME;
	if(rbuf[0] != '+')
		goto CALLEXIT;

	str.Format("RNO %s\r\n", m_NumMsg);
	sock.Send(str, str.GetLength(), 0);
	if(!RecvSock(sock.m_hSocket, rbuf, sizeof(rbuf), 30))
		return ERR_SOCK_TIME;
	if(rbuf[0] != '+')
		goto CALLEXIT;

	str.Format("CALL\r\n");
	sock.Send(str, str.GetLength(), 0);
	if(!RecvSock(sock.m_hSocket, rbuf, sizeof(rbuf), 30))
		return ERR_SOCK_TIME;

	str.Format("QUIT\r\n");
	sock.Send(str, str.GetLength(), 0);

CALLEXIT:
	if(rbuf[0] == '+')
		ret = 0;
	else
		ret = atoi(&rbuf[4]);

	sock.Close();

	return ret;
}

int CPager::AnyCall()
{
	CString		str, tmp1, tmp2;
//	char		rbuf[1024*10];
	CMySocket	TextSocket;

	m_Server = ServerName[2];	// copy gloval to local

char*	smshead = 
"POST /messenger/bin/telsend.dll?input HTTP/1.1\r\n\
Content-Type: application/x-www-form-urlencoded\r\n\
Host: Null\r\n\
Content-Length: %d\r\n\
Connection: Keep-Alive\r\n\r\n";
char*	smsbody =
"callnum=%s&reqnum=%s&reqname=%s&text=%s&mode=TXT\r\n\r\n";
//mode=TXT&callnum=0183251997&reqnum=111&reqname=%C0%CC%BD%C2%B0%E6&text=%C5%D7%BD%BA%C6%AE

	tmp2.Format(smsbody, m_PagerNo, m_NumMsg, "SEOULCOMM.", m_NumMsg);
	tmp1.Format(smshead, tmp2.GetLength()); 

	str = tmp1 + tmp2;

	if (!TextSocket.Create())
		return ERR_SOCK_OPEN;

	TextSocket.m_nTimeOut = m_TimeOut;	//m_pMyApp->m_ConnTimeOut;
	
	if(!TextSocket.Connect(m_Server, PortNo[2])) { //ip, m_Port+702)) {
		return ERR_SOCK_CONN;
	}
	
	Sleep(2000);
	TextSocket.Send(str, str.GetLength(), 0);

	Sleep(3000);
//	if( !RecvSock(TextSocket, rbuf, sizeof(rbuf), timeout) ) {
//		log.ResultMsg = "�� ������ ���� - �޼����� ���۵�.";
//	}
//	StripTags(rbuf);
//	pDoc->Message(rbuf+str.Find("\r\n\r\n"));
//	TextSocket.Close();
//	pDoc->Message("  �� ���� �޼��� ó�� �Ϸ�.\r\n");
	return 0;
}
