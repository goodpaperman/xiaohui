#include "stdafx.h"

//////////////////////////////////////////////////////////////////////////////////
//																				//
//					Implementation of the CSock class							//
//																				//
//////////////////////////////////////////////////////////////////////////////////
//																				//
//			1999 Presented by Seung Kyung, Lee.									//
//			E-Mail : weneed@samsung.co.kr										//
//																				//
//			Designed using Microsoft VisualC++ 6.0 and MFC						//
//			Tested on WindowsNT 4.0  Server										//
//																				//
//////////////////////////////////////////////////////////////////////////////////

class CSock : public CSocket
{
	virtual BOOL ConnectHelper(const SOCKADDR* lpSockAddr, int nSockAddrLen);
	virtual void OnClose( int nErrorCode );
public:
	CSock() { m_Kill = TRUE; }
	BOOL	m_Kill;
};
