#include "stdafx.h"
#include "Sock.h"

/// CSocket modify - timeout module.
BOOL CSock::ConnectHelper(const SOCKADDR* lpSockAddr, int nSockAddrLen)
{
	if (m_pbBlocking != NULL)
	{
		WSASetLastError(WSAEINPROGRESS);
		return  FALSE;
	}

	m_nConnectError = -1;

	if (!CAsyncSocket::ConnectHelper(lpSockAddr, nSockAddrLen))
	{
		if (GetLastError() == WSAEWOULDBLOCK)
		{
	// Insert....
			CTime		curt, st;
			CTimeSpan	span(0, 0, 0, m_nTimeOut);

			st = CTime().GetCurrentTime();
	//.......
			while (PumpMessages(FD_CONNECT))
			{
				if (m_nConnectError != -1)
				{
					WSASetLastError(m_nConnectError);
					return (m_nConnectError == 0);
				}
	// Insert....
				curt = CTime().GetCurrentTime();
				if(curt > (st+span))
					return FALSE;
	//..............
			}
		}
		return FALSE;
	}
	m_Kill = FALSE;
	return TRUE;
}

void CSock::OnClose(int nErrorCode)
{
	m_Kill = TRUE;
}
