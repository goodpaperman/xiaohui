// OptionsSheet.cpp : implementation file
//

#include "stdafx.h"
#include "QryTool.h"
#include "OptionsSheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COptionsSheet

IMPLEMENT_DYNAMIC(COptionsSheet, CPropertySheet)

COptionsSheet::COptionsSheet(UINT nIDCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(nIDCaption, pParentWnd, iSelectPage)
{
}

COptionsSheet::COptionsSheet(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(pszCaption, pParentWnd, iSelectPage)
{
	AddPage(&m_pageGeneralPage);
	AddPage(&m_pageNewConns);
}

COptionsSheet::~COptionsSheet()
{
}

BEGIN_MESSAGE_MAP(COptionsSheet, CPropertySheet)
	//{{AFX_MSG_MAP(COptionsSheet)
	ON_BN_CLICKED(IDOK, OnOK)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COptionsSheet message handlers

BOOL COptionsSheet::OnInitDialog() 
{
	BOOL bResult = CPropertySheet::OnInitDialog();
	
	int rgiButtons[] = {IDOK, IDCANCEL, ID_APPLY_NOW, IDHELP};

	// Move OK
	CWnd* pWndTemp = GetDlgItem(rgiButtons[1]);
	CRect rect;
	pWndTemp->GetWindowRect(&rect);
	ScreenToClient(&rect);
	pWndTemp = GetDlgItem(rgiButtons[0]);
	pWndTemp->MoveWindow(&rect);
	
	// Move Cancel
	pWndTemp = GetDlgItem(rgiButtons[2]);
	pWndTemp->GetWindowRect(&rect);
	ScreenToClient(&rect);
	pWndTemp->ShowWindow(SW_HIDE);
	pWndTemp = GetDlgItem(rgiButtons[1]);
	pWndTemp->MoveWindow(&rect);
	
	return bResult;
}

void COptionsSheet::OnOK()
{
	CWaitCursor wait;

	bool bOK = m_pageGeneralPage.Validate();
	if(::IsWindow(m_pageNewConns.m_hWnd))
		bOK = bOK && m_pageNewConns.Validate();

	if(bOK)
		EndDialog(IDOK);
}