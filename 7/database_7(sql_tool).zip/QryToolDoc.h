// QryToolDoc.h : interface of the CQryToolDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_QRYTOOLDOC_H__E1966CBD_6232_11D3_A7CD_00C04F595ED0__INCLUDED_)
#define AFX_QRYTOOLDOC_H__E1966CBD_6232_11D3_A7CD_00C04F595ED0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CQryToolDoc : public CRichEditDoc
{
protected: // create from serialization only
	CQryToolDoc();
	DECLARE_DYNCREATE(CQryToolDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CQryToolDoc)
	public:
	virtual BOOL CanCloseFrame(CFrameWnd* pFrame);
	virtual void SetTitle(LPCTSTR lpszTitle);
	virtual BOOL SaveModified();
	virtual BOOL OnSaveDocument(LPCTSTR lpszPathName);
	//}}AFX_VIRTUAL
	virtual CRichEditCntrItem* CreateClientItem(REOBJECT* preo) const;

// Implementation
public:
	virtual ~CQryToolDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CQryToolDoc)
	afx_msg void OnFileSave();
	afx_msg void OnFileSaveAs();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void ChangeTitle(const CString& sTitle);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_QRYTOOLDOC_H__E1966CBD_6232_11D3_A7CD_00C04F595ED0__INCLUDED_)