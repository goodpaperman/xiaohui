#if !defined(AFX_NEWCONNECTIONS_H__4F25AC53_7F10_11D3_A848_00C04F595ED0__INCLUDED_)
#define AFX_NEWCONNECTIONS_H__4F25AC53_7F10_11D3_A848_00C04F595ED0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// NewConnections.h : header file
//

class COptionsSheet;

/////////////////////////////////////////////////////////////////////////////
// CNewConnections dialog

class CNewConnections : public CPropertyPage
{
	DECLARE_DYNCREATE(CNewConnections)

// Construction
public:
	CNewConnections();
	~CNewConnections();
	int m_nLoginTimeOut;
	bool Validate();

// Dialog Data
	//{{AFX_DATA(CNewConnections)
	enum { IDD = IDD_NEW_CONNECTIONS };
	CString	m_strLoginTimeOut;
	//}}AFX_DATA

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CNewConnections)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CNewConnections)
	virtual BOOL OnInitDialog();
	afx_msg void OnReset();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	COptionsSheet* m_pSheet;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NEWCONNECTIONS_H__4F25AC53_7F10_11D3_A848_00C04F595ED0__INCLUDED_)