// QryToolDoc.cpp : implementation of the CQryToolDoc class
//

#include "stdafx.h"
#include "QryTool.h"
#include "QryToolDoc.h"
#include "MainFrm.h"
#include "ChildFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CQryToolDoc

IMPLEMENT_DYNCREATE(CQryToolDoc, CRichEditDoc)

BEGIN_MESSAGE_MAP(CQryToolDoc, CRichEditDoc)
	//{{AFX_MSG_MAP(CQryToolDoc)
	ON_COMMAND(ID_FILE_SAVE, OnFileSave)
	ON_COMMAND(ID_FILE_SAVE_AS, OnFileSaveAs)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CQryToolDoc construction/destruction

CQryToolDoc::CQryToolDoc()
{
	m_bRTF = FALSE;
}

CQryToolDoc::~CQryToolDoc()
{
}

CRichEditCntrItem* CQryToolDoc::CreateClientItem(REOBJECT* preo) const
{
	UNUSED_ALWAYS(preo);

	return NULL;
}

/////////////////////////////////////////////////////////////////////////////
// CQryToolDoc diagnostics

#ifdef _DEBUG
void CQryToolDoc::AssertValid() const
{
	CRichEditDoc::AssertValid();
}

void CQryToolDoc::Dump(CDumpContext& dc) const
{
	CRichEditDoc::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CQryToolDoc commands

void CQryToolDoc::SetTitle(LPCTSTR lpszTitle) 
{
	CString sTitle = lpszTitle;
	CChildFrame* pFrame = NULL;
	if(sTitle.Find('-') == -1)
	{
		POSITION pos = GetFirstViewPosition();
		while(pos != NULL)	
		{
			CView* pView = GetNextView(pos);
			ASSERT(pView != NULL);
			if(pView->IsKindOf(RUNTIME_CLASS(CQryView))) 
			{
				CQryView* pQryView = (CQryView*)pView;
				ASSERT(pQryView != NULL);
				pFrame = (CChildFrame*)pQryView->GetParentFrame();
				break;
			}
			
			if(pView->IsKindOf(RUNTIME_CLASS(CResultView))) 
			{
				CResultView* pResultView = (CResultView*)pView;
				ASSERT(pResultView != NULL);
				pFrame = (CChildFrame*)pResultView->GetParentFrame();
				break;
			}
		}
	}

	if(pFrame != NULL)
	{
		if(!pFrame->m_strDataSource.IsEmpty())
		{
			sTitle = pFrame->m_strDataSource + " - " + CString(lpszTitle);
			long nStart = -1;
			long nEnd = -1;
			pFrame->m_pQryView->GetRichEditCtrl().GetSel(nStart, nEnd);
			int nBuff = nEnd-nStart;
			CString sSQL;
			if(nBuff == 0)
				pFrame->m_pQryView->GetRichEditCtrl().GetWindowText(sSQL);
			else if(nBuff > 20000)
			{
				pFrame->m_pQryView->GetRichEditCtrl().GetWindowText(sSQL);
				sSQL = sSQL.Mid(nStart, nBuff);
			}
			else
				sSQL = pFrame->m_pQryView->GetRichEditCtrl().GetSelText();

			if(sSQL.IsEmpty())
				sSQL = "New Query";
			
			sSQL.Replace(_T("\n"), _T(" "));
			sSQL.Replace(_T("\r"), _T(" "));
			if(sSQL.GetLength() > 15)
				sTitle = sTitle + _T(" - (") + sSQL.Left(15) + _T("...)");
			else
				sTitle = sTitle + _T(" - (") + sSQL + _T(")");
		}
	}

	CRichEditDoc::SetTitle(sTitle);
}

BOOL CQryToolDoc::CanCloseFrame(CFrameWnd* pFrame) 
{
	CString sTitle = GetTitle();
	ChangeTitle(sTitle);
	BOOL bRet = CRichEditDoc::CanCloseFrame(pFrame);
	if(!bRet)
		m_strTitle = sTitle;
	
	return bRet;
}

BOOL CQryToolDoc::SaveModified() 
{
	CString sTitle = GetTitle();
	ChangeTitle(sTitle);
	BOOL bRet = CRichEditDoc::SaveModified();
	if(!bRet)
		m_strTitle = sTitle;
	
	return bRet;
}

void CQryToolDoc::OnFileSave() 
{
	CString sTitle = GetTitle();
	ChangeTitle(sTitle);
	if(!CRichEditDoc::DoSave(GetPathName()))
		m_strTitle = sTitle;
}

void CQryToolDoc::OnFileSaveAs() 
{
	CString sTitle = GetTitle();
	ChangeTitle(sTitle);
	if(!CRichEditDoc::DoSave(NULL))
		m_strTitle = sTitle;
}

// Must override this even if there is no extra implementation
BOOL CQryToolDoc::OnSaveDocument(LPCTSTR lpszPathName) 
{
	CMainFrame* pMainFrame = (CMainFrame*)AfxGetMainWnd();
	CChildFrame* pChildFrame = NULL;
	if(pMainFrame != NULL)
	{
		pChildFrame = (CChildFrame*)pMainFrame->MDIGetActive();
		if(pChildFrame != NULL)
			pChildFrame->m_wndStatusBar.SetPaneText(0, _T("Please wait..."));
	}

	return CRichEditDoc::OnSaveDocument(lpszPathName);
}

void CQryToolDoc::ChangeTitle(const CString& sTitle)
{
	CString sBuff = sTitle;
	int nPos = sBuff.Find(_T(" - ("));
	if(nPos != -1)
		sBuff = sBuff.Left(nPos);
	nPos = sBuff.Find(_T("- "));
	if(nPos != -1)
		m_strTitle = sBuff.Mid(nPos+2);
}