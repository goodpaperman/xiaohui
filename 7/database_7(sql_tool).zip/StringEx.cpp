// StringEx.cpp: implementation of the CStringEx class.
//

#include "stdafx.h"
#include "StringEx.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// CStringEx

int CStringEx::Find(LPCTSTR lpszSub, int nStartPos) const
{
	ASSERT(AfxIsValidString(lpszSub, FALSE));
	
	// find first matching substring
	LPTSTR lpsz = _tcsstr(m_pchData+nStartPos, lpszSub);
	
	// return -1 for not found, distance from beginning otherwise
	return (lpsz == NULL) ? -1 : (int)(lpsz - m_pchData);
}

int CStringEx::FindNoCase(LPCTSTR lpszSub, int nStartPos) const
{
	CStringEx sLowerThis = *this;
	sLowerThis.MakeLower();
	
	CStringEx sLowerSub = lpszSub;
	sLowerSub.MakeLower();
	
	return sLowerThis.Find(sLowerSub, nStartPos);
}