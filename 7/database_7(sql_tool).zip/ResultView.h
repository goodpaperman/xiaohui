//{{AFX_INCLUDES()
#include "msflexgrid.h"
//}}AFX_INCLUDES
#if !defined(AFX_RESULTVIEW_H__96F0E255_A409_11D1_B9D3_204C4F4F5020__INCLUDED_)
#define AFX_RESULTVIEW_H__96F0E255_A409_11D1_B9D3_204C4F4F5020__INCLUDED_

#if _MSC_VER >= 1000 
#pragma once
#endif // _MSC_VER >= 1000
// ResultView.h : header file
//

#include "QryToolDoc.h"

/////////////////////////////////////////////////////////////////////////////
// CResultView form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class CChildFrame;

class CResultView : public CRichEditView
{
protected:
	CResultView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CResultView)

public:
	CMSFlexGrid* m_pGridCtrl;
	CString m_strObjName;

// Attributes
public:
	CQryToolDoc* GetDocument();

// Operations
public:
	void SetFontEx();
	void SetWrapNone();
	void SetWrapToWindow();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CResultView)
	public:
	virtual void OnInitialUpdate();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CResultView();
	virtual HMENU GetContextMenu(WORD wSelType, LPOLEOBJECT lpOleObj, CHARRANGE* lpChrg);

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CResultView)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnEditCopy();
	afx_msg void OnUpdateEditCopy(CCmdUI* pCmdUI);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnUpdateFileSave(CCmdUI* pCmdUI);
	afx_msg void OnFilePrint();
	afx_msg void OnFileSaveAs();
	afx_msg int OnMouseActivate(CWnd* pDesktopWnd, UINT nHitTest, UINT message);
	afx_msg void OnUpdateFilePrint(CCmdUI* pCmdUI);
	afx_msg void OnViewWrapWord();
	afx_msg void OnUpdateViewWrapWord(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditPaste(CCmdUI* pCmdUI);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnGridSaveSelection();
	afx_msg void OnEditSelectAll();
	afx_msg void OnUpdateEditSelectAll(CCmdUI* pCmdUI);
	afx_msg void OnViewFont();
	afx_msg void OnEditClearAll();
	afx_msg void OnUpdateEditClearAll(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditCut(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditReplace(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	LOGFONT m_lf;
	void SetResultViewFont();
	void SetGridFont();
	CChildFrame* m_pChildFrame;
	void CopyGridData();
	BOOL ExportResults(const bool& bSaveSelection = false);
	BOOL ExportToFile(CStdioFile* pFile, LPCTSTR lpszDelimiter, const BOOL& bColumnNames,
		const bool& bSaveSelection = false);
	void InvokeGridMenu();
	CFont m_font;
};

#ifndef _DEBUG  // debug version in SQLView.cpp
inline CQryToolDoc* CResultView::GetDocument()
   { return (CQryToolDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RESULTVIEW_H__96F0E255_A409_11D1_B9D3_204C4F4F5020__INCLUDED_)