// Helpers.cpp: implementation of the CHelpers class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Helpers.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// CHelpers

CHelpers::CHelpers()
{
}

CHelpers::~CHelpers()
{
}

int CHelpers::Insert(CListCtrlEx* pListCtrl, CString& sRow, int nImage/* = -1*/,
		int nIndex/* = -1*/)
{
	ASSERT(pListCtrl);

	int nItemIndex = -1;
	int nEnd = sRow.Find(_T("|"));
	if(nEnd != -1)
	{
		int nSubItem = 0;
		LV_ITEM lvItem;
		CString sColVal;
		lvItem.mask = LVIF_TEXT;
		
		if(nImage != -1)
		{
			lvItem.mask |= LVIF_IMAGE;
			lvItem.iImage = nImage;
		}
		
		if(nIndex != -1)
			lvItem.iItem = nIndex;

		lvItem.iSubItem = nSubItem++;
		sColVal = sRow.Mid(0, nEnd);
		lvItem.pszText = sColVal.GetBuffer(sColVal.GetLength()+1);
		sColVal.ReleaseBuffer();
		nItemIndex 	= pListCtrl->InsertItem(&lvItem);
		ASSERT(nItemIndex != -1);
		if(nItemIndex != -1)
		{
			while(sRow.GetLength() > nEnd) 
			{  		
				sRow = sRow.Mid(nEnd + 1);
				nEnd = sRow.Find(_T("|"));
				if(nEnd == -1)
					break;
				
				lvItem.iItem = nItemIndex;
				lvItem.iSubItem = nSubItem++;
				sColVal = sRow.Mid(0, nEnd);
				lvItem.pszText = sColVal.GetBuffer(sColVal.GetLength()+1);
				sColVal.ReleaseBuffer();
				pListCtrl->SetItem(&lvItem);
			}
		}
	}

	return nItemIndex;
}

CString CHelpers::GetFileExceptionError(const int& nCause)
{
	CString sBuff(_T("An unspecified error occurred."));
	
	switch(nCause)
	{
		case CFileException::fileNotFound:
			sBuff = _T("The file could not be located.");
			break;
		
		case CFileException::badPath:
			sBuff = _T("All or part of the path is invalid.");
			break;
		
		case CFileException::tooManyOpenFiles:
			sBuff = _T("The permitted number of open files was exceeded.");
			break;
		
		case CFileException::accessDenied:
			sBuff = _T("The file could not be accessed.");
			break;

		case CFileException::invalidFile:
			sBuff = _T("There was an attempt to use an invalid file handle.");
			break;
		
		case CFileException::removeCurrentDir:
			sBuff = _T("The current working directory cannot be removed.");
			break;
		
		case CFileException::directoryFull:
			sBuff = _T("There are no more directory entries.");
			break;
			
		case CFileException::badSeek:
			sBuff = _T("There was an error trying to set the file pointer.");
			break;
			
		case CFileException::hardIO:
			sBuff = _T("There was a hardware error.");
			break;

		case CFileException::sharingViolation:
			sBuff = _T("SHARE.EXE was not loaded, or a shared region was locked.");
			break;
			
		case CFileException::lockViolation:
			sBuff = _T("There was an attempt to lock a region that was already locked.");
			break;
			
		case CFileException::diskFull:
			sBuff = _T("The disk is full.");
			break;
		
		case CFileException::endOfFile:
			sBuff = _T("The end of file was reached."); 
			break;
	}

	return sBuff;
}