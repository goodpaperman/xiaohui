// NewConnections.cpp : implementation file
//

#include "stdafx.h"
#include "qrytool.h"
#include "NewConnections.h"
#include "OptionsSheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern LPCTSTR g_szConfigure;
LPCTSTR g_szLoginTimeOut = _T("LoginTimeOut");
/////////////////////////////////////////////////////////////////////////////
// CNewConnections property page

IMPLEMENT_DYNCREATE(CNewConnections, CPropertyPage)

CNewConnections::CNewConnections() : CPropertyPage(CNewConnections::IDD)
{
	//{{AFX_DATA_INIT(CNewConnections)
	m_strLoginTimeOut = _T("");
	//}}AFX_DATA_INIT
}

CNewConnections::~CNewConnections()
{
}

void CNewConnections::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNewConnections)
	DDX_Text(pDX, IDC_LOGIN_TIMEOUT, m_strLoginTimeOut);
	DDV_MaxChars(pDX, m_strLoginTimeOut, 5);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CNewConnections, CPropertyPage)
	//{{AFX_MSG_MAP(CNewConnections)
	ON_BN_CLICKED(IDC_RESET, OnReset)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNewConnections message handlers

BOOL CNewConnections::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	m_pSheet = (COptionsSheet*)GetParent();

	m_nLoginTimeOut = AfxGetApp()->GetProfileInt(g_szConfigure, g_szLoginTimeOut, 0);
	if(m_nLoginTimeOut > 99999 || m_nLoginTimeOut < 0)
		m_nLoginTimeOut = 0;
	m_strLoginTimeOut.Format(_T("%d"), m_nLoginTimeOut);

	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

bool CNewConnections::Validate()
{
	CWaitCursor wait;

	UpdateData();

	m_strLoginTimeOut.TrimRight();
	m_strLoginTimeOut.TrimLeft();
	if(m_strLoginTimeOut.IsEmpty())
	{
		m_pSheet->SetActivePage(this);
		AfxMessageBox(_T("<Login Timeout> is a required field. The default value is Zero."));
		GetDlgItem(IDC_LOGIN_TIMEOUT)->SetFocus();
		return false;
	}

#ifdef _UNICODE
	USES_CONVERSION;
	m_nLoginTimeOut = atoi(W2CA((LPCTSTR)m_strLoginTimeOut));
#else
	m_nLoginTimeOut = atoi((LPCTSTR)m_strLoginTimeOut);
#endif
	if(m_nLoginTimeOut > 99999 || m_nLoginTimeOut < 0)
	{
		m_pSheet->SetActivePage(this);
		AfxMessageBox(_T("Please enter an integer between 0 and 99999."));
		GetDlgItem(IDC_LOGIN_TIMEOUT)->SetFocus();
		return false;
	}
	
	CWinApp* pApp = AfxGetApp();
	pApp->WriteProfileInt(g_szConfigure, g_szLoginTimeOut, m_nLoginTimeOut);

	return true;
}

void CNewConnections::OnReset() 
{
	m_nLoginTimeOut = 0;
	m_strLoginTimeOut.Format(_T("%d"), m_nLoginTimeOut);
	
	UpdateData(FALSE);	
}