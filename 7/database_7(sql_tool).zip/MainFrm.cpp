// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "QryTool.h"
#include "MainFrm.h"
#include "QryToolDoc.h"
#include "OptionsSheet.h"
#include "font.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CQryToolApp theApp;

LPCTSTR g_szUntitled = _T("Untitled");
int g_nUntitledBump = 0;
/////////////////////////////////////////////////////////////////////////////
// CMDIClientWnd

CMDIClientWnd::CMDIClientWnd()
{
}

CMDIClientWnd::~CMDIClientWnd()
{
}

BEGIN_MESSAGE_MAP(CMDIClientWnd, CWnd)
	//{{AFX_MSG_MAP(CMDIClientWnd)
	ON_WM_PAINT()
	ON_WM_WINDOWPOSCHANGING()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMDIClientWnd message handlers

void CMDIClientWnd::OnPaint() 
{
	CRect rect;
	GetClientRect(&rect);
	BITMAP bm;
	m_bitmap.GetBitmap(&bm);
	int nX = rect.right - bm.bmWidth - rect.Width()/30;
	int nY = rect.bottom - bm.bmHeight - rect.Height()/20;
	CDC dcImage;
	CPaintDC dc(this);
	if(dcImage.CreateCompatibleDC(&dc))
	{
		CBitmap* pOldBitmap = dcImage.SelectObject(&m_bitmap);
		dc.BitBlt(nX, nY, bm.bmWidth, bm.bmHeight, &dcImage, 0, 0, SRCCOPY);
		dcImage.SelectObject(pOldBitmap);
	}
}

void CMDIClientWnd::OnWindowPosChanging(WINDOWPOS FAR* lpwndpos) 
{
	CWnd::OnWindowPosChanging(lpwndpos);
	if(lpwndpos != NULL && !(lpwndpos->flags & SWP_NOMOVE))
	{	 
		CWnd* pParent = GetParent();	
		if(pParent != NULL)
		{
			CRect rect;						
			GetWindowRect(&rect);				
			pParent->ScreenToClient(&rect);	
			pParent->InvalidateRect(&rect);
			PostMessage(WM_PAINT);
		}
	}
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CMDIFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CMDIFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_CLOSE()
	ON_COMMAND(ID_FILE_DISCONNECT_ALL, OnFileDisconnectAll)
	ON_COMMAND(ID_FILE_CONNECT, OnFileConnect)
	ON_COMMAND(ID_HELP_README, OnHelpReadme)
	ON_COMMAND(ID_FILE_DISCONNECT, OnFileDisconnect)
	ON_COMMAND(ID_FILE_CONFIGURE, OnFileConfigure)
	ON_COMMAND(ID_EDIT_GOTO, OnEditGoto)
	ON_COMMAND(ID_WINDOW_TILE_HORZ, OnWindowTileHorz)
	ON_UPDATE_COMMAND_UI(ID_WINDOW_TILE_HORZ, OnUpdateWindowTileHorz)
	ON_COMMAND(ID_WINDOW_TILE_VERT, OnWindowTileVert)
	ON_UPDATE_COMMAND_UI(ID_WINDOW_TILE_VERT, OnUpdateWindowTileVert)
	ON_UPDATE_COMMAND_UI(ID_EDIT_GOTO, OnUpdateEditGoto)
	ON_COMMAND(ID_WINDOW_CASCADE, OnWindowCascade)
	ON_UPDATE_COMMAND_UI(ID_WINDOW_CASCADE, OnUpdateWindowCascade)
	ON_COMMAND(ID_WINDOW_ARRANGE, OnWindowArrange)
	ON_UPDATE_COMMAND_UI(ID_WINDOW_ARRANGE, OnUpdateWindowArrange)
	ON_COMMAND(ID_WINDOW_NEXT, OnWindowNext)
	ON_UPDATE_COMMAND_UI(ID_WINDOW_NEXT, OnUpdateWindowNext)
	ON_COMMAND(ID_WINDOW_PREVIOUS, OnWindowPrevious)
	ON_UPDATE_COMMAND_UI(ID_WINDOW_PREVIOUS, OnUpdateWindowPrevious)
	ON_UPDATE_COMMAND_UI(ID_FILE_OPEN, OnUpdateFileOpen)
	ON_UPDATE_COMMAND_UI(ID_SET_DBCOMBO_FOCUS, OnUpdateSetDbcomboFocus)
	//}}AFX_MSG_MAP
	ON_UPDATE_COMMAND_UI(ID_INDICATOR_NUM_CONNECTIONS, OnUpdateIndicatorNumConns)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_NUM_CONNECTIONS,
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame() :
	m_pWndCurrentChild(NULL),
	m_bCloseAfterCancel(FALSE),
	m_bDisconnectAllAfterCancel(FALSE)
{
}

CMainFrame::~CMainFrame()
{
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CMDIFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CMDIFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CMDIFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE(_T("Failed to create status bar\n"));
		return -1;      // fail to create
	}
	
	int nIndex = 0;
	UINT nID = ID_SEPARATOR;
	UINT nStyle = -1;
	int nWidth = -1;
	m_wndStatusBar.GetPaneInfo(nIndex, nID, nStyle, nWidth);
	m_wndStatusBar.SetPaneInfo(nIndex, nID, SBPS_NORMAL | SBPS_STRETCH, nWidth);
	m_wndStatusBar.SetPaneInfo(
		1, ID_INDICATOR_NUM_CONNECTIONS, SBPS_NORMAL, 131
		);

	if(!m_wndMDIClient.m_bitmap.LoadBitmap(IDB_INTRO_BMP))
		return -1;
	if(!m_wndMDIClient.SubclassWindow(m_hWndMDIClient))
	{ 
		TRACE(_T("Failed to subclass MDI client window\n"));
        return -1;                                     
    }
	
	return 0;
}

void CMainFrame::OnFileConnect() 
{
	ConnectEx();
}

void CMainFrame::OnFileDisconnect() 
{
	CWaitCursor wait;
	m_wndStatusBar.SetPaneText(0, _T("Please wait..."));
	CChildFrame* pChild = (CChildFrame*)MDIGetActive();
	if(pChild != NULL)
		pChild->SendMessage(WM_CLOSE);
	m_wndStatusBar.SetPaneText(0, _T(""));	
}

void CMainFrame::OnFileDisconnectAll()
{
	CWaitCursor wait;

	m_wndStatusBar.SetPaneText(0, _T("Please wait..."));

	CChildFrame* pChild = (CChildFrame*)MDIGetActive();
	CChildFrame* pOldChild = NULL;
	m_bDisconnectAllAfterCancel = TRUE;
	do
	{
		pOldChild = pChild;
		if(pChild != NULL)
			pChild->SendMessage(WM_CLOSE);

		m_strConnections.Format(_T("Total # of connections: %d"), m_listChildFrame.size());
		m_wndStatusBar.SetPaneText(1, m_strConnections);
		
		pChild = (CChildFrame*)MDIGetActive();
		if(pChild != NULL && pChild == pOldChild && pChild->m_bCanceling)
		{
			pChild->m_bCloseMainFrameAfterCancel = m_bCloseAfterCancel;
			pChild->m_bDisconnectAllAfterCancel = m_bDisconnectAllAfterCancel;
		}

		if(pChild == pOldChild)
			break;
	}
	while(pChild != NULL);
	m_bDisconnectAllAfterCancel = FALSE;

	m_wndStatusBar.SetPaneText(0, _T(""));
}

void CMainFrame::OnFileConfigure() 
{
	COptionsSheet sheet(_T("Configure"));
	if(sheet.DoModal() == IDOK)
	{
		CWaitCursor wait;

		m_wndStatusBar.SetPaneText(0, _T("Please wait..."));

		CMDIChildWnd* pChild = GetNextMDIChildWnd();
		while(pChild != NULL)
		{
			((CChildFrame*)pChild)->SetCommandTimeOut(
				sheet.m_pageGeneralPage.m_nQueryTimeOut
				);
			((CChildFrame*)pChild)->SetCacheSize(
				sheet.m_pageGeneralPage.m_nCacheSize
				);
			((CChildFrame*)pChild)->SetThreadPriority(
				sheet.m_pageGeneralPage.m_strThreadPriority
				);

			pChild = GetNextMDIChildWnd();
		}

		m_wndStatusBar.SetPaneText(0, _T(""));
	}
}

CDocument* CMainFrame::ConnectEx(LPCTSTR lpszConnectString, LPCTSTR lpszFileName,
	 LPCTSTR lpszInitialCatalog)
{
	CWaitCursor wait;
	
	m_wndStatusBar.SetPaneText(0, _T("Establishing new connection..."));

	CDocument* pDoc = NULL;
	if(m_listChildFrame.size() > 511)
	{
		CString sMsg = "Connection limit reached. You must close some connections ";
				sMsg +="before attempting to open any more connections.";
		AfxMessageBox(sMsg, MB_ICONSTOP);
	}
	else
	{
		CString sTitle;
		pDoc = theApp.m_pDocTemplate->CreateNewDocument();
		ASSERT_VALID(pDoc);
		if(pDoc == NULL)
			TRACE(_T("CDocTemplate::CreateNewDocument returned NULL.\n"));
		else
		{
			CChildFrame* pFrame = (CChildFrame*)theApp.m_pDocTemplate->
				CreateNewFrame(pDoc, NULL);
			ASSERT_VALID(pFrame);
			if(pFrame == NULL)
			{
				if(pDoc != NULL)
				{
					delete pDoc;
					pDoc = NULL;
				}
			}
			else
			{
				pDoc->m_bEmbedded = TRUE;
				if(lpszFileName != NULL)
				{
					CWaitCursor wait;
					if(pDoc->OnOpenDocument(lpszFileName))
					{
						pDoc->SetPathName(lpszFileName);
						sTitle = pDoc->GetTitle();
					}
					else
					{
						TRACE(_T("CDocument::OnOpenDocument returned FALSE.\n"));
						pFrame->DestroyWindow();  // Also destroys the associated doc/view
						pDoc = NULL;
					}
				}
				else
				{
					if(!pDoc->OnNewDocument())
					{
						TRACE(_T("CDocument::OnNewDocument returned FALSE.\n"));
						pFrame->DestroyWindow(); // Also destroys the associated doc/view
						pDoc = NULL;
					}
				}
				
				if(pDoc != NULL)
				{
					if(!pFrame->Connect(lpszConnectString, lpszInitialCatalog))
					{
						pFrame->DestroyWindow();  // Also destroys the associated doc/view
						pDoc = NULL;
					}
					else
					{
						if(sTitle.IsEmpty())
							sTitle.Format(_T("%s_%d - (New Query)"), g_szUntitled, ++g_nUntitledBump);
						pDoc->SetTitle(pFrame->m_strDataSource + _T(" - ") + sTitle);
						theApp.m_pDocTemplate->InitialUpdateFrame(pFrame, pDoc);
						pDoc->m_bEmbedded = FALSE;
						pFrame->SetActiveView(pFrame->m_pQryView);
						m_listChildFrame.push_back(pFrame);
						if(m_listChildFrame.size() == 1)
							pFrame->ShowWindow(SW_SHOWMAXIMIZED);
						m_strConnections.Format(
							_T("Total # of connections: %d"),
							m_listChildFrame.size()
							);
						m_wndStatusBar.SetPaneText(1, m_strConnections);
						UpdateWindow();
					}
				}
			}
		}
	}

	m_wndStatusBar.SetPaneText(0, _T(""));

	return pDoc;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs) 
{
	if(!CMDIFrameWnd::PreCreateWindow(cs) )
		return FALSE;

	cs.style = WS_OVERLAPPED | WS_CAPTION /*| FWS_ADDTOTITLE*/
		| WS_THICKFRAME | WS_SYSMENU | WS_MINIMIZEBOX | WS_MAXIMIZEBOX;

	return TRUE;
}

void CMainFrame::OnUpdateIndicatorNumConns(CCmdUI* pCmdUI)
{
	m_strConnections.Format(_T("Total # of connections: %d"), m_listChildFrame.size());
	pCmdUI->SetText(m_strConnections);
}

void CMainFrame::OnUpdateFileOpen(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_listChildFrame.size());
}

void CMainFrame::OnUpdateSetDbcomboFocus(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_listChildFrame.size());
}

void CMainFrame::OnEditGoto()
{
	if(m_dlgGoTo.m_hWnd != NULL)
		m_dlgGoTo.SetFocus();
	else
		m_dlgGoTo.Create(IDD_EDIT_GOTO);

	m_dlgGoTo.CenterWindow();
	m_dlgGoTo.ShowWindow(SW_SHOW);
	m_dlgGoTo.UpdateWindow();
}

void CMainFrame::OnUpdateEditGoto(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_listChildFrame.size());	
}

void CMainFrame::OnWindowNext() 
{
	MDINext();
}

void CMainFrame::OnUpdateWindowNext(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_listChildFrame.size() > 1);
}

void CMainFrame::OnWindowPrevious() 
{
	::SendMessage(m_hWndMDIClient, WM_MDINEXT, 0, 1);
}

void CMainFrame::OnUpdateWindowPrevious(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_listChildFrame.size() > 1);
}

void CMainFrame::OnWindowCascade() 
{
	MDICascade();
}

void CMainFrame::OnUpdateWindowCascade(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_listChildFrame.size());
}

void CMainFrame::OnWindowTileHorz() 
{
	MDITile(MDITILE_HORIZONTAL);
}

void CMainFrame::OnUpdateWindowTileHorz(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_listChildFrame.size());
}

void CMainFrame::OnWindowTileVert() 
{
	MDITile(MDITILE_VERTICAL);
}

void CMainFrame::OnUpdateWindowTileVert(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_listChildFrame.size());
}

void CMainFrame::OnWindowArrange() 
{
	MDIIconArrange();
}

void CMainFrame::OnUpdateWindowArrange(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_listChildFrame.size());
}

void CMainFrame::OnHelpReadme() 
{
	const int nSize = 256;
	TCHAR lpszModuleFileName[nSize];
	DWORD dwSize = ::GetModuleFileName(
				AfxGetInstanceHandle(), lpszModuleFileName, nSize
				);
	ASSERT(dwSize);
	CString sFileName = lpszModuleFileName;
	int nPos = sFileName.ReverseFind(_T('\\'));
	ASSERT(nPos != -1);
	sFileName = sFileName.Left(nPos) + _T("\\readme.txt");
	HINSTANCE h = ::ShellExecute(
		NULL, _T("open"), sFileName, NULL, NULL, SW_SHOWNORMAL
		);
	if((UINT)h <= 32)
		AfxMessageBox(_T("Readme.txt not found in the current working directory."));
}

CMDIChildWnd* CMainFrame::GetNextMDIChildWnd()
{ 
	if(!m_pWndCurrentChild)
		m_pWndCurrentChild = m_wndMDIClient.GetWindow(GW_CHILD);
	else
        m_pWndCurrentChild =
			(CMDIChildWnd*)m_pWndCurrentChild->GetWindow(GW_HWNDNEXT);
	
	if(!m_pWndCurrentChild)
		return NULL;
	
	if(!m_pWndCurrentChild->GetWindow(GW_OWNER))
	{
        if(m_pWndCurrentChild->
			IsKindOf(RUNTIME_CLASS(CMDIChildWnd)))
			return (CMDIChildWnd*)m_pWndCurrentChild;
		else
			return GetNextMDIChildWnd();
	}
    else
		return GetNextMDIChildWnd();
}

/////////////////////////////////////////////////////////////////////////////
// Helpers for saving/restoring window state

static TCHAR BASED_CODE szSection[] = _T("Settings");
static TCHAR BASED_CODE szWindowPos[] = _T("WindowPos");
static TCHAR szFormat[] = _T("%u,%u,%d,%d,%d,%d,%d,%d,%d,%d");

static BOOL PASCAL ReadWindowPlacement(LPWINDOWPLACEMENT pwp)
{
	CWinApp* pApp = AfxGetApp();
	
	CString strBuffer = pApp->GetProfileString(szSection, szWindowPos);
	
	if(strBuffer.IsEmpty())
		return FALSE;

	WINDOWPLACEMENT wp;
	int nRead = _stscanf(strBuffer, szFormat,
		&wp.flags, &wp.showCmd,
		&wp.ptMinPosition.x, &wp.ptMinPosition.y,
		&wp.ptMaxPosition.x, &wp.ptMaxPosition.y,
		&wp.rcNormalPosition.left, &wp.rcNormalPosition.top,
		&wp.rcNormalPosition.right, &wp.rcNormalPosition.bottom);

	if(nRead != 10)
		return FALSE;

	wp.length = sizeof(wp);
	*pwp = wp;

	return TRUE;
}

static void PASCAL WriteWindowPlacement(LPWINDOWPLACEMENT pwp)
{
	TCHAR szBuffer[sizeof(_T("-32767"))*8 + sizeof(_T("65535"))*2];

	wsprintf(szBuffer, szFormat,
		pwp->flags, pwp->showCmd,
		pwp->ptMinPosition.x, pwp->ptMinPosition.y,
		pwp->ptMaxPosition.x, pwp->ptMaxPosition.y,
		pwp->rcNormalPosition.left, pwp->rcNormalPosition.top,
		pwp->rcNormalPosition.right, pwp->rcNormalPosition.bottom);
	
	AfxGetApp()->WriteProfileString(szSection, szWindowPos, szBuffer);
}

/////////////////////////////////////////////////////////////////////////////

void CMainFrame::InitialShowWindow(UINT nCmdShow)
{
	WINDOWPLACEMENT wp;
	if(!ReadWindowPlacement(&wp))
		CenterWindow();
	else
	{
		if(nCmdShow != SW_SHOWNORMAL)
			wp.showCmd = nCmdShow;
		else
			nCmdShow = wp.showCmd;

		SetWindowPlacement(&wp);
	}
	
	ShowWindow(nCmdShow);
	UpdateWindow();
}

void CMainFrame::OnClose() 
{
	if(IsIconic())
		ActivateFrame();

	m_bCloseAfterCancel = TRUE;
	OnFileDisconnectAll();
	m_bCloseAfterCancel = FALSE;
	
	WINDOWPLACEMENT wp;
	wp.length = sizeof(wp);
	if(GetWindowPlacement(&wp))
	{
		wp.flags = 0;
	
		if(IsZoomed())
			wp.flags |= WPF_RESTORETOMAXIMIZED;
		
		if(wp.showCmd != SW_SHOWMINIMIZED)
			WriteWindowPlacement(&wp);
	}
			
	if(m_listChildFrame.size() == 0)
		CMDIFrameWnd::OnClose();
}