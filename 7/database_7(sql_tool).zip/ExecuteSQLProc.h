// ExecuteSQLProc.h: interface for the CExecuteSQLProc class.
//

#if !defined(AFX_EXECUTESQLPROC_H__17AD8043_E4C3_11D2_A4A8_204C4F4F5020__INCLUDED_)
#define AFX_EXECUTESQLPROC_H__17AD8043_E4C3_11D2_A4A8_204C4F4F5020__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ChildFrm.h"

//////////////////////////////////////////////////////////////////////
// CExecuteSQLProc

UINT ExecuteSQLProc(LPVOID lpVoid);
UINT ExecuteSQLProcProc(LPVOID lpVoid);

class CExecuteSQLProc  
{
public:
	virtual ~CExecuteSQLProc();
	CExecuteSQLProc();
	static void PopulateGrid(ThreadParam* pTP);
	static void SetGridHeaderInfo(const MSFlexGridLib::IMSFlexGridPtr&
		ptrGridCtrl, CRecordsetEx* pSet);
	static long m_lRow;
};

#endif // !defined(AFX_EXECUTESQLPROC_H__17AD8043_E4C3_11D2_A4A8_204C4F4F5020__INCLUDED_)