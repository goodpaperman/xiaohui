// MySheet.cpp : implementation file
//
// This is a part of the Microsoft Foundation Classes C++ library.
// Copyright (C) 1992-1998 Microsoft Corporation
// All rights reserved.
//
// This source code is only intended as a supplement to the
// Microsoft Foundation Classes Reference and related
// electronic documentation provided with the library.
// See these sources for detailed information regarding the
// Microsoft Foundation Classes product.

#include "stdafx.h"
#include "QryTool.h"
#include "MySheet.h"
#include "catsets.h"
#include "DrvInfo.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// stolen from afximpl.h...
#define _countof(array) (sizeof(array)/sizeof(array[0]))

#define WM_NEW_DSN (WM_USER + 100)
/////////////////////////////////////////////////////////////////////////////
// CMyPropertySheet

IMPLEMENT_DYNAMIC(CMyPropertySheet, CPropertySheet)

CMyPropertySheet::CMyPropertySheet(UINT nIDCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(nIDCaption, pParentWnd, iSelectPage)
{
}

CMyPropertySheet::CMyPropertySheet(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(pszCaption, pParentWnd, iSelectPage)
{
	m_bCursorLib = FALSE;
}

CMyPropertySheet::~CMyPropertySheet()
{
}

BEGIN_MESSAGE_MAP(CMyPropertySheet, CPropertySheet)
	//{{AFX_MSG_MAP(CMyPropertySheet)
	ON_BN_CLICKED(IDOK, OnOK)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyPropertySheet message handlers

BOOL CMyPropertySheet::OnInitDialog()
{
	CWaitCursor wait;

	BOOL bRet = CPropertySheet::OnInitDialog();

	int rgiButtons[] = {IDOK, IDCANCEL, ID_APPLY_NOW, IDHELP};

	CRect rect;
	GetDlgItem(rgiButtons[0])->GetWindowRect(&rect);
	CFont* pFont = GetDlgItem(rgiButtons[0])->GetFont();
	ScreenToClient(&rect);
	int nDiff = rect.right - rect.left;
	rect.right = nDiff + 70;
	rect.left = 6;
	rect.top += 5;
	rect.bottom += 5;
	if(!m_static.Create(_T("Cursor Library Not Loaded"), WS_CHILD | WS_VISIBLE,
					rect, this, IDC_CURSOR_LIB))
		TRACE(_T("Error creating cursor library static.\n"));
	else
		m_static.SetFont(pFont);

	// Move OK
	CWnd* pWndTemp = GetDlgItem(rgiButtons[1]);
	pWndTemp->GetWindowRect(&rect);
	ScreenToClient(&rect);
	pWndTemp = GetDlgItem(rgiButtons[0]);
	pWndTemp->MoveWindow(&rect);
	pWndTemp->SetWindowText(_T("&Save As..."));

	// Move Cancel
	pWndTemp = GetDlgItem(rgiButtons[2]);
	pWndTemp->GetWindowRect(&rect);
	ScreenToClient(&rect);
	pWndTemp->ShowWindow(SW_HIDE);
	pWndTemp = GetDlgItem(rgiButtons[1]);
	pWndTemp->MoveWindow(&rect);
	pWndTemp->SetWindowText(_T("&Close"));

	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	ASSERT(pFrame != NULL);
	m_pChildFrame = (CChildFrame*)pFrame->MDIGetActive();
	ASSERT(m_pChildFrame != NULL);
	if(m_pChildFrame->m_database.IsOpen())
	{
		int nPages = GetPageCount();
		for(int i = 0; i < nPages; i++)
			((CMyPage*)GetPage(i))->OnNewDSN();
	}

	return bRet;
}

void CMyPropertySheet::OnOK()
{
	CWaitCursor wait;

	UpdateData(TRUE);

	UCHAR buffer[200];
	SWORD cbData;
	::SQLGetInfo(
		m_pChildFrame->m_database.m_hdbc, SQL_DRIVER_NAME, (PTR)buffer, 200, &cbData
		);
	CString sDriverName = buffer;
	int nPos = sDriverName.Find('.');
	if(nPos != -1)
		sDriverName = sDriverName.Left(nPos);
	CString strFilter = _T("Driver Info Files (*.txt)|*.txt|All Files(*.*)|*.*|");
	CFileDialog dlg(false, _T("txt"), sDriverName, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
				strFilter, this);
	
	if(dlg.DoModal() == IDOK)
	{
		CWaitCursor wait;

		CStdioFile file;
		CFileException e;
		CString sPathName = dlg.GetPathName();
		if(!file.Open(sPathName, CFile::typeText | CFile::modeCreate
			  | CFile::modeWrite, &e))
		{
			CString sBuff;
			sBuff.Format(_T("File Path Name: <%s> "), sPathName);
			sBuff += CHelpers::GetFileExceptionError(e.m_cause);
			AfxMessageBox(sBuff);
		}
		else
		{
			if(m_bCursorLib)
				file.WriteString(_T("Cursor Library is Loaded\n\n"));
			else
				file.WriteString(_T("Cursor Library is Not Loaded\n\n"));
			
			int nPages = GetPageCount();
			for(int i = 0; i < nPages; i++)
				((CMyPage*)GetPage(i))->DumpToFile(file);
			
			file.Close();
		}
	}
}