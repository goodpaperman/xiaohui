// StringEx.h header file
//

#if !defined(AFX_STRINGEX_H__EC4A985F_BA87_11D1_AE4F_204C4F4F5020__INCLUDED_)
#define AFX_STRINGEX_H__EC4A985F_BA87_11D1_AE4F_204C4F4F5020__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

//////////////////////////////////////////////////////////////////////
// StringEx.h

class CStringEx : public CString
{
public:
	CStringEx() : CString( ){};
	CStringEx(const CString& stringSrc) : CString(stringSrc){};
	int Find(LPCTSTR lpszSub, int nStartPos = 0) const;
	int FindNoCase(LPCTSTR lpszSub, int nStartPos = 0) const;
};

#endif // !defined(AFX_STRINGEX_H__EC4A985F_BA87_11D1_AE4F_204C4F4F5020__INCLUDED_)