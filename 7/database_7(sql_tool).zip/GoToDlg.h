#if !defined(AFX_GOTODLG_H__2E5DC683_88B3_11D3_A873_00C04F595ED0__INCLUDED_)
#define AFX_GOTODLG_H__2E5DC683_88B3_11D3_A873_00C04F595ED0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// GoToDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CGoToDlg dialog

class CGoToDlg : public CDialog
{
// Construction
public:
	CGoToDlg(CWnd* pParent = NULL);   // standard constructor
	~CGoToDlg();

// Dialog Data
	//{{AFX_DATA(CGoToDlg)
	enum { IDD = IDD_EDIT_GOTO };
	CString	m_strLine;
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGoToDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CGoToDlg)
	afx_msg void OnGoTo();
	afx_msg void OnClose();
	afx_msg void OnPrev();
	afx_msg void OnChangeLine();
	afx_msg void OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized);
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	bool PopulateLineNum();
	bool m_bPrev;
	bool m_bNext;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GOTODLG_H__2E5DC683_88B3_11D3_A873_00C04F595ED0__INCLUDED_)