// QryTool.h : main header file for the QRYTOOL application
//

#if !defined(AFX_QRYTOOL_H__E1966CB5_6232_11D3_A7CD_00C04F595ED0__INCLUDED_)
#define AFX_QRYTOOL_H__E1966CB5_6232_11D3_A7CD_00C04F595ED0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CQryToolApp:
// See QryTool.cpp for the implementation of this class
//

class CQryToolApp : public CWinApp
{
public:
	CQryToolApp();
	virtual ~CQryToolApp();
	CMultiDocTemplate* m_pDocTemplate;
	
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CQryToolApp)
	public:
	virtual BOOL InitInstance();
	virtual CDocument* OpenDocumentFile(LPCTSTR lpszFileName);
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CQryToolApp)
	afx_msg void OnAppAbout();
	afx_msg void OnUpdateFileMruFile1(CCmdUI* pCmdUI);
	afx_msg void OnFilePrintSetup();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	BOOL RegisterGridCtrl();
	bool IsGridCtrlRegistered();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_QRYTOOL_H__E1966CB5_6232_11D3_A7CD_00C04F595ED0__INCLUDED_)