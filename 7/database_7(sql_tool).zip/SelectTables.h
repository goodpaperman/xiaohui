#if !defined(AFX_SELECTTABLES_H__8466BCB3_0FF4_11D2_AEF9_204C4F4F5020__INCLUDED_)
#define AFX_SELECTTABLES_H__8466BCB3_0FF4_11D2_AEF9_204C4F4F5020__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// SelectTables.h : header file
//

#include "ChildFrm.h"

/////////////////////////////////////////////////////////////////////////////
// CSelectTables dialog

class CSelectTables : public CDialog
{
// Construction
public:
	CString m_strObjName;
	CString m_strType;
	CSelectTables(CWnd* pParent = NULL);   // standard constructor
	CString m_strSQL;

// Dialog Data
	//{{AFX_DATA(CSelectTables)
	enum { IDD = IDD_SELECT_TABLES };
	CButton	m_buttonTextOnly;
	CButton	m_buttonSystemTables;
	CButton	m_buttonViews;
	CListCtrlEx	m_ctrlList;
	BOOL	m_bTextOnly;
	CString	m_strSearch;
	//}}AFX_DATA
	
	CString m_strTableName;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSelectTables)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSelectTables)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnDblclkList1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnColumnclickList1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSystemTables();
	afx_msg void OnViews();
	afx_msg void OnChangeSearch();
	afx_msg void OnTextOnly();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	CString GetColumnListForTextDataSrc(const CString& sTable);
	bool GetColumnList(const CString& sTN, CString& sColumns);
	bool m_bSort;
	BOOL PopulateList();
	CChildFrame* m_pChildFrame;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SELECTTABLES_H__8466BCB3_0FF4_11D2_AEF9_204C4F4F5020__INCLUDED_)