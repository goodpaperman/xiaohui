// ExportDlg.cpp : implementation file
//

#include "stdafx.h"
#include "QryTool.h"
#include "ExportDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

LPCTSTR g_szExportOptions = _T("Grid\\Export Options");
LPCTSTR g_szFormat = _T("Format");
LPCTSTR g_szCoumnNames = _T("ColumnNames");
/////////////////////////////////////////////////////////////////////////////
// CExportDlg

IMPLEMENT_DYNAMIC(CExportDlg, CFileDialog)

CExportDlg::CExportDlg(BOOL bOpenFileDialog, LPCTSTR lpszDefExt, LPCTSTR lpszFileName,
		DWORD dwFlags, LPCTSTR lpszFilter, CWnd* pParentWnd) :
		CFileDialog(bOpenFileDialog, lpszDefExt, lpszFileName, dwFlags, lpszFilter, pParentWnd)
{
	m_ofn.Flags |= OFN_ENABLETEMPLATE;
	m_ofn.lpTemplateName = MAKEINTRESOURCE(IDD_EXPORT_DIALOG);
		
	m_bColumnNames = TRUE;
	m_strDelimiter = _T("Comma Seperated");

	m_bSaveSelection = false;
}

BEGIN_MESSAGE_MAP(CExportDlg, CFileDialog)
	//{{AFX_MSG_MAP(CExportDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL CExportDlg::OnInitDialog() 
{
	BOOL bRet = CFileDialog::OnInitDialog();

	if(bRet)
	{
		CComboBox* pCB = (CComboBox*)GetDlgItem(IDC_DELIMITER);
		pCB->AddString(_T("Comma Seperated"));
		pCB->AddString(_T("Tab Delimited"));
		pCB->AddString(_T("Pipe Seperated"));
		pCB->AddString(_T("<None>"));
		
		CWinApp* pApp = AfxGetApp();
		m_strDelimiter = pApp->GetProfileString(g_szExportOptions, g_szFormat);
		m_strDelimiter.TrimRight(); 
		m_strDelimiter.TrimLeft();
		if(m_strDelimiter.IsEmpty())
			m_strDelimiter = _T("Comma Seperated");
		pCB->SelectString(-1, m_strDelimiter);

		CButton* pB = (CButton*)GetDlgItem(IDC_COLUMNS);
		pB->SetCheck(pApp->GetProfileInt(g_szExportOptions, g_szCoumnNames, 1));
		pB->EnableWindow(m_bSaveSelection ? FALSE : TRUE);
	}
	
	return bRet;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CExportDlg::OnFileNameOK()
{
	BOOL bRet = CFileDialog::OnFileNameOK();
	
	if(!bRet)
	{
		CString sBuff;
		GetDlgItem(IDC_DELIMITER)->GetWindowText(sBuff);
		if(sBuff.Find(_T("Comma")) != -1)
			m_strDelimiter = _T(",");
		if(sBuff.Find(_T("Tab")) != -1)
			m_strDelimiter = _T("\t");
		if(sBuff.Find(_T("Pipe")) != -1)
			m_strDelimiter = _T("|");
		if(sBuff.Find(_T("<None>")) != -1)
			m_strDelimiter = _T("");
		
		CWinApp* pApp = AfxGetApp();
		pApp->WriteProfileString(g_szExportOptions, g_szFormat, sBuff);
		CButton* pB = (CButton*)GetDlgItem(IDC_COLUMNS);
		m_bColumnNames = pB->GetCheck();
		pApp->WriteProfileInt(g_szExportOptions, g_szCoumnNames, m_bColumnNames);
	}

	return bRet;
}
