// QryTool.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "QryTool.h"
#include "MainFrm.h"
#include "ChildFrm.h"
#include "QryToolDoc.h"
#include "QryView.h"
#include "StaticLink.h"
#include "ChildFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

LPCTSTR g_lpszProgID = _T("MSFlexGridLib.MSFlexGrid");
/////////////////////////////////////////////////////////////////////////////
// CQryToolApp

BEGIN_MESSAGE_MAP(CQryToolApp, CWinApp)
	//{{AFX_MSG_MAP(CQryToolApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_FILE_PRINT_SETUP, OnFilePrintSetup)
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CQryToolApp construction

CQryToolApp::CQryToolApp() :
	m_pDocTemplate(NULL)
{
}

CQryToolApp::~CQryToolApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CQryToolApp object

CQryToolApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CQryToolApp initialization

BOOL CQryToolApp::InitInstance()
{
	CWaitCursor wait;

	// Initialize OLE libraries
	if(!AfxOleInit())
	{
		AfxMessageBox(IDP_OLE_INIT_FAILED);
		return FALSE;
	}

	AfxEnableControlContainer();

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	if(!IsGridCtrlRegistered())
	{
		if(!RegisterGridCtrl())
		{
			CString sMsg = "<MsFlxGrd.ocx> not registered. Please register ";
					sMsg +="<MsFlxGrd.ocx> and then try again.";
			AfxMessageBox(sMsg);
			return FALSE;
		}
	}

	SetRegistryKey(_T("George Poulose"));

	LoadStdProfileSettings(9);  // Load standard INI file options (including MRU)

	m_pDocTemplate = new CMultiDocTemplate(
		IDR_QUERY_TYPE,
		RUNTIME_CLASS(CQryToolDoc),
		RUNTIME_CLASS(CChildFrame),
		RUNTIME_CLASS(CQryView));
	AddDocTemplate(m_pDocTemplate);
	
	CMainFrame* pMainFrame = new CMainFrame;
	if(!pMainFrame->LoadFrame(IDR_MAINFRAME))
		return FALSE;
	m_pMainWnd = pMainFrame;

	m_pMainWnd->DragAcceptFiles();

	EnableShellOpen();
	RegisterShellFileTypes(TRUE);

	if(m_lpCmdLine[0] == '\0')
	{
		pMainFrame->InitialShowWindow(m_nCmdShow);
		pMainFrame->UpdateWindow();
		pMainFrame->ConnectEx();
	}
	else
	{
		// Parse command line for standard shell commands, DDE, file open
		CCommandLineInfo cmdInfo;
		ParseCommandLine(cmdInfo);
		if(cmdInfo.m_nShellCommand == CCommandLineInfo::FileNew)
		{
			AfxMessageBox(_T("Usage: Standard shell commands, DDE, and file open only."));
			return FALSE;
		}
		
		pMainFrame->InitialShowWindow(m_nCmdShow);
		pMainFrame->UpdateWindow();
		if(!ProcessShellCommand(cmdInfo))
			TRACE(_T("Error processing shell command.\n"));
	}

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CQryToolApp commands

bool CQryToolApp::IsGridCtrlRegistered()
{
	bool bRet = false;
	
	CLSID clsid;
	HRESULT hr = AfxGetClassIDFromString(g_lpszProgID, &clsid);
	if(SUCCEEDED(hr))
		bRet = true;

	return bRet;
}

BOOL CQryToolApp::RegisterGridCtrl()
{
	TCHAR lpszPath[_MAX_PATH];
	DWORD dwLength = _MAX_PATH;
	BOOL bRet = ::SearchPath(NULL, _T("MsFlxGrd.ocx"), NULL, dwLength,
		lpszPath, NULL);
	if(bRet)
	{
		HINSTANCE hOCX = NULL;
#ifdef _AFXDLL	
		hOCX = AfxLoadLibrary(lpszPath);
#else
		hOCX = ::LoadLibrary(lpszPath);
#endif
		if(hOCX == NULL)
			bRet = FALSE;
		else
		{
#ifdef _UNICODE	
			USES_CONVERSION;
			if(FAILED((*(GetProcAddress(hOCX, W2CA(_T("DllRegisterServer")))))()))
			{
				TRACE(_T("DLLRegisterServer() Failed.\n"));
				bRet = FALSE;
			}
#else
			if(FAILED((*(GetProcAddress(hOCX, "DllRegisterServer")))()))
			{
				TRACE(_T("DLLRegisterServer() Failed.\n"));
				bRet = FALSE;
			}
#endif

#ifdef _AFXDLL			
			AfxFreeLibrary(hOCX);
#else
			::FreeLibrary(hOCX);
#endif
		}
	}

	return bRet;
}

void CQryToolApp::OnUpdateFileMruFile1(CCmdUI* pCmdUI) 
{
	if(pCmdUI->m_nIndex == 0)
		OnUpdateRecentFileMenu(pCmdUI);
}

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	CStatic	m_staticText;
	CString	m_strODBCVersion;
	CString	m_strBuildType;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	virtual BOOL OnInitDialog();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	COLORREF m_colorUnvisited;
	COLORREF m_colorVisited;
	BOOL m_bVisited;
	CStaticLink m_staticLink;
	CFont m_font;
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	m_strODBCVersion = _T("CDatabase::m_hdbc == NULL");
	m_strBuildType = _T("");
	//}}AFX_DATA_INIT

	m_colorUnvisited = RGB(0, 0, 255);	 // blue
	m_colorVisited   = RGB(128, 0, 128); // purple
	m_bVisited       = FALSE;
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	DDX_Control(pDX, IDC_URL_TEXT, m_staticText);
	DDX_Text(pDX, IDC_ADO_VERSION, m_strODBCVersion);
	DDX_Text(pDX, IDC_BUILD_TYPE, m_strBuildType);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	ON_WM_CTLCOLOR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// App command to run the dialog
void CQryToolApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

BOOL CAboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

#ifdef _UNICODE
	m_strBuildType = "(Unicode Build)";
#else
	m_strBuildType = "(MBCS Build)";
#endif
	
	CRect rect;
	m_staticText.GetWindowRect(&rect);
	ScreenToClient(&rect);
	if(!m_staticLink.Create(_T(""),	WS_CHILD | WS_VISIBLE, rect, this, IDC_EMAIL))
		TRACE(_T("Failed to create URL link.\n"));

	try
	{
		CMainFrame* pMainFrame = (CMainFrame*)AfxGetMainWnd();
		ASSERT(pMainFrame);
		CChildFrame* pFrame = (CChildFrame*)pMainFrame->MDIGetActive();
		if(pFrame != NULL && pFrame->m_database.IsOpen())
		{
			UCHAR buffer[200];
			SWORD cbData;
			::SQLGetInfo(
				pFrame->m_database.m_hdbc, SQL_ODBC_VER, (PTR)buffer, 200, &cbData
				);
			m_strODBCVersion = buffer;
		}
	}
	catch(...)
	{
		m_strODBCVersion = "<Unknown>";
	}

	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

HBRUSH CAboutDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hBr = NULL;
	if(pWnd != &m_staticText)
		hBr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	else
	{
		if(!(HFONT)m_font)
		{
			LOGFONT lf;
			GetFont()->GetObject(sizeof(lf), &lf);
			lf.lfUnderline = TRUE;
			m_font.CreateFontIndirect(&lf);
			pWnd->SetFont(&m_font);
		}
		
		pDC->SelectObject(&m_font);
		pDC->SetTextColor(m_staticLink.m_bVisited ? m_colorVisited : m_colorUnvisited);
		pDC->SetBkMode(TRANSPARENT);
				
		hBr = (HBRUSH)::GetStockObject(HOLLOW_BRUSH);
	}

	return hBr;	
}

/////////////////////////////////////////////////////////////////////////////
// CQryToolApp message handlers

CDocument* CQryToolApp::OpenDocumentFile(LPCTSTR lpszFileName) 
{
	CWaitCursor wait;
	CDocument* pDoc = NULL;
	CMainFrame* pMainFrame = (CMainFrame*)AfxGetMainWnd();
	ASSERT(pMainFrame != NULL);
	CChildFrame* pFrame = (CChildFrame*)pMainFrame->MDIGetActive();
	if(pFrame == NULL)
		pDoc = pMainFrame->ConnectEx(NULL, lpszFileName);
	else
	{
		pDoc = pFrame->GetActiveDocument();
		ASSERT(pDoc != NULL);
		if(!((CQryToolDoc*)pDoc)->SaveModified())
			pDoc = NULL;
		else
		{
			pFrame->m_wndStatusBar.SetPaneText(0, _T("Please wait..."));

			if(!pDoc->OnOpenDocument(lpszFileName))
				pDoc = NULL;
			else
				pDoc->SetPathName(lpszFileName);
		}
	}

	return pDoc;
}

void CQryToolApp::OnFilePrintSetup() 
{
	CWaitCursor wait;
	CWinApp::OnFilePrintSetup();
}