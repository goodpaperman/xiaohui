// Helpers.h: interface for the CHelpers class.
//

#if !defined(AFX_HELPERS_H__DF0ED2F1_BED3_11D2_BDAA_204C4F4F5020__INCLUDED_)
#define AFX_HELPERS_H__DF0ED2F1_BED3_11D2_BDAA_204C4F4F5020__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//////////////////////////////////////////////////////////////////////
// CHelpers

class CHelpers
{
public:
	static int Insert(CListCtrlEx* pListCtrl, CString& sRow, int nImage = -1,
		int nIndex = -1);
	static CString GetFileExceptionError(const int& nCause);
	~CHelpers();
private:
	CHelpers();
};

#endif // !defined(AFX_HELPERS_H__DF0ED2F1_BED3_11D2_BDAA_204C4F4F5020__INCLUDED_)