// ProceduresDlg.cpp : implementation file
//

#include "stdafx.h"
#include "QryTool.h"
#include "ProceduresDlg.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CProceduresDlg dialog

CProceduresDlg::CProceduresDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CProceduresDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CProceduresDlg)
	m_strSearch = _T("");
	//}}AFX_DATA_INIT

	m_nSelectedItem = 0;
	m_bSort = true;
}

void CProceduresDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CProceduresDlg)
	DDX_Control(pDX, IDC_LIST1, m_ctrlList);
	DDX_Text(pDX, IDC_SEARCH, m_strSearch);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CProceduresDlg, CDialog)
	//{{AFX_MSG_MAP(CProceduresDlg)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST1, OnDblclkList1)
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_LIST1, OnItemchangedList1)
	ON_NOTIFY(LVN_COLUMNCLICK, IDC_LIST1, OnColumnclickList1)
	ON_EN_CHANGE(IDC_SEARCH, OnChangeSearch)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CProceduresDlg message handlers

BOOL CProceduresDlg::OnInitDialog() 
{
	CWaitCursor wait;

	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	ASSERT(pFrame);
	m_pChildFrame = (CChildFrame*)pFrame->MDIGetActive();
	m_pChildFrame->m_wndStatusBar.SetPaneText(0, _T("Please wait..."));

	CDialog::OnInitDialog();

	LV_COLUMN lvcColumn;
	lvcColumn.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	lvcColumn.fmt = LVCFMT_LEFT;
	
	CRect rect;
	m_ctrlList.GetClientRect(&rect);
	CSize size = rect.Size();
	int nWidth = size.cx/2;
	lvcColumn.cx = nWidth;
	lvcColumn.pszText = _T("Name");
	lvcColumn.iSubItem = 0;
	m_ctrlList.InsertColumn(0, &lvcColumn);

	lvcColumn.cx = nWidth;
	lvcColumn.pszText = _T("Owner");
	lvcColumn.iSubItem = 1;
	m_ctrlList.InsertColumn(1, &lvcColumn);

	if(!PopulateList())
		SendMessage(WM_CLOSE);
	else
	{
		m_ctrlList.SetFullRowSel(TRUE);
		UpdateData(FALSE);
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CProceduresDlg::PopulateList()
{
	BOOL bRet = FALSE;

	try
	{
		CStoredProcedures set(&m_pChildFrame->m_database);
		bRet = set.Open();
		if(bRet)
		{
			CString sBuff;
			int nPos = -1;
			int nIndex = 0;
			while(!set.IsEOF())
			{
				nPos = set.m_strProcedureName.Find(';');
				if(nPos != -1)
					set.m_strProcedureName = set.m_strProcedureName.Left(nPos);

				sBuff = set.m_strProcedureName;

				if(!m_pChildFrame->m_bIsJetDriver &&
					set.m_strProcedureName.Find(' ') != -1) // MS SQL Server scenario
					sBuff = "[" + set.m_strProcedureName + "]";

				CHelpers::Insert(&m_ctrlList, sBuff + "|" +
					set.m_strProcedureOwner + "|", -1, nIndex++);

				set.MoveNext();			
			}

			m_ctrlList.SetItemState(0, LVIS_SELECTED | LVIS_FOCUSED,
						LVIS_SELECTED | LVIS_FOCUSED);
		}
	}
	catch(CDBException* e)
	{
	   if(e)
	   {
			CString sMsg;
			if(!e->m_strError.IsEmpty())
				sMsg.Format(_T("%s%s"), (LPCTSTR)e->m_strError, (LPCTSTR)e->m_strStateNativeOrigin);
			else
				sMsg = e->m_strStateNativeOrigin;

			e->Delete();

			AfxMessageBox(sMsg);
	   }
	}
	catch(CMemoryException* e)
	{
		AfxMessageBox(_T("Out-of-memory."));

		if(e)
			e->Delete();
	}
	catch(LPCTSTR e)
	{
		AfxMessageBox(e);
	}
	catch(...)
	{
		AfxMessageBox(_T("Errors occurred."));
	}

	if(!m_ctrlList.GetItemCount())
	{
		GetDlgItem(IDOK)->EnableWindow(FALSE);
		GetDlgItem(IDCANCEL)->SetWindowText(_T("&Close"));
	}

	return bRet;
}

void CProceduresDlg::OnDblclkList1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	CWaitCursor wait;

	if(GetDlgItem(IDOK)->IsWindowEnabled())
		OnOK();

	*pResult = 0;
}

void CProceduresDlg::OnOK() 
{
	CWaitCursor wait;

	m_strProcedureName = m_ctrlList.GetItemText(m_nSelectedItem, 0);

	CDialog::OnOK();
}

void CProceduresDlg::OnItemchangedList1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;

	if(pNMListView->uNewState)
		m_nSelectedItem = pNMListView->iItem;
	
	*pResult = 0;
}

void CProceduresDlg::OnColumnclickList1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	CWaitCursor wait;

	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;

	CSortColumn sort(&m_ctrlList, pNMListView->iSubItem, false);
	sort.Sort(m_bSort = !m_bSort);
	m_nSelectedItem = m_ctrlList.GetNextItem(-1, LVNI_SELECTED);

	*pResult = 0;
}

void CProceduresDlg::OnChangeSearch() 
{
	UpdateData(TRUE);

	LVFINDINFO findInfo;
	findInfo.flags = LVFI_PARTIAL | LVFI_STRING;
	findInfo.psz = (LPCTSTR)m_strSearch;
	int nItem = m_ctrlList.FindItem(&findInfo);
	m_ctrlList.SetItemState(nItem, LVIS_SELECTED, LVIS_SELECTED);
	m_ctrlList.EnsureVisible(nItem, TRUE);
}