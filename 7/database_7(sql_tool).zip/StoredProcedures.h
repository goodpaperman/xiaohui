// CStoredProcedures- Interface file

#pragma once

/////////////////////////////////////////////////////////////////////////////
// CStoredProcedures - results from ::SQLProcedures()

class CStoredProcedures : public CRecordsetEx
{
public:
	CStoredProcedures(CDatabase* pDatabase);
	DECLARE_DYNAMIC(CStoredProcedures)

// Field Data
	CString	m_strProcedureQualifier;
	CString	m_strProcedureOwner;
	CString	m_strProcedureName;
	CString	m_strRemarks;
	int	m_fProcedureType;

// Operations
	BOOL Open(LPCSTR pszProcQualifier = NULL,
			 LPCSTR pszProcOwner = NULL,
			 LPCSTR pszProcName = NULL,
			 UINT nOpenType = CRecordset::forwardOnly);
// Overrides
	virtual CString GetDefaultConnect();
	virtual CString GetDefaultSQL();
	virtual void DoFieldExchange(CFieldExchange*);

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};
