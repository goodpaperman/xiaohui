/////////////////////////////////////////////////////////////////////////////
// CStoredProcedure - Implementation file

#include "stdafx.h"
#include "StoredProcedures.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CStoredProcedures

IMPLEMENT_DYNAMIC(CStoredProcedures, CRecordsetEx)

CStoredProcedures::CStoredProcedures(CDatabase* pDatabase)
	: CRecordsetEx(pDatabase)
{
	m_strProcedureQualifier	= _T("");
	m_strProcedureOwner		= _T("");
	m_strProcedureName		= _T("");
	m_strRemarks			= _T("");
	m_fProcedureType		= 0;
	m_nFields = 5;
}

BOOL CStoredProcedures::Open(LPCSTR pszProcQualifier,
	LPCSTR pszProcOwner,LPCSTR pszProcName,
	UINT nOpenType)
{
	RETCODE	nRetCode;
	UWORD	bFunctionExists;

	// Make sure SQLProcedures is supported
	AFX_SQL_SYNC(::SQLGetFunctions(m_pDatabase->m_hdbc,
		SQL_API_SQLPROCEDURES, &bFunctionExists));
	if(!Check(nRetCode))
		AfxThrowDBException(nRetCode, m_pDatabase, m_hstmt);
	if(!bFunctionExists)
		throw _T("<::SQLProcedures> not supported.");

	// Cache state info and allocate hstmt
	SetState(nOpenType,NULL,readOnly);
	if(!AllocHstmt())
		return FALSE;

	TRY
	{
		OnSetOptions(m_hstmt);
		AllocStatusArrays();

		// Call the ODBC function
		AFX_ODBC_CALL(::SQLProcedures(m_hstmt,
			(UCHAR FAR*)pszProcQualifier,SQL_NTS,
			(UCHAR FAR*)pszProcOwner,SQL_NTS,
			(UCHAR FAR*)pszProcName,SQL_NTS));
	 	if(!Check(nRetCode))
			AfxThrowDBException(nRetCode, m_pDatabase, m_hstmt);

		// Allocate memory and cache info
		AllocAndCacheFieldInfo();
		AllocRowset();

		// Fetch the first row of data
		MoveNext();

		// If EOF, result set is empty, set BOF as well
		m_bBOF = m_bEOF;
	}

	CATCH_ALL(e)
	{
		Close();
		THROW_LAST();
	}
	END_CATCH_ALL

	return TRUE;
}

void CStoredProcedures::DoFieldExchange(CFieldExchange* pFX)
{
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Text(pFX,_T("PROCEDURE_QUALIFIER"),m_strProcedureQualifier);
	RFX_Text(pFX,_T("PROCEDURE_OWNER"),m_strProcedureOwner);
	RFX_Text(pFX,_T("PROCEDURE_NAME"),m_strProcedureName);
	RFX_Text(pFX,_T("REMARKS"),m_strRemarks);
	RFX_Int(pFX,_T("PROCEDURE_TYPE"),m_fProcedureType);
}

CString CStoredProcedures::GetDefaultConnect()
{ 
	return _T("ODBC;");
}

CString CStoredProcedures::GetDefaultSQL()
{ 
	return "!"; // Direct ODBC call
}

/////////////////////////////////////////////////////////////////////////////
// CStoredProcedures diagnostics

#ifdef _DEBUG
void CStoredProcedures::AssertValid() const
{
	CRecordsetEx::AssertValid();
}

void CStoredProcedures::Dump(CDumpContext& dc) const
{
	CRecordsetEx::Dump(dc);
}
#endif //_DEBUG