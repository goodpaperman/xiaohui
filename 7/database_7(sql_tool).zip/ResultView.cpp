// ResultView.cpp : implementation file
//

#include "stdafx.h"
#include "QryTool.h"
#include "ResultView.h"
#include "ChildFrm.h"
#include "ExportDlg.h"
#include "font.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

LPCTSTR g_szResult = _T("Result");
LPCTSTR g_szResultWordWrap = _T("WrapWord");
extern LPCTSTR szQueryFont;
extern LPCTSTR g_szResultFont;
extern LPCTSTR g_szGridFont;
extern LPCTSTR g_szMessages;
/////////////////////////////////////////////////////////////////////////////
// CResultView

IMPLEMENT_DYNCREATE(CResultView, CRichEditView)

CResultView::CResultView()
{
	m_nWordWrap = AfxGetApp()->GetProfileInt(g_szResult, g_szResultWordWrap, WrapNone);
	m_pGridCtrl = NULL;
}

CResultView::~CResultView()
{
	if(m_font.m_hObject != NULL)
	{
		m_font.Detach();
		m_font.m_hObject = NULL;
	}
}

BEGIN_MESSAGE_MAP(CResultView, CRichEditView)
	//{{AFX_MSG_MAP(CResultView)
	ON_WM_SIZE()
	ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
	ON_UPDATE_COMMAND_UI(ID_EDIT_COPY, OnUpdateEditCopy)
	ON_WM_CREATE()
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE, OnUpdateFileSave)
	ON_COMMAND(ID_FILE_PRINT, OnFilePrint)
	ON_COMMAND(ID_FILE_SAVE_AS, OnFileSaveAs)
	ON_WM_MOUSEACTIVATE()
	ON_UPDATE_COMMAND_UI(ID_FILE_PRINT, OnUpdateFilePrint)
	ON_COMMAND(ID_VIEW_WRAP_WORD, OnViewWrapWord)
	ON_UPDATE_COMMAND_UI(ID_VIEW_WRAP_WORD, OnUpdateViewWrapWord)
	ON_UPDATE_COMMAND_UI(ID_EDIT_PASTE, OnUpdateEditPaste)
	ON_WM_SETFOCUS()
	ON_COMMAND(ID_GRID_SAVE_SELECTION, OnGridSaveSelection)
	ON_COMMAND(ID_EDIT_SELECT_ALL, OnEditSelectAll)
	ON_UPDATE_COMMAND_UI(ID_EDIT_SELECT_ALL, OnUpdateEditSelectAll)
	ON_COMMAND(ID_VIEW_FONT, OnViewFont)
	ON_COMMAND(ID_EDIT_CLEAR_ALL, OnEditClearAll)
	ON_UPDATE_COMMAND_UI(ID_EDIT_CLEAR_ALL, OnUpdateEditClearAll)
	ON_UPDATE_COMMAND_UI(ID_EDIT_CUT, OnUpdateEditCut)
	ON_UPDATE_COMMAND_UI(ID_EDIT_REPLACE, OnUpdateEditReplace)
	//}}AFX_MSG_MAP
	ON_COMMAND(ID_FILE_PRINT, CRichEditView::OnFilePrint)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CResultView diagnostics

#ifdef _DEBUG
void CResultView::AssertValid() const
{
	CRichEditView::AssertValid();
}

void CResultView::Dump(CDumpContext& dc) const
{
	CRichEditView::Dump(dc);
}

CQryToolDoc* CResultView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CQryToolDoc)));
	return (CQryToolDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CResultView message handlers

void CResultView::OnSize(UINT nType, int cx, int cy) 
{
	CRichEditView::OnSize(nType, cx, cy);
	
	if(m_pGridCtrl != NULL && m_pGridCtrl->m_hWnd != NULL)
	{
		m_pGridCtrl->MoveWindow(0, 0, cx, cy);
		m_pGridCtrl->Invalidate();
		m_pGridCtrl->UpdateWindow();
		Invalidate();
		UpdateWindow();
	}
}

void CResultView::OnEditCopy()
{
	CWaitCursor wait;

	bool bCopyGrid = m_pGridCtrl && ::IsWindow(m_pGridCtrl->m_hWnd) &&
				m_pGridCtrl->IsWindowVisible();
	if(!bCopyGrid)
		GetRichEditCtrl().Copy();
	else
	{
		if(m_pChildFrame->m_bExecuting)
		{
			m_pGridCtrl->Invalidate();
			m_pGridCtrl->UpdateWindow();
		}
		
#ifdef _UNICODE
		AfxMessageBox(_T("Not implemented yet."));
#else
		CopyGridData();
#endif

		if(m_pChildFrame->m_bExecuting)
		{
			m_pGridCtrl->Invalidate();
			m_pGridCtrl->UpdateWindow();
		}
	}
}

void CResultView::CopyGridData()
{
	m_pChildFrame->m_wndStatusBar.SetPaneText(0, _T("Copying..."));
	
	long lCol = m_pGridCtrl->GetCol();
	long lRow = m_pGridCtrl->GetRow();
	long lColSel = m_pGridCtrl->GetColSel();
	long lRowSel = m_pGridCtrl->GetRowSel();
	if(lColSel < lCol)
	{
		lCol = lColSel;
		lColSel = m_pGridCtrl->GetCol();
	}
	if(lRowSel < lRow)
	{
		lRow = lRowSel;
		lRowSel = m_pGridCtrl->GetRow();
	}
	CSharedFile memFile(GMEM_MOVEABLE | GMEM_DDESHARE | GMEM_ZEROINIT);
	CString sBuff;
	USES_CONVERSION;
	for(long lR = lRow; lR <= lRowSel; lR++)
	{
		for(long lC = lCol; lC <= lColSel; lC++)
		{
			sBuff = m_pGridCtrl->GetTextMatrix(lR, lC);
			memFile.Write(T2A(const_cast<LPTSTR>((LPCTSTR)sBuff)), sBuff.GetLength());
			if(lC < lColSel)
				memFile.Write(_T("\t"), lstrlen(_T("\t")));
		}
		if(lR < lRowSel)
			memFile.Write(_T("\n"), lstrlen(_T("\n")));
	}

	COleDataSource* pDataSource = new COleDataSource;
	ASSERT(pDataSource);
	pDataSource->CacheGlobalData(CF_TEXT, memFile.Detach());
	pDataSource->SetClipboard();
}

void CResultView::OnUpdateEditCopy(CCmdUI* pCmdUI) 
{
	long lStart = -1;
	long lEnd = -1;
	GetRichEditCtrl().GetSel(lStart, lEnd);
	bool bEnable = (m_pGridCtrl && ::IsWindow(m_pGridCtrl->m_hWnd) &&
		m_pGridCtrl->IsWindowVisible()) || (lEnd-lStart);
	pCmdUI->Enable(bEnable);
}

int CResultView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if(CRichEditView::OnCreate(lpCreateStruct) == -1)
		return -1;

	m_pChildFrame = (CChildFrame*)GetParentFrame();

	GetRichEditCtrl().SetReadOnly();

	LOGFONT lf;
	memset(&lf, 0, sizeof(lf));
	m_pChildFrame->GetProfileFont(
		g_szResultFont,
		&lf,
		false, 
		NULL,
		NULL
		);
	if(lf.lfHeight == 0)
	{
		lf.lfHeight = -15;
		lf.lfWeight = 400;
		_tcscpy(lf.lfFaceName, _T("Courier"));
	}
	if(!m_font.CreateFontIndirect(&lf))
		TRACE(_T("Could Not create font.\n"));

	if(m_font.m_hObject != NULL)
		GetRichEditCtrl().SetFont(&m_font);

	return 0;
}

void CResultView::OnUpdateFileSave(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(FALSE);
}

void CResultView::OnFilePrint() 
{
	CWaitCursor wait;
	
	CDocument* pDoc = m_pChildFrame->GetActiveDocument();
	ASSERT(pDoc != NULL);
	CString sTitle = pDoc->GetTitle();
	if(sTitle.IsEmpty())
		sTitle = "Untitled.";
	if(m_strObjName.IsEmpty())
		m_strObjName = "Untitled";
	m_pChildFrame->LockWindowUpdate();
	pDoc->SetTitle(m_strObjName);
	CRichEditView::OnFilePrint();
	pDoc->SetTitle(sTitle);
	m_pChildFrame->UnlockWindowUpdate();
}

void CResultView::OnGridSaveSelection() 
{
	if(m_pChildFrame->m_bExecuting)
	{
		m_pGridCtrl->Invalidate();
		m_pGridCtrl->UpdateWindow();
	}
	
	if(!ExportResults(true))
		TRACE(_T("Error exporting results.\n"));
	
	if(m_pChildFrame->m_bExecuting)
	{
		m_pGridCtrl->Invalidate();
		m_pGridCtrl->UpdateWindow();
	}
}

void CResultView::OnFileSaveAs() 
{
	CWaitCursor wait;
	
	bool bExport = m_pGridCtrl && ::IsWindow(m_pGridCtrl->m_hWnd) &&
		m_pGridCtrl->IsWindowVisible();

	if(bExport)
	{
		if(!ExportResults())
			TRACE(_T("Error exporting results.\n"));
	}
	else
	{
		CStringEx sBuff;
		GetRichEditCtrl().GetWindowText(sBuff);
		CString strFilter, sDefaultExt;
		if(!m_strObjName.IsEmpty() && sBuff.FindNoCase(m_strObjName) != -1)
		{
			sDefaultExt = _T("qry");
			strFilter = _T("Query Files (*.qry)|*.qry|All Files (*.*)|*.*|");
		}
		else
		{
			sDefaultExt = _T("txt");
			strFilter = _T("Text Files (*.txt)|*.txt|All Files(*.*)|*.*|");
			m_strObjName = _T("Untitled");
		}
    
		CFileDialog dlg(false, sDefaultExt, m_strObjName, OFN_HIDEREADONLY |
			OFN_OVERWRITEPROMPT, strFilter, this);
		if(dlg.DoModal() == IDOK)
		{
			CWaitCursor wait;

			CString sBuff;
			CString sPathName = dlg.GetPathName();

			CStdioFile file;
			CFileException fileException;
			if(!file.Open(sPathName, CFile::typeText | CFile::modeCreate |  
						CFile::modeWrite, &fileException))
			{
				sBuff.Format(_T("File Path Name: <%s> "), sPathName);
				sBuff += CHelpers::GetFileExceptionError(fileException.m_cause);
				AfxMessageBox(sBuff);
			}
			else
			{
				GetRichEditCtrl().GetWindowText(sBuff);
				file.WriteString(sBuff);
			}
		}
	}
}

int CResultView::OnMouseActivate(CWnd* pDesktopWnd, UINT nHitTest, UINT message) 
{
	const MSG* pMsg = GetCurrentMessage();
	GetParent()->SendMessage(WM_MOUSEACTIVATE, pMsg->wParam, pMsg->lParam);	

	return CRichEditView::OnMouseActivate(pDesktopWnd, nHitTest, message);
}

HMENU CResultView::GetContextMenu(WORD /*wSelType*/, LPOLEOBJECT /*lpOleObj*/,
							   CHARRANGE* /*lpChrg*/)
{ 
	bool bOkToInvokeGridMenu = m_pGridCtrl && ::IsWindow(m_pGridCtrl->m_hWnd) &&
		m_pGridCtrl->IsWindowVisible();
	if(bOkToInvokeGridMenu)
		InvokeGridMenu();
	else
	{
		CMenu menu;
		if(menu.LoadMenu(IDR_RCLICK))
		{
			CMenu* pMenu = menu.GetSubMenu(2);
			ASSERT(pMenu);
			int nTextLength = GetRichEditCtrl().GetTextLength();
			if(!nTextLength)
			{
				pMenu->EnableMenuItem(ID_EDIT_SELECT_ALL, MF_BYCOMMAND | MF_GRAYED);
				pMenu->EnableMenuItem(ID_EDIT_CLEAR, MF_BYCOMMAND | MF_GRAYED);
			}

			long lStart = -1;
			long lEnd = -1;
			GetRichEditCtrl().GetSel(lStart, lEnd);
			if(lEnd-lStart == 0)
				pMenu->EnableMenuItem(ID_EDIT_COPY, MF_BYCOMMAND | MF_GRAYED);

			CPoint point;
			::GetCursorPos(&point);
			pMenu->TrackPopupMenu(0, point.x, point.y, this);
		}
	}

	return NULL;
}

void CResultView::OnUpdateFilePrint(CCmdUI* pCmdUI) 
{
	bool bEnable = (m_pGridCtrl != NULL && ::IsWindow(m_pGridCtrl->m_hWnd) &&
		m_pGridCtrl->IsWindowVisible());
	pCmdUI->Enable(!bEnable);
}

void CResultView::OnViewWrapWord() 
{
	m_nWordWrap = (m_nWordWrap == WrapNone) ? WrapToWindow : WrapNone;
	WrapChanged();
	AfxGetApp()->WriteProfileInt(g_szResult, g_szResultWordWrap, m_nWordWrap);
}

void CResultView::OnUpdateViewWrapWord(CCmdUI* pCmdUI) 
{
	bool bEnable = (m_pGridCtrl != NULL && ::IsWindow(m_pGridCtrl->m_hWnd) &&
		m_pGridCtrl->IsWindowVisible());
	pCmdUI->Enable(!bEnable);
	pCmdUI->SetCheck(m_nWordWrap == WrapToWindow);
}

void CResultView::SetWrapNone()
{
	if(m_nWordWrap == WrapToWindow)
	{
		m_nWordWrap = WrapNone;
		WrapChanged();
	}
}

void CResultView::SetWrapToWindow()
{
	if(m_nWordWrap == WrapNone)
	{
		m_nWordWrap = WrapToWindow;
		WrapChanged();
	}
}

void CResultView::OnUpdateEditReplace(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(FALSE);
}

void CResultView::OnUpdateEditCut(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(FALSE);	
}

void CResultView::OnUpdateEditPaste(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(FALSE);
}

void CResultView::OnSetFocus(CWnd* pOldWnd) 
{
	bool bFocus = m_pGridCtrl && ::IsWindow(m_pGridCtrl->m_hWnd) &&
		m_pGridCtrl->IsWindowVisible();
	if(!bFocus)
		CRichEditView::OnSetFocus(pOldWnd);
	else
		m_pGridCtrl->SetFocus();
}

BOOL CResultView::ExportResults(const bool& bSaveSelection)
{
	CWaitCursor wait;

	BOOL bRet = FALSE;

	CString strFilter = _T("Export Files (*.csv)|*.csv|All Files(*.*)|*.*|");
	CExportDlg dlg(false, _T("csv"), _T("Untitled"), OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
				strFilter, this);
	dlg.m_bSaveSelection = bSaveSelection;
	if(bSaveSelection)
		dlg.m_ofn.lpstrTitle = _T("Save Selection");
	else
		dlg.m_ofn.lpstrTitle = _T("Save Grid Results");
	if(dlg.DoModal() != IDOK)
		return FALSE;	

	CString sBuff;
	CString sPathName = dlg.GetPathName();
	CStdioFile file;
	CFileException fileException;
	bRet = file.Open(sPathName, CFile::typeText | CFile::modeCreate |  
				CFile::modeWrite, &fileException);
	if(!bRet)
	{
		sBuff.Format(_T("File Path Name: <%s> "), sPathName);
		sBuff += CHelpers::GetFileExceptionError(fileException.m_cause);
		AfxMessageBox(sBuff);
	}
	else
	{
		if(!ExportToFile(&file, dlg.m_strDelimiter, dlg.m_bColumnNames, bSaveSelection))
		{
			TRACE(_T("Error exporting to file.\n"));
			file.Close();
			file.Remove(sPathName);
			bRet = FALSE;
		}
	}

	return bRet;
}

void CResultView::InvokeGridMenu()
{
	CWaitCursor wait;

	CMenu menu;
	if(menu.LoadMenu(IDR_RCLICK))
	{
		CMenu* pMenu = menu.GetSubMenu(1);
		if(pMenu)
		{
			CPoint point;
			::GetCursorPos(&point);
			pMenu->TrackPopupMenu(0, point.x, point.y, this);
		}
	}
}

BOOL CResultView::ExportToFile(CStdioFile* pFile, LPCTSTR lpszDelimiter,
	const BOOL& bColumnNames, const bool& bSaveSelection)
{
	CWaitCursor wait;

	BOOL bRet = TRUE;

	ASSERT(pFile && pFile->m_pStream);

	if(bSaveSelection)
	{
		m_pChildFrame->m_wndStatusBar.SetPaneText(0, _T("Saving selection..."));

		long lCol = m_pGridCtrl->GetCol();
		long lRow = m_pGridCtrl->GetRow();
		long lColSel = m_pGridCtrl->GetColSel();
		long lRowSel = m_pGridCtrl->GetRowSel();
		if(lColSel < lCol)
		{
			lCol = lColSel;
			lColSel = m_pGridCtrl->GetCol();
		}
		if(lRowSel < lRow)
		{
			lRow = lRowSel;
			lRowSel = m_pGridCtrl->GetRow();
		}
		for(long lR = lRow; lR <= lRowSel; lR++)
		{
			for(long lC = lCol; lC <= lColSel; lC++)
			{
				pFile->WriteString(m_pGridCtrl->GetTextMatrix(lR, lC));
				if(lC < lColSel)
					pFile->WriteString(lpszDelimiter);
			}
			if(lR < lRowSel)
				pFile->WriteString(_T("\n"));
		}
	}
	else
	{
		m_pChildFrame->m_wndStatusBar.SetPaneText(0, _T("Saving grid results..."));

		CMSFlexGrid* pGrid = NULL;
		long lCols = 0;
		long lRows = 0;
		for(POSITION pos = m_pChildFrame->m_GridList.GetHeadPosition(); pos != NULL;)
		{
			pGrid = (CMSFlexGrid*)m_pChildFrame->m_GridList.GetNext(pos);
			ASSERT(pGrid);
			lCols = pGrid->GetCols();
			lRows = pGrid->GetRows();
			for(long lR = (bColumnNames ? 0 : 1); lR < lRows; lR++)
			{
				for(long lC = 0; lC < lCols; lC++)
				{
					pFile->WriteString(pGrid->GetTextMatrix(lR, lC));
					if(lC < lCols-1)
						pFile->WriteString(lpszDelimiter);
				}
				if(lR < lRows)
					pFile->WriteString(_T("\n"));
			}

			pFile->WriteString(_T("\n"));
		}
	}
	
	pFile->Close();

	return bRet;
}

void CResultView::OnInitialUpdate() 
{
	CRichEditView::OnInitialUpdate();

	SetMargins(CRect(720, 720, 720, 720));
}

BOOL CResultView::OnPreparePrinting(CPrintInfo* pInfo) 
{
	BOOL bRet = DoPreparePrinting(pInfo);

	if(pInfo->m_pPD->GetDevMode()->dmOrientation == DMORIENT_LANDSCAPE)
	{
		CString sMsg = "Currently printing functionality is not supported for ";
				sMsg +="landscape mode. Please choose portrait mode and then try ";
				sMsg +="again.";
		AfxMessageBox(sMsg);
		bRet = FALSE;
	}
		
	return bRet;
}

BOOL CResultView::PreTranslateMessage(MSG* pMsg) 
{
	if(m_pGridCtrl && ::IsWindow(m_pGridCtrl->m_hWnd) &&
		m_pGridCtrl->IsWindowVisible())
	{
		if(pMsg->message == WM_KEYDOWN)
		{
			if(pMsg->wParam == VK_RETURN)
				::MessageBeep(MB_ICONEXCLAMATION);
			else
				PreTranslateInput(pMsg);
		}
	}
	
	return CRichEditView::PreTranslateMessage(pMsg);
}

void CResultView::OnEditSelectAll() 
{
	bool bGridSelectAll = m_pGridCtrl && ::IsWindow(m_pGridCtrl->m_hWnd) &&
				m_pGridCtrl->IsWindowVisible();
	if(!bGridSelectAll)
		GetRichEditCtrl().SetSel(0, -1);
	else
	{
		m_pGridCtrl->SetRow(1);
		m_pGridCtrl->SetCol(0);
		m_pGridCtrl->SetRowSel(m_pGridCtrl->GetRows()-1);
		m_pGridCtrl->SetColSel(m_pGridCtrl->GetCols()-1);
	}
}

void CResultView::OnUpdateEditSelectAll(CCmdUI* pCmdUI) 
{
	bool bEnable = (m_pGridCtrl && ::IsWindow(m_pGridCtrl->m_hWnd) &&
		m_pGridCtrl->IsWindowVisible() && m_pGridCtrl->GetRows() > 1) ||
		GetRichEditCtrl().GetTextLength();
	pCmdUI->Enable(bEnable);	
}

void CResultView::OnViewFont() 
{
	bool bGridFont = m_pGridCtrl && ::IsWindow(m_pGridCtrl->m_hWnd) &&
			m_pGridCtrl->IsWindowVisible();
	if(!bGridFont)
		SetResultViewFont();
	else
	{
		try
		{
			if(m_pChildFrame->m_bExecuting)
			{
				m_pGridCtrl->Invalidate();
				m_pGridCtrl->UpdateWindow();
			}
			
			SetGridFont();

			if(m_pChildFrame->m_bExecuting)
			{
				m_pGridCtrl->Invalidate();
				m_pGridCtrl->UpdateWindow();
			}
		}
		catch(COleDispatchException* e)
		{
			if(e)
			{
				AfxMessageBox(e->m_strDescription);
				e->Delete();
			}
		}
		catch(...)
		{
			AfxMessageBox(_T("Errors occurred."));
		}
	}
}

void CResultView::SetGridFont()
{
	COleFont font(m_pGridCtrl->GetFont());
	LOGFONT lf;
	memset(&lf, 0, sizeof(lf));
	lf.lfCharSet = font.GetCharset();
	lf.lfItalic = font.GetItalic();
	lstrcpyn((TCHAR*)lf.lfFaceName, font.GetName(), sizeof(lf.lfFaceName));
	lf.lfStrikeOut = font.GetStrikethrough();
	lf.lfUnderline = font.GetUnderline();
	lf.lfWeight = font.GetWeight();
	CDC dc;
	dc.Attach(::GetDC(NULL));
	CY cy = font.GetSize();
	lf.lfHeight = MulDiv(cy.Lo/10000, dc.GetDeviceCaps(LOGPIXELSY), 72);
	::ReleaseDC(NULL, dc.Detach());
 	CFontDialog dlg(&lf, CF_SCREENFONTS | CF_INITTOLOGFONTSTRUCT);
	if(dlg.DoModal() == IDOK)
	{
		CWaitCursor wait;
		CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
		ASSERT(pFrame != NULL);
		CChildFrame* pChild = NULL;
		std::list<CChildFrame*>::const_iterator i;
		int nGridCount = -1;
		CMSFlexGrid* pGrid = NULL;
		for(i = pFrame->m_listChildFrame.begin();
			i != pFrame->m_listChildFrame.end(); ++i)
		{
			pChild = (*i);
			if(pChild != NULL)
			{
				pChild->m_GridFont.m_lf = *dlg.m_cf.lpLogFont;
				pChild->m_GridFont.m_bIsBold = dlg.IsBold();
				pChild->m_GridFont.m_strFaceName = dlg.GetFaceName();
				pChild->m_GridFont.m_bIsBold = dlg.IsBold();
				pChild->m_GridFont.m_nSize = dlg.GetSize()*1000;

				for(int n = 0; n < pChild->m_nGridCount; n++)
				{
					pGrid = (CMSFlexGrid*)pChild->m_GridList.GetAt(
						pChild->m_GridList.FindIndex(n));
					if(pGrid != NULL)
					{
						font = pGrid->GetFont();
						font.SetBold(dlg.IsBold());
						font.SetCharset(dlg.m_cf.lpLogFont->lfCharSet);
						font.SetItalic(dlg.m_cf.lpLogFont->lfItalic);
						font.SetName(dlg.GetFaceName());
						cy.Lo = dlg.GetSize()*1000;
						cy.Hi = 0;
						cy.int64 = cy.Lo;
						font.SetSize(cy);
						font.SetUnderline(dlg.m_cf.lpLogFont->lfUnderline);
						font.SetWeight(dlg.m_cf.lpLogFont->lfWeight);
					}
				}
			}
		}
		
		if(pChild != NULL)
			pChild->WriteProfileFont(
				g_szGridFont,
				&pChild->m_GridFont.m_lf,
				true,
				&pChild->m_GridFont.m_bIsBold,
				&pChild->m_GridFont.m_nSize
				);
	}
}

void CResultView::SetResultViewFont()
{
	LOGFONT lf;
	if(m_font.m_hObject != NULL)
		m_font.GetObject(sizeof(LOGFONT), &lf);
	else
		::GetObject(GetStockObject(SYSTEM_FONT), sizeof(LOGFONT), &lf);
	CFontDialog dlg(&lf, CF_SCREENFONTS | CF_INITTOLOGFONTSTRUCT);
	if(dlg.DoModal() == IDOK)
	{
		CWaitCursor wait;
		CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
		ASSERT(pFrame != NULL);
		CChildFrame* pChild = NULL;
		std::list<CChildFrame*>::const_iterator i;
		long nStart = -1;
		long nEnd = -1;
		for(i = pFrame->m_listChildFrame.begin();
				i != pFrame->m_listChildFrame.end(); ++i)
		{
			pChild = (*i);
			if(pChild != NULL)
			{
				if(pChild->m_pResultView->m_font.m_hObject != NULL)
					pChild->m_pResultView->m_font.DeleteObject();
				if(pChild->m_pResultView->m_font.CreateFontIndirect(&lf))
					pChild->m_pResultView->SetFontEx();
			}
		}
		
		if(pChild != NULL)
			pChild->WriteProfileFont(
				g_szResultFont,
				dlg.m_cf.lpLogFont,
				false,
				NULL,
				NULL
				);
	}
}

void CResultView::SetFontEx()
{
	long nStart = -1;
	long nEnd = -1;
	CRichEditCtrl& edit = GetRichEditCtrl();
	edit.GetSel(nStart, nEnd);
	edit.SetSel(0, 0);
	edit.SetFont(&m_font, TRUE);
	edit.SetSel(nStart, nEnd);
	edit.Invalidate();
	edit.UpdateWindow();
}

void CResultView::OnEditClearAll() 
{
	CString sMsg = "The requested operation cannot be undone. Are you sure you wish to continue?";
	if(AfxMessageBox(sMsg, MB_YESNO | MB_ICONQUESTION) == IDYES)
	{
		bool bGridClear = (m_pGridCtrl && ::IsWindow(m_pGridCtrl->m_hWnd) &&
				m_pGridCtrl->IsWindowVisible());
		if(!bGridClear)
		{	
			if(!m_pChildFrame->m_strStatusText.CompareNoCase(g_szMessages))
				m_pChildFrame->m_strMessages.erase();
			else
			{
				if(m_pChildFrame->m_strProcText.length())
					m_pChildFrame->m_strProcText.erase();
			}
			GetRichEditCtrl().SetWindowText(NULL);
			Invalidate();
			UpdateWindow();
		}
		else
		{
			m_pChildFrame->m_pQryView->SetFocus();
			m_pChildFrame->OnExceptionClear("");
			SetFocus();
		}

		m_pChildFrame->OnViewMessages();

		if(!m_pChildFrame->m_strMessages.length() && !m_pChildFrame->m_nGridCount &&
			!m_pChildFrame->m_strProcText.length())
		{
			m_pChildFrame->m_strPaneTextZero = "Ready";
			m_pChildFrame->m_wndStatusBar.SetPaneText(0, m_pChildFrame->m_strPaneTextZero);
			
			m_pChildFrame->m_strExecutionTime = "Exec time: 00:00:00";
			m_pChildFrame->m_wndStatusBar.SetPaneText(
				m_pChildFrame->m_nExecutionTimePaneNo, m_pChildFrame->m_strExecutionTime
				);
			
			try
			{
				if(m_pChildFrame->m_database.IsOpen())
					m_pChildFrame->m_strStatusText = "CDatabase::IsOpen == TRUE";
				else
					m_pChildFrame->m_strStatusText = "CDatabase::IsOpen == FALSE";
				m_pChildFrame->m_wndStatusBar.SetPaneText(
					2, m_pChildFrame->m_strStatusText
					);
			}
			catch(...)
			{
				m_pChildFrame->m_strStatusText = "Results grid #0 of 0; 0 row(s); 0 col(s)";
				m_pChildFrame->m_wndStatusBar.SetPaneText(
					2, m_pChildFrame->m_strStatusText
					);
			}
		}
	}
}

void CResultView::OnUpdateEditClearAll(CCmdUI* pCmdUI) 
{
	bool bEnable = (m_pGridCtrl && ::IsWindow(m_pGridCtrl->m_hWnd) &&
		m_pGridCtrl->IsWindowVisible());
	pCmdUI->Enable((bEnable || GetRichEditCtrl().GetTextLength()) &&
		!m_pChildFrame->m_bExecuting);		
}