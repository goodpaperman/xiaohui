-------------------------------------
Query Tool (using ODBC) -- Readme.txt
-------------------------------------

(c) 1999 George Poulose. All rights reserved.

Known Problems
--------------
1. <None>.

License Info
------------
This product is licensed. However, distributing the software with other products
(commercial or otherwise) without prior written permission of the author is strictly
prohibited.

Comments and Bug Report
-----------------------
If you have any comments, pl. send it to g.poulose@computer.org. If you are reporting
a bug, pl. include a reliable repro.

Acknowledgements
----------------
Thanks to Ronald Pihlgren of Microsoft Corporation for his <ODBCInfo> MFC database
sample. 

// __End_