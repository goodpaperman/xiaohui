// ExecuteSQLProc.cpp: implementation of the CExecuteSQLProc class.
//

#include "stdafx.h"
#include "QryTool.h"
#include "ExecuteSQLProc.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

long CExecuteSQLProc::m_lRow = 0;
//////////////////////////////////////////////////////////////////////
// CExecuteSQLProc

CExecuteSQLProc::CExecuteSQLProc()
{
}

CExecuteSQLProc::~CExecuteSQLProc()
{
}

UINT ExecuteSQLProc(LPVOID lpVoid)
{
	ThreadParam* pTP = (ThreadParam*)lpVoid;
	ASSERT(pTP != NULL);
	ASSERT(!pTP->m_strSQL.IsEmpty());
	CChildFrame* pChildFrame = pTP->m_pFrame;
	ASSERT(pChildFrame != NULL);
	bool bCaughtException = false;
	CString sBuff;
	try
	{
		CExecuteSQLProc::PopulateGrid(pTP);
	}
	catch(CDBException* e)
	{
		if(e)
		{
			if(!pChildFrame->m_bCanceled)
			{
				bCaughtException = true;
				
				if(pChildFrame->m_strMessages.length())
					pChildFrame->m_strMessages += _T("\n\n");
			
				if(!e->m_strError.IsEmpty())
					sBuff.Format(
						_T("%s%s"), (LPCTSTR)e->m_strError, (LPCTSTR)e->m_strStateNativeOrigin
						);
				else
					sBuff = e->m_strStateNativeOrigin;
				
				if(sBuff.IsEmpty())
					sBuff = "Errors occurred.";

				pChildFrame->m_strMessages += sBuff;
			}

			e->Delete();
	   }
	}
	catch(CMemoryException* e)
	{
		if(!pChildFrame->m_bCanceled)
		{
			bCaughtException = true;

			if(pChildFrame->m_strMessages.length())
				pChildFrame->m_strMessages += _T("\n\n");
			pChildFrame->m_strMessages += _T("Out-of-Memory.");
		}

		if(e)
			e->Delete();
	}
	catch(COleException* e)
	{
		if(!pChildFrame->m_bCanceled)
		{
			bCaughtException = true;

			if(e)
			{
				TCHAR szMsg[255];
				e->GetErrorMessage(szMsg, 255);
				
				if(pChildFrame->m_strMessages.length())
					pChildFrame->m_strMessages += _T("\n\n");
				pChildFrame->m_strMessages += szMsg;
			}
		}

		if(e)
			e->Delete();
	}
	catch(COleDispatchException* e)
	{
		if(!pChildFrame->m_bCanceled)
		{
			bCaughtException = true;

			if(e)
			{
				if(pChildFrame->m_strMessages.length())
					pChildFrame->m_strMessages += _T("\n\n");
				pChildFrame->m_strMessages += e->m_strDescription;
			}
		}

		if(e)
			e->Delete();
	}
	catch(LPCTSTR e)
	{
		if(!pChildFrame->m_bCanceled)
		{
			bCaughtException = true;
		
			if(pChildFrame->m_strMessages.length())
				pChildFrame->m_strMessages += _T("\n\n");
			pChildFrame->m_strMessages += e;
		}
	}
	catch(...)
	{
		if(!pChildFrame->m_bCanceled)
		{
			bCaughtException = true;

			if(pChildFrame->m_strMessages.length())
				pChildFrame->m_strMessages += _T("\n\n");
			pChildFrame->m_strMessages += _T("Errors occurred.");
		}
	}

	try
	{
		if(pChildFrame->m_bIsTSQLSupported && !pChildFrame->m_bCanceled)
		{
			if(pTP->m_strSQL.FindNoCase(_T("USE ")) != -1)
			{
				if(!pChildFrame->SelectDatabase())
					TRACE(_T("Error selecting database context.\n"));
			}
		}

		if(pChildFrame->m_bCanceled)
		{
			if(CExecuteSQLProc::m_lRow > 1)
				CExecuteSQLProc::m_lRow = --CExecuteSQLProc::m_lRow;
			if(pTP->m_pGridCtrl != NULL)
				::SendMessage(
					pChildFrame->m_hWnd, WM_SET_GRID_ROWS,
					CExecuteSQLProc::m_lRow, pChildFrame->m_bCanceled
					);
		}

		if(pTP->m_ptrGridCtrl != NULL)
		{
			pTP->m_ptrGridCtrl.Release();
			pTP->m_ptrGridCtrl = NULL;
		}
	}
	catch(...)
	{
		TRACE(_T("Errors occurred.\n"));
	}

	try
	{
		::PostMessage(
				pChildFrame->m_hWnd, WM_EXECUTION_COMPLETE, bCaughtException, -1
				);
	}
	catch(...)
	{
	}

	return 0;
}

void CExecuteSQLProc::PopulateGrid(ThreadParam* pTP)
{
	CChildFrame* pChildFrame = pTP->m_pFrame;
	ASSERT(pChildFrame != NULL);
	pChildFrame->CloseRecordset();
	if(!pChildFrame->m_bCanceled && pChildFrame->m_pSet->ExecDirect(pTP->m_strSQL))
	{
		long nCols = pChildFrame->m_pSet->GetODBCFieldCount();
		long lRow = 0;
		CString sBuff;
		_bstr_t bstrBuff;
		long lMaxRows =  700;
		_variant_t vCol((long)-1);
		SQLINTEGER nRowsAffected = -1;
		if(nCols == 0)
		{
			if(pChildFrame->m_bSQLRowCountSupported && !pChildFrame->m_bCanceled)
			{
				if(::SQLRowCount(pChildFrame->m_pSet->m_hstmt, &nRowsAffected) !=
					SQL_SUCCESS)
					TRACE(_T("Error getting rows affected info.\n"));
				
				if(nRowsAffected != -1)
					sBuff.Format(_T("(%d row(s) affected)"), nRowsAffected);
				if(pChildFrame->m_strMessages.length())
					pChildFrame->m_strMessages += _T("\n\n");
				pChildFrame->m_strMessages += sBuff;
			}
		}
		else
		{
			if(::SendMessage(pChildFrame->m_hWnd, WM_GET_GRID_CTRL,
				nCols, 0L) == -1)
				throw _T("Failed to create grid control.");
			if(!pChildFrame->m_bCanceled)
				CExecuteSQLProc::SetGridHeaderInfo(
					pTP->m_ptrGridCtrl, pChildFrame->m_pSet
					);
			if(!pChildFrame->m_bCanceled && !pChildFrame->m_pSet->IsBOF())
			{
				if(::SendMessage(pChildFrame->m_hWnd, WM_SET_GRID_ROWS,
					lMaxRows, 0L) == -1)
					throw _T("Unable to Allocate Memory for FlexGrid.");
					
				if(pChildFrame->m_bCanceled)
					CExecuteSQLProc::m_lRow = lRow+1;
		
				while(!pChildFrame->m_bCanceled && !pChildFrame->m_pSet->IsEOF())
				{
					if(lRow >= lMaxRows-1)
					{
						lMaxRows += 700;
						if(!pChildFrame->m_bCanceled)
							if(::SendMessage(pChildFrame->m_hWnd, WM_SET_GRID_ROWS,
								lMaxRows, 0L) == -1)
								throw _T("Unable to Allocate Memory for FlexGrid.");
						pTP->m_pGridCtrl->Invalidate();
						pTP->m_pGridCtrl->UpdateWindow();
					}

					++lRow;
					CExecuteSQLProc::m_lRow = lRow+1;
					for(int n = 0; n < nCols; n++)
					{
						try
						{
							pChildFrame->m_pSet->GetFieldValue(n, sBuff);
						}
						catch(CDBException* e)
						{
							if(e)
							{
								if(!pChildFrame->m_bCanceled)
									if(::SendMessage(pChildFrame->m_hWnd, WM_SET_GRID_ROWS,
										lRow+1, 0L) == -1)
										TRACE(_T("Unable to Allocate Memory for FlexGrid.\n"));
								
								throw e;
							}
						}
						bstrBuff = (LPCTSTR)sBuff;
						if(FAILED(pTP->m_ptrGridCtrl->put_TextMatrix(
							lRow, n, bstrBuff)))
						{
							if(::SendMessage(pChildFrame->m_hWnd, WM_SET_GRID_ROWS,
									lRow+1, 0L) == -1)
									TRACE(_T("Unable to Allocate Memory for FlexGrid\n"));
								throw _T("Subscript out of range.");
						}
					}

					if(!pChildFrame->m_bCanceled)
					{
						try
						{
							pChildFrame->m_pSet->MoveNext();
						}
						catch(CDBException* e)
						{
							if(e)
							{
								if(!pChildFrame->m_bCanceled)
								{
									if(::SendMessage(pChildFrame->m_hWnd, WM_SET_GRID_ROWS,
										lRow+1, 0L) == -1)
										TRACE(_T("Unable to Allocate Memory for FlexGrid\n"));
								
									sBuff.Format(
										_T("[%d row(s) affected (application specific)]"),
										lRow
										);
									if(pChildFrame->m_strMessages.length())
										pChildFrame->m_strMessages += _T("\n\n");
									pChildFrame->m_strMessages += sBuff;
								}

								throw e;
							}
						}
					}
				}
				if(::SendMessage(pChildFrame->m_hWnd, WM_SET_GRID_ROWS,
					lRow+1, 0L) == -1)
					throw _T("Unable to Allocate Memory for FlexGrid.");
			}

			if(pChildFrame->m_bCanceled)
				CExecuteSQLProc::m_lRow = lRow+1;
			else
			{
				sBuff.Format(
					_T("[%d row(s) affected (application specific)]"),
					lRow
					);
				if(pChildFrame->m_strMessages.length())
					pChildFrame->m_strMessages += _T("\n\n");
				pChildFrame->m_strMessages += sBuff;
			}
		}

		// while <::SQLMoreResults> loop. Also reset the cursor state
		while(pChildFrame->m_bIsMultiSetSupported && !pChildFrame->m_bCanceled &&
			pChildFrame->m_pSet->FlushResultSet())
		{   
			// Clean up the old column info and build new one
			pChildFrame->m_pSet->AllocAndCacheFieldInfo();
			nCols = pChildFrame->m_pSet->GetODBCFieldCount();
			lRow = 0;
			if(nCols == 0)
			{
				if(pChildFrame->m_bSQLRowCountSupported && !pChildFrame->m_bCanceled)
				{
					nRowsAffected = -1;
					if(::SQLRowCount(pChildFrame->m_pSet->m_hstmt, &nRowsAffected) !=
						SQL_SUCCESS)
						TRACE(_T("Error getting rows affected info.\n"));
					
					if(nRowsAffected != -1)
						sBuff.Format(_T("(%d row(s) affected)"), nRowsAffected);
					if(pChildFrame->m_strMessages.length())
						pChildFrame->m_strMessages += _T("\n\n");
					pChildFrame->m_strMessages += sBuff;
				}
			}
			else
			{
				if(::SendMessage(pChildFrame->m_hWnd, WM_GET_GRID_CTRL,
					nCols, 0L) == -1)
					throw _T("Failed to create grid control.");
				if(!pChildFrame->m_bCanceled)
					CExecuteSQLProc::SetGridHeaderInfo(
						pTP->m_ptrGridCtrl, pChildFrame->m_pSet
						);
				if(!pChildFrame->m_bCanceled && !pChildFrame->m_pSet->IsBOF())
				{
					if(::SendMessage(pChildFrame->m_hWnd, WM_SET_GRID_ROWS,
						lMaxRows, 0L) == -1)
						throw _T("Unable to Allocate Memory for FlexGrid.");
					
					if(pChildFrame->m_bCanceled)
						CExecuteSQLProc::m_lRow = lRow+1;
					
					try
					{
						pChildFrame->m_pSet->MoveNext();
					}
					catch(CDBException* e)
					{
						if(e)
						{
							if(!pChildFrame->m_bCanceled)
							{
								if(::SendMessage(pChildFrame->m_hWnd, WM_SET_GRID_ROWS,
									lRow+1, 0L) == -1)
									TRACE(_T("Unable to Allocate Memory for FlexGrid\n"));
							
								sBuff.Format(
									_T("[%d row(s) affected (application specific)]"),
									lRow
									);
								if(pChildFrame->m_strMessages.length())
									pChildFrame->m_strMessages += _T("\n\n");
								pChildFrame->m_strMessages += sBuff;
							}

							throw e;
						}
					}

					while(!pChildFrame->m_bCanceled && !pChildFrame->m_pSet->IsEOF())
					{     
						if(lRow >= lMaxRows-1)
						{
							lMaxRows += 700;
							if(!pChildFrame->m_bCanceled)
								if(::SendMessage(pChildFrame->m_hWnd, WM_SET_GRID_ROWS,
									lMaxRows, 0L) == -1)
									throw _T("Unable to Allocate Memory for FlexGrid.");
							pTP->m_pGridCtrl->Invalidate();
							pTP->m_pGridCtrl->UpdateWindow();
						}

						++lRow;
						CExecuteSQLProc::m_lRow = lRow+1;
						for(int n = 0; n < nCols; n++)
						{
							try
							{
								pChildFrame->m_pSet->GetFieldValue(n, sBuff);
							}
							catch(CDBException* e)
							{
								if(e)
								{
									if(!pChildFrame->m_bCanceled)
										if(::SendMessage(pChildFrame->m_hWnd, WM_SET_GRID_ROWS,
											lRow+1, 0L) == -1)
											TRACE(_T("Unable to Allocate Memory for FlexGrid.\n"));
									
									throw e;
								}
							}
							bstrBuff = (LPCTSTR)sBuff;
							if(FAILED(pTP->m_ptrGridCtrl->put_TextMatrix(
								lRow, n, bstrBuff)))
							{
								if(::SendMessage(pChildFrame->m_hWnd, WM_SET_GRID_ROWS,
										lRow+1, 0L) == -1)
										TRACE(_T("Unable to Allocate Memory for FlexGrid\n"));
									throw _T("Subscript out of range.");
							}
						}

						if(!pChildFrame->m_bCanceled)
						{
							try
							{
								pChildFrame->m_pSet->MoveNext();
							}
							catch(CDBException* e)
							{
								if(e)
								{
									if(!pChildFrame->m_bCanceled)
									{
										if(::SendMessage(pChildFrame->m_hWnd, WM_SET_GRID_ROWS,
											lRow+1, 0L) == -1)
											TRACE(_T("Unable to Allocate Memory for FlexGrid\n"));
									
										sBuff.Format(
											_T("[%d row(s) affected (application specific)]"),
											lRow
											);
										if(pChildFrame->m_strMessages.length())
											pChildFrame->m_strMessages += _T("\n\n");
										pChildFrame->m_strMessages += sBuff;
									}

									throw e;
								}
							}
						}
					}
					if(::SendMessage(pChildFrame->m_hWnd, WM_SET_GRID_ROWS,
						lRow+1, 0L) == -1)
						throw _T("Unable to Allocate Memory for FlexGrid.");
				}

				if(pChildFrame->m_bCanceled)
					CExecuteSQLProc::m_lRow = lRow+1;
				else
				{
					sBuff.Format(
						_T("[%d row(s) affected (application specific)]"),
						lRow
						);
					if(pChildFrame->m_strMessages.length())
						pChildFrame->m_strMessages += _T("\n\n");
					pChildFrame->m_strMessages += sBuff;
				}
			}
		}
	}
	pChildFrame->CloseRecordset();
}

void CExecuteSQLProc::SetGridHeaderInfo(const MSFlexGridLib::IMSFlexGridPtr&
	ptrGridCtrl, CRecordsetEx* pSet)
{
	ASSERT(ptrGridCtrl != NULL);
	ASSERT(pSet != NULL);

	CODBCFieldInfo fieldInfo;
	int nPrecision = 0;
	int nFieldLength = 0;
	int nArbitraryFactor = 110;
	int nCols = pSet->GetODBCFieldCount();
	UINT nMaxWidth = 50;
	for(int n = 0; n < nCols; n++)
	{
		pSet->GetODBCFieldInfo(n, fieldInfo);
		nFieldLength = fieldInfo.m_strName.GetLength();
		if(fieldInfo.m_nPrecision < (UDWORD)nFieldLength)
			nPrecision = nFieldLength;
		else if(fieldInfo.m_nPrecision > nMaxWidth)
			nPrecision = nMaxWidth;
		else
			nPrecision = fieldInfo.m_nPrecision;

		ptrGridCtrl->put_ColAlignment(
			n, MSFlexGridLib::flexAlignLeftCenter
			);
		ptrGridCtrl->put_ColWidth(
			n, (nPrecision+fieldInfo.m_nScale)*nArbitraryFactor
			);
		ptrGridCtrl->put_TextMatrix(
			0, n, (_bstr_t)fieldInfo.m_strName
			);
	}
}

UINT ExecuteSQLProcProc(LPVOID lpVoid)
{
	ThreadParam* pTP = (ThreadParam*)lpVoid;
	ASSERT(pTP != NULL);
	CChildFrame* pChildFrame = pTP->m_pFrame;
	ASSERT(pChildFrame != NULL);
	pChildFrame->m_strProcText.erase();
	bool bCaughtException = false;
	CString sBuff;
	try
	{
		pChildFrame->CloseRecordset();
		if(!pChildFrame->m_bCanceled && pChildFrame->m_pSet->ExecDirect(pTP->m_strSQL))
		{
			if(!pChildFrame->m_bCanceled && !pChildFrame->m_pSet->IsBOF() &&
				pChildFrame->m_pSet->GetODBCFieldCount())
			{
				while(!pChildFrame->m_bCanceled && !pChildFrame->m_pSet->IsEOF())
				{
					pChildFrame->m_pSet->GetFieldValue((short)0, sBuff);
					pChildFrame->m_strProcText += (LPCTSTR)sBuff;
					if(!pChildFrame->m_bCanceled)
						pChildFrame->m_pSet->MoveNext();
				}
			}
			
			// while <::SQLMoreResults> loop. Also, reset the cursor state
			// Microsoft SQL Server, SybaseSQLAnywhere, and Oracle will bail
			// here.
			while(!pChildFrame->m_bCanceled && pChildFrame->m_bIsMultiSetSupported &&
				pChildFrame->m_pSet->FlushResultSet())
			{							
				// Clean up the old column info and build  new one
				if(!pChildFrame->m_bCanceled)
					pChildFrame->m_pSet->AllocAndCacheFieldInfo();
				if(!pChildFrame->m_bCanceled && !pChildFrame->m_pSet->IsBOF() &&
					pChildFrame->m_pSet->GetODBCFieldCount())
				{
					pChildFrame->m_strProcText += _T("\n\n");

					if(!pChildFrame->m_bCanceled)
						pChildFrame->m_pSet->MoveNext();

					while(!pChildFrame->m_bCanceled && !pChildFrame->m_pSet->IsEOF())
					{
						pChildFrame->m_pSet->GetFieldValue((short)0, sBuff);
						pChildFrame->m_strProcText += sBuff;
						if(!pChildFrame->m_bCanceled)
							pChildFrame->m_pSet->MoveNext();
					}
				}
			}

			if(!pChildFrame->m_bCanceled && !pChildFrame->m_strProcText.length())
				pChildFrame->m_strProcText = _T("NULL");
		}
	}
	catch(CDBException* e)
	{
		if(e)
		{
			if(!pChildFrame->m_bCanceled)
			{
				bCaughtException = true;
				
				if(pChildFrame->m_strMessages.length())
					pChildFrame->m_strMessages += _T("\n\n");
			
				if(!e->m_strError.IsEmpty())
					sBuff.Format(
						_T("%s%s"), (LPCTSTR)e->m_strError, (LPCTSTR)e->m_strStateNativeOrigin
						);
				else
					sBuff = e->m_strStateNativeOrigin;
				
				if(sBuff.IsEmpty())
					sBuff = "Errors occurred.";

				pChildFrame->m_strMessages += sBuff;
			}

			e->Delete();
	   }
	}
	catch(CMemoryException* e)
	{
		if(!pChildFrame->m_bCanceled)
		{
			bCaughtException = true;

			if(pChildFrame->m_strMessages.length())
				pChildFrame->m_strMessages += _T("\n\n");
			pChildFrame->m_strMessages += _T("Out-of-Memory.");
		}

		if(e)
			e->Delete();
	}
	catch(...)
	{
		if(!pChildFrame->m_bCanceled)
		{
			bCaughtException = true;

			if(pChildFrame->m_strMessages.length())
				pChildFrame->m_strMessages += _T("\n\n");
			pChildFrame->m_strMessages += _T("Errors occurred.");
		}
	}

	pChildFrame->CloseRecordset();
	
	try
	{
		if(pChildFrame->m_bIsTSQLSupported && !pChildFrame->m_bCanceled)
		{
			if(pTP->m_strSQL.FindNoCase(_T("USE ")) != -1)
			{
				if(!pChildFrame->SelectDatabase())
					TRACE(_T("Error selecting database context.\n"));
			}
		}
	}
	catch(...)
	{
		TRACE(_T("Errors occurred.\n"));
	}

	try
	{
		::PostMessage(
			pChildFrame->m_hWnd, WM_EXEC_PROC_COMPLETE,
			bCaughtException, 0L
			);
	}
	catch(...)
	{
		TRACE(_T("Errors occurred.\n"));
	}

	return 0;
}