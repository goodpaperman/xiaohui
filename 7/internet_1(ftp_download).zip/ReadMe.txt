I first make this program to transfer data in http style, this is
why the program is http.

Thanks for downloading my program and my source.

Any comment,
vlad3@sympatico.ca

http://rlp.dynip.com
( this website is directly on my computer, my computer is a server
if you can't connect is because my computer is turn off )

My CV is online, but in french only, i'm in Montr�al city, in the
Qu�bec province, in Canada.