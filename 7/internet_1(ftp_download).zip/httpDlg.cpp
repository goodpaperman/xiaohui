// httpDlg.cpp : implementation file
//

#include "stdafx.h"
#include "http.h"
#include "httpDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#include "ftpget.h"
#include "addfile.h"

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHttpDlg dialog

CHttpDlg::CHttpDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CHttpDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CHttpDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CHttpDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CHttpDlg)
	DDX_Control(pDX, IDC_PASS_EMAIL, m_pass_email);
	DDX_Control(pDX, IDC_ANON, m_anon);
	DDX_Control(pDX, IDC_USER_NAME, m_user);
	DDX_Control(pDX, IDC_SERVER, m_server);
	DDX_Control(pDX, IDC_PASSWORD, m_pass);
	DDX_Control(pDX, IDC_FOLDER, m_folder);
	DDX_Control(pDX, IDC_FIL_LIST, m_file);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CHttpDlg, CDialog)
	//{{AFX_MSG_MAP(CHttpDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_NEW_VER, OnNewVer)
	ON_BN_CLICKED(IDC_ADD, OnAdd)
	ON_BN_CLICKED(IDC_DEL, OnDel)
	ON_BN_CLICKED(IDC_ANON, OnAnon)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHttpDlg message handlers

BOOL CHttpDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	m_folder.SetWindowText("c:\\download\\");
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CHttpDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CHttpDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CHttpDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CHttpDlg::OnNewVer() //Get These file button
{
	CString folder;
	CString user;
	CString pass;
	CString server;
	// CString program_name;
	CString tempRemote;
	CString tempLocal;
	// error
	CString Error;

	// get folder
	m_folder.GetWindowText(folder);
	// Get username, password, server
	m_user.GetWindowText(user);
	m_pass.GetWindowText(pass);
	m_server.GetWindowText(server);

	// get every file name in the box
	// make 2 CStringArray, one for remote, the other for local
	CStringArray remote;
	CStringArray local;

	for(int x=0;x<m_file.GetCount();x++)
	{
		m_file.GetText(x,tempRemote);
		remote.Add(tempRemote);
		tempLocal = folder + tempRemote;
		local.Add(tempLocal);
	}	

	// open CFtpGet class
	CFtpGet ftpget;
	// SetRight
	ftpget.SetAccessRight(user,pass);
	// open server
	bool conectOK;
	conectOK = ftpget.OpenConnection(server);
	// transfer multiple file
	if(conectOK)
	{
		ftpget.GetMultipleFile(&remote,&local,m_file.GetCount());
	}
	else
		memset(ftpget.missed,0,sizeof(bool[100]));
	// verify which file, if any, have not been transfered
	for(int test=0;test<m_file.GetCount();test++)
	{
		if(ftpget.missed[test])
		{
			m_file.GetText(test,Error);
			Error = "The file " + Error;
			Error += " is missing!";
			AfxMessageBox(Error);
		}
	}
	// close connection
	ftpget.CloseConnection();
	// quit this function
}

void CHttpDlg::OnAdd() // Add button
{
	// TODO: Add your control notification handler code here
	CAddFile add;
	int ret = add.DoModal();
	int lng = 0;
	CString newfile;

	if(ret == IDOK)
	{
		// get m_new_file lenght
		lng = add.strNewFile.GetLength();
		// if OK put in list
		if(lng == 0 )// no input
			return;

		m_file.AddString(add.strNewFile);
	}
	
}

void CHttpDlg::OnDel() // delete button
{
	// TODO: Add your control notification handler code here
	int selection=0;

	selection = m_file.GetCurSel();
	// now i get the good one
	if(selection <0)
	{
		AfxMessageBox("You have to select a value in the file list");
		return;
	}

	m_file.DeleteString(selection);
	// no more in the dialog
	
}

void CHttpDlg::OnAnon() // anonymous check button
{
	// TODO: Add your control notification handler code here
	int check = m_anon.GetCheck();

	if(check == 1)
	{
		// store some info in mem
		m_user.GetWindowText(cOldUser,99);
		m_pass.GetWindowText(cOldPass,99);

		// set new value
		m_user.SetWindowText("anonymous");
		m_pass.SetWindowText("your@email.com");
		m_pass_email.SetWindowText("Your email");

		// you can't edit anonymous
		m_user.SetReadOnly(TRUE);
	}else
	{
		// set the old value ( if any )
		m_user.SetWindowText(cOldUser);
		m_pass.SetWindowText(cOldPass);
		m_pass_email.SetWindowText("Password");

		// you have to edit the user name.
		m_user.SetReadOnly(FALSE);
	}
	
}
