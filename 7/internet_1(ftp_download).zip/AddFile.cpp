// AddFile.cpp : implementation file
//

#include "stdafx.h"
#include "http.h"
#include "AddFile.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAddFile dialog


CAddFile::CAddFile(CWnd* pParent /*=NULL*/)
	: CDialog(CAddFile::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAddFile)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CAddFile::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAddFile)
	DDX_Control(pDX, IDC_NEW_FILE, m_new_file);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAddFile, CDialog)
	//{{AFX_MSG_MAP(CAddFile)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAddFile message handlers

int CAddFile::DoModal() 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CDialog::DoModal();
}

void CAddFile::OnCancel() 
{
	// TODO: Add extra cleanup here
	strNewFile = "";
	CDialog::OnCancel();
}

void CAddFile::OnOK() 
{
	// TODO: Add extra validation here
	m_new_file.GetWindowText(strNewFile);
	CDialog::OnOK();
}
