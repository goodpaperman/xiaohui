#if !defined(AFX_ADDFILE_H__F8D882C0_F36D_11D3_9FF0_0080C8F223E1__INCLUDED_)
#define AFX_ADDFILE_H__F8D882C0_F36D_11D3_9FF0_0080C8F223E1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AddFile.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CAddFile dialog

class CAddFile : public CDialog
{
// Construction
public:
	CAddFile(CWnd* pParent = NULL);   // standard constructor

	CString strNewFile;
// Dialog Data
	//{{AFX_DATA(CAddFile)
	enum { IDD = IDD_ADD_FILE };
	CEdit	m_new_file;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAddFile)
	public:
	virtual int DoModal();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CAddFile)
	virtual void OnCancel();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ADDFILE_H__F8D882C0_F36D_11D3_9FF0_0080C8F223E1__INCLUDED_)
