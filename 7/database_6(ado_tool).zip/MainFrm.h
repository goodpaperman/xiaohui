// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINFRM_H__E1966CB9_6232_11D3_A7CD_00C04F595ED0__INCLUDED_)
#define AFX_MAINFRM_H__E1966CB9_6232_11D3_A7CD_00C04F595ED0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ChildFrm.h"
#include "GoToDlg.h"

/////////////////////////////////////////////////////////////////////////////
// CMDIClientWnd window

class CMDIClientWnd : public CWnd
{
// Construction
public:
	CMDIClientWnd();

// Attributes
public:
	CBitmap m_bitmap;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMDIClientWnd)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMDIClientWnd();

	// Generated message map functions
protected:
	//{{AFX_MSG(CMDIClientWnd)
	afx_msg void OnPaint();
	afx_msg void OnWindowPosChanging(WINDOWPOS FAR* lpwndpos);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CMDIClientWnd window

class CMainFrame : public CMDIFrameWnd
{
	DECLARE_DYNAMIC(CMainFrame)
public:
	CMainFrame();

// Attributes
public:
	CMDIClientWnd m_wndMDIClient;
	CStatusBar m_wndStatusBar;

// Operations
public:
	void InitialShowWindow(UINT nCmdShow);
	CDocument* ConnectEx(LPCTSTR lpszConnectString = NULL,
		LPCTSTR lpszFileName = NULL, LPCTSTR lpszInitialCatalog = NULL);
	std::list<CChildFrame*> m_listChildFrame;
	CGoToDlg m_dlgGoTo;
	
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL
protected:

// Implementation
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

public:
// Generated message map functions
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnClose();
	afx_msg void OnFileDisconnectAll();
	afx_msg void OnFileConnect();
	afx_msg void OnHelpReadme();
	afx_msg void OnFileDisconnect();
	afx_msg void OnFileConfigure();
	afx_msg void OnEditGoto();
	afx_msg void OnUpdateEditGoto(CCmdUI* pCmdUI);
	afx_msg void OnWindowArrange();
	afx_msg void OnUpdateWindowArrange(CCmdUI* pCmdUI);
	afx_msg void OnWindowCascade();
	afx_msg void OnUpdateWindowCascade(CCmdUI* pCmdUI);
	afx_msg void OnWindowTileHorz();
	afx_msg void OnUpdateWindowTileHorz(CCmdUI* pCmdUI);
	afx_msg void OnWindowTileVert();
	afx_msg void OnUpdateWindowTileVert(CCmdUI* pCmdUI);
	afx_msg void OnWindowNext();
	afx_msg void OnUpdateWindowNext(CCmdUI* pCmdUI);
	afx_msg void OnWindowPrevious();
	afx_msg void OnUpdateWindowPrevious(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFileOpen(CCmdUI* pCmdUI);
	afx_msg void OnUpdateSetDbcomboFocus(CCmdUI* pCmdUI);
	//}}AFX_MSG
	afx_msg void OnUpdateIndicatorNumConns(CCmdUI* pCmdUI);
	DECLARE_MESSAGE_MAP()
private:
	BOOL m_bCloseAfterCancel;
	BOOL m_bDisconnectAllAfterCancel;
	CString m_strConnections;
	CWnd* m_pWndCurrentChild;
	CMDIChildWnd* GetNextMDIChildWnd();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRM_H__E1966CB9_6232_11D3_A7CD_00C04F595ED0__INCLUDED_)