// ProceduresDlg.cpp : implementation file
//

#include "stdafx.h"
#include "QryTool.h"
#include "ProceduresDlg.h"
#include "MainFrm.h"
#include "ChildFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CProceduresDlg dialog

CProceduresDlg::CProceduresDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CProceduresDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CProceduresDlg)
	m_strSearch = _T("");
	//}}AFX_DATA_INIT

	m_nSelectedItem = 0;
	m_bSort = true;
}

void CProceduresDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CProceduresDlg)
	DDX_Control(pDX, IDC_LIST1, m_ctrlList);
	DDX_Text(pDX, IDC_SEARCH, m_strSearch);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CProceduresDlg, CDialog)
	//{{AFX_MSG_MAP(CProceduresDlg)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST1, OnDblclkList1)
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_LIST1, OnItemchangedList1)
	ON_NOTIFY(LVN_COLUMNCLICK, IDC_LIST1, OnColumnclickList1)
	ON_EN_CHANGE(IDC_SEARCH, OnChangeSearch)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CProceduresDlg message handlers

BOOL CProceduresDlg::OnInitDialog() 
{
	CWaitCursor wait;

	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	ASSERT(pFrame);
	m_pChildFrame = (CChildFrame*)pFrame->MDIGetActive();
	m_pChildFrame->m_wndStatusBar.SetPaneText(0, _T("Please wait..."));
	
	CDialog::OnInitDialog();
	
	LV_COLUMN lvcColumn;
	lvcColumn.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	lvcColumn.fmt = LVCFMT_LEFT;
	CRect rect;
	m_ctrlList.GetClientRect(&rect);
	int nWidth = rect.Size().cx/3;
	lvcColumn.cx = nWidth;
	lvcColumn.pszText = _T("Name");
	lvcColumn.iSubItem = 0;
	m_ctrlList.InsertColumn(0, &lvcColumn);

	lvcColumn.cx = nWidth;
	lvcColumn.pszText = _T("Schema");
	lvcColumn.iSubItem = 1;
	m_ctrlList.InsertColumn(1, &lvcColumn);

	lvcColumn.cx = nWidth;
	lvcColumn.pszText = _T("Catalog");
	lvcColumn.iSubItem = 2;
	m_ctrlList.InsertColumn(2, &lvcColumn);

	if(!PopulateList())
		SendMessage(WM_CLOSE);
	else
	{
		m_ctrlList.SetFullRowSel(TRUE);
		UpdateData(FALSE);
	}
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

bool CProceduresDlg::PopulateList()
{
	bool bRet = true;
	try
	{
		ADODB::_RecordsetPtr ptrRS = m_pChildFrame->m_ptrConnection->OpenSchema(
				ADODB::adSchemaProcedures);
		if(!ptrRS->adoBOF)
		{
			CString sName, sSchema, sCatalog;
			int nPos = -1;
			HRESULT hr = S_OK;
			int nIndex = 0;
			while(!ptrRS->adoEOF)
			{
				sName = CHelpers::CrackStrVariant(ptrRS->
					GetCollect(L"PROCEDURE_NAME"));
				nPos = sName.Find(';');
				if(nPos != -1)
					sName = sName.Left(nPos);
				if(sName.Find(' ') != -1) // MS SQL Server scenario
					sName = "[" + sName + "]";
				// Alternatively...
				sSchema = CHelpers::CrackStrVariant(ptrRS->Fields->
					GetItem(_variant_t((long)1))->Value);
				sCatalog = CHelpers::CrackStrVariant(ptrRS->Fields->
					GetItem(_variant_t((long)0))->Value);

				CHelpers::Insert(&m_ctrlList, sName + "|" + sSchema + "|" +
					sCatalog + "|", -1, nIndex++);

				hr = ptrRS->MoveNext();
				if(FAILED(hr))
					_com_issue_error(hr);
			}

			m_ctrlList.SetItemState(0, LVIS_SELECTED | LVIS_FOCUSED,
					LVIS_SELECTED | LVIS_FOCUSED);
		}
	}
	catch(const _com_error& e)
	{
		bRet = false;

		CString sMsg = m_pChildFrame->GetProviderError();
		if(sMsg.IsEmpty())
			sMsg = m_pChildFrame->GetComError(e);

		AfxMessageBox(sMsg);
	}
	catch(...)
	{
		bRet = false;

		AfxMessageBox(_T("Errors occurred."));
	}

	if(!m_ctrlList.GetItemCount())
	{
		GetDlgItem(IDOK)->EnableWindow(FALSE);
		GetDlgItem(IDCANCEL)->SetWindowText(_T("&Close"));
	}

	return bRet;
}

void CProceduresDlg::OnDblclkList1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	CWaitCursor wait;

	if(GetDlgItem(IDOK)->IsWindowEnabled())
		OnOK();

	*pResult = 0;
}

void CProceduresDlg::OnOK() 
{
	m_strProcedureName = m_ctrlList.GetItemText(m_nSelectedItem, 0);
	
	CDialog::OnOK();
}

void CProceduresDlg::OnItemchangedList1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;

	if(pNMListView->uNewState)
		m_nSelectedItem = pNMListView->iItem;
	
	*pResult = 0;
}

void CProceduresDlg::OnColumnclickList1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	CWaitCursor wait;

	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;

	CSortColumn sort(&m_ctrlList, pNMListView->iSubItem, false);
	sort.Sort(m_bSort = !m_bSort);
	m_nSelectedItem = m_ctrlList.GetNextItem(-1, LVNI_SELECTED);

	*pResult = 0;
}

void CProceduresDlg::OnChangeSearch() 
{
	UpdateData();

	LVFINDINFO findInfo;
	findInfo.flags = LVFI_PARTIAL | LVFI_STRING;
	findInfo.psz = (LPCTSTR)m_strSearch;
	int nItem = m_ctrlList.FindItem(&findInfo);
	m_ctrlList.SetItemState(nItem, LVIS_SELECTED, LVIS_SELECTED);
	m_ctrlList.EnsureVisible(nItem, TRUE);
}