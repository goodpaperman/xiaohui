------------------------------------
Query Tool (using ADO) -- Readme.txt
------------------------------------

(c) 1999 George Poulose. All rights reserved.

Known Problems
--------------
1. In the case of MSDASQL provider for MS SQL Server, the T-SQL keyword <USE> may not
   switch the database context to the specified database. Use the combo box provided
   on the toolbar to change the database context.

Recommendations
---------------
1. Wherever possible, using native OLE DB providers is highly recommended.

License Info
------------
This product is licensed. However, distributing the software with other products
(commercial or otherwise) without prior written permission of the author is strictly
prohibited.

Comments and Bug Report
-----------------------
If you have any comments, pl. send it to g.poulose@computer.org. If you are reporting
a bug, pl. include a reliable repro.

// __End_