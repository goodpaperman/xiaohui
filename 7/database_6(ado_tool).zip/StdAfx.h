// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__E1966CB7_6232_11D3_A7CD_00C04F595ED0__INCLUDED_)
#define AFX_STDAFX_H__E1966CB7_6232_11D3_A7CD_00C04F595ED0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxdisp.h>        // MFC Automation classes
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT

#include <afxrich.h>		// MFC rich edit classes
#include <afxadv.h>			// CSharedFile
#include <atlconv.h>

#pragma warning(disable: 4786)

#include <string>
#include <list>
#include <algorithm>

#include "StringEx.h"
#include "ListCtrlEx.h"
#include "SortColumn.h"
#include "Helpers.h"

#pragma message ("TODO: Add the path to <Oledb32.dll>, and <Msado15.dll> via Tools->Options->Directories->Include Files. This is usually <C:\\Program Files\\Common Files\\system\\ole db\\>, and <C:\\Program Files\\Common Files\\system\\ado\\>, respectively.")

#import <Oledb32.dll>  raw_interfaces_only exclude("IDBPromptInitialize", "IDataInitialize") no_auto_exclude
#import <Msado15.dll>  rename("EOF", "adoEOF") rename("BOF", "adoBOF")
#import <MsFlxGrd.ocx> raw_interfaces_only

// Skip over first five messages since the framework
// uses a few of these messages
#define WM_EXECUTION_COMPLETE	(WM_USER + 0x1001)
#define WM_EXEC_PROC_COMPLETE	(WM_USER + 0x1002)
#define WM_CANCEL_COMPLETE		(WM_USER + 0x1003)
#define WM_GET_GRID_CTRL		(WM_USER + 0x1004)
#define WM_SET_GRID_ROWS		(WM_USER + 0x1005)

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__E1966CB7_6232_11D3_A7CD_00C04F595ED0__INCLUDED_)