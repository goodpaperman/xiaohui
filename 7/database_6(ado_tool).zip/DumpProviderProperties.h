#if !defined(AFX_DUMPPROVIDERPROPERTIES_H__7F6D2A63_3D70_11D3_A78E_00C04F595ED0__INCLUDED_)
#define AFX_DUMPPROVIDERPROPERTIES_H__7F6D2A63_3D70_11D3_A78E_00C04F595ED0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DumpProviderProperties.h : header file
//

#include "ChildFrm.h"

/////////////////////////////////////////////////////////////////////////////
// CDumpProviderProperties dialog

class CDumpProviderProperties : public CDialog
{
// Construction
public:
	CDumpProviderProperties(CWnd* pParent = NULL);   // standard constructor
	~CDumpProviderProperties();

// Dialog Data
	//{{AFX_DATA(CDumpProviderProperties)
	enum { IDD = IDD_DUMP_PROVIDER_PROPERTIES };
	CString	m_strSQL;
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDumpProviderProperties)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDumpProviderProperties)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void DumpProviderProperties(CStdioFile* pFile);
	void DumpProperty(const ADODB::PropertiesPtr& ptrProperties,
		CStdioFile* pFile);
	CChildFrame* m_pChildFrame;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DUMPPROVIDERPROPERTIES_H__7F6D2A63_3D70_11D3_A78E_00C04F595ED0__INCLUDED_)