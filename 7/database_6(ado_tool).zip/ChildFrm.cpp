// ChildFrm.cpp : implementation of the CChildFrame class
//

#include "stdafx.h"
#include "QryTool.h"
#include "ChildFrm.h"
#include "QryToolDoc.h"
#include "SelectTables.h"
#include "ProceduresDlg.h"
#include "DumpProviderProperties.h"
#include "MainFrm.h"
#include "QryToolConnectionEvents.h"
#include "font.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CQryToolApp theApp;

// Database combo
LPCTSTR g_szNoData = _T("<No Data>");
LPCTSTR g_szRefresh = _T("<Refresh>");
LPCTSTR g_szNotSupported = _T("<Not supported>");

// Configure
extern LPCTSTR g_szConfigure;
extern LPCTSTR g_szQueryTimeOut;
extern LPCTSTR g_szCacheSize;
extern LPCTSTR g_szThreadPriority;
extern LPCTSTR g_szTimeCritical;
extern LPCTSTR g_szHighest;
extern LPCTSTR g_szAboveNormal;
extern LPCTSTR g_szNormal;
extern LPCTSTR g_szBelowNormal;
extern LPCTSTR g_szLowest;

// OLEDB providers
LPCTSTR g_szODBCJTDriver = _T("ODBCJT32.DLL");
LPCTSTR g_szMSOLEDBProviderForODBCDrivers = _T("MSDASQL.DLL");
LPCTSTR g_szMSADIPP = _T("MSDAIPP.DLL");
LPCTSTR g_szMSOLEDBProForIP = _T("Microsoft OLE DB Provider for Internet Publishing");

// Databases
LPCTSTR g_szMSJet = _T("MS Jet");
LPCTSTR g_szMSSQLServer = _T("MS SQL Server");
LPCTSTR g_szMicrosoftSQLServer = _T("Microsoft SQL Server");
LPCTSTR g_szSQLAnyWhere =_T("Sybase SQL Anywhere");
LPCTSTR g_szASAnyWhere =_T("Adaptive Server Anywhere");
LPCTSTR g_szSybaseOpenServer = _T("SQL Server");
LPCTSTR g_szOracle = _T("Oracle");
LPCTSTR g_szVisualFoxPro = _T("Visual FoxPro");

// New connections
extern LPCTSTR g_szUntitled;
extern int g_nUntitledBump;

// License key
extern LPCTSTR g_lpszProgID;

// Font properties
LPCTSTR g_szQueryFont = _T("Query\\Font");
LPCTSTR g_szResultFont = _T("Result\\Font");
LPCTSTR g_szGridFont = _T("Grid\\Font");
// For QryView and ResultView
LPCTSTR g_szHeight = _T("Height");
LPCTSTR g_szWeight = _T("Weight");
LPCTSTR g_szItalic = _T("Italic");
LPCTSTR g_szUnderline = _T("Underline");
LPCTSTR g_szPitchAndFamily = _T("PitchAndFamily");
LPCTSTR g_szCharSet = _T("CharSet");
LPCTSTR g_szFaceName = _T("FaceName");
LPCTSTR g_szSystem = _T("System");
// For grid
LPCTSTR g_szBold = _T("Bold");
LPCTSTR g_szSize = _T("Size");

// Messages
LPCTSTR g_szMessages = _T("Messages");
/////////////////////////////////////////////////////////////////////////////
// CChildFrame

IMPLEMENT_DYNCREATE(CChildFrame, CMDIChildWnd)

BEGIN_MESSAGE_MAP(CChildFrame, CMDIChildWnd)
	//{{AFX_MSG_MAP(CChildFrame)
	ON_WM_CREATE()
	ON_WM_CLOSE()
	ON_COMMAND(ID_QUERY_NEW, OnQueryNew)
	ON_UPDATE_COMMAND_UI(ID_QUERY_NEW, OnUpdateQueryNew)
	ON_COMMAND(ID_VIEW_PREV_RESULT_SET, OnViewPrevResultSet)
	ON_UPDATE_COMMAND_UI(ID_VIEW_PREV_RESULT_SET, OnUpdateViewPrevResultSet)
	ON_COMMAND(ID_VIEW_NEXT_RESULT_SET, OnViewNextResultSet)
	ON_UPDATE_COMMAND_UI(ID_VIEW_NEXT_RESULT_SET, OnUpdateViewNextResultSet)
	ON_COMMAND(ID_VIEW_LAST_RESULT_SET, OnViewLastResultSet)
	ON_UPDATE_COMMAND_UI(ID_VIEW_LAST_RESULT_SET, OnUpdateViewLastResultSet)
	ON_COMMAND(ID_VIEW_FIRST_RESULT_SET, OnViewFirstResultSet)
	ON_UPDATE_COMMAND_UI(ID_VIEW_FIRST_RESULT_SET, OnUpdateViewFirstResultSet)
	ON_COMMAND(ID_SQL_SELECT_PROCEDURES, OnSqlSelectProcedures)
	ON_UPDATE_COMMAND_UI(ID_SQL_SELECT_PROCEDURES, OnUpdateSqlSelectProcedures)
	ON_COMMAND(ID_SQL_OBJECTS, OnSqlObjects)
	ON_UPDATE_COMMAND_UI(ID_SQL_OBJECTS, OnUpdateSqlObjects)
	ON_COMMAND(ID_SQL_EXECUTE, OnSqlExecute)
	ON_UPDATE_COMMAND_UI(ID_SQL_EXECUTE, OnUpdateSqlExecute)
	ON_COMMAND(ID_SQL_CANCEL, OnSqlCancel)
	ON_UPDATE_COMMAND_UI(ID_SQL_CANCEL, OnUpdateSqlCancel)
	ON_CBN_SELCHANGE(IDW_COMBO, OnSelChangeDatabase)
	ON_COMMAND(ID_SQL_SELECT_TABLES_EX, OnSqlSelectTables)
	ON_UPDATE_COMMAND_UI(ID_SQL_SELECT_TABLES_EX, OnUpdateSqlSelectTables)
	ON_UPDATE_COMMAND_UI(IDW_COMBO, OnUpdateCombo)
	ON_UPDATE_COMMAND_UI(ID_FILE_MRU_FILE1, OnUpdateFileMruFile1)
	ON_WM_TIMER()
	ON_COMMAND(ID_VIEW_MESSAGES, OnViewMessages)
	ON_UPDATE_COMMAND_UI(ID_VIEW_MESSAGES, OnUpdateViewMessages)
	ON_WM_SIZE()
	ON_COMMAND(ID_DUMP_PROVIDER_PROPERTIES_EX, OnDumpProviderPropertiesEx)
	ON_UPDATE_COMMAND_UI(ID_DUMP_PROVIDER_PROPERTIES_EX, OnUpdateDumpProviderPropertiesEx)
	ON_COMMAND(ID_SET_DBCOMBO_FOCUS, OnSetDbcomboFocus)
	//}}AFX_MSG_MAP
	ON_UPDATE_COMMAND_UI(ID_INDICATOR_PANE_TEXT_ZERO, OnUpdateIndicatorPaneTextZero)
	ON_UPDATE_COMMAND_UI(ID_INDICATOR_EXECUTION_TIME, OnUpdateIndicatorExecTime)
	ON_UPDATE_COMMAND_UI(ID_INDICATOR_RESULT_SET, OnUpdateIndicatorResultSetInfo)
	ON_UPDATE_COMMAND_UI(ID_INDICATOR_POSITION, OnUpdateIndicatorPosition)
	ON_MESSAGE(WM_EXECUTION_COMPLETE, OnExecutionComplete)
	ON_MESSAGE(WM_EXEC_PROC_COMPLETE, OnExecProcComplete)
	ON_MESSAGE(WM_CANCEL_COMPLETE, OnCancelComplete)
	ON_MESSAGE(WM_GET_GRID_CTRL, OnGetGridCtrl)
	ON_MESSAGE(WM_SET_GRID_ROWS, OnSetGridRows)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_INDICATOR_PANE_TEXT_ZERO,
	ID_INDICATOR_EXECUTION_TIME,
	ID_INDICATOR_RESULT_SET,
	ID_INDICATOR_POSITION
};

/////////////////////////////////////////////////////////////////////////////
// CChildFrame construction/destruction

CChildFrame::CChildFrame() :
	m_bOKToSize(false),
	m_nExecutionTimePaneNo(1),
	m_nResultSetPaneNo(2),
	m_nLineColPaneNo(3),
	m_nID(2000),
	m_nIndex(0),
	m_nGridCount(0),
	m_strPaneTextZero("Ready"),
	m_strExecutionTime("Exec time: 00:00:00"),
	m_strStatusText("_ConnectionPtr::State == adStateClosed"),
	m_strLineColInfo(_T("Ln 1, Col 1")),
	m_bIsJetDriver(FALSE),
	m_bIsTSQLSupported(FALSE),
	m_bIsMultiSetSupported(FALSE),
	m_bExecuting(FALSE),
	m_bCanceling(FALSE),
	m_bCanceled(FALSE),
	m_ptrConnection(NULL),
	m_ptrCommand(NULL),
	m_ptrRecordset(NULL),
	m_lConnectionState(ADODB::adStateClosed),
	m_nQueryTimeOut(AfxGetApp()->GetProfileInt(g_szConfigure, g_szQueryTimeOut, 0)),
	m_nCacheSize(AfxGetApp()->GetProfileInt(g_szConfigure, g_szCacheSize, 100)),
	m_nThreadPriority(GetThreadPriority(AfxGetApp()->GetProfileString(g_szConfigure,
		g_szThreadPriority))),
	m_bExecuteCompleteHandled(FALSE),
	m_pQryView(NULL),
	m_pResultView(NULL),
	m_nTimerID(0),
	m_bCloseMainFrameAfterCancel(FALSE),
	m_bDisconnectAllAfterCancel(FALSE),
	m_bCloseAfterCancel(FALSE),
	m_bProcText(FALSE),
	m_pCE(NULL),
	m_dwCnEvents(-1),
	m_pThreadExecuteSQL(NULL),
	m_pThreadCancelSQL(NULL),
	m_bSupports_adAsyncExecute(TRUE)
{
}

CChildFrame::~CChildFrame()
{
	CWaitCursor wait;

	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	if(pFrame != NULL)
	{
		pFrame->m_wndMDIClient.Invalidate();
		pFrame->m_wndMDIClient.UpdateWindow();
		pFrame->UpdateWindow();
	
		std::list<CChildFrame*>::iterator i = 
			std::find(pFrame->m_listChildFrame.begin(),
				pFrame->m_listChildFrame.end(), this);
		if(i != pFrame->m_listChildFrame.end())
			pFrame->m_listChildFrame.erase(i);

		if(pFrame->m_listChildFrame.size() == 0)
			if(::IsWindow(pFrame->m_dlgGoTo.m_hWnd))
				pFrame->m_dlgGoTo.DestroyWindow();
	}
}

/////////////////////////////////////////////////////////////////////////////
// CChildFrame diagnostics

#ifdef _DEBUG
void CChildFrame::AssertValid() const
{
	CMDIChildWnd::AssertValid();
}

void CChildFrame::Dump(CDumpContext& dc) const
{
	CMDIChildWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CChildFrame message handlers

int CChildFrame::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if(CMDIChildWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if(!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE(_T("Failed to create toolbar\n"));
		return -1;      // fail to create
	}

	if(!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE(_T("Failed to create status bar\n"));
		return -1;      // fail to create
	}

	int nIndex = 0;
	UINT nID = ID_SEPARATOR;
	UINT nStyle = -1;
	int nWidth = -1;
	m_wndStatusBar.GetPaneInfo(nIndex, nID, nStyle, nWidth);
	m_wndStatusBar.SetPaneInfo(nIndex, nID, SBPS_NORMAL | SBPS_STRETCH, nWidth);
	m_wndStatusBar.SetPaneInfo(
		m_nExecutionTimePaneNo, ID_INDICATOR_EXECUTION_TIME, SBPS_NORMAL, 100
		);
	m_wndStatusBar.SetPaneInfo(
		m_nResultSetPaneNo, ID_INDICATOR_RESULT_SET, SBPS_NORMAL, 230
		);
	m_wndStatusBar.SetPaneInfo(
		m_nLineColPaneNo, ID_INDICATOR_POSITION, SBPS_NORMAL, 100
		);
	
	CRect rect;
	nIndex = m_wndToolBar.GetToolBarCtrl().CommandToIndex(IDW_COMBO);
	m_wndToolBar.SetButtonInfo(nIndex, IDW_COMBO, TBBS_SEPARATOR, 205);
	m_wndToolBar.GetToolBarCtrl().GetItemRect(nIndex, &rect);
	rect.top = 3;
	rect.bottom = rect.top + 250 /*drop height*/;
	if(!m_comboBox.Create(CBS_DROPDOWNLIST | CBS_SORT | WS_VISIBLE |
		WS_TABSTOP | WS_VSCROLL, rect, &m_wndToolBar, IDW_COMBO))
	{
		TRACE(_T("Failed to create combo-box\n"));
		return FALSE;
	}
	LOGFONT logFont;
	memset(&logFont, 0, sizeof(logFont));
	logFont.lfHeight = -11;
	logFont.lfWeight = 400;
	_tcscpy(logFont.lfFaceName, _T("MS Sans Serif"));
	if(!m_font.CreateFontIndirect(&logFont))
		TRACE(_T("Could Not create font for Combo\n"));
	else
		m_comboBox.SetFont(&m_font);
	m_comboBox.EnableWindow(FALSE);

	// TODO: Remove this if you don't want tool tips or a resizeable toolbar
	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);

	GetProfileFont(
		g_szGridFont,
		&m_GridFont.m_lf,
		true, 
		&m_GridFont.m_bIsBold,
		&m_GridFont.m_nSize
		);
	m_GridFont.m_strFaceName = m_GridFont.m_lf.lfFaceName;
	
	return 0;
}

BOOL CChildFrame::Connect(LPCTSTR lpszConnectString, const bool& bRetry,
	LPCTSTR lpszInitialCatalog)
{
	CWaitCursor wait;

	BOOL bRet = FALSE;
	CString sMsg;
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	ASSERT(pFrame != NULL);
	pFrame->m_wndStatusBar.SetPaneText(0, _T("Establishing new connection..."));
	try
	{
		HRESULT hr = S_OK;
		if(lpszConnectString != NULL) 	 // <New query> scenario
		{
			hr = m_ptrConnection.CreateInstance(__uuidof(ADODB::Connection));
			if(FAILED(hr))
				_com_issue_error(hr);
			
			m_strConnectString = lpszConnectString;
		}
		else
		{
			MSDASC::IDataSourceLocatorPtr ptrDataSourceWnd = NULL;
			hr = ptrDataSourceWnd.CreateInstance(__uuidof(MSDASC::DataLinks));
			if(FAILED(hr))
				_com_issue_error(hr);
        
			hr = ptrDataSourceWnd->put_hWnd((long)this->m_hWnd);
			if(FAILED(hr))
				_com_issue_error(hr);
                
			if(!bRetry)
			{
				IDispatchPtr ptrDispatch = NULL;
				hr = ptrDataSourceWnd->PromptNew(&ptrDispatch);
				if(FAILED(hr))
					_com_issue_error(hr);
        		if(ptrDispatch != NULL)
				{
					m_ptrConnection = ptrDispatch;
					BSTR bstrConnectString = m_ptrConnection->ConnectionString;
					USES_CONVERSION;
					m_strConnectString = W2CT(bstrConnectString);
					TRACE(_T("Connect String: %s\n"), (LPCTSTR)m_strConnectString);
				}
			}
			else
			{
				IDispatch* pDispatch = NULL;
				hr = m_ptrConnection.QueryInterface(IID_IDispatch, &pDispatch);
				if(FAILED(hr))
					_com_issue_error(hr);

				short bSuccess = 0;
				hr = ptrDataSourceWnd->PromptEdit(&pDispatch, &bSuccess);
				if(FAILED(hr))
				{
					if(ptrDataSourceWnd != NULL)
					{
						ptrDataSourceWnd.Release();
						ptrDataSourceWnd = NULL;
					}
					if(pDispatch != NULL)
					{
						pDispatch->Release();
						pDispatch = NULL;
					}
					
					_com_issue_error(hr);
				}

				if(!bSuccess) // User clicked on <Cancel>
					m_strConnectString.Empty();
				else
				{
					BSTR bstrConnectString = m_ptrConnection->ConnectionString;
					USES_CONVERSION;
					m_strConnectString = W2CT(bstrConnectString);
					TRACE(_T("Connect String: %s\n"), (LPCTSTR)m_strConnectString);
				}

				if(pDispatch != NULL)
				{
					pDispatch->Release();
					pDispatch = NULL;
				}
			}

			if(ptrDataSourceWnd != NULL)
			{
				ptrDataSourceWnd.Release();
				ptrDataSourceWnd = NULL;
			}
		}

		if(!m_strConnectString.IsEmpty())
		{
			CWaitCursor wait;

			pFrame->m_wndStatusBar.SetPaneText(0, _T("Establishing new connection..."));

			m_dwStart = ::GetTickCount();
			
			hr = SetConnectionEvents();
			if(FAILED(hr))
				_com_issue_error(hr);

			hr = m_ptrConnection->Open(
					_bstr_t((LPCTSTR)m_strConnectString),
					_bstr_t(L""),
					_bstr_t(L""),
					ADODB::adConnectUnspecified
					);
			if(FAILED(hr))
				_com_issue_error(hr);
			
			m_lConnectionState = m_ptrConnection->State;
			
			hr = m_ptrCommand.CreateInstance(__uuidof(ADODB::Command));
			if(FAILED(hr))
				_com_issue_error(hr);
			
			try
			{
				m_ptrCommand->ActiveConnection = m_ptrConnection;
			}
			catch(...)
			{
			}
			
			try
			{
				if(m_nQueryTimeOut > 99999 || m_nQueryTimeOut < 0)
					m_nQueryTimeOut = 0;
				m_ptrConnection->CommandTimeout = m_nQueryTimeOut;
			}
			catch(...)
			{
			}

			hr = m_ptrRecordset.CreateInstance(__uuidof(ADODB::Recordset));
			if(FAILED(hr))
				_com_issue_error(hr);

			try
			{
				if(m_nCacheSize > 999999 || m_nCacheSize <= 0)
					m_nCacheSize = 100;
				m_ptrRecordset->CacheSize = m_nCacheSize;
			}
			catch(...)
			{
			}
						
			if(!SetProperties(lpszInitialCatalog))
				TRACE(_T("Error setting properties.\n"));

			if(m_strDataSource.IsEmpty())
				m_strDataSource = "<Unknown>";
			
			m_strStatusText = "_ConnectionPtr::State == adStateOpen";
			
			SetExecutionTime();
			
			bRet = TRUE;
		}
	}
	catch(const _com_error& e)
	{
		sMsg = GetProviderError();
		if(sMsg.IsEmpty())
			sMsg = GetComError(e);
	}
	catch(COleException* e)
	{
		if(e)
		{
			TCHAR szMsg[255];
			e->GetErrorMessage(szMsg, 255);
			sMsg = szMsg;
			e->Delete();
		}
	}
	catch(COleDispatchException* e)
	{
		if(e)
		{
			sMsg = e->m_strDescription;
			e->Delete();
		}
	}
	catch(CMemoryException* e)
	{
		sMsg = "Out-of-Memory.";
		if(e)
			e->Delete();
	}
	catch(CException* e)
	{
		if(e)
		{
			TCHAR szMsg[255];
			e->GetErrorMessage(szMsg, 255);
			sMsg = szMsg;
			e->Delete();
		}
	}
	catch(...)
	{	
		sMsg = "Errors occurred.";
	}

	if(!bRet && !sMsg.IsEmpty())
	{
		if(AfxMessageBox(sMsg, MB_RETRYCANCEL | MB_ICONQUESTION) == IDRETRY)
		{
			m_strConnectString.Empty();
			bRet = Connect(NULL, true);
		}
	}

	pFrame->m_wndStatusBar.SetPaneText(0, _T(""));

	return bRet;
}

void CChildFrame::OnQueryNew() 
{
	try
	{
		CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
		ASSERT(pFrame != NULL);
		CString sInitialCatalog;
		m_comboBox.GetWindowText(sInitialCatalog);
		pFrame->ConnectEx(m_strConnectString, NULL, sInitialCatalog);
	}
	catch(...)
	{
		AfxMessageBox(_T("Errors occurred."));
	}
}

void CChildFrame::OnUpdateQueryNew(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_lConnectionState == ADODB::adStateOpen);
}

BOOL CChildFrame::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext) 
{
	if(!m_wndSplitter.CreateStatic(this, 2, 1))
	{
		TRACE(_T("Failed to CreateStaticSplitter\n"));
		return FALSE;
	}
 	
	if(!m_wndSplitter.CreateView(0, 0,
		RUNTIME_CLASS(CQryView), CSize(0, 0), pContext))
	{
		TRACE(_T("Failed to create third pane\n"));
		return FALSE;
	}

	// CResultView must be the last in the creation process.
	// There can be only one CRichEditDoc per CRichEditView
	if(!m_wndSplitter.CreateView(1, 0,
		RUNTIME_CLASS(CResultView), CSize(0, 0), pContext))
	{
		TRACE(_T("Failed to create first pane\n"));
		return FALSE;
	}

	m_pQryView = GetQryView();
	ASSERT(m_pQryView != NULL);
	
	m_pResultView = GetResultView();
	ASSERT(m_pResultView != NULL);

	m_bOKToSize = true;

	return TRUE;
}

void CChildFrame::OnSize(UINT nType, int cx, int cy) 
{
	if(m_bOKToSize)
	{
		CRect rect;
		GetClientRect(&rect);
		m_wndSplitter.SetRowInfo(0, rect.Height()/2, 0);
	}

	CMDIChildWnd::OnSize(nType, cx, cy);
}

void CChildFrame::OnSqlExecute() 
{
	if(!m_bExecuting)
	{
		m_strPaneTextZero = _T("Executing query batch...");
		m_wndStatusBar.SetPaneText(0, m_strPaneTextZero);

		OnExceptionClear(CString(""));

		m_dwStart = ::GetTickCount();
		m_nTimerID = SetTimer(1, 1000, NULL);
		m_strExecutionTime = "Exec time: 00:00:00";
		m_wndStatusBar.SetPaneText(m_nExecutionTimePaneNo, m_strExecutionTime);

		m_strStatusText = "Results grid #0 of 0; 0 row(s); 0 col(s)";
		m_wndStatusBar.SetPaneText(2, m_strStatusText);

		m_strMessages.erase();
		m_strProcText.erase();
			
		m_bExecuting = TRUE;
		m_bCanceling = FALSE;
		m_bCanceled = FALSE;
		if(m_bIsTSQLSupported)
			m_comboBox.EnableWindow(FALSE);
		
		long nStart = -1;
		long nEnd = -1;
		m_pQryView->GetRichEditCtrl().GetSel(nStart, nEnd);
		int nBuff = nEnd-nStart;
		CStringEx sSQL;
		if(nBuff == 0)
			m_pQryView->GetRichEditCtrl().GetWindowText(sSQL);
		else if(nBuff > 20000)
		{
			m_pQryView->GetRichEditCtrl().GetWindowText(sSQL);
			sSQL = sSQL.Mid(nStart, nBuff);
		}
		else
			sSQL = m_pQryView->GetRichEditCtrl().GetSelText();

		CDocument* pDoc = GetActiveDocument();
		ASSERT(pDoc != NULL);
		CString sBuff = sSQL;
		CString sTitle = pDoc->GetTitle();
		nBuff = sTitle.Find(_T(" - ("));
		if(nBuff != -1)
			sTitle = sTitle.Left(nBuff);
		sBuff.Replace(_T("\n"), _T(" "));
		sBuff.Replace(_T("\r"), _T(" "));
		if(sBuff.GetLength() > 15)
			sTitle = sTitle + _T(" - (") + sBuff.Left(15) + _T("...)");
		else
			sTitle = sTitle + _T(" - (") + sBuff + _T(")");
		pDoc->SetTitle(sTitle);
		
		if(m_bIsTSQLSupported)
		{
			LPCTSTR lpszHelpText = _T("sp_helptext ");
			int nPos = sSQL.FindNoCase(lpszHelpText);
			if(nPos != -1)
			{
				if(sSQL.Mid(0, _tcslen(lpszHelpText)) == lpszHelpText)
				{
					m_bProcText = TRUE;
					CString sObjName = sSQL.Mid(nPos + _tcslen(lpszHelpText));
					nPos = sObjName.FindOneOf(_T("\n\r\t "));
					if(nPos != -1)				
						sObjName = sObjName.Left(nPos);
					m_pResultView->m_strObjName = sObjName;
					if(!m_strDBMS.CompareNoCase(g_szSQLAnyWhere) ||
						!m_strDBMS.CompareNoCase(g_szASAnyWhere))
					{
						sSQL.Format(_T("SELECT text FROM syscomments where id = object_id('%s') "),
							(LPCTSTR)sObjName);
						sSQL += _T("order by number, colid2, colid");
					}
				}
			}
		}

		if(m_bProcText)
		{
			m_strStatusText = "# of lines of text: 0";
			m_wndStatusBar.SetPaneText(2, m_strStatusText);
		}

		if(!ExecuteSQL(sSQL))
			TRACE(_T("Error executing SQL: %s\n"), (LPCTSTR)sSQL);
	}
}

BOOL CChildFrame::ExecuteSQL(const CStringEx& sSQL)
{
	BOOL bRet = TRUE;

	CloseRecordset();

	try
	{
		m_strSQL = sSQL;
		long lOption = ADODB::adAsyncExecute;
		if(!m_bSupports_adAsyncExecute)
			lOption = ADODB::adCmdText;
		BSTR bstrSQL = m_strSQL.AllocSysString();
		HRESULT hr = m_ptrRecordset->Open(
				bstrSQL,
				m_ptrConnection.GetInterfacePtr(),
				ADODB::adOpenForwardOnly,
				ADODB::adLockReadOnly,
				lOption
				);
		::SysFreeString(bstrSQL);
		if(FAILED(hr))
			_com_issue_error(hr);
	}
	catch(const _com_error& e)
	{
		bRet = FALSE;

		CString sBuff = GetProviderError();
		if(!sBuff.IsEmpty())
			m_strMessages = sBuff;
		else
			m_strMessages = GetComError(e);
	}
	catch(...)
	{
		bRet = FALSE;

		m_strMessages = _T("Errors occurred.");
	}

	if(!bRet)
	{
		if(m_bProcText)
			OnExecProcComplete(true, -1);
		else
			OnExecutionComplete(true, -1);
	}

	return bRet;
}

CQryView* CChildFrame::GetQryView()
{
	return static_cast<CQryView*>(m_wndSplitter.GetPane(0, 0));
}

CResultView* CChildFrame::GetResultView()
{
	CResultView* pResultView = NULL;
	if(m_wndSplitter.m_hWnd != NULL)
		pResultView = static_cast<CResultView*>(m_wndSplitter.GetPane(1, 0));

	return pResultView;
}

void CChildFrame::OnSqlSelectTables() 
{
	CWaitCursor wait;

	CSelectTables dlg;
	if(dlg.DoModal() == IDOK)
	{
		CString sBuff;
		m_pQryView->GetRichEditCtrl().GetWindowText(sBuff);
		int nStart = sBuff.GetLength();
		sBuff += dlg.m_strSQL;
		int nEnd = sBuff.GetLength();
		m_pQryView->GetRichEditCtrl().SetWindowText(sBuff);
		m_pQryView->GetRichEditCtrl().SetSel(nStart+2, nEnd);
		if(dlg.m_bTextOnly && !dlg.m_strType.CompareNoCase(_T("VIEW")) &&
			(m_bIsTSQLSupported || !m_strDBMS.CompareNoCase(g_szOracle) ||
			m_bIsJetDriver))
		{
			m_pResultView->m_strObjName = dlg.m_strObjName;
			m_bProcText = TRUE;
		}
		OnSqlExecute();
	}
}

void CChildFrame::OnUpdateSqlSelectTables(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_lConnectionState == ADODB::adStateOpen && !m_bExecuting);
}

void CChildFrame::OnExceptionClear(const CString& sMsg)
{
	m_pResultView->SetRedraw(FALSE);
	
	ClearGridList();
	
	m_pResultView->GetRichEditCtrl().SetWindowText(sMsg);
	m_pResultView->GetRichEditCtrl().SetSel(0, 0); // Scroll up!
	m_pResultView->SetRedraw(TRUE);
	
	m_nID = 2000;
	m_nIndex = 0;

	m_bExecuteCompleteHandled = FALSE;
	
	m_bCloseMainFrameAfterCancel = FALSE;
	m_bDisconnectAllAfterCancel = FALSE;
	m_bCloseAfterCancel = FALSE;
	
	if(m_nTimerID != 0)
	{
		KillTimer(m_nTimerID);
		m_nTimerID = 0;
	}
	
	m_pResultView->Invalidate();
	m_pResultView->UpdateWindow();
}

BOOL CChildFrame::FillCombo()
{
	BOOL bRet = TRUE;

	CString sMsg;

	m_comboBox.ResetContent();

	try
	{
		ADODB::_RecordsetPtr ptrRS = m_ptrConnection->OpenSchema(
						ADODB::adSchemaCatalogs
						);
		if(ptrRS != NULL)
		{
			if(ptrRS->adoBOF)
			{
				m_comboBox.AddString(g_szNoData);
				m_comboBox.SetCurSel(0);
			}
			else
			{
				CString sDBName;
				while(!ptrRS->adoEOF)
				{
					sDBName = (LPCTSTR)(_bstr_t)ptrRS->Fields->
						GetItem(_variant_t((long)0))->Value;
					if(sDBName.Find(' ') != -1)
						sDBName = "[" + sDBName + "]";
					m_comboBox.AddString(sDBName);
					
					ptrRS->MoveNext();
				}
			}

			m_comboBox.InsertString(m_comboBox.GetCount(), g_szRefresh);
			m_comboBox.EnableWindow();
		}
	}
	catch(const _com_error& e)
	{
		UNUSED_ALWAYS(e);

		sMsg = GetProviderError();
		if(!sMsg.IsEmpty())
			sMsg = "Provider Error";
		else
			sMsg = "_com_error";

		bRet = FALSE;
	}

	if(bRet)
	{
		if(m_comboBox.GetCount())
			if(!SelectDatabase())
				TRACE(_T("Error selecting database context.\n"));
	}
	else
	{
		m_comboBox.AddString(sMsg);
		m_comboBox.SetCurSel(0);
	}

	return bRet;
}

bool CChildFrame::PutInitialCatalog(LPCTSTR lpszInitialCatalog)
{
	bool bRet = true;

	try
	{
		CloseRecordset();

		long lOption = ADODB::adCmdText;
		CString strSQL = "use " + CString(lpszInitialCatalog);
		HRESULT hr = m_ptrRecordset->Open(
				_bstr_t((LPCTSTR)strSQL),
				m_ptrConnection.GetInterfacePtr(),
				ADODB::adOpenForwardOnly,
				ADODB::adLockReadOnly,
				lOption
				);
		if(FAILED(hr))
			_com_issue_error(hr);
		
		CloseRecordset();

		CString sDBName = lpszInitialCatalog;
		CString sBuff = sDBName;
		if(sDBName.Find(_T("[")) != -1)
		{
			sBuff = sDBName.Mid(1);
			int nPos = sBuff.Find(_T("]"));
			if(nPos != -1)
				sBuff = sBuff.Left(nPos);
		}
		ADODB::PropertiesPtr ptrProperties = m_ptrConnection->GetProperties();
		ADODB::PropertyPtr ptrProperty = ptrProperties->GetItem("Current Catalog");
		hr = ptrProperty->put_Value(_variant_t((LPCTSTR)sBuff));
		if(FAILED(hr))
			_com_issue_error(hr);
	}
	catch(const _com_error& e)
	{
		CString sMsg = GetProviderError();
		if(sMsg.IsEmpty())
			sMsg = GetComError(e);

		TRACE(_T("%s\n"), (LPCTSTR)sMsg);

		bRet = false;
	}
	catch(...)
	{
		TRACE(_T("Errors occurred.\n"));

		bRet = false;
	}

	return bRet;
}

void CChildFrame::OnSelChangeDatabase()
{
	CWaitCursor wait;

	CString sBuff, sDBName, sMsg;
	m_comboBox.GetWindowText(sDBName);
	if(!sDBName.CompareNoCase(g_szNoData) ||
		!sDBName.CompareNoCase(g_szNotSupported))
		;
	else if(!sDBName.CompareNoCase(g_szRefresh))
	{
		if(!FillCombo())
			TRACE(_T("Error filling combo.\n"));
	}
	else
	{
		if(sDBName != m_strDBName)
		{
			try
			{
				CloseRecordset();

				long lOption = ADODB::adCmdText;
				CString strSQL = "use " + sDBName;
				HRESULT hr = m_ptrRecordset->Open(
						_bstr_t((LPCTSTR)strSQL),
						m_ptrConnection.GetInterfacePtr(),
						ADODB::adOpenForwardOnly,
						ADODB::adLockReadOnly,
						lOption
						);
				if(FAILED(hr))
					_com_issue_error(hr);

				CloseRecordset();

				sBuff = sDBName;
				if(sDBName.Find(_T("[")) != -1)
				{
					sBuff = sDBName.Mid(1);
					int nPos = sBuff.Find(_T("]"));
					if(nPos != -1)
						sBuff = sBuff.Left(nPos);
				}
				ADODB::PropertiesPtr ptrProperties = m_ptrConnection->GetProperties();
				ADODB::PropertyPtr ptrProperty = ptrProperties->GetItem("Current Catalog");
				hr = ptrProperty->put_Value(_variant_t((LPCTSTR)sBuff));
				if(FAILED(hr))
					_com_issue_error(hr);
				m_comboBox.SelectString(-1, (m_strDBName = (LPCTSTR)sDBName));
			}
			catch(const _com_error& e)
			{
				m_comboBox.SelectString(-1, m_strDBName); // the Old one
				
				sMsg = GetProviderError();
				if(sMsg.IsEmpty())
					sMsg = GetComError(e);

				AfxMessageBox(sMsg);
			}
			catch(...)
			{
				m_comboBox.SelectString(-1, m_strDBName); // the Old one

				AfxMessageBox(_T("Errors occurred."));
			}
		}
	}
}

void CChildFrame::OnSqlSelectProcedures() 
{
	CWaitCursor wait;

	CProceduresDlg dlg;
	if(dlg.DoModal() == IDOK)
	{
		CStringEx sBuff;
		CRichEditCtrl& edit = m_pQryView->GetRichEditCtrl();
		edit.GetWindowText(sBuff);
		sBuff += "\r\n\r\n";
		int nStart = sBuff.GetLength();
		
		CString sSQL;
		if(!m_strDBMS.CompareNoCase(g_szSybaseOpenServer) ||
		   !m_strDBMS.CompareNoCase(g_szMSSQLServer) ||
		   !m_strDBMS.CompareNoCase(g_szMicrosoftSQLServer) ||
		   !m_strDBMS.CompareNoCase(g_szSQLAnyWhere) ||
			!m_strDBMS.CompareNoCase(g_szASAnyWhere)
		   )
			sSQL = "sp_helptext " + dlg.m_strProcedureName;
		else if(!m_strDBMS.CompareNoCase(g_szOracle))
		{
			sSQL = "select TEXT from ALL_SOURCE where type = 'PROCEDURE' and NAME = '";
			sSQL += dlg.m_strProcedureName + "'" ;
		}
		else
			sSQL += dlg.m_strProcedureName + " // Procedure text not supported";

		sBuff += sSQL;
		int nEnd = sBuff.GetLength();
		edit.SetWindowText(sBuff);
		edit.SetSel(nStart, nEnd);
		m_pResultView->m_strObjName = dlg.m_strProcedureName;
		m_bProcText = TRUE;
		OnSqlExecute();
	}
}

void CChildFrame::OnUpdateSqlSelectProcedures(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_lConnectionState == ADODB::adStateOpen && !m_bExecuting);
}

void CChildFrame::OnSqlObjects() 
{
	if(!m_bExecuting)
	{
		CRect rect;
		UINT nIndex = m_wndToolBar.GetToolBarCtrl().CommandToIndex(ID_SQL_OBJECTS);
		m_wndToolBar.GetToolBarCtrl().GetItemRect(nIndex, &rect);
		rect.top = rect.bottom;
		m_wndToolBar.ClientToScreen(&rect.TopLeft());
		
		CMenu menu;
		if(menu.CreatePopupMenu())
		{
			DWORD dwFlags = MF_ENABLED | MF_STRING;
			menu.AppendMenu(dwFlags, ID_SQL_SELECT_TABLES_EX, _T("&Tables...\tF8"));
			menu.AppendMenu(dwFlags, ID_SQL_SELECT_PROCEDURES, _T("&Procedures...\tF9"));
			menu.TrackPopupMenu(TPM_LEFTALIGN | TPM_LEFTBUTTON, rect.left, rect.top, this);
		}
	}
}

void CChildFrame::ClearGridList()
{
	for(POSITION pos = m_GridList.GetHeadPosition(); pos != NULL;)
	{
		CMSFlexGrid* pGridCtrl =  (CMSFlexGrid*)m_GridList.GetNext(pos);
		if(pGridCtrl != NULL)
		{
			pGridCtrl->DestroyWindow();
			delete pGridCtrl;
			pGridCtrl = NULL;
		}
	}
	
	if(!m_GridList.IsEmpty())
	{
		m_GridList.RemoveAll();
		m_nGridCount = 0;
	}

	CResultView* pResultView = GetResultView();
	if(pResultView != NULL)
		pResultView->m_pGridCtrl = NULL;
}

void CChildFrame::OnUpdateIndicatorPaneTextZero(CCmdUI* pCmdUI)
{
	if(!m_bExecuting)
		if(m_strPaneTextZero.IsEmpty())
			m_strPaneTextZero = "Ready";
	pCmdUI->SetText(m_strPaneTextZero);
	pCmdUI->Enable(TRUE);
}

void CChildFrame::OnUpdateIndicatorExecTime(CCmdUI* pCmdUI)
{
	pCmdUI->SetText(m_strExecutionTime);
	pCmdUI->Enable(TRUE);
}

void CChildFrame::OnUpdateIndicatorResultSetInfo(CCmdUI* pCmdUI)
{
	if(m_strStatusText.CompareNoCase(g_szMessages) != 0 &&
		m_strProcText.length())
	{
		m_strStatusText.Format(
				_T("# of lines of text: %d"),
				m_pResultView->GetRichEditCtrl().GetLineCount()
				);
	}
	pCmdUI->SetText(m_strStatusText);
	pCmdUI->Enable(TRUE);
}

void CChildFrame::OnUpdateIndicatorPosition(CCmdUI* pCmdUI)
{
	CView* pView = GetActiveView();
	bool bGrid = false;
	if(pView != NULL && pView->IsKindOf(RUNTIME_CLASS(CResultView)))
	{
		bGrid = m_pResultView->m_pGridCtrl != NULL &&
			::IsWindow(m_pResultView->m_pGridCtrl->m_hWnd) &&
			m_pResultView->m_pGridCtrl->IsWindowVisible();
		if(bGrid)
			m_strLineColInfo.Format(
				_T("Ln %d, Col %d"),
				m_pResultView->m_pGridCtrl->GetRow(),
				m_pResultView->m_pGridCtrl->GetCol()+1
				);
	}
	if(!bGrid)
	{
		CRichEditCtrl* pRichEditCtrl = NULL;
		if(pView != NULL)
		{
			if(pView->IsKindOf(RUNTIME_CLASS(CQryView)))
				pRichEditCtrl = &m_pQryView->GetRichEditCtrl();
			else if(pView->IsKindOf(RUNTIME_CLASS(CResultView)))
				pRichEditCtrl = &m_pResultView->GetRichEditCtrl();
		}
		if(pRichEditCtrl != NULL)
		{
			long lStart = -1;
			long lEnd = -1;
			pRichEditCtrl->GetSel(lStart, lEnd);
			m_strLineColInfo.Format(
				_T("Ln %d, Col %d"),
				pRichEditCtrl->LineFromChar(lStart)+1,
				((lEnd-lStart) >= 0 ? lEnd-pRichEditCtrl->LineIndex(-1) :
					lStart-pRichEditCtrl->LineIndex(-1))+1
				);
		}
	}
	
	pCmdUI->SetText(m_strLineColInfo);
	pCmdUI->Enable(TRUE);
}

void CChildFrame::OnViewPrevResultSet() 
{
	if(m_nIndex > 1)
	{
		POSITION pos = m_GridList.FindIndex(m_nIndex-2);
		DisplayResults((CMSFlexGrid*)m_GridList.GetAt(pos), --m_nIndex);
	}
}

void CChildFrame::OnViewNextResultSet() 
{
	if(m_nIndex > 0 && m_nIndex < m_nGridCount)
	{ 
		POSITION pos = m_GridList.FindIndex(m_nIndex);
		DisplayResults((CMSFlexGrid*)m_GridList.GetAt(pos), ++m_nIndex);
	}
}

void CChildFrame::OnViewFirstResultSet() 
{
	if(m_nIndex > 1)
	{
		m_nIndex = 0;
		POSITION pos = m_GridList.FindIndex(m_nIndex);
		DisplayResults((CMSFlexGrid*)m_GridList.GetAt(pos), ++m_nIndex);
	}
}

void CChildFrame::OnViewLastResultSet() 
{
	if(m_nIndex > 0 && m_nIndex < m_nGridCount)
	{
		m_nIndex = m_nGridCount;
		POSITION pos = m_GridList.FindIndex(--m_nIndex);
		DisplayResults((CMSFlexGrid*)m_GridList.GetAt(pos), ++m_nIndex);
	}
}

void CChildFrame::OnUpdateViewPrevResultSet(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_nIndex > 1);
}

void CChildFrame::OnUpdateViewNextResultSet(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_nIndex > 0 && m_nIndex < m_nGridCount);
}

void CChildFrame::OnUpdateViewFirstResultSet(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_nIndex > 1);
}

void CChildFrame::OnUpdateViewLastResultSet(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_nIndex > 0 && m_nIndex < m_nGridCount);
}

void CChildFrame::DisplayResults(CMSFlexGrid* pGridCtrl, const int& nCurrentSet)
{
	m_pResultView->GetRichEditCtrl().SetWindowText(NULL);

	if(m_nGridCount > 1)
		HideResultSets();
	
	if(GetFocus() == m_pResultView)
	{
		pGridCtrl->SetFocus();
		m_pResultView->SetRedraw(TRUE);
	}
	CRect rect;
	m_pResultView->GetWindowRect(&rect);
	m_pResultView->m_pGridCtrl = pGridCtrl;
	pGridCtrl->MoveWindow(0, 0, rect.Width(), rect.Height());
	pGridCtrl->ShowWindow(SW_SHOW);
	pGridCtrl->Invalidate();
	pGridCtrl->UpdateWindow();
	m_pResultView->Invalidate();
	m_pResultView->UpdateWindow();
	m_strStatusText.Format(_T("Results grid #%d of %d; %d row(s); %d col(s)"),
		nCurrentSet, m_nGridCount, pGridCtrl->GetRows()-1, pGridCtrl->GetCols());
	m_wndStatusBar.SetPaneText(m_nResultSetPaneNo, m_strStatusText);
}

void CChildFrame::HideResultSets()
{
	for(int n = 0; n < m_nGridCount; n++)
	{
		POSITION pos = m_GridList.FindIndex(n);
		if(pos != NULL)
		{
			CMSFlexGrid* pGrid = (CMSFlexGrid*)m_GridList.GetAt(pos);
			if(pGrid != NULL)
				pGrid->ShowWindow(SW_HIDE);
		}
	}
}

void CChildFrame::OnUpdateSqlObjects(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_lConnectionState == ADODB::adStateOpen && !m_bExecuting);
}

void CChildFrame::OnUpdateSqlExecute(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_lConnectionState == ADODB::adStateOpen && m_pQryView != NULL
		&& m_pQryView->GetRichEditCtrl().GetTextLength() && !m_bExecuting);
}

UINT CancelSQLProc(LPVOID lpVoid)
{
	TCP* pTCP = (TCP*)lpVoid;
	ASSERT(pTCP != NULL);
	CChildFrame* pFrame = pTCP->m_pFrame;
	ASSERT(pFrame != NULL);
	try
	{
		if(pFrame->m_ptrRecordset != NULL)
		{
			if(pFrame->m_bSupports_adAsyncExecute)
			{
				if(pFrame->m_ptrRecordset->State == ADODB::adStateExecuting ||
					pFrame->m_ptrRecordset->State == ADODB::adStateExecuting+ADODB::adStateOpen ||
					pFrame->m_ptrRecordset->State == ADODB::adStateOpen ||
					pFrame->m_ptrRecordset->State == ADODB::adStateFetching)
				{
					HRESULT hr = pFrame->m_ptrRecordset->Cancel();
					if(FAILED(hr))
						_com_issue_error(hr);
				}
			}
		}
	}
	catch(const _com_error& e)
	{
		CString sMsg = pFrame->GetProviderError();
		if(!sMsg.IsEmpty())
			sMsg = pFrame->GetComError(e);

		TRACE(_T("%s\n"), (LPCTSTR)sMsg);
	}
	catch(...)
	{
		TRACE(_T("Errors occurred on <Cancel>.\n"));
	}

	pFrame->m_bCanceled = TRUE;

	if(::IsWindow(pFrame->m_hWnd))
		::PostMessage(pFrame->m_hWnd, WM_CANCEL_COMPLETE, 0L, 0L);

	return 0L;
}

LONG CChildFrame::OnCancelComplete(UINT wParam, LONG lParam)
{
	UNUSED_ALWAYS(wParam);
	UNUSED_ALWAYS(lParam);

	if(::IsWindow(m_hWnd))
	{
		if(!m_strSQL.IsEmpty())
		{
			if(m_bProcText)
				OnExecProcComplete(0, -1);
			else
				OnExecutionComplete(0, -1);
		}

		CloseAfterCancelIfNecessary();
	}
		
	return 0L;
}

void CChildFrame::CloseAfterCancelIfNecessary()
{
	if(m_bCloseMainFrameAfterCancel)
	{
		m_bCloseMainFrameAfterCancel = FALSE;
		CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
		if(pFrame != NULL)
			pFrame->SendMessage(WM_CLOSE);
	}
	else if(m_bDisconnectAllAfterCancel)
	{
		m_bDisconnectAllAfterCancel = FALSE;
		CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
		if(pFrame != NULL)
			pFrame->OnFileDisconnectAll();
	}
	else if(m_bCloseAfterCancel)
	{
		m_bCloseAfterCancel = FALSE;
		SendMessage(WM_CLOSE);
	}
}

void CChildFrame::CancelQuery()
{
	if(!m_bExecuting)
		CloseAfterCancelIfNecessary();
	else if(!m_bCanceling && !m_bExecuteCompleteHandled)
	{
		m_bCanceling = TRUE;
		m_strPaneTextZero = _T("Attempting to cancel query batch...");
		m_wndStatusBar.SetPaneText(0, m_strPaneTextZero);
		m_TCP.m_pFrame = this;
		m_pThreadCancelSQL = AfxBeginThread(CancelSQLProc, &m_TCP);
		ASSERT(m_pThreadCancelSQL != NULL);
		m_pThreadCancelSQL->m_pMainWnd = this;
	}
}

void CChildFrame::OnSqlCancel() 
{
	m_bCloseAfterCancel = FALSE;
	CancelQuery();
}

void CChildFrame::OnUpdateSqlCancel(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_lConnectionState == ADODB::adStateOpen && m_bExecuting
		&& !m_bCanceling);
}

void CChildFrame::OnUpdateCombo(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_lConnectionState == ADODB::adStateOpen && 
		m_bIsTSQLSupported && !m_bExecuting);
}

BOOL CChildFrame::SelectDatabase()
{
	BOOL bRet = TRUE;
	
	try
	{
		ADODB::PropertiesPtr ptrProperties = m_ptrConnection->GetProperties();
		HRESULT hr = ptrProperties->Refresh();
		if(FAILED(hr))
			_com_issue_error(hr);
		ADODB::PropertyPtr ptrProperty = ptrProperties->GetItem("Current Catalog");
		_bstr_t bstrDBName = (_bstr_t)ptrProperty->GetValue();
		m_ptrConnection->DefaultDatabase = bstrDBName;
		m_comboBox.SelectString(-1, (m_strDBName = (LPCTSTR)bstrDBName));
	}
	catch(const _com_error& e)
	{
		CString sMsg = GetProviderError();
		if(!sMsg.IsEmpty())
			TRACE(_T("%s\n"), (LPCTSTR)sMsg);
		else
		{
			sMsg = GetComError(e);
			TRACE(_T("%s\n"), (LPCTSTR)sMsg);
		}

		bRet = FALSE;
	}

	return bRet;
}

void CChildFrame::SetExecutionTime()
{
	DWORD dwDiff = ::GetTickCount() - m_dwStart;
	COleDateTimeSpan span(0, 0, 0, dwDiff/1000);
	CString sBuff;
	sBuff.Format(_T("Exec time: %02d:%02d:%02d"),
			span.GetHours(), span.GetMinutes(), span.GetSeconds());
	m_strExecutionTime = sBuff;
	m_wndStatusBar.SetPaneText(1, m_strExecutionTime);
}

bool CChildFrame::SetProperties(LPCTSTR lpszInitialCatalog)
{
	bool bRet = true;

	try
	{
		ADODB::PropertyPtr ptrProperty = NULL;
		ADODB::PropertiesPtr ptrProperties = m_ptrConnection->GetProperties();
		HRESULT hr = ptrProperties->Refresh();
		if(FAILED(hr))
			_com_issue_error(hr);
		
		try
		{
			ptrProperty = ptrProperties->GetItem("Provider Name");
			m_strProviderName = (LPCTSTR)(_bstr_t)ptrProperty->GetValue();
		}
		catch(...)
		{
		}

		try
		{
			ptrProperty = ptrProperties->GetItem("Data Source");
			m_strDataSource = (LPCTSTR)(_bstr_t)ptrProperty->GetValue();
		}
		catch(...)
		{
		}
		
		try
		{
			if(m_strDataSource.IsEmpty())
			{
				ptrProperty = ptrProperties->GetItem("Current Catalog");
				m_strDataSource = (LPCTSTR)(_bstr_t)ptrProperty->GetValue();
			}
		}
		catch(...)
		{
		}

		try
		{
			ptrProperty = ptrProperties->GetItem("Multiple Results");
			m_bIsMultiSetSupported = (bool)ptrProperty->GetValue();
		}
		catch(...)
		{
		}
				
		try
		{
			ptrProperty = ptrProperties->GetItem("DBMS Name");
			m_strDBMS = CHelpers::CrackStrVariant(ptrProperty->GetValue());
		}
		catch(...)
		{
		}

		m_bIsJetDriver = !m_strDBMS.CompareNoCase(g_szMSJet);
		try
		{
			if(!m_strProviderName.CompareNoCase(g_szMSOLEDBProviderForODBCDrivers))
			{
				ptrProperty = ptrProperties->GetItem("Driver Name");
				CString sDriverName = (LPCTSTR)(_bstr_t)ptrProperty->GetValue();
				if(!sDriverName.CompareNoCase(g_szODBCJTDriver))
					m_bIsJetDriver = TRUE;
			}
		}
		catch(...)
		{
		}

		if(m_bIsJetDriver || !m_strProviderName.CompareNoCase(g_szMSADIPP) ||
			!m_strProviderName.CompareNoCase(g_szMSOLEDBProForIP))
			m_bSupports_adAsyncExecute = FALSE;
		
		m_bIsTSQLSupported = (!m_strDBMS.CompareNoCase(g_szSQLAnyWhere) ||
			!m_strDBMS.CompareNoCase(g_szASAnyWhere) ||
			!m_strDBMS.CompareNoCase(g_szSybaseOpenServer) ||
			!m_strDBMS.CompareNoCase(g_szMicrosoftSQLServer) ||
			!m_strDBMS.CompareNoCase(g_szMSSQLServer));
		if(m_bIsTSQLSupported)
		{
			CString sInitialCatalog = lpszInitialCatalog; 
			if(sInitialCatalog.CompareNoCase(g_szNoData) != 0 &&
				lpszInitialCatalog != NULL)
				if(!PutInitialCatalog(lpszInitialCatalog))
					TRACE(_T("Error putting initial catalog.\n"));
			if(!FillCombo())
				TRACE(_T("Error filling combo.\n"));
		}
		else
		{
			m_comboBox.AddString(_T("<Not supported>"));
			m_comboBox.SetCurSel(0);
		}
	}
	catch(const _com_error& e)
	{
		bRet = false;

		CString sMsg = GetProviderError();
		if(sMsg.IsEmpty())
			sMsg = GetComError(e);

		TRACE(_T("%s\n"), (LPCTSTR)sMsg);
	}

	return bRet;
}

void CChildFrame::OnDumpProviderPropertiesEx() 
{
	CDumpProviderProperties dlg;
	dlg.DoModal();
}

void CChildFrame::OnUpdateDumpProviderPropertiesEx(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_lConnectionState == ADODB::adStateOpen && !m_bExecuting);
}

CString CChildFrame::GetProviderError()
{
	CString sErrors;
	if(m_ptrConnection != NULL)
	{
		ADODB::ErrorsPtr ptrErrors = m_ptrConnection->Errors;
		long lCount = ptrErrors->Count;
		ADODB::ErrorPtr ptrError = NULL;
		CString sError;
		for(long n = 0; n < lCount; n++)
		{
			ptrError = ptrErrors->GetItem(n);
			sError.Format(
				_T("%s\nState: %s, Native: %d, Source: %s"),
				(LPCTSTR)ptrError->Description,
				(LPCTSTR)ptrError->SQLState,
				ptrError->NativeError,
				(LPCTSTR)ptrError->Source
				);
			sErrors += sError + "\n\n";
		}
	}

	if(!sErrors.IsEmpty())
		sErrors = sErrors.Left(sErrors.GetLength()-2);

	return sErrors;
}

CString CChildFrame::GetComError(const _com_error& e)
{
	CString sMsg;
	sMsg.Format(
		_T("HRESULT: 0x%08lx; Error: %s"),
		e.Error(),
		e.ErrorMessage()
		);
	
	if(e.ErrorInfo())
	{
		sMsg += "\nSource: " + CString((LPCTSTR)e.Source()) +
			"; Description: " + CString((LPCTSTR)e.Description());
	}

	return sMsg;
}

void CChildFrame::OnUpdateFileMruFile1(CCmdUI* pCmdUI) 
{
	theApp.OnUpdateFileMruFile1(pCmdUI);
}

int CChildFrame::GetThreadPriority(const CString& sPriority)
{
	int nThreadPriority = THREAD_PRIORITY_LOWEST;
	if(!sPriority.CompareNoCase(g_szTimeCritical))
		nThreadPriority = THREAD_PRIORITY_TIME_CRITICAL;
	else if(!sPriority.CompareNoCase(g_szHighest))
		nThreadPriority = THREAD_PRIORITY_HIGHEST;
	else if(!sPriority.CompareNoCase(g_szAboveNormal))
		nThreadPriority = THREAD_PRIORITY_ABOVE_NORMAL;
	else if(!sPriority.CompareNoCase(g_szNormal))
		nThreadPriority = THREAD_PRIORITY_NORMAL;
	else if(!sPriority.CompareNoCase(g_szBelowNormal))
		nThreadPriority = THREAD_PRIORITY_BELOW_NORMAL;
	else if(!sPriority.CompareNoCase(g_szLowest))
		nThreadPriority = THREAD_PRIORITY_LOWEST;
	else
		nThreadPriority = THREAD_PRIORITY_LOWEST;

	return nThreadPriority;
}

void CChildFrame::SetCommandTimeOut(const int& lCmdTimeOut)
{
	if(m_lConnectionState == ADODB::adStateOpen)
	{
		try
		{
			m_ptrConnection->CommandTimeout = lCmdTimeOut;
			m_nQueryTimeOut = lCmdTimeOut;
		}
		catch(const _com_error& e)
		{
			CString sMsg = GetProviderError();
			if(sMsg.IsEmpty())
				sMsg = GetComError(e);
			TRACE(_T("%s\n"), (LPCTSTR)sMsg);
		}
		catch(...)
		{
			TRACE(_T("Errors occurred.\n"));
		}
	}
}

void CChildFrame::SetCacheSize(const int& nCacheSize)
{
	if(m_ptrRecordset != NULL)
	{
		try
		{
			if(!m_bExecuting)
			{
				m_ptrRecordset->CacheSize = nCacheSize;
				m_nCacheSize = nCacheSize;
			}
		}
		catch(const _com_error& e)
		{
			CString sMsg = GetProviderError();
			if(sMsg.IsEmpty())
				sMsg = GetComError(e);
			TRACE(_T("%s\n"), (LPCTSTR)sMsg);
		}
		catch(...)
		{
			TRACE(_T("Errors occurred.\n"));
		}
	}
}

void CChildFrame::SetThreadPriority(const CString& sThreadPriority)
{
	m_nThreadPriority = GetThreadPriority(sThreadPriority);	
}

LONG CChildFrame::OnExecProcComplete(UINT wParam, LONG lParam)
{
	UNUSED_ALWAYS(lParam);
	OnExecutionComplete(wParam, lParam);
	m_bProcText = FALSE;

	return 0L;
}

LONG CChildFrame::OnExecutionComplete(UINT wParam, LONG lParam)
{
	UNUSED_ALWAYS(lParam);

	if(::IsWindow(m_hWnd) && !m_bExecuteCompleteHandled)
	{
		m_bExecuteCompleteHandled = TRUE;
		m_strSQL.Empty();

		CloseRecordset();

		if(m_bProcText)
		{
			if(m_strProcText.length())
			{
				if(m_strStatusText.CompareNoCase(g_szMessages) != 0)
				{
					m_pResultView->GetRichEditCtrl().SetWindowText(m_strProcText.c_str());
					m_pResultView->GetRichEditCtrl().SetSel(0, 0); // Scroll up!
					m_strStatusText.Format(
						_T("# of lines of text: %d"),
						m_pResultView->GetRichEditCtrl().GetLineCount()
						);
					m_pResultView->Invalidate();
					m_pResultView->UpdateWindow();
				}
			}
		}
		else
		{
			if(m_nGridCount)
			{
				SetResultSetInfo();
				m_ThreadParam.m_pGridCtrl->SetRedraw(TRUE);
				m_ThreadParam.m_pGridCtrl->Invalidate();
				m_ThreadParam.m_pGridCtrl->UpdateWindow();
				m_pResultView->SetRedraw(TRUE);
				m_pResultView->Invalidate();
				m_pResultView->UpdateWindow();
				if(m_strStatusText.CompareNoCase(g_szMessages) != 0)
					m_ThreadParam.m_pGridCtrl->ShowWindow(SW_SHOW);
			}
		}

		if(m_bCanceled)
		{
			m_strPaneTextZero = "Query batch canceled";
			if(m_strMessages.length())
				m_strMessages += _T("\n\n");
			m_strMessages += _T("Query canceled by user.");
		}
		else if(wParam)
			m_strPaneTextZero = "Query batch completed with errors";
		else
		{
			m_strPaneTextZero = "Query batch completed";
			if(m_bProcText)
			{
				if(!m_strProcText.length() && !m_strMessages.length())
					m_strMessages = _T("The command(s) completed successfully.");
			}
			else
			{
				if(!m_nGridCount && !m_strMessages.length())
					m_strMessages = _T("The command(s) completed successfully.");
			}
		}
		
		m_wndStatusBar.SetPaneText(0, m_strPaneTextZero);
				
		if(m_bProcText)
		{
			if(!m_strProcText.length() && m_strStatusText.CompareNoCase(g_szMessages) != 0)
				OnViewMessages();
		}
		else
		{
			if(!m_nGridCount && m_strStatusText.CompareNoCase(g_szMessages) != 0)
				OnViewMessages();
		}

		SetExecutionTime();

		if(m_nTimerID != 0)
		{
			KillTimer(m_nTimerID);
			m_nTimerID = 0;
		}

		m_bExecuting = FALSE;
		m_bCanceling = FALSE;
		m_bCanceled = FALSE;
		
		bool bOkUI = true;
		if(m_bCloseMainFrameAfterCancel)
			bOkUI = false;
		if(m_bDisconnectAllAfterCancel)
			bOkUI = false;
		if(m_bCloseAfterCancel)
			bOkUI = false;
		if(bOkUI)
		{
			LONG lIdle = 0;
			while(AfxGetApp()->OnIdle(lIdle++));
		}
	}

	return 0L;
}

LONG CChildFrame::OnGetGridCtrl(UINT wParam, LONG lParam)
{
	LRESULT lResult = 0L;
	
	if(::IsWindow(m_hWnd))
	{
		UNUSED_ALWAYS(lParam);

		CMSFlexGrid* pGridCtrl = NULL;
		try
		{
			pGridCtrl = new CMSFlexGrid();
			ASSERT(pGridCtrl != NULL);
			m_ThreadParam.m_pGridCtrl = NULL;
			m_ThreadParam.m_ptrGridCtrl = NULL;
			CRect rect(0, 0, 0, 0);
			m_pResultView->GetWindowRect(&rect);
			if(!pGridCtrl->Create(g_lpszProgID, WS_CHILD | WS_VISIBLE | WS_HSCROLL |
				WS_VSCROLL, rect, m_pResultView, m_nID++, NULL, FALSE,
				L"72E67120-5959-11cf-91F6-C2863C385E30"))
			{
				TRACE(_T("Failed to create GridCtrl.\n"));
				lResult = -1L;
			}
			else
			{
				pGridCtrl->ShowWindow(SW_HIDE);
			
				m_GridList.AddTail(pGridCtrl);
				m_nGridCount = m_GridList.GetCount();
				if(m_nGridCount == 1)
					if(GetFocus() == m_pResultView)
						m_pQryView->SetFocus();

				m_ThreadParam.m_pGridCtrl = pGridCtrl;
				m_ThreadParam.m_ptrGridCtrl = pGridCtrl->GetControlUnknown();
				if(m_nIndex == 0)
					m_pResultView->m_pGridCtrl = pGridCtrl;

				m_ThreadParam.m_ptrGridCtrl->put_BackColorBkg(
					(unsigned long)RGB(255, 255, 255)
					);
				m_ThreadParam.m_ptrGridCtrl->put_BorderStyle(
					MSFlexGridLib::flexBorderNone
					);
				m_ThreadParam.m_ptrGridCtrl->put_AllowUserResizing(
					MSFlexGridLib::flexResizeColumns
					);
				m_ThreadParam.m_ptrGridCtrl->put_FocusRect(
					MSFlexGridLib::flexFocusNone
					);
				m_ThreadParam.m_ptrGridCtrl->put_HighLight(
					MSFlexGridLib::flexHighlightAlways
					);
				m_ThreadParam.m_ptrGridCtrl->put_ScrollBars(
					MSFlexGridLib::flexScrollBarBoth
					);
				
				if(m_GridFont.m_lf.lfHeight != 0)
				{
					COleFont font(pGridCtrl->GetFont());
					font.SetBold(m_GridFont.m_bIsBold);
					font.SetCharset(m_GridFont.m_lf.lfCharSet);
					font.SetItalic(m_GridFont.m_lf.lfItalic);
					font.SetName(m_GridFont.m_strFaceName);
					CY cy;
					cy.Lo = m_GridFont.m_nSize;
					cy.Hi = 0;
					cy.int64 = cy.Lo;
					font.SetSize(cy);
					font.SetUnderline(m_GridFont.m_lf.lfUnderline);
					font.SetWeight(m_GridFont.m_lf.lfWeight);
				}
				
				m_ThreadParam.m_ptrGridCtrl->put_Cols(0);
				m_ThreadParam.m_ptrGridCtrl->put_Rows(1);
				m_ThreadParam.m_ptrGridCtrl->put_Cols(wParam);

				if(m_nGridCount == 2)
				{
					POSITION pos = m_GridList.FindIndex(m_nIndex);
					if(pos != NULL)
					{
						++m_nIndex;
						if(m_strStatusText.CompareNoCase(g_szMessages) != 0)
							DisplayResults((CMSFlexGrid*)m_GridList.GetAt(pos), m_nIndex);
						
						bool bOkUI = true;
						if(m_bCloseMainFrameAfterCancel)
							bOkUI = false;
						if(m_bDisconnectAllAfterCancel)
							bOkUI = false;
						if(m_bCloseAfterCancel)
							bOkUI = false;
						if(bOkUI)
						{
							LONG lIdle = 0;
							while(AfxGetApp()->OnIdle(lIdle++));
						}
					}
				}
				
				pGridCtrl->MoveWindow(0, 0, rect.Width(), rect.Height());
			}
		}
		catch(COleDispatchException* e)
		{
			lResult = -1L;
			
			if(e)
				e->Delete();
		}
		catch(const _com_error& e)
		{
			lResult = -1L;

			TRACE(_T("%s\n"), (LPCTSTR)GetComError(e));
		}
		catch(...)
		{
			lResult = -1L;
		}

		if(lResult == -1L)
		{
			if(pGridCtrl != NULL)
			{
				pGridCtrl->DestroyWindow();
				delete pGridCtrl;
				pGridCtrl = NULL;
			}
		}
	}
	
	return lResult;
}

LONG CChildFrame::OnSetGridRows(UINT wParam, LONG lParam)
{
	LRESULT lResult = 0L;
	
	if(::IsWindow(m_hWnd))
	{
		UNUSED_ALWAYS(lParam);

		try
		{
			if(m_ThreadParam.m_ptrGridCtrl != NULL)
			{
				m_pResultView->SetRedraw(FALSE);
				
				HRESULT hr = m_ThreadParam.m_ptrGridCtrl->put_Redraw(FALSE);
				if(FAILED(hr))
					_com_issue_error(hr);
				
				hr = m_ThreadParam.m_ptrGridCtrl->put_Rows(wParam);
				if(FAILED(hr))
					_com_issue_error(hr);
				
				hr = m_ThreadParam.m_ptrGridCtrl->put_Redraw(TRUE);
				if(FAILED(hr))
					_com_issue_error(hr);
				
				m_pResultView->SetRedraw(TRUE);
				if(m_nGridCount == 1)
					if(m_strStatusText.CompareNoCase(g_szMessages) != 0)
						m_ThreadParam.m_pGridCtrl->ShowWindow(SW_SHOW);
			}
		}
		catch(const _com_error& e)
		{
			lResult = -1L;

			TRACE(_T("%s\n"), (LPCTSTR)GetComError(e));
		}
		catch(...)
		{
			lResult = -1L;
		}
	}

	return lResult;
}

void CChildFrame::OnViewMessages() 
{
	if(m_strStatusText.CompareNoCase(g_szMessages) != 0)
	{
		HideResultSets();
		
		m_pResultView->GetRichEditCtrl().SetWindowText(m_strMessages.c_str());
		m_strStatusText = g_szMessages;
	}
	else
	{
		if(m_strProcText.length())
		{
			m_pResultView->SetWrapNone();
			m_pResultView->GetRichEditCtrl().SetWindowText(m_strProcText.c_str());
			m_pResultView->GetRichEditCtrl().SetSel(0, 0); // Scroll up!
			m_strStatusText.Format(
				_T("# of lines of text: %d"),
				m_pResultView->GetRichEditCtrl().GetLineCount()
				);
		}
		else
		{
			int nCurrentSet = 1;
			if(m_nIndex != 0)
				nCurrentSet = m_nIndex;
			POSITION pos = m_GridList.FindIndex(nCurrentSet-1);
			if(pos == NULL)
			{
				m_pResultView->GetRichEditCtrl().SetWindowText(NULL);
				m_strStatusText = "Results grid #0 of 0; 0 row(s); 0 col(s)";
			}
			else
			{
				CMSFlexGrid* pGrid = (CMSFlexGrid*)m_GridList.GetAt(pos);
				if(pGrid != NULL)
					DisplayResults(pGrid, nCurrentSet);
			}
		}
	}
	m_pResultView->Invalidate();
	m_pResultView->UpdateWindow();
}

void CChildFrame::OnUpdateViewMessages(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_lConnectionState == ADODB::adStateOpen && m_strMessages.length());
	pCmdUI->SetCheck(!m_strStatusText.CompareNoCase(g_szMessages) &&
		m_lConnectionState == ADODB::adStateOpen && m_strMessages.length());
}

bool CChildFrame::SelectDataBaseEx()
{
	bool bRet = true;
	
	CloseRecordset();

	try
	{
		long lOption = ADODB::adCmdText;
		_bstr_t bstr = L"select db_name()";
		HRESULT hr = m_ptrRecordset->Open(
				bstr,
				m_ptrConnection.GetInterfacePtr(),
				ADODB::adOpenForwardOnly,
				ADODB::adLockReadOnly,
				lOption
				);
		if(FAILED(hr))
			_com_issue_error(hr);
		
		if(m_ptrRecordset->State != ADODB::adStateClosed)
		{
			if(!m_ptrRecordset->adoBOF)
			{
				_bstr_t bstrDBName = (_bstr_t)m_ptrRecordset->
					Fields->GetItem((long)0)->Value;
				
				ADODB::PropertiesPtr ptrProperties = m_ptrConnection->GetProperties();
				HRESULT hr = ptrProperties->Refresh();
				if(FAILED(hr))
					_com_issue_error(hr);
				
				ADODB::PropertyPtr ptrProperty = ptrProperties->GetItem("Current Catalog");
				hr = ptrProperty->put_Value(_variant_t((LPCTSTR)bstrDBName));
				if(FAILED(hr))
					_com_issue_error(hr);
				m_comboBox.SelectString(-1, (m_strDBName = (LPCTSTR)bstrDBName));
			}
		}
	}
	catch(const _com_error& e)
	{
		CString sMsg = GetProviderError();
		if(!sMsg.IsEmpty())
			TRACE(_T("%s\n"), (LPCTSTR)sMsg);
		else
		{
			sMsg = GetComError(e);
			TRACE(_T("%s\n"), (LPCTSTR)sMsg);
		}

		bRet = false;
	}
	catch(...)
	{
		TRACE(_T("Errors occurred.\n"));
	}
	
	CloseRecordset();

	return bRet;
}

void CChildFrame::OnTimer(UINT nIDEvent) 
{
	if(m_nTimerID != nIDEvent)
		CMDIChildWnd::OnTimer(nIDEvent);
	else
	{
		if(m_bExecuting)
		{
			SetExecutionTime();
			if(!m_bProcText)
				SetResultSetInfo();
		}
	}
}

void CChildFrame::SetResultSetInfo()
{
	if(m_strStatusText.CompareNoCase(g_szMessages) != 0)
	{
		int nCurrentSet = 1;
		if(m_nIndex != 0)
			nCurrentSet = m_nIndex;
		POSITION pos = m_GridList.FindIndex(nCurrentSet-1);
		if(pos != NULL)
		{
			CMSFlexGrid* pGrid = (CMSFlexGrid*)m_GridList.GetAt(pos);
			if(pGrid != NULL)
			{
				m_strStatusText.Format(_T("Results grid #%d of %d; %d row(s); %d col(s)"),
					nCurrentSet, m_nGridCount, pGrid->GetRows()-1, pGrid->GetCols());
				m_wndStatusBar.SetPaneText(m_nResultSetPaneNo, m_strStatusText);
			}
		}
	}
}

void CChildFrame::CloseRecordset()
{
	try
	{
		if(m_ptrRecordset->State != ADODB::adStateClosed)
		{
			HRESULT hr = m_ptrRecordset->Close();
			if(FAILED(hr))
				_com_issue_error(hr);
		}
	}
	catch(const _com_error& e)
	{
		CString sMsg = GetProviderError();
		if(sMsg.IsEmpty())
			sMsg = GetComError(e);

		TRACE(_T("%s\n"), (LPCTSTR)sMsg);
	}
	catch(...)
	{
		TRACE(_T("Errors occurred.\n"));
	}
}

void CChildFrame::OnSetDbcomboFocus() 
{
	m_comboBox.SetFocus();
}

void CChildFrame::PostNcDestroy() 
{
	CWaitCursor wait;

	ClearGridList();

	if(m_font.m_hObject != NULL)
	{
		m_font.Detach();
		m_font.m_hObject = NULL;
	}

	try
	{
		HRESULT hr = S_OK;
		if(m_ptrConnection != NULL)
		{
			hr = m_ptrConnection->Close();
			if(FAILED(hr))
				_com_issue_error(hr);
		}
		
		if(m_ptrCommand != NULL)
		{
			m_ptrCommand.Release();
			m_ptrCommand = NULL;
		}

		if(m_ptrRecordset != NULL)
		{
			m_ptrRecordset.Release();
			m_ptrRecordset = NULL;
		}

		if(m_ptrConnection != NULL)
		{
			try
			{
				hr = ClearConnectionEvents();
				if(FAILED(hr))
					_com_issue_error(hr);
			}
			catch(const _com_error& e)
			{
				CString sMsg = GetProviderError();
				if(sMsg.IsEmpty())
					sMsg = GetComError(e);

				TRACE(_T("ClearConnectionEvents: %s\n"), (LPCTSTR)sMsg);
				
				try
				{
					if(m_pCE != NULL)
					{
						delete m_pCE;
						m_pCE = NULL;
					}
				}
				catch(...)
				{
				}
			}
			catch(...)
			{
				TRACE(_T("Errors occurred.\n"));

				try
				{
					if(m_pCE != NULL)
					{
						delete m_pCE;
						m_pCE = NULL;
					}
				}
				catch(...)
				{
				}
			}

			m_ptrConnection.Release();
			m_ptrConnection = NULL;
		}
	}
	catch(const _com_error& e)
	{
		CString sMsg = GetProviderError();
		if(sMsg.IsEmpty())
			sMsg = GetComError(e);

		TRACE(_T("%s\n"), (LPCTSTR)sMsg);
	}
	catch(...)
	{
		TRACE(_T("Errors occurred.\n"));
	}

	if(m_nTimerID != 0)
	{
		if(::IsWindow(this->m_hWnd))
			KillTimer(m_nTimerID);

		m_nTimerID = 0;
	}

	if(m_pThreadCancelSQL != NULL &&
		AfxIsValidAddress(m_pThreadCancelSQL, sizeof(m_pThreadCancelSQL)) &&
		m_pThreadCancelSQL->m_hThread != NULL)
	{
		m_pThreadCancelSQL->PostThreadMessage(WM_QUIT, 0L, 0L);
		::WaitForSingleObject(m_pThreadCancelSQL->m_hThread, 30000);
	}

	if(m_pThreadExecuteSQL != NULL &&
		AfxIsValidAddress(m_pThreadExecuteSQL, sizeof(m_pThreadExecuteSQL)) &&
		m_pThreadExecuteSQL->m_hThread != NULL)
	{
		m_pThreadExecuteSQL->PostThreadMessage(WM_QUIT, 0L, 0L);
		::WaitForSingleObject(m_pThreadExecuteSQL->m_hThread, 30000);
	}
		
	CMDIChildWnd::PostNcDestroy();
}

void CChildFrame::OnClose() 
{
	bool bOKToClose = true;
	if(m_bCanceling)
		m_bCloseAfterCancel = TRUE;
	else
	{
		if(IsIconic())
			ShowWindow(SW_SHOWNORMAL);

		if(!m_strSQL.IsEmpty() || m_bExecuting)
		{
			CString sMsg = "A query execution is in progress. Are you sure you wish to cancel this query?";
			if(AfxMessageBox(sMsg, MB_YESNO | MB_ICONQUESTION) == IDNO)
				bOKToClose = false;
			else
			{
				if(!m_bCanceling)
				{
					m_bCloseAfterCancel = TRUE;
					CancelQuery();
					bOKToClose = false;
				}
			}
		}
	}

	if(m_bCanceling)
		if(!m_bCanceled)
			bOKToClose = false;

	if(bOKToClose)
		CMDIChildWnd::OnClose();
}

/////////////////////////////////////////////////////////////////////////////
// ADO Events

HRESULT CChildFrame::SetConnectionEvents()
{
	IConnectionPointContainer* pCPC = NULL;
	HRESULT hr = m_ptrConnection->QueryInterface(
		IID_IConnectionPointContainer, (LPVOID*)&pCPC
		);
	if(FAILED(hr))
		return hr;
	
	IConnectionPoint* pCP = NULL;
	hr = pCPC->FindConnectionPoint(__uuidof(ConnectionEvents), &pCP);
	pCPC->Release();
	if(FAILED(hr))
		return hr;
	m_pCE = new CQryToolConnectionEvents(this);
	hr = pCP->Advise(m_pCE, &m_dwCnEvents);
	pCP->Release();
	
	return hr;
}

HRESULT CChildFrame::ClearConnectionEvents()
{
	IConnectionPointContainer* pCPC = NULL;
	HRESULT hr = m_ptrConnection->QueryInterface(
		IID_IConnectionPointContainer, (LPVOID *) &pCPC
		);
	if(FAILED(hr))
		return hr;

	IConnectionPoint* pCP = NULL;
	hr =  pCPC->FindConnectionPoint(__uuidof(ConnectionEvents), &pCP);
	pCPC->Release();
	if(FAILED(hr))
		return hr;
	hr = pCP->Unadvise(m_dwCnEvents);
	pCP->Release();

	return hr;
}

/////////////////////////////////////////////////////////////////////////////
// Helpers for saving/restoring font state

void CChildFrame::GetProfileFont(LPCTSTR szSec, LOGFONT* plf, const bool& bGrid, 
	BOOL* pIsBold, int* pSize)
{
	CWinApp* pApp = AfxGetApp();
	plf->lfHeight = pApp->GetProfileInt(szSec, g_szHeight, 0);
	if(plf->lfHeight != 0)
	{
		plf->lfWeight = pApp->GetProfileInt(szSec, g_szWeight, 0);
		plf->lfItalic = (BYTE)pApp->GetProfileInt(szSec, g_szItalic, 0);
		plf->lfUnderline = (BYTE)pApp->GetProfileInt(szSec, g_szUnderline, 0);
		plf->lfPitchAndFamily = (BYTE)pApp->GetProfileInt(szSec, g_szPitchAndFamily, 0);
		plf->lfCharSet = (BYTE)pApp->GetProfileInt(szSec, g_szCharSet, DEFAULT_CHARSET);
		CString strFont = pApp->GetProfileString(szSec, g_szFaceName, g_szSystem);
		lstrcpyn((TCHAR*)plf->lfFaceName, strFont, sizeof(plf->lfFaceName));
		plf->lfFaceName[sizeof(plf->lfFaceName)-1] = 0;
		
		if(bGrid)
		{
			*pIsBold = pApp->GetProfileInt(szSec, g_szBold, 0);
			*pSize = pApp->GetProfileInt(szSec, g_szSize, 0);
		}
	}
}

void CChildFrame::WriteProfileFont(LPCTSTR szSec, const LOGFONT* plf,
	const bool& bGrid, BOOL* pIsBold, int* pSize)
{
	if(plf->lfHeight != 0)
	{
		CWinApp* pApp = AfxGetApp();
		pApp->WriteProfileInt(szSec, g_szHeight, plf->lfHeight);
		pApp->WriteProfileInt(szSec, g_szWeight, plf->lfWeight);
		pApp->WriteProfileInt(szSec, g_szItalic, plf->lfItalic);
		pApp->WriteProfileInt(szSec, g_szUnderline, plf->lfUnderline);
		pApp->WriteProfileInt(szSec, g_szPitchAndFamily, plf->lfPitchAndFamily);
		pApp->WriteProfileInt(szSec, g_szCharSet, plf->lfCharSet);
		pApp->WriteProfileString(szSec, g_szFaceName, (LPCTSTR)plf->lfFaceName);

		if(bGrid)
		{
			pApp->WriteProfileInt(szSec, g_szBold, *pIsBold);
			pApp->WriteProfileInt(szSec, g_szSize, *pSize);
		}
	}
}