// GeneralPage.cpp : implementation file
//

#include "stdafx.h"
#include "QryTool.h"
#include "GeneralPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// Data Source
LPCTSTR g_szConfigure = _T("Configure");
LPCTSTR g_szQueryTimeOut = _T("QueryTimeOut"); 
LPCTSTR g_szCacheSize = _T("CacheSize"); 

// Query
LPCTSTR g_szThreadPriority = _T("ThreadPriority");
LPCTSTR g_szTimeCritical = _T("Time critical");
LPCTSTR g_szHighest = _T("Highest");
LPCTSTR g_szAboveNormal = _T("Above Normal");
LPCTSTR g_szNormal = _T("Normal");
LPCTSTR g_szBelowNormal = _T("Below Normal");
LPCTSTR g_szLowest = _T("Lowest");
/////////////////////////////////////////////////////////////////////////////
// CGeneralPage property page

IMPLEMENT_DYNCREATE(CGeneralPage, CPropertyPage)

CGeneralPage::CGeneralPage() : CPropertyPage(CGeneralPage::IDD)
{
	//{{AFX_DATA_INIT(CGeneralPage)
	m_strQueryTimeOut = _T("");
	m_strCacheSize = _T("");
	//}}AFX_DATA_INIT
}

CGeneralPage::~CGeneralPage()
{
}

void CGeneralPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGeneralPage)
	DDX_Control(pDX, IDC_EXECUTION_PRIORITY, m_cbThreadPriority);
	DDX_Text(pDX, IDC_QUERY_TIMEOUT, m_strQueryTimeOut);
	DDV_MaxChars(pDX, m_strQueryTimeOut, 5);
	DDX_Text(pDX, IDC_CACHE_SIZE, m_strCacheSize);
	DDV_MaxChars(pDX, m_strCacheSize, 6);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CGeneralPage, CPropertyPage)
	//{{AFX_MSG_MAP(CGeneralPage)
	ON_BN_CLICKED(IDC_RESET, OnReset)
	ON_CBN_SELCHANGE(IDC_EXECUTION_PRIORITY, OnSelchangeExecutionPriority)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGeneralPage message handlers

bool CGeneralPage::Validate()
{
	CWaitCursor wait;

	UpdateData();

	m_strQueryTimeOut.TrimRight();
	m_strQueryTimeOut.TrimLeft();
	if(m_strQueryTimeOut.IsEmpty())
	{
		AfxMessageBox(_T("<Query Timeout> is a required field. The default value is Zero."));
		GetDlgItem(IDC_QUERY_TIMEOUT)->SetFocus();
		return false;
	}

	m_strCacheSize.TrimRight();
	m_strCacheSize.TrimLeft();
	if(m_strCacheSize.IsEmpty())
	{
		AfxMessageBox(_T("<Cache Size> is a required field. The default value is 100."));
		GetDlgItem(IDC_CACHE_SIZE)->SetFocus();
		return false;
	}

#ifdef _UNICODE	
	USES_CONVERSION;
	m_nQueryTimeOut = atoi(W2CA((LPCTSTR)m_strQueryTimeOut));
#else
	m_nQueryTimeOut = atoi((LPCTSTR)m_strQueryTimeOut);
#endif
	if(m_nQueryTimeOut > 99999 || m_nQueryTimeOut < 0)
	{
		AfxMessageBox(_T("Please enter an integer between 0 and 99999."));
		GetDlgItem(IDC_QUERY_TIMEOUT)->SetFocus();
		return false;
	}

#ifdef _UNICODE	
	m_nCacheSize = atoi(W2CA((LPCTSTR)m_strCacheSize));
#else
	m_nCacheSize = atoi((LPCTSTR)m_strCacheSize);
#endif
	if(m_nCacheSize > 349999 || m_nCacheSize < 1)
	{
		AfxMessageBox(_T("Please enter an integer between 1 and 349999."));
		GetDlgItem(IDC_CACHE_SIZE)->SetFocus();
		return false;
	}
	
	CWinApp* pApp = AfxGetApp();
	pApp->WriteProfileInt(g_szConfigure, g_szQueryTimeOut, m_nQueryTimeOut);
	pApp->WriteProfileInt(g_szConfigure, g_szCacheSize, m_nCacheSize);
	
	m_cbThreadPriority.GetWindowText(m_strThreadPriority);
	pApp->WriteProfileString(g_szConfigure, g_szThreadPriority, m_strThreadPriority);

	return true;
}

void CGeneralPage::OnReset() 
{
	m_nQueryTimeOut = 0;
	m_strQueryTimeOut.Format(_T("%d"), m_nQueryTimeOut);
	
	m_nCacheSize = 100;
	m_strCacheSize.Format(_T("%d"), m_nCacheSize);

	m_cbThreadPriority.SelectString(-1, g_szLowest);

	UpdateData(FALSE);
}

BOOL CGeneralPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	m_nQueryTimeOut = AfxGetApp()->GetProfileInt(g_szConfigure, g_szQueryTimeOut, 0);
	if(m_nQueryTimeOut > 99999 || m_nQueryTimeOut < 0)
		m_nQueryTimeOut = 0;
	m_strQueryTimeOut.Format(_T("%d"), m_nQueryTimeOut);

	m_nCacheSize = AfxGetApp()->GetProfileInt(g_szConfigure, g_szCacheSize, 100);
	if(m_nCacheSize > 999999 || m_nCacheSize <= 0)
		m_nCacheSize = 100;
	m_strCacheSize.Format(_T("%d"), m_nCacheSize);

	m_cbThreadPriority.SetItemData(
		m_cbThreadPriority.AddString(g_szTimeCritical),
		THREAD_PRIORITY_TIME_CRITICAL);

	m_cbThreadPriority.SetItemData(
		m_cbThreadPriority.AddString(g_szHighest),
		THREAD_PRIORITY_HIGHEST);

	m_cbThreadPriority.SetItemData(
		m_cbThreadPriority.AddString(g_szAboveNormal),
		THREAD_PRIORITY_ABOVE_NORMAL);

	m_cbThreadPriority.SetItemData(
		m_cbThreadPriority.AddString(g_szNormal),
		THREAD_PRIORITY_NORMAL);

	m_cbThreadPriority.SetItemData(
		m_cbThreadPriority.AddString(g_szBelowNormal),
		THREAD_PRIORITY_BELOW_NORMAL);

	m_cbThreadPriority.SetItemData(
		m_cbThreadPriority.AddString(g_szLowest),
		THREAD_PRIORITY_LOWEST);

	m_strThreadPriority = AfxGetApp()->GetProfileString(g_szConfigure, g_szThreadPriority);
	m_strThreadPriority.TrimRight(); 
	m_strThreadPriority.TrimLeft();
	if(m_strThreadPriority.IsEmpty())
		m_strThreadPriority = g_szLowest;
	m_cbThreadPriority.SelectString(-1, m_strThreadPriority);

	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CGeneralPage::OnSelchangeExecutionPriority() 
{
	m_cbThreadPriority.GetWindowText(m_strThreadPriority);
	if(m_strThreadPriority.CompareNoCase(g_szLowest) != 0)
	{
		CString sMsg = "Warning: Changing the query execution thread priority class ";
				sMsg +="other than the default (Lowest) may cause undesired results ";
				sMsg +="including system instability. Are you sure you want to ";
				sMsg +="change the priority class?";
		if(AfxMessageBox(sMsg, MB_YESNO | MB_ICONQUESTION) == IDNO)
			m_cbThreadPriority.SelectString(-1, g_szLowest);
		else
			m_cbThreadPriority.SelectString(-1, m_strThreadPriority);
	}
}