// ChildFrm.h : interface of the CChildFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_CHILDFRM_H__E1966CBB_6232_11D3_A7CD_00C04F595ED0__INCLUDED_)
#define AFX_CHILDFRM_H__E1966CBB_6232_11D3_A7CD_00C04F595ED0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "QryView.h"
#include "ResultView.h"

class CQryToolConnectionEvents;

struct ThreadParam
{
	CStringEx m_strSQL;
	CChildFrame* m_pFrame;
	CMSFlexGrid* m_pGridCtrl;
	MSFlexGridLib::IMSFlexGridPtr m_ptrGridCtrl;
	ADODB::_RecordsetPtr m_ptrRS;
	_variant_t m_vRowsAffected;
};

struct TCP
{
	CChildFrame* m_pFrame;
};

struct GridFont
{
	LOGFONT m_lf;
	BOOL m_bIsBold;
	CString m_strFaceName;
	int m_nSize;
};

class CChildFrame : public CMDIChildWnd
{
	DECLARE_DYNCREATE(CChildFrame)
public:
	CChildFrame();

// Attributes
public:

// Operations
public:
	ADODB::_ConnectionPtr m_ptrConnection;
	ADODB::_CommandPtr m_ptrCommand;
	ADODB::_RecordsetPtr m_ptrRecordset;
	ThreadParam m_ThreadParam;
	TCP m_TCP;
	GridFont m_GridFont;
	void GetProfileFont(LPCTSTR szSec, LOGFONT* plf, const bool& bGrid, 
		BOOL* pIsBold, int* pSize);
	void WriteProfileFont(LPCTSTR szSec, const LOGFONT* plf, const bool& bGrid,
		BOOL* pIsBold, int* pSize);
	CQryView* m_pQryView;
	CResultView* m_pResultView;
	void SetCommandTimeOut(const int& lCmdTimeOut);
	void SetCacheSize(const int& nCacheSize);
	CString GetComError(const _com_error& e);
	CString GetProviderError();
	BOOL m_bDisconnectAllAfterCancel;
	BOOL m_bCloseMainFrameAfterCancel;
	BOOL m_bIsTSQLSupported;
	BOOL m_bIsMultiSetSupported;
	BOOL m_bIsJetDriver;
	CWinThread* m_pThreadExecuteSQL;
	CWinThread* m_pThreadCancelSQL;
				
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChildFrame)
	protected:
	virtual BOOL OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext);
	virtual void PostNcDestroy();
	//}}AFX_VIRTUAL

// Implementation
public:
	int m_nLineColPaneNo;
	CString m_strLineColInfo;
	BOOL m_bSupports_adAsyncExecute;
	int m_nGridCount;
	void CloseRecordset();
#if defined _UNICODE
	std::basic_string<wchar_t> m_strProcText;
	std::basic_string<wchar_t> m_strMessages;
#else
	std::basic_string<char> m_strProcText;
	std::basic_string<char> m_strMessages;
#endif
	BOOL m_bProcText;
	int m_nExecutionTimePaneNo;
	CString m_strExecutionTime;
	BOOL m_bCanceling;
	CString m_strPaneTextZero;
	BOOL m_bExecuteCompleteHandled;
	bool SelectDataBaseEx();
	BOOL SelectDatabase();
	int m_nThreadPriority;
	void SetThreadPriority(const CString& sThreadPriority);
	CString m_strDataSource;
	void InitialShowWindow(UINT nCmdShow);
	CQryView* GetQryView();
	CResultView* GetResultView();
	int m_nResultSetPaneNo;
	CString m_strDBMS;
	BOOL Connect(LPCTSTR lpszConnectString = NULL, const bool& bRetry = false,
		LPCTSTR lpszInitialCatalog = NULL);
	CString m_strConnectString;
	long m_lConnectionState;
	CString m_strProviderName;
	CString m_strSQL;
	BOOL m_bCanceled;
	BOOL m_bExecuting;
	CString m_strDBName;
	CPtrList m_GridList;
	CString m_strStatusText;
	void OnExceptionClear(const CString& sMsg);
	BOOL ExecuteSQL(const CStringEx& sSQL);
	CSplitterWnd m_wndSplitter;
	void SetExecutionTime();
	int m_nIndex;
	void DisplayResults(CMSFlexGrid* pGridCtrl, const int& nCurrentSet);
	virtual ~CChildFrame();
	CStatusBar m_wndStatusBar;
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	CToolBar m_wndToolBar;
	
// Generated message map functions
public:
	//{{AFX_MSG(CChildFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnClose();
	afx_msg void OnQueryNew();
	afx_msg void OnUpdateQueryNew(CCmdUI* pCmdUI);
	afx_msg void OnViewPrevResultSet();
	afx_msg void OnUpdateViewPrevResultSet(CCmdUI* pCmdUI);
	afx_msg void OnViewNextResultSet();
	afx_msg void OnUpdateViewNextResultSet(CCmdUI* pCmdUI);
	afx_msg void OnViewLastResultSet();
	afx_msg void OnUpdateViewLastResultSet(CCmdUI* pCmdUI);
	afx_msg void OnViewFirstResultSet();
	afx_msg void OnUpdateViewFirstResultSet(CCmdUI* pCmdUI);
	afx_msg void OnSqlSelectProcedures();
	afx_msg void OnUpdateSqlSelectProcedures(CCmdUI* pCmdUI);
	afx_msg void OnSqlObjects();
	afx_msg void OnUpdateSqlObjects(CCmdUI* pCmdUI);
	afx_msg void OnSqlExecute();
	afx_msg void OnUpdateSqlExecute(CCmdUI* pCmdUI);
	afx_msg void OnSqlCancel();
	afx_msg void OnUpdateSqlCancel(CCmdUI* pCmdUI);
	afx_msg void OnSelChangeDatabase();
	afx_msg void OnSqlSelectTables();
	afx_msg void OnUpdateSqlSelectTables(CCmdUI* pCmdUI);
	afx_msg void OnUpdateCombo(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFileMruFile1(CCmdUI* pCmdUI);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnViewMessages();
	afx_msg void OnUpdateViewMessages(CCmdUI* pCmdUI);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnDumpProviderPropertiesEx();
	afx_msg void OnUpdateDumpProviderPropertiesEx(CCmdUI* pCmdUI);
	afx_msg void OnSetDbcomboFocus();
	//}}AFX_MSG
	afx_msg void OnUpdateIndicatorPaneTextZero(CCmdUI* pCmdUI);
	afx_msg void OnUpdateIndicatorExecTime(CCmdUI* pCmdUI);
	afx_msg void OnUpdateIndicatorResultSetInfo(CCmdUI* pCmdUI);
	afx_msg void OnUpdateIndicatorPosition(CCmdUI* pCmdUI);
	afx_msg long OnExecutionComplete(UINT wParam, LONG lParam);
	afx_msg long OnExecProcComplete(UINT wParam, LONG lParam);
	afx_msg long OnCancelComplete(UINT wParam, LONG lParam);
	afx_msg long OnGetGridCtrl(UINT wParam, LONG lParam);
	afx_msg long OnSetGridRows(UINT wParam, LONG lParam);
	DECLARE_MESSAGE_MAP()
private:
	bool m_bOKToSize;
	bool PutInitialCatalog(LPCTSTR lpszInitialCatalog);
	void CloseAfterCancelIfNecessary();
	BOOL m_bCloseAfterCancel;
	CQryToolConnectionEvents* m_pCE;
	DWORD  m_dwCnEvents;
	void ClearGridList();
	void CancelQuery();
	int m_nCacheSize;
	int m_nQueryTimeOut;
	void SetResultSetInfo();
	UINT m_nTimerID;
	HRESULT SetConnectionEvents();
	HRESULT ClearConnectionEvents();
	int GetThreadPriority(const CString& sPriority);
	CString m_strAppTitle;
	CFont m_font;
	CComboBox m_comboBox;
	bool SetProperties(LPCTSTR lpszInitialCatalog = NULL);
	DWORD m_dwStart;
	void HideResultSets();
	UINT m_nID;
	BOOL FillCombo();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHILDFRM_H__E1966CBB_6232_11D3_A7CD_00C04F595ED0__INCLUDED_)