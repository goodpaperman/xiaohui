// QryView.h : interface of the CQryView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_QRYVIEW_H__E1966CBF_6232_11D3_A7CD_00C04F595ED0__INCLUDED_)
#define AFX_QRYVIEW_H__E1966CBF_6232_11D3_A7CD_00C04F595ED0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CChildFrame;

#include "QryToolDoc.h"

class CQryView : public CRichEditView
{
protected: // create from serialization only
	CQryView();
	DECLARE_DYNCREATE(CQryView)

// Attributes
public:
	CQryToolDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CQryView)
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	void SetFontEx();
	virtual ~CQryView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	virtual HMENU GetContextMenu(WORD wSelType, LPOLEOBJECT lpOleObj, CHARRANGE* lpChrg);

// Generated message map functions
protected:
	CFont m_font;
	//{{AFX_MSG(CQryView)
	afx_msg void OnSqlExecute();
	afx_msg void OnUpdateViewWrapWord(CCmdUI* pCmdUI);
	afx_msg void OnViewWrapWord();
	afx_msg void OnFilePrint();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnEditAdvancedMakeSelectionLowercase();
	afx_msg void OnUpdateEditAdvancedMakeSelectionLowercase(CCmdUI* pCmdUI);
	afx_msg void OnEditAdvancedMakeSelectionUppercase();
	afx_msg void OnUpdateEditAdvancedMakeSelectionUppercase(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditClearAll(CCmdUI* pCmdUI);
	afx_msg void OnEditClearAll();
	afx_msg void OnViewFont();
	afx_msg void OnEditPaste();
	afx_msg void OnUpdateEditPaste(CCmdUI* pCmdUI);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnEditTabifySelection();
	afx_msg void OnUpdateEditTabifySelection(CCmdUI* pCmdUI);
	afx_msg void OnEditUntabifySelection();
	afx_msg void OnUpdateEditUntabifySelection(CCmdUI* pCmdUI);
	afx_msg void OnSqlCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void ToggleCase(const bool& bUpper = true);
	void ToggleTabify(const bool& bTabify = true);
	CChildFrame* m_pChildFrame;
};

#ifndef _DEBUG  // debug version in QryView.cpp
inline CQryToolDoc* CQryView::GetDocument()
   { return (CQryToolDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_QRYVIEW_H__E1966CBF_6232_11D3_A7CD_00C04F595ED0__INCLUDED_)