// CQryToolConnectionEvents.h: interface for the CQryToolConnectionEvents class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ISQLCONNECTIONEVENTS_H__62B7E2B3_3EDE_11D3_A793_00C04F595ED0__INCLUDED_)
#define AFX_ISQLCONNECTIONEVENTS_H__62B7E2B3_3EDE_11D3_A793_00C04F595ED0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ADOConnectionEvents.h"
#include "ChildFrm.h"

//////////////////////////////////////////////////////////////////////
// CISQLConnectionEvents

UINT ExecuteSQLProc(LPVOID lpVoid);
UINT ExecuteSQLProcProc(LPVOID lpVoid);

class CQryToolConnectionEvents : public CADOConnectionEvents
{
public:
	CQryToolConnectionEvents(CChildFrame* pChildFrame = NULL);
	virtual ~CQryToolConnectionEvents();

	STDMETHOD(ExecuteComplete)( 
		LONG RecordsAffected,
		ADOError* pError,
		EventStatusEnum* adStatus,
		_ADOCommand* pCommand,
		_ADORecordset* pRecordset,
		_ADOConnection* pConnection
		);
	static HRESULT PopulateGrid(ThreadParam* pTP);
	static void SetGridHeaderInfo(const MSFlexGridLib::IMSFlexGridPtr&
		ptrGridCtrl, const ADODB::FieldsPtr& ptrFields, const long& lCols);
	static long m_lRow;
private:
	CChildFrame* m_pChildFrame;
};

//////////////////////////////////////////////////////////////////////

#endif // !defined(AFX_ISQLCONNECTIONEVENTS_H__62B7E2B3_3EDE_11D3_A793_00C04F595ED0__INCLUDED_)