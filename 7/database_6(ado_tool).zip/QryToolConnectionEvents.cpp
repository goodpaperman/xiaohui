// QryToolConnectionEvents.cpp: implementation of the CQryToolConnectionEvents class.
//

#include "stdafx.h"
#include "QryToolConnectionEvents.h"
#include "MainFrm.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

long CQryToolConnectionEvents::m_lRow = 0;
//////////////////////////////////////////////////////////////////////
// CQryToolConnectionEvents

CQryToolConnectionEvents::CQryToolConnectionEvents(CChildFrame* pChildFrame)
{
	m_pChildFrame = pChildFrame;
}

CQryToolConnectionEvents::~CQryToolConnectionEvents()
{
	m_pChildFrame = NULL;
}

STDMETHODIMP CQryToolConnectionEvents::ExecuteComplete( 
	LONG RecordsAffected,
	ADOError* pError,
	EventStatusEnum* adStatus,
	_ADOCommand* pCommand,
	_ADORecordset* pRecordset,
	_ADOConnection* pConnection)
{
	OutputDebugString(_T("ExecuteComplete event fired.\n"));

	UNUSED_ALWAYS(adStatus);
	UNUSED_ALWAYS(pError);
	UNUSED_ALWAYS(pCommand);
	UNUSED_ALWAYS(pConnection);
	
	HRESULT hr = S_OK;

	if(m_pChildFrame != NULL && 
		AfxIsValidAddress(m_pChildFrame, sizeof(m_pChildFrame)) != NULL &&
		!m_pChildFrame->m_strSQL.IsEmpty() && !m_pChildFrame->m_bCanceled &&
		m_pChildFrame->m_bExecuting)
	{
		m_pChildFrame->m_ThreadParam.m_strSQL = m_pChildFrame->m_strSQL;
		m_pChildFrame->m_strSQL.Empty();
		m_pChildFrame->m_ThreadParam.m_pFrame = m_pChildFrame;
		ASSERT(m_pChildFrame != NULL);
		m_pChildFrame->m_ThreadParam.m_ptrRS = pRecordset;
		if(m_pChildFrame->m_bProcText)
		{
			m_pChildFrame->m_pThreadExecuteSQL = AfxBeginThread(
				ExecuteSQLProcProc, &m_pChildFrame->m_ThreadParam,
				m_pChildFrame->m_nThreadPriority
				);
		}
		else
		{
			m_pChildFrame->m_ThreadParam.m_pGridCtrl = NULL;
			m_pChildFrame->m_ThreadParam.m_ptrGridCtrl = NULL;
			m_pChildFrame->m_ThreadParam.m_vRowsAffected = RecordsAffected;
			m_pChildFrame->m_pThreadExecuteSQL = AfxBeginThread(
				ExecuteSQLProc, &m_pChildFrame->m_ThreadParam,
				m_pChildFrame->m_nThreadPriority
				);
		}

		ASSERT(m_pChildFrame->m_pThreadExecuteSQL != NULL);
		m_pChildFrame->m_pThreadExecuteSQL->m_pMainWnd = m_pChildFrame;
	}

	return hr;
}

UINT ExecuteSQLProc(LPVOID lpVoid)
{
	ThreadParam* pTP = (ThreadParam*)lpVoid;
	CChildFrame* pChildFrame = pTP->m_pFrame;
	ASSERT(pChildFrame != NULL);
	ASSERT(pTP != NULL);
	ASSERT(!pTP->m_strSQL.IsEmpty());
	HRESULT hr = S_OK;
	bool bCaughtException = false;
	try
	{
		hr = CQryToolConnectionEvents::PopulateGrid(pTP);
		if(FAILED(hr))
			_com_issue_error(hr);
	}
	catch(const _com_error& e)
	{
		if(!pChildFrame->m_bCanceled)
		{
			bCaughtException = true;

			if(pChildFrame->m_strMessages.length())
				pChildFrame->m_strMessages += _T("\n\n");
			CString sBuff = pChildFrame->GetProviderError();
			if(!sBuff.IsEmpty())
				pChildFrame->m_strMessages += sBuff;
			else
				pChildFrame->m_strMessages += pChildFrame->GetComError(e);
		}
	}
	catch(CMemoryException* e)
	{
		if(!pChildFrame->m_bCanceled)
		{
			bCaughtException = true;

			if(pChildFrame->m_strMessages.length())
				pChildFrame->m_strMessages += _T("\n\n");
			pChildFrame->m_strMessages += _T("Out-of-Memory.");
		}

		if(e)
			e->Delete();
	}
	catch(COleException* e)
	{
		if(!pChildFrame->m_bCanceled)
		{
			bCaughtException = true;

			if(e)
			{
				TCHAR szMsg[255];
				e->GetErrorMessage(szMsg, 255);
				
				if(pChildFrame->m_strMessages.length())
					pChildFrame->m_strMessages += _T("\n\n");
				pChildFrame->m_strMessages += szMsg;
			}
		}

		if(e)
			e->Delete();
	}
	catch(COleDispatchException* e)
	{
		if(!pChildFrame->m_bCanceled)
		{
			bCaughtException = true;

			if(e)
			{
				if(pChildFrame->m_strMessages.length())
					pChildFrame->m_strMessages += _T("\n\n");
				pChildFrame->m_strMessages += e->m_strDescription;
			}
		}

		if(e)
			e->Delete();
	}
	catch(LPCTSTR e)
	{
		if(!pChildFrame->m_bCanceled)
		{
			bCaughtException = true;
		
			if(pChildFrame->m_strMessages.length())
				pChildFrame->m_strMessages += _T("\n\n");
			pChildFrame->m_strMessages += e;
		}
	}
	catch(...)
	{
		if(!pChildFrame->m_bCanceled)
		{
			bCaughtException = true;

			if(pChildFrame->m_strMessages.length())
				pChildFrame->m_strMessages += _T("\n\n");
			pChildFrame->m_strMessages += _T("Errors occurred.");
		}
	}

	try
	{
		if(pChildFrame->m_bIsTSQLSupported && !pChildFrame->m_bCanceled)
		{
			pChildFrame->m_strSQL.Empty();
			if(pTP->m_strSQL.FindNoCase(_T("USE ")) != -1)
			{
				if(!pChildFrame->SelectDataBaseEx())
					TRACE(_T("Error selecting database context.\n"));
			}
		}

		if(pChildFrame->m_bCanceled)
		{
			if(CQryToolConnectionEvents::m_lRow > 1)
				CQryToolConnectionEvents::m_lRow = --CQryToolConnectionEvents::m_lRow;
			if(pTP->m_pGridCtrl != NULL)
				::SendMessage(
					pChildFrame->m_hWnd, WM_SET_GRID_ROWS,
					CQryToolConnectionEvents::m_lRow, pChildFrame->m_bCanceled
					);
		}

		if(pTP->m_ptrGridCtrl != NULL)
		{
			pTP->m_ptrGridCtrl.Release();
			pTP->m_ptrGridCtrl = NULL;
		}
	}
	catch(...)
	{
		TRACE(_T("Errors occurred.\n"));
	}

	try
	{
		::PostMessage(
			pChildFrame->m_hWnd, WM_EXECUTION_COMPLETE, bCaughtException, -1
			);
	}
	catch(...)
	{
		TRACE(_T("Errors occurred.\n"));
	}

	return 0;
}

HRESULT CQryToolConnectionEvents::PopulateGrid(ThreadParam* pTP)
{
	CChildFrame* pChildFrame = pTP->m_pFrame;
	ASSERT(pChildFrame != NULL);
	ADODB::_RecordsetPtr ptrRS = pTP->m_ptrRS;
	long lState = ADODB::adStateClosed;
	long nTotalCols = 0;
	long nCols = 0;
	long lRow = 0;
	long lType = ADODB::adEmpty;
	ADODB::FieldsPtr ptrFields = NULL;
	ADODB::FieldPtr ptrField = NULL;
	long lMaxRows =  700;
	_variant_t vCol((long)-1);
	_variant_t vRowsAffected = pTP->m_vRowsAffected;
	_bstr_t bstrBuff;
	CString sBuff;
	HRESULT hr = S_OK;
	do
	{
		hr = ptrRS->get_State(&lState);
		if(FAILED(hr))
			_com_issue_error(hr);
		if(lState == ADODB::adStateClosed)
		{
			if((long)vRowsAffected != -1 && !pChildFrame->m_bExecuteCompleteHandled)
			{
				sBuff.Format(_T("(%d row(s) affected)"), (long)vRowsAffected);
				if(pChildFrame->m_strMessages.length())
					pChildFrame->m_strMessages += _T("\n\n");
				pChildFrame->m_strMessages += sBuff;
			}
		}
		else if(lState == ADODB::adStateOpen &&
			lState != ADODB::adStateClosed)
		{
			ptrFields = ptrRS->Fields;
			nCols = ptrFields->Count; 
			lRow = 0;
			if(!pChildFrame->m_bCanceled && nCols)
			{
				nTotalCols += nCols;
				if(::SendMessage(pChildFrame->m_hWnd, WM_GET_GRID_CTRL,
					nCols, 0L) == -1)
					throw _T("Failed to create grid control.");
				if(!pChildFrame->m_bCanceled)
					CQryToolConnectionEvents::SetGridHeaderInfo(
						pTP->m_ptrGridCtrl, ptrFields, nCols
						);
				if(!pChildFrame->m_bCanceled && ptrRS->State == ADODB::adStateOpen &&
					!ptrRS->adoBOF)
				{
					if(::SendMessage(pChildFrame->m_hWnd, WM_SET_GRID_ROWS,
						lMaxRows, 0L) == -1)
						throw _T("Unable to Allocate Memory for FlexGrid.");
					
					if(pChildFrame->m_bCanceled)
						CQryToolConnectionEvents::m_lRow = lRow+1;
					
					while(!pChildFrame->m_bCanceled && !ptrRS->adoEOF)
					{
						if(lRow >= lMaxRows-1)
						{
							lMaxRows += 700;
							if(!pChildFrame->m_bCanceled)
								if(::SendMessage(pChildFrame->m_hWnd, WM_SET_GRID_ROWS,
									lMaxRows, 0L) == -1)
									throw _T("Unable to Allocate Memory for FlexGrid.");
							
							pTP->m_pGridCtrl->Invalidate();
							pTP->m_pGridCtrl->UpdateWindow();
						}

						++lRow;
						for(long n = 0; n < nCols; n++)
						{
							try
							{
								if(!pChildFrame->m_bCanceled)
								{
									hr = ptrFields->get_Item((vCol = n), &ptrField);
									if(FAILED(hr))
									{
										if(::SendMessage(pChildFrame->m_hWnd, WM_SET_GRID_ROWS,
											lRow+1, 0L) == -1)
											TRACE(_T("Unable to Allocate Memory for FlexGrid.\n"));
										_com_issue_error(hr);
									}
									lType = ptrField->Type;
									if(lType == ADODB::adLongVarBinary ||
									   lType == ADODB::adVarBinary ||
									   lType == ADODB::adBinary)
									   bstrBuff = L"<Binary>/<Raw>";
									else
										bstrBuff = (_bstr_t)ptrField->Value;
								}
							}
							catch(...)
							{
								// If we get here, probably it is because of
								// type mismatch
								if(!pChildFrame->m_bCanceled)
								{
									VARIANT _result;
									VariantInit(&_result);
									hr = ptrField->get_Value(&_result);
									if(FAILED(hr))
									{
										if(::SendMessage(pChildFrame->m_hWnd, WM_SET_GRID_ROWS,
											lRow+1, 0L) == -1)
											TRACE(_T("Unable to Allocate Memory for FlexGrid\n"));
										_com_issue_error(hr);
									}
									bstrBuff = (LPCTSTR)CHelpers::CrackStrVariant(_result);
								}
							}
							
							hr = pTP->m_ptrGridCtrl->put_TextMatrix(lRow, n, bstrBuff);
							if(FAILED(hr))
							{
								if(::SendMessage(pChildFrame->m_hWnd, WM_SET_GRID_ROWS,
									lRow+1, 0L) == -1)
									TRACE(_T("Unable to Allocate Memory for FlexGrid\n"));
								throw _T("Subscript out of range.");
							}
						}

						if(!pChildFrame->m_bCanceled)
						{
							hr = ptrRS->raw_MoveNext();
							if(FAILED(hr))
							{
								if(::SendMessage(pChildFrame->m_hWnd, WM_SET_GRID_ROWS,
									lRow+1, 0L) == -1)
									TRACE(_T("Unable to Allocate Memory for FlexGrid\n"));
								if(!pChildFrame->m_bCanceled && !pChildFrame->m_bExecuteCompleteHandled)
								{
									sBuff.Format(
										_T("[%d row(s) affected (application specific)]"),
										lRow
										);
									if(pChildFrame->m_strMessages.length())
										pChildFrame->m_strMessages += _T("\n\n");
									pChildFrame->m_strMessages += sBuff;
								}
								_com_issue_error(hr);
							}
						}
					}

					if(::SendMessage(pChildFrame->m_hWnd, WM_SET_GRID_ROWS,
						lRow+1, 0L) == -1)
						throw _T("Unable to Allocate Memory for FlexGrid.");
				}

				if(pChildFrame->m_bCanceled)
					CQryToolConnectionEvents::m_lRow = lRow+1;
				else
				{
					if(!pChildFrame->m_bExecuteCompleteHandled)
					{
						sBuff.Format(
							_T("[%d row(s) affected (application specific)]"),
							lRow
							);
						if(pChildFrame->m_strMessages.length())
							pChildFrame->m_strMessages += _T("\n\n");
						pChildFrame->m_strMessages += sBuff;
					}
				}
			}
		}

		if(!pChildFrame->m_bIsMultiSetSupported)
			break;
	}
	while(!pChildFrame->m_bCanceled &&
		(ptrRS = ptrRS->NextRecordset(&vRowsAffected)) != NULL);
	
	pChildFrame->CloseRecordset();

	return hr;
}

void CQryToolConnectionEvents::SetGridHeaderInfo(const MSFlexGridLib::IMSFlexGridPtr&
	ptrGridCtrl, const ADODB::FieldsPtr& ptrFields, const long& lCols)
{
	if(lCols)
	{
		ASSERT(ptrGridCtrl != NULL);
		ASSERT(ptrFields != NULL);
		long lColWidth = 0L;
		long nDefinedSize = 0L;
		long lFieldNameLength = 0L;
		int nArbitraryFactor = 110;
		long nMaxWidth = 50;
		ADODB::FieldPtr ptrField = NULL;
		long lType = ADODB::adEmpty;
		_variant_t vCol((long)-1);
		for(long n = 0; n < lCols; n++)
		{
			HRESULT hr = ptrFields->get_Item((vCol = n), &ptrField);
			if(FAILED(hr))
				_com_issue_error(hr);

			nDefinedSize = ptrField->DefinedSize;
			lFieldNameLength = ptrField->Name.length();
			lType = ptrField->Type;
			if(lType == ADODB::adLongVarBinary ||
				lType == ADODB::adVarBinary ||
				lType == ADODB::adBinary)
			{
				if(8 < lFieldNameLength)
					lColWidth = lFieldNameLength;
				else
					lColWidth = 8;
			}
			else
			{
				if(nDefinedSize < lFieldNameLength)
					lColWidth = lFieldNameLength;
				else if(nDefinedSize > nMaxWidth)
					lColWidth = nMaxWidth;
				else
					lColWidth = nDefinedSize;
			}

			hr = ptrGridCtrl->put_ColAlignment(n, MSFlexGridLib::flexAlignLeftCenter);
			if(FAILED(hr))
				_com_issue_error(hr);
			hr = ptrGridCtrl->put_ColWidth(n, (lColWidth+5)*nArbitraryFactor);
			if(FAILED(hr))
				_com_issue_error(hr);
			hr = ptrGridCtrl->put_TextMatrix(0, n, ptrField->Name);
			if(FAILED(hr))
				_com_issue_error(hr);
		}
	}
}

UINT ExecuteSQLProcProc(LPVOID lpVoid)
{
	ThreadParam* pTP = (ThreadParam*)lpVoid;
	ASSERT(pTP != NULL);
	CChildFrame* pChildFrame = pTP->m_pFrame;
	ASSERT(pChildFrame != NULL);
	HRESULT hr = S_OK;
	bool bCaughtException = false;
	ADODB::_RecordsetPtr ptrRS = pTP->m_ptrRS;
	CString sMsg;
	try
	{
		long lState = ADODB::adStateClosed;
		hr = ptrRS->get_State(&lState);
		if(FAILED(hr))
			_com_issue_error(hr);
		if(lState != ADODB::adStateClosed)
		{
			while(!pChildFrame->m_bCanceled && ptrRS != NULL && !ptrRS->adoBOF)
			{
				while(!pChildFrame->m_bCanceled && !ptrRS->adoEOF)
				{
					if(!pChildFrame->m_bCanceled)
						pChildFrame->m_strProcText += (LPCTSTR)(_bstr_t)ptrRS->Fields->
							GetItem(_variant_t((long)0))->Value;

					if(!pChildFrame->m_bCanceled)
						ptrRS->MoveNext();
				}

				if(!pChildFrame->m_bCanceled)
					pChildFrame->m_strProcText += _T("\n\n");

				if(!pChildFrame->m_bCanceled && pChildFrame->m_bIsMultiSetSupported)
					ptrRS = ptrRS->NextRecordset(NULL);
			}

			if(!pChildFrame->m_bCanceled && !pChildFrame->m_strProcText.length())
				pChildFrame->m_strProcText = _T("NULL");
		}
	}
	catch(const _com_error& e)
	{
		if(!pChildFrame->m_bCanceled)
		{
			bCaughtException = true;

			if(pChildFrame->m_strMessages.length())
				pChildFrame->m_strMessages += _T("\n\n");
			CString sBuff = pChildFrame->GetProviderError();
			if(!sBuff.IsEmpty())
				pChildFrame->m_strMessages += sBuff;
			else
				pChildFrame->m_strMessages += pChildFrame->GetComError(e);
		}
	}
	catch(CMemoryException* e)
	{
		if(!pChildFrame->m_bCanceled)
		{
			bCaughtException = true;

			if(pChildFrame->m_strMessages.length())
				pChildFrame->m_strMessages += _T("\n\n");
			pChildFrame->m_strMessages += _T("Out-of-Memory.");
		}

		if(e)
			e->Delete();
	}
	catch(...)
	{
		if(!pChildFrame->m_bCanceled)
		{
			bCaughtException = true;

			if(pChildFrame->m_strMessages.length())
				pChildFrame->m_strMessages += _T("\n\n");
			pChildFrame->m_strMessages += _T("Errors occurred.");
		}
	}

	pChildFrame->CloseRecordset();
	
	try
	{
		if(pChildFrame->m_bIsTSQLSupported && !pChildFrame->m_bCanceled)
		{
			pChildFrame->m_strSQL.Empty();
			if(pTP->m_strSQL.FindNoCase(_T("USE ")) != -1)
			{
				if(!pChildFrame->SelectDataBaseEx())
					TRACE(_T("Error selecting database context.\n"));
			}
		}
	}
	catch(...)
	{
		TRACE(_T("Errors occurred.\n"));
	}

	try
	{
		::PostMessage(
			pChildFrame->m_hWnd, WM_EXEC_PROC_COMPLETE, bCaughtException, 0L
			);
	}
	catch(...)
	{
		TRACE(_T("Errors occurred.\n"));
	}

	return 0;
}