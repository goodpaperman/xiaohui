#if !defined(AFX_PROCEDURESDLG_H__CF685183_91E1_11D2_BD39_204C4F4F5020__INCLUDED_)
#define AFX_PROCEDURESDLG_H__CF685183_91E1_11D2_BD39_204C4F4F5020__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ProceduresDlg.h : header file
//

class CChildFrame;

/////////////////////////////////////////////////////////////////////////////
// CProceduresDlg dialog

class CProceduresDlg : public CDialog
{
// Construction
public:
	CString m_strProcedureName;
	CProceduresDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CProceduresDlg)
	enum { IDD = IDD_SELECT_PROCEDURES };
	CButton	m_buttonSystemTables;
	CListCtrlEx	m_ctrlList;
	CString	m_strSearch;
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CProceduresDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CProceduresDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnDblclkList1(NMHDR* pNMHDR, LRESULT* pResult);
	virtual void OnOK();
	afx_msg void OnItemchangedList1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnColumnclickList1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnChangeSearch();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	bool m_bSort;
	int m_nSelectedItem;
	bool PopulateList();
	CChildFrame* m_pChildFrame;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROCEDURESDLG_H__CF685183_91E1_11D2_BD39_204C4F4F5020__INCLUDED_)