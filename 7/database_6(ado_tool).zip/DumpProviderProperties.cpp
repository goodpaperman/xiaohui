// DumpProviderProperties.cpp : implementation file
//

#include "stdafx.h"
#include "QryTool.h"
#include "DumpProviderProperties.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDumpProviderProperties dialog

CDumpProviderProperties::CDumpProviderProperties(CWnd* pParent /*=NULL*/)
	: CDialog(CDumpProviderProperties::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDumpProviderProperties)
	m_strSQL = _T("SELECT 2*3");
	//}}AFX_DATA_INIT
}

CDumpProviderProperties::~CDumpProviderProperties()
{
}

void CDumpProviderProperties::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDumpProviderProperties)
	DDX_Text(pDX, IDC_SQL, m_strSQL);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CDumpProviderProperties, CDialog)
	//{{AFX_MSG_MAP(CDumpProviderProperties)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDumpProviderProperties message handlers

void CDumpProviderProperties::OnOK() 
{
	CWaitCursor wait;

	m_pChildFrame->m_wndStatusBar.SetPaneText(0, _T("Dumping provider properties..."));

	bool bException = false;
	try
	{
		UpdateData();
		
		HRESULT hr = S_OK;

		m_pChildFrame->CloseRecordset();

		BSTR bstrSQL = m_strSQL.AllocSysString();
		hr = m_pChildFrame->m_ptrRecordset->Open(
				bstrSQL,
				m_pChildFrame->m_ptrConnection.GetInterfacePtr(),
				ADODB::adOpenForwardOnly,
				ADODB::adLockReadOnly,
				ADODB::adCmdText
				);
		::SysFreeString(bstrSQL);
		if(FAILED(hr))
			_com_issue_error(hr);
		
		long lState = ADODB::adStateClosed;
		hr = m_pChildFrame->m_ptrRecordset->get_State(&lState);
		if(FAILED(hr))
			_com_issue_error(hr);
		if(m_pChildFrame->m_ptrRecordset != NULL && lState == ADODB::adStateClosed)
		{
			AfxMessageBox(_T("Query returned zero records/columns. Cannot dump provider properties."));
			bException = true;
		}
		else
		{
			CString sProviderName = m_pChildFrame->m_strProviderName;
			int nPos = sProviderName.Find('.');
			if(nPos != -1)
				sProviderName = sProviderName.Left(nPos);
			TCHAR lpszTempPath[_MAX_PATH];
			DWORD dwSize = ::GetTempPath(_MAX_PATH, lpszTempPath);
			ASSERT(dwSize); 
			CString sFileName = lpszTempPath;
			nPos = sFileName.ReverseFind(_T('\\'));
			ASSERT(nPos != -1);
			sFileName = sFileName.Left(nPos) + _T("\\[") + 	sProviderName + _T("_") +
				m_pChildFrame->m_strDBMS + _T("].txt");
			int nLength = sFileName.GetLength();
			for(int n = 0; n < nLength; n++)
			{
				if(sFileName.GetAt(n) == _T(' '))
					sFileName.SetAt(n, _T('_'));
			}
			CString sBuff;
			CStdioFile file;
			CFileException fileException;
			BOOL bRet = file.Open(sFileName, CFile::typeText | CFile::modeCreate |  
						CFile::modeWrite, &fileException);
			if(!bRet)
			{
				bException = true;
				sBuff.Format(_T("File Path Name: <%s> "), sFileName);
				sBuff += CHelpers::GetFileExceptionError(fileException.m_cause);
				AfxMessageBox(sBuff);
			}
			else
			{
				DumpProviderProperties(&file);
				file.Close();
			
				HINSTANCE h = ::ShellExecute(NULL, _T("open"), sFileName, NULL,
					NULL, SW_SHOWNORMAL);
				if((UINT)h > 32)
					;
				else
				{
					bException = true;
					AfxMessageBox(_T("Error dumping provider properties."));
				}
			}

			m_pChildFrame->CloseRecordset();
		}
	}
	catch(const _com_error& e)
	{
		bException = true;

		CString sMsg = m_pChildFrame->GetProviderError();
		if(sMsg.IsEmpty())
			sMsg = m_pChildFrame->GetComError(e);
		
		AfxMessageBox(sMsg);

		GetDlgItem(IDC_SQL)->SetFocus();
	}
	catch(...)
	{
		AfxMessageBox(_T("Errors occurred."));
	}

	if(m_pChildFrame->m_bIsTSQLSupported)
	{
		m_strSQL.MakeUpper();
		if(m_strSQL.Find(_T("USE ")) != -1)
		{
			if(!m_pChildFrame->SelectDataBaseEx())
				TRACE(_T("Error selecting database context.\n"));
		}
	}

	m_pChildFrame->m_wndStatusBar.SetPaneText(0, _T(""));

	if(!bException)
		CDialog::OnOK();
}

void CDumpProviderProperties::DumpProviderProperties(CStdioFile* pFile)
{
	CWaitCursor wait;

	ASSERT(pFile && pFile->m_pStream);

	pFile->WriteString(_T("Properties Collection for the Connection object\n"));
	pFile->WriteString(_T("-----------------------------------------------\n"));
	pFile->WriteString(_T("\n"));
	ADODB::PropertiesPtr ptrProperties = NULL;
	HRESULT hr = m_pChildFrame->m_ptrConnection->get_Properties(&ptrProperties);
	if(FAILED(hr))
		_com_issue_error(hr);
	DumpProperty(ptrProperties, pFile);

	pFile->WriteString(_T("\nProperties Collection for the Command object"));
	pFile->WriteString(_T("\n--------------------------------------------"));
	pFile->WriteString(_T("\n\n"));
	hr = m_pChildFrame->m_ptrCommand->get_Properties(&ptrProperties);
	if(FAILED(hr))
		_com_issue_error(hr);
	hr = ptrProperties->Refresh();
	if(FAILED(hr))
		_com_issue_error(hr);
	DumpProperty(ptrProperties, pFile);

	pFile->WriteString(_T("\nProperties Collection for the Recordset object"));
	pFile->WriteString(_T("\n----------------------------------------------"));
	pFile->WriteString(_T("\n\n"));
	hr = m_pChildFrame->m_ptrRecordset->get_Properties(&ptrProperties);
	if(FAILED(hr))
		_com_issue_error(hr);
	hr = ptrProperties->Refresh();
	if(FAILED(hr))
		_com_issue_error(hr);
	DumpProperty(ptrProperties, pFile);

	ADODB::FieldsPtr ptrFields = NULL;
	hr = m_pChildFrame->m_ptrRecordset->get_Fields(&ptrFields);
	if(FAILED(hr))
		_com_issue_error(hr);
	ADODB::FieldPtr ptrField = NULL;
	hr = ptrFields->get_Item(_variant_t(0L), &ptrField);
	if(FAILED(hr))
		_com_issue_error(hr);
	pFile->WriteString(_T("\nProperties Collection for the Field object"));
	pFile->WriteString(_T("\n------------------------------------------"));
	pFile->WriteString(_T("\n\n"));
	hr = ptrField->get_Properties(&ptrProperties);
	if(FAILED(hr))
		_com_issue_error(hr);
	hr = ptrProperties->Refresh();
	if(FAILED(hr))
		_com_issue_error(hr);
	DumpProperty(ptrProperties, pFile);
}

void CDumpProviderProperties::DumpProperty(const ADODB::PropertiesPtr& ptrProperties,
	CStdioFile* pFile)
{
    ASSERT(ptrProperties != NULL);
	ASSERT(pFile && pFile->m_pStream);
	long nCount = 0;
	HRESULT hr = ptrProperties->get_Count(&nCount);
	if(FAILED(hr))
		_com_issue_error(hr);
	CString strTmp;
	// Enumerate through properties collection
	ADODB::PropertyPtr ptrProperty;
	for(int n = 0; n < nCount; n++ )
    {
		try
		{
			// Get Current Property
			ptrProperty = ptrProperties->GetItem(_variant_t((long)n));
			
			// Display Name
			strTmp.Format(_T("Property %03d: %s"),
				n+1, (LPCTSTR)ptrProperty->GetName());
			pFile->WriteString(strTmp + _T("\n"));
			
			// Display Type
			strTmp.Format(_T("\t\t  Type       = %s"),
				(LPCTSTR)CHelpers::GetType((int)ptrProperty->GetType()));
			pFile->WriteString(strTmp + _T("\n"));
			
			// Display Value
			strTmp.Format(_T("\t\t  Value      = %s"),
				(LPCTSTR)CHelpers::CrackStrVariant(ptrProperty->GetValue()));
			pFile->WriteString(strTmp + _T("\n"));
			
			// Display Attributes
			strTmp.Format(_T("\t\t  Attributes = %s"),
				(LPCTSTR)CHelpers::GetPropertyAttributes(
				(ADODB::PropertyAttributesEnum)ptrProperty->GetAttributes())); 
			pFile->WriteString(strTmp + _T("\n"));
		}
		catch(const _com_error& e)
		{
			CString sMsg = m_pChildFrame->GetProviderError();
			if(sMsg.IsEmpty())
				sMsg = m_pChildFrame->GetComError(e);
			TRACE(_T("%s\n"), (LPCTSTR)sMsg);
		}
		catch(...)
		{
			TRACE(_T("Errors occurred.\n"));
		}
    }
}

BOOL CDumpProviderProperties::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	ASSERT(pFrame);
	m_pChildFrame = (CChildFrame*)pFrame->MDIGetActive();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}