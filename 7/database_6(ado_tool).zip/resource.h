//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by QryTool.rc
//
#define IDC_RESET                       3
#define IDC_CLOSE                       3
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDW_COMBO                       101
#define ID_INDICATOR_RESULT_SET         103
#define IDC_EMAIL                       107
#define ID_INDICATOR_NUM_CONNECTIONS    108
#define ID_INDICATOR_PANE_TEXT_ZERO     110
#define ID_INDICATOR_EXECUTION_TIME     113
#define ID_INDICATOR_POSITION           115
#define ID_SET_DBCOMBO_FOCUS            116
#define IDR_MAINFRAME                   128
#define IDR_QUERY_TYPE                  129
#define IDD_SELECT_TABLES               131
#define IDR_RCLICK                      133
#define IDD_SELECT_PROCEDURES           133
#define IDD_EXPORT_DIALOG               136
#define IDD_EDIT_GOTO                   137
#define IDC_MY_CURSOR                   145
#define IDD_GENERAL                     146
#define IDD_DUMP_PROVIDER_PROPERTIES    148
#define IDB_INTRO_BMP                   169
#define IDC_LINE                        1004
#define IDC_PREV                        1005
#define IDC_BUILD_TYPE                  1005
#define IDC_LIST1                       1006
#define IDC_GOTO                        1006
#define IDC_SYSTEM_TABLES               1011
#define IDC_DELIMITER                   1012
#define IDC_VIEWS                       1012
#define IDC_TEXT_ONLY                   1024
#define IDC_QUERY_TIMEOUT               1029
#define IDC_CACHE_SIZE                  1030
#define IDC_EXECUTION_PRIORITY          1031
#define IDC_SEARCH                      1032
#define IDC_COLUMNS                     1034
#define IDC_URL_TEXT                    1035
#define IDC_ADO_VERSION                 1039
#define IDC_SQL                         1040
#define stc32                           0x045f
#define ID_FILE_DISCONNECT_ALL          32772
#define ID_SQL_EXECUTE                  32773
#define ID_FILE_CONNECT                 32776
#define ID_SQL_SELECT_PROCEDURES        32779
#define ID_SQL_OBJECTS                  32780
#define ID_VIEW_WRAP_WORD               32782
#define ID_EDIT_ADVANCED_MAKE_SELECTION_UPPERCASE 32783
#define ID_EDIT_ADVANCED_MAKE_SELECTION_LOWERCASE 32784
#define ID_FILE_DISCONNECT              32785
#define ID_SQL_SELECT_TABLES_EX         32788
#define ID_VIEW_PREV_RESULT_SET         32790
#define ID_VIEW_NEXT_RESULT_SET         32792
#define ID_VIEW_LAST_RESULT_SET         32794
#define ID_VIEW_FIRST_RESULT_SET        32796
#define ID_SQL_CANCEL                   32800
#define ID_GRID_SAVE_SELECTION          32803
#define ID_QUERY_NEW                    32805
#define ID_VIEW_FONT                    32806
#define ID_HELP_README                  32808
#define ID_EDIT_GOTO                    32809
#define ID_EDIT_TABIFY_SELECTION        32816
#define ID_EDIT_UNTABIFY_SELECTION      32817
#define ID_FILE_CONFIGURE               32818
#define ID_VIEW_MESSAGES                32819
#define ID_WINDOW_NEXT                  32821
#define ID_WINDOW_PREVIOUS              32822
#define ID_DUMP_PROVIDER_PROPERTIES_EX  32825

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        144
#define _APS_NEXT_COMMAND_VALUE         32826
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           117
#endif
#endif
