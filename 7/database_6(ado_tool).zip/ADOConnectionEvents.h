// ADOConnectionEvents.h : CADOConnectionEvents
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_ADOCONNECTIONEVENTS_H__281392F0_A02D_11D3_A8CD_00C04F595ED0__INCLUDED_)
#define AFX_ADOCONNECTIONEVENTS__281392F0_A02D_11D3_A8CD_00C04F595ED0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <adoint.h>

/////////////////////////////////////////////////////////////////////////////
// CADOConnectionEvents

class CADOConnectionEvents : public ConnectionEventsVt
{
public :
	ULONG m_ulRefCount;
	CADOConnectionEvents():m_ulRefCount(0){}
	
	STDMETHOD(QueryInterface)(REFIID iid, LPVOID* ppvObject)
	{
		if(IsEqualIID(__uuidof(IUnknown), iid) || 
			IsEqualIID(__uuidof(ConnectionEventsVt), iid)) 
		{
			*ppvObject = this;
			AddRef();
			return S_OK;
		}
		else 
			return E_NOINTERFACE;
	}
	
	STDMETHOD_(ULONG, AddRef)()
	{
		return m_ulRefCount++;
	}
	
	STDMETHOD_(ULONG, Release)()
	{
		if (--m_ulRefCount == 0)
		{
			delete this;
			return 0;
		}
		else 
			return m_ulRefCount;
	}
		
	STDMETHOD(InfoMessage)( 
		ADOError* pError,
		EventStatusEnum* adStatus,
		_ADOConnection* pConnection)
	{
		*adStatus = adStatusUnwantedEvent; 
		return S_OK;
	}
		
	STDMETHOD(BeginTransComplete)( 
		LONG TransactionLevel,
		ADOError* pError,
		EventStatusEnum* adStatus,
		_ADOConnection* pConnection)
	{
		*adStatus = adStatusUnwantedEvent; 
		return S_OK;
	}
	
	STDMETHOD(CommitTransComplete)( 
		ADOError* pError,
		EventStatusEnum* adStatus,
		_ADOConnection* pConnection)
	{
		*adStatus = adStatusUnwantedEvent; 
		return S_OK;
	}
	
    STDMETHOD(RollbackTransComplete)( 
		ADOError* pError,
		EventStatusEnum* adStatus,
		_ADOConnection* pConnection)
	{
		*adStatus = adStatusUnwantedEvent; 
		return S_OK;
	}
		
    STDMETHOD(WillExecute)( 
		BSTR* Source,
		CursorTypeEnum* CursorType,
		LockTypeEnum* LockType,
		long* Options,
		EventStatusEnum* adStatus,
		_ADOCommand* pCommand,
		_ADORecordset* pRecordset,
		_ADOConnection* pConnection)
	{
		*adStatus = adStatusUnwantedEvent; 
		return S_OK;
    }   
	
	STDMETHOD(ExecuteComplete)( 
		LONG RecordsAffected,
		ADOError* pError,
		EventStatusEnum* adStatus,
		_ADOCommand* pCommand,
		_ADORecordset* pRecordset,
		_ADOConnection* pConnection)
	{
		*adStatus = adStatusUnwantedEvent; 
		return S_OK;
	}
	
	STDMETHOD(WillConnect)( 
		BSTR* ConnectionString,
		BSTR* UserID,
		BSTR* Password,
		long* Options,
		EventStatusEnum* adStatus,
		_ADOConnection* pConnection) 
	{
		*adStatus = adStatusUnwantedEvent; 
		return S_OK;
	}
		
	STDMETHOD(ConnectComplete)( 
		ADOError* pError,
		EventStatusEnum* adStatus,
		_ADOConnection* pConnection)
	{
		*adStatus = adStatusUnwantedEvent; 
		return S_OK;
	}
		
    STDMETHOD(Disconnect)( 
		EventStatusEnum* adStatus,
		_ADOConnection* pConnection)
	{
		*adStatus = adStatusUnwantedEvent; 
		return S_OK;
	}
};

/////////////////////////////////////////////////////////////////////////////

#endif // !defined(AFX_ADOCONNECTIONEVENTS__281392F0_A02D_11D3_A8CD_00C04F595ED0__INCLUDED_)