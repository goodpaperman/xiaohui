// QryView.cpp : implementation of the CQryView class
//

#include "stdafx.h"
#include "QryTool.h"
#include "QryToolDoc.h"
#include "QryView.h"
#include "MainFrm.h"
#include "ChildFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

LPCTSTR g_szQuery = _T("Query");
LPCTSTR g_szQueryWordWrap = _T("WrapWord");
extern LPCTSTR g_szQueryFont;
/////////////////////////////////////////////////////////////////////////////
// CQryView

IMPLEMENT_DYNCREATE(CQryView, CRichEditView)

BEGIN_MESSAGE_MAP(CQryView, CRichEditView)
	//{{AFX_MSG_MAP(CQryView)
	ON_COMMAND(ID_SQL_EXECUTE, OnSqlExecute)
	ON_UPDATE_COMMAND_UI(ID_VIEW_WRAP_WORD, OnUpdateViewWrapWord)
	ON_COMMAND(ID_VIEW_WRAP_WORD, OnViewWrapWord)
	ON_COMMAND(ID_FILE_PRINT, OnFilePrint)
	ON_WM_SIZE()
	ON_COMMAND(ID_EDIT_ADVANCED_MAKE_SELECTION_LOWERCASE, OnEditAdvancedMakeSelectionLowercase)
	ON_UPDATE_COMMAND_UI(ID_EDIT_ADVANCED_MAKE_SELECTION_LOWERCASE, OnUpdateEditAdvancedMakeSelectionLowercase)
	ON_COMMAND(ID_EDIT_ADVANCED_MAKE_SELECTION_UPPERCASE, OnEditAdvancedMakeSelectionUppercase)
	ON_UPDATE_COMMAND_UI(ID_EDIT_ADVANCED_MAKE_SELECTION_UPPERCASE, OnUpdateEditAdvancedMakeSelectionUppercase)
	ON_UPDATE_COMMAND_UI(ID_EDIT_CLEAR_ALL, OnUpdateEditClearAll)
	ON_COMMAND(ID_EDIT_CLEAR_ALL, OnEditClearAll)
	ON_COMMAND(ID_VIEW_FONT, OnViewFont)
	ON_COMMAND(ID_EDIT_PASTE, OnEditPaste)
	ON_UPDATE_COMMAND_UI(ID_EDIT_PASTE, OnUpdateEditPaste)
	ON_WM_CREATE()
	ON_COMMAND(ID_EDIT_TABIFY_SELECTION, OnEditTabifySelection)
	ON_UPDATE_COMMAND_UI(ID_EDIT_TABIFY_SELECTION, OnUpdateEditTabifySelection)
	ON_COMMAND(ID_EDIT_UNTABIFY_SELECTION, OnEditUntabifySelection)
	ON_UPDATE_COMMAND_UI(ID_EDIT_UNTABIFY_SELECTION, OnUpdateEditUntabifySelection)
	ON_COMMAND(ID_SQL_CANCEL, OnSqlCancel)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CRichEditView::OnFilePrint)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CQryView construction/destruction

CQryView::CQryView()
{
	m_nWordWrap = AfxGetApp()->GetProfileInt(g_szQuery, g_szQueryWordWrap, WrapNone);
}

CQryView::~CQryView()
{
	if(m_font.m_hObject != NULL)
	{
		m_font.Detach();
		m_font.m_hObject = NULL;
	}
}

void CQryView::OnInitialUpdate()
{
	CRichEditView::OnInitialUpdate();

	if(m_font.m_hObject != NULL)
		GetRichEditCtrl().SetFont(&m_font);

	SetMargins(CRect(720, 720, 720, 720));

	m_pChildFrame = (CChildFrame*)GetParentFrame();
}

/////////////////////////////////////////////////////////////////////////////
// CQryView printing

BOOL CQryView::OnPreparePrinting(CPrintInfo* pInfo)
{
	BOOL bRet = DoPreparePrinting(pInfo);

	if(pInfo->m_pPD->GetDevMode()->dmOrientation == DMORIENT_LANDSCAPE)
	{
		CString sMsg = "Currently printing functionality is not supported for ";
				sMsg +="landscape mode. Please choose portrait mode and then try ";
				sMsg +="again.";
		AfxMessageBox(sMsg);
		bRet = FALSE;
	}
		
	return bRet;
}

/////////////////////////////////////////////////////////////////////////////
// CQryView diagnostics

#ifdef _DEBUG
void CQryView::AssertValid() const
{
	CRichEditView::AssertValid();
}

void CQryView::Dump(CDumpContext& dc) const
{
	CRichEditView::Dump(dc);
}

CQryToolDoc* CQryView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CQryToolDoc)));
	return (CQryToolDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CQryView message handlers

void CQryView::OnSqlExecute() 
{
	m_pChildFrame->OnSqlExecute();
}

void CQryView::OnSqlCancel() 
{
	m_pChildFrame->OnSqlCancel();
}

void CQryView::OnUpdateViewWrapWord(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(m_nWordWrap == WrapToWindow);
}

void CQryView::OnViewWrapWord() 
{
	m_nWordWrap = (m_nWordWrap == WrapNone) ? WrapToWindow : WrapNone;
	WrapChanged();
	AfxGetApp()->WriteProfileInt(g_szQuery, g_szQueryWordWrap, m_nWordWrap);
}

void CQryView::OnFilePrint() 
{
	CWaitCursor wait;
	CRichEditView::OnFilePrint();
}

void CQryView::OnEditClearAll() 
{
	GetRichEditCtrl().SetSel(0, -1);
	GetRichEditCtrl().Clear();
}

void CQryView::OnUpdateEditClearAll(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetRichEditCtrl().GetTextLength());
}

HMENU CQryView::GetContextMenu(WORD /*wSelType*/, LPOLEOBJECT /*lpOleObj*/,
							   CHARRANGE* /*lpChrg*/)
{
	CMenu menu;
	if(menu.LoadMenu(IDR_RCLICK))
	{
		CMenu* pMenu = menu.GetSubMenu(0);
		ASSERT(pMenu);
		long lStart = -1;
		long lEnd = -1;
		GetRichEditCtrl().GetSel(lStart, lEnd);
		if(lEnd-lStart == 0)
		{
			pMenu->EnableMenuItem(ID_EDIT_CUT, MF_BYCOMMAND | MF_GRAYED);
			pMenu->EnableMenuItem(ID_EDIT_COPY, MF_BYCOMMAND | MF_GRAYED);
		}

		if(!GetRichEditCtrl().CanPaste())
			pMenu->EnableMenuItem(ID_EDIT_PASTE, MF_BYCOMMAND | MF_GRAYED);

		int nLength = GetRichEditCtrl().GetTextLength();
		if(m_pChildFrame->m_lConnectionState != ADODB::adStateOpen ||
			!nLength || m_pChildFrame->m_bExecuting)
			pMenu->EnableMenuItem(ID_SQL_EXECUTE, MF_BYCOMMAND | MF_GRAYED);

		if(m_pChildFrame->m_lConnectionState != ADODB::adStateOpen ||
			!m_pChildFrame->m_bExecuting || m_pChildFrame->m_bCanceling)
			pMenu->EnableMenuItem(ID_SQL_CANCEL, MF_BYCOMMAND | MF_GRAYED);

		if(!nLength)
		{
			pMenu->EnableMenuItem(ID_EDIT_CLEAR_ALL, MF_BYCOMMAND | MF_GRAYED);
			pMenu->EnableMenuItem(ID_EDIT_SELECT_ALL, MF_BYCOMMAND | MF_GRAYED);
		}

		CPoint point;
		::GetCursorPos(&point);
		pMenu->TrackPopupMenu(0, point.x, point.y, this);
	}

	return NULL;
}

void CQryView::OnSize(UINT nType, int cx, int cy) 
{
	CRichEditView::OnSize(nType, cx, cy);

	Invalidate();
	UpdateWindow();
}

void CQryView::OnEditAdvancedMakeSelectionLowercase() 
{
	ToggleCase(false);
}

void CQryView::OnEditAdvancedMakeSelectionUppercase() 
{
	ToggleCase();
}

void CQryView::ToggleCase(const bool& bUpper)
{
	CWaitCursor wait;

	CRichEditCtrl& edit = GetRichEditCtrl();
	long nStart = -1;
	long nEnd = -1;
	edit.GetSel(nStart, nEnd);
	int nDiff = nEnd-nStart;
	CString sText;
	if(nDiff < 50000)
		sText = GetRichEditCtrl().GetSelText();
	else
	{
		GetRichEditCtrl().GetWindowText(sText);
		sText = sText.Mid(nStart, nDiff);
	}
	if(bUpper)
		sText.MakeUpper();
	else
		sText.MakeLower();
	edit.ReplaceSel(sText);
	edit.SetSel(nStart, nEnd);
}

void CQryView::OnUpdateEditAdvancedMakeSelectionLowercase(CCmdUI* pCmdUI) 
{
	long lStart = -1;
	long lEnd = -1;
	GetRichEditCtrl().GetSel(lStart, lEnd);
	pCmdUI->Enable(lEnd-lStart);
}

void CQryView::OnUpdateEditAdvancedMakeSelectionUppercase(CCmdUI* pCmdUI) 
{
	long lStart = -1;
	long lEnd = -1;
	GetRichEditCtrl().GetSel(lStart, lEnd);
	pCmdUI->Enable(lEnd-lStart);
}

void CQryView::OnViewFont() 
{
	LOGFONT lf;
	if(m_font.m_hObject != NULL)
		m_font.GetObject(sizeof(LOGFONT), &lf);
	else
		::GetObject(GetStockObject(SYSTEM_FONT), sizeof(LOGFONT), &lf);
	CFontDialog dlg(&lf, CF_SCREENFONTS | CF_INITTOLOGFONTSTRUCT);
	if(dlg.DoModal() == IDOK)
	{
		CWaitCursor wait;
		CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
		ASSERT(pFrame != NULL);
		CChildFrame* pChild = NULL;
		std::list<CChildFrame*>::const_iterator i;
		long nStart = -1;
		long nEnd = -1;
		for(i = pFrame->m_listChildFrame.begin();
				i != pFrame->m_listChildFrame.end(); ++i)
		{
			pChild = (*i);
			if(pChild != NULL)
			{
				if(pChild->m_pQryView->m_font.m_hObject != NULL)
					pChild->m_pQryView->m_font.DeleteObject();
				if(pChild->m_pQryView->m_font.CreateFontIndirect(&lf))
					pChild->m_pQryView->SetFontEx();
			}
		}

		if(pChild != NULL)
			pChild->WriteProfileFont(
				g_szQueryFont,
				dlg.m_cf.lpLogFont,
				false,
				NULL,
				NULL
				);
	}	
}

void CQryView::OnEditPaste() 
{
	GetRichEditCtrl().PasteSpecial(CF_TEXT);
}

void CQryView::OnUpdateEditPaste(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(GetRichEditCtrl().CanPaste());
}

void CQryView::SetFontEx()
{
	long nStart = -1;
	long nEnd = -1;
	CRichEditCtrl& edit = GetRichEditCtrl();
	edit.GetSel(nStart, nEnd);
	edit.SetSel(0, 0);
	edit.SetFont(&m_font, TRUE);
	edit.SetSel(nStart, nEnd);
	edit.Invalidate();
	edit.UpdateWindow();
}

int CQryView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if(CRichEditView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	LOGFONT lf;
	memset(&lf, 0, sizeof(lf));
	m_pChildFrame->GetProfileFont(
		g_szQueryFont,
		&lf,
		false, 
		NULL,
		NULL
		);
	if(lf.lfHeight == 0)
	{
		lf.lfHeight = -15;
		lf.lfWeight = 400;
		_tcscpy(lf.lfFaceName, _T("Courier"));
	}
	if(!m_font.CreateFontIndirect(&lf))
		TRACE(_T("Could Not create font.\n"));

	if(m_font.m_hObject != NULL)
		GetRichEditCtrl().SetFont(&m_font);
	
	return 0;
}

void CQryView::OnEditTabifySelection() 
{
	ToggleTabify();
}

void CQryView::OnEditUntabifySelection() 
{
	ToggleTabify(false);
}

void CQryView::OnUpdateEditTabifySelection(CCmdUI* pCmdUI) 
{
	long lStart = -1;
	long lEnd = -1;
	GetRichEditCtrl().GetSel(lStart, lEnd);
	pCmdUI->Enable(lEnd-lStart);
}

void CQryView::OnUpdateEditUntabifySelection(CCmdUI* pCmdUI) 
{
	long lStart = -1;
	long lEnd = -1;
	GetRichEditCtrl().GetSel(lStart, lEnd);
	pCmdUI->Enable(lEnd-lStart);	
}

void CQryView::ToggleTabify(const bool& bTabify)
{
	CWaitCursor wait;

	CRichEditCtrl& edit = GetRichEditCtrl();
    long nStart = -1;
    long nEnd = -1;
    edit.GetSel(nStart, nEnd);
    int nDiff = nEnd-nStart;
    CString sText;
    if(nDiff < 50000)
        sText = GetRichEditCtrl().GetSelText();
    else
    {
        GetRichEditCtrl().GetWindowText(sText);
        sText = sText.Mid(nStart, nDiff);
    }
    if(bTabify)
	{
        int nLength = sText.GetLength();
		sText.Replace(_T("    "), _T("\t"));
		nEnd -= nLength - sText.GetLength();
	}
    else
	{
		int nLength = sText.GetLength();
        sText.Replace(_T("\t"), _T("    "));
		nEnd += sText.GetLength() - nLength;
	}
	edit.ReplaceSel(sText);
	edit.SetSel(nStart, nEnd);
}