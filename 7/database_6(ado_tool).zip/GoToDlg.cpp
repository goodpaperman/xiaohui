// GoToDlg.cpp : implementation file
//

#include "stdafx.h"
#include "qrytool.h"
#include "GoToDlg.h"
#include "MainFrm.h"
#include "ChildFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGoToDlg dialog

CGoToDlg::CGoToDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGoToDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGoToDlg)
	m_strLine = _T("");
	//}}AFX_DATA_INIT

	m_bPrev = false;
	m_bNext = false;
}

CGoToDlg::~CGoToDlg()
{
	OnClose();
}

void CGoToDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGoToDlg)
	DDX_Text(pDX, IDC_LINE, m_strLine);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CGoToDlg, CDialog)
	//{{AFX_MSG_MAP(CGoToDlg)
	ON_BN_CLICKED(IDC_GOTO, OnGoTo)
	ON_BN_CLICKED(IDC_CLOSE, OnClose)
	ON_BN_CLICKED(IDC_PREV, OnPrev)
	ON_EN_CHANGE(IDC_LINE, OnChangeLine)
	ON_WM_ACTIVATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGoToDlg message handlers

void CGoToDlg::OnGoTo() 
{
	UpdateData();
	m_strLine.TrimRight();
	m_strLine.TrimLeft();
	long nMaxLineCount = -1;
	long nCurrentLine = -1;
	long nLineToGo = -1;
#ifdef _UNICODE
	USES_CONVERSION;
	nLineToGo = atol(W2CA((LPCTSTR)m_strLine));
#else
	nLineToGo = atol((LPCTSTR)m_strLine);
#endif
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	ASSERT(pFrame != NULL);
	CChildFrame* pChildFrame = (CChildFrame*)pFrame->MDIGetActive();
	CView* pView = NULL;
	if(pChildFrame != NULL)
		pView = pChildFrame->GetActiveView();
	bool bGrid = false;
	if(pView != NULL && pView->IsKindOf(RUNTIME_CLASS(CResultView)))
	{
		bGrid = pChildFrame->m_pResultView->m_pGridCtrl != NULL &&
			::IsWindow(pChildFrame->m_pResultView->m_pGridCtrl->m_hWnd) &&
			pChildFrame->m_pResultView->m_pGridCtrl->IsWindowVisible();
		if(bGrid)
		{
#ifdef _GOTO			
			try
			{
				nMaxLineCount = pChildFrame->m_pResultView->m_pGridCtrl->GetRows();
				nCurrentLine = pChildFrame->m_pResultView->m_pGridCtrl->GetRow();
				if(m_bPrev)
					nLineToGo = --nCurrentLine;
				else if(m_bNext)
					nLineToGo = ++nCurrentLine;
				
				if(nLineToGo > nMaxLineCount || nLineToGo < 0)
				{
					nLineToGo = nMaxLineCount;
					m_strLine.Format(_T("%d"), nLineToGo);
					GetDlgItem(IDC_LINE)->SetWindowText(m_strLine);
				}
				else if(nLineToGo == 0)
				{
					nLineToGo = 1;
					m_strLine = "1";
					GetDlgItem(IDC_LINE)->SetWindowText(m_strLine);
				}
				pChildFrame->m_pResultView->m_pGridCtrl->SetRow(nLineToGo);
				
				pChildFrame->m_strLineColInfo.Format(
					_T("Ln %d, Col %d"),
					pChildFrame->m_pResultView->m_pGridCtrl->GetRow(),
					pChildFrame->m_pResultView->m_pGridCtrl->GetCol()+1
					);
				pChildFrame->m_wndStatusBar.SetPaneText(
					pChildFrame->m_nLineColPaneNo, pChildFrame->m_strLineColInfo
					);
			}
			catch(COleDispatchException* e)
			{
				if(e)
					e->Delete();
			}
			catch(...)
			{
			}
#endif
		}
	}
	if(!bGrid)
	{
		CRichEditCtrl* pRichEditCtrl = NULL;
		if(pView != NULL)
		{
			if(pView->IsKindOf(RUNTIME_CLASS(CQryView)))
				pRichEditCtrl = &pChildFrame->m_pQryView->GetRichEditCtrl();
			else if(pView->IsKindOf(RUNTIME_CLASS(CResultView)))
				pRichEditCtrl = &pChildFrame->m_pResultView->GetRichEditCtrl();
		
			nMaxLineCount = pRichEditCtrl->GetLineCount();
			long lStart = -1;
			long lEnd = -1;
			pRichEditCtrl->GetSel(lStart, lEnd);
			nCurrentLine = pRichEditCtrl->LineFromChar(lStart)+1;
			
			if(m_bPrev)
				nLineToGo = --nCurrentLine;
			else if(m_bNext)
				nLineToGo = ++nCurrentLine;
			
			if(nLineToGo > nMaxLineCount || nLineToGo < 0)
			{
				nLineToGo = nMaxLineCount;
				m_strLine.Format(_T("%d"), nLineToGo);
				GetDlgItem(IDC_LINE)->SetWindowText(m_strLine);
			}
			else if(nLineToGo == 0)
			{
				nLineToGo = 1;
				m_strLine = "1";
				GetDlgItem(IDC_LINE)->SetWindowText(m_strLine);
			}
			
			lStart = pRichEditCtrl->LineIndex(nLineToGo-1);
			lEnd = lStart+1;
			pRichEditCtrl->SetSel(lStart, lEnd);
			
			pRichEditCtrl->GetSel(lStart, lEnd);
			pChildFrame->m_strLineColInfo.Format(
				_T("Ln %d, Col %d"),
				pRichEditCtrl->LineFromChar(lStart)+1,
				((lEnd-lStart) >= 0 ? lEnd-pRichEditCtrl->LineIndex(-1) :
					lStart-pRichEditCtrl->LineIndex(-1))+1
				);
			pChildFrame->m_wndStatusBar.SetPaneText(
				pChildFrame->m_nLineColPaneNo, pChildFrame->m_strLineColInfo
				);
		}
	}

	GetDlgItem(IDC_LINE)->SetFocus();
}

void CGoToDlg::OnClose() 
{
   DestroyWindow();
}

void CGoToDlg::OnPrev() 
{
	m_bPrev = true;
	OnGoTo();
	m_bPrev = false;
}

void CGoToDlg::OnChangeLine() 
{
	UpdateData();
	m_strLine.TrimRight();
	m_strLine.TrimLeft();
	if(m_strLine.IsEmpty())
	{
		GetDlgItem(IDC_PREV)->EnableWindow(TRUE);
		GetDlgItem(IDC_GOTO)->SetWindowText(_T("&Next"));
		m_bNext = true;
	}
	else
	{
		GetDlgItem(IDC_PREV)->EnableWindow(FALSE);
		GetDlgItem(IDC_GOTO)->SetWindowText(_T("&Go To"));
		m_bNext = false;
	}
}

bool CGoToDlg::PopulateLineNum()
{
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	ASSERT(pFrame != NULL);
	CChildFrame* pChildFrame = (CChildFrame*)pFrame->MDIGetActive();
	CView* pView = NULL;
	if(pChildFrame != NULL)
		pView = pChildFrame->GetActiveView();
	bool bGrid = false;
	if(pView != NULL && pView->IsKindOf(RUNTIME_CLASS(CResultView)))
	{
		bGrid = pChildFrame->m_pResultView->m_pGridCtrl != NULL &&
			::IsWindow(pChildFrame->m_pResultView->m_pGridCtrl->m_hWnd) &&
			pChildFrame->m_pResultView->m_pGridCtrl->IsWindowVisible();
		if(bGrid)
			m_strLine.Format(
				_T("%d"),
				pChildFrame->m_pResultView->m_pGridCtrl->GetRow()
				);
	}
	
	if(!bGrid)
	{
		CRichEditCtrl* pRichEditCtrl = NULL;
		if(pView != NULL)
		{
			if(pView->IsKindOf(RUNTIME_CLASS(CQryView)))
				pRichEditCtrl = &pChildFrame->m_pQryView->GetRichEditCtrl();
			else if(pView->IsKindOf(RUNTIME_CLASS(CResultView)))
				pRichEditCtrl = &pChildFrame->m_pResultView->GetRichEditCtrl();
		}
		if(pRichEditCtrl != NULL)
		{
			long lStart = -1;
			long lEnd = -1;
			pRichEditCtrl->GetSel(lStart, lEnd);
			m_strLine.Format(_T("%d"), pRichEditCtrl->LineFromChar(lStart)+1);
		}
	}

	if(pView != NULL)
	{
		CWnd* pWnd = GetDlgItem(IDC_LINE);
		if(pWnd != NULL)
		{
			pWnd->SetWindowText(m_strLine);
			pWnd->EnableWindow(!bGrid);
		}
		GetDlgItem(IDC_GOTO)->EnableWindow(!bGrid);
		GetDlgItem(IDC_LINE)->EnableWindow(!bGrid);
	}
	else
	{
		GetDlgItem(IDC_LINE)->SetWindowText(NULL);
		GetDlgItem(IDC_LINE)->EnableWindow(FALSE);
		GetDlgItem(IDC_GOTO)->EnableWindow(FALSE);
		GetDlgItem(IDC_PREV)->EnableWindow(FALSE);
		GetDlgItem(IDC_CLOSE)->SetFocus();
	}

	return bGrid;
}

void CGoToDlg::OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized) 
{
	bool bGrid = false;
	if(nState == WA_ACTIVE  || nState == WA_CLICKACTIVE)
		bGrid = PopulateLineNum();
	CDialog::OnActivate(nState, pWndOther, bMinimized);
	if(!bGrid)
		GetDlgItem(IDC_LINE)->SetFocus();
	else
		GetDlgItem(IDC_CLOSE)->SetFocus();
}

BOOL CGoToDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	return FALSE;
}