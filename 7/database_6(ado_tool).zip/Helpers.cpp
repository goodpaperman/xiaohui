// Helpers.cpp: implementation of the CHelpers class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Helpers.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// CHelpers

CHelpers::CHelpers()
{
}

CHelpers::~CHelpers()
{
}

int CHelpers::Insert(CListCtrlEx* pListCtrl, CString& sRow, int nImage/* = -1*/,
		int nIndex/* = -1*/)
{
	ASSERT(pListCtrl);

	int nItemIndex = -1;
	int nEnd = sRow.Find(_T("|"));
	if(nEnd != -1)
	{
		int nSubItem = 0;
		LV_ITEM lvItem;
		CString sColVal;
		lvItem.mask = LVIF_TEXT;
		
		if(nImage != -1)
		{
			lvItem.mask |= LVIF_IMAGE;
			lvItem.iImage = nImage;
		}
		
		if(nIndex != -1)
			lvItem.iItem = nIndex;

		lvItem.iSubItem = nSubItem++;
		sColVal = sRow.Mid(0, nEnd);
		lvItem.pszText = sColVal.GetBuffer(sColVal.GetLength()+1);
		sColVal.ReleaseBuffer();
		nItemIndex 	= pListCtrl->InsertItem(&lvItem);
		ASSERT(nItemIndex != -1);
		if(nItemIndex != -1)
		{
			while(sRow.GetLength() > nEnd) 
			{  		
				sRow = sRow.Mid(nEnd + 1);
				nEnd = sRow.Find(_T("|"));
				if(nEnd == -1)
					break;
				
				lvItem.iItem = nItemIndex;
				lvItem.iSubItem = nSubItem++;
				sColVal = sRow.Mid(0, nEnd);
				lvItem.pszText = sColVal.GetBuffer(sColVal.GetLength()+1);
				sColVal.ReleaseBuffer();
				pListCtrl->SetItem(&lvItem);
			}
		}
	}

	return nItemIndex;
}

CString CHelpers::GetFileExceptionError(const int& nCause)
{
	CString sBuff(_T("An unspecified error occurred."));
	
	switch(nCause)
	{
		case CFileException::fileNotFound:
			sBuff = _T("The file could not be located.");
			break;
		
		case CFileException::badPath:
			sBuff = _T("All or part of the path is invalid.");
			break;
		
		case CFileException::tooManyOpenFiles:
			sBuff = _T("The permitted number of open files was exceeded.");
			break;
		
		case CFileException::accessDenied:
			sBuff = _T("The file could not be accessed.");
			break;

		case CFileException::invalidFile:
			sBuff = _T("There was an attempt to use an invalid file handle.");
			break;
		
		case CFileException::removeCurrentDir:
			sBuff = _T("The current working directory cannot be removed.");
			break;
		
		case CFileException::directoryFull:
			sBuff = _T("There are no more directory entries.");
			break;
			
		case CFileException::badSeek:
			sBuff = _T("There was an error trying to set the file pointer.");
			break;
			
		case CFileException::hardIO:
			sBuff = _T("There was a hardware error.");
			break;

		case CFileException::sharingViolation:
			sBuff = _T("SHARE.EXE was not loaded, or a shared region was locked.");
			break;
			
		case CFileException::lockViolation:
			sBuff = _T("There was an attempt to lock a region that was already locked.");
			break;
			
		case CFileException::diskFull:
			sBuff = _T("The disk is full.");
			break;
		
		case CFileException::endOfFile:
			sBuff = _T("The end of file was reached."); 
			break;
	}

	return sBuff;
}

CString CHelpers::GetType(const int& nType)
{
	CString strTmp;
	
	switch(nType)
	{
	   case ADODB::adBigInt:
		   strTmp = "(adBigInt) An 8-byte signed integer";
		   break;
	   case ADODB::adBinary:
		   strTmp = "(adBinary) A binary value";
		   break;
	   case ADODB::adBoolean:
		   strTmp = "(adBoolean) A Boolean value";
		   break;
	   case ADODB::adBSTR:
		   strTmp = "(adBSTR) A null-terminated character string (Unicode)";
		   break;
	   case ADODB::adChar:
		   strTmp = "(adChar) A String value";
		   break;
	   case ADODB::adCurrency:
		   strTmp = "(adCurrency) A currency value (8-byte signed integer scaled by 10,000)";
		   break;
	   case ADODB::adDate:
		   strTmp = "(adDate) A Date value";
		   break;
	   case ADODB::adDBDate:
		   strTmp = "(adDBDate) A date value (yyyymmdd)";
		   break;
	   case ADODB::adDBTime:
		   strTmp = "(adDBTime) A time value (hhmmss)";
		   break;
	   case ADODB::adDBTimeStamp:
		   strTmp = "(adDBTimeStamp) A date-time stamp (yyyymmddhhmmss plus a fraction in billionths)";
		   break;
	   case ADODB::adDecimal:
		   strTmp = "(adDecimal) An exact numeric value with a fixed precision and scale";
		   break;
	   case ADODB::adDouble:
		   strTmp = "(adDouble) A double-precision floating point value";
		   break;
	   case ADODB::adEmpty:
		   strTmp = "(adEmpty) No value was specified";
		   break;
	   case ADODB::adError:
		   strTmp = "(adError) A 32-bit Error code";
		   break;
	   case ADODB::adGUID:
		   strTmp = "(adGUID) A globally unique identifier (GUID)";
		   break;
	   case ADODB::adIDispatch:
		   strTmp = "(adIDispatch) A pointer to an IDispatch interface on an OLE object";
		   break;
	   case ADODB::adInteger:
		   strTmp = "(adInteger) A 4-byte signed integer";
		   break;
	   case ADODB::adIUnknown:
		   strTmp = "(adIUnknown) A pointer to an IUnknown interface on an OLE object";
		   break;
	   case ADODB::adLongVarBinary:
		   strTmp = "(adLongVarBinary) A long binary value (Parameter object only)";
		   break;
	   case ADODB::adLongVarChar:
		   strTmp = "(adLongVarChar) A long String value (Parameter object only)";
		   break;
	   case ADODB::adLongVarWChar:
		   strTmp = "(adLongVarWChar) A long null-terminated string value (Parameter object only)";
		   break;
	   case ADODB::adNumeric:
		   strTmp = "(adNumeric) An exact numeric value with a fixed precision and scale";
		   break;
	   case ADODB::adSingle:
		   strTmp = "(adSingle) A single-precision floating point value";
		   break;
	   case ADODB::adSmallInt:
		   strTmp = "(adSmallInt) A 2-byte signed integer";
		   break;
	   case ADODB::adTinyInt:
		   strTmp = "(adTinyInt) A 1-byte signed integer";
		   break;
	   case ADODB::adUnsignedBigInt:
		   strTmp = "(adUnsignedBigInt) An 8-byte unsigned integer";
		   break;
	   case ADODB::adUnsignedInt:
		   strTmp = "(adUnsignedInt) A 4-byte unsigned integer";
		   break;
	   case ADODB::adUnsignedSmallInt:
		   strTmp = "(adUnsignedSmallInt) A 2-byte unsigned integer";
		   break;
	   case ADODB::adUnsignedTinyInt:
		   strTmp = "(adUnsignedTinyInt) A 1-byte unsigned integer";
		   break;
	   case ADODB::adUserDefined:
		   strTmp = "(adUserDefined) A user-defined variable";
		   break;
	   case ADODB::adVarBinary:
		   strTmp = "(adVarBinary) A binary value (Parameter object only)";
		   break;
	   case ADODB::adVarChar:
		   strTmp = "(adVarChar) A String value (Parameter object only)";
		   break;
	   case ADODB::adVariant:
		   strTmp = "(adVariant) An OLE Automation Variant";
		   break;
	   case ADODB::adVarWChar:
		   strTmp = "(adVarWChar) A null-terminated Unicode character string (Parameter object only)";
		   break;
	   case ADODB::adWChar:
		   strTmp = "(adWChar) A null-terminated Unicode character string";
		   break;
	   default:   
		   strTmp.Format(_T("%d = = Unrecognized Type"), nType);
   }
   
   return strTmp;
}

// CrackStrVariant() taken from the CCrack::strVariant method found in the
// DAOVIEW sample that ships with VC 5.0/6.0
CString CHelpers::CrackStrVariant(const COleVariant& var)
{
    CString strRet;
    strRet = _T("<Unknown>");
    switch(var.vt)
	{
		case VT_EMPTY:
		case VT_NULL:
			strRet = _T("NULL");
			break;
		case VT_I2:
			strRet.Format(_T("%hd"), V_I2(&var));
			break;
		case VT_I4:
			strRet.Format(_T("%d"),V_I4(&var));
			break;
		case VT_R4:
			strRet.Format(_T("%e"), (double)V_R4(&var));
			break;
		case VT_R8:
			strRet.Format(_T("%e"), V_R8(&var));
			break;
		case VT_CY:
			strRet = COleCurrency(var).Format();
			break;
		case VT_DATE:
			strRet = COleDateTime(var).Format(_T("%c"));
			break;
		case VT_BSTR:
			strRet = V_BSTR(&var);
			break;
		case VT_DISPATCH:
			strRet = _T("VT_DISPATCH");
			break;
		case VT_ERROR:
			strRet = _T("VT_ERROR");
			break;
		case VT_BOOL:
			return ( V_BOOL(&var) ? _T("TRUE") : _T("FALSE"));
		case VT_VARIANT:
			strRet = _T("VT_VARIANT");
			break;
		case VT_UNKNOWN:
			strRet = _T("VT_UNKNOWN");
			break;
		case VT_I1:
			strRet = _T("VT_I1");
			break;
		case VT_UI1:
			strRet.Format(_T("0x%02hX"), (unsigned short)V_UI1(&var));
			break;
		case VT_UI2:
			strRet = _T("VT_UI2");
			break;
		case VT_UI4:
			strRet = _T("VT_UI4");
			break;
		case VT_I8:
			strRet = _T("VT_I8");
			break;
		case VT_UI8:
			strRet = _T("VT_UI8");
			break;
		case VT_INT:
			strRet = _T("VT_INT");
			break;
		case VT_UINT:
			strRet = _T("VT_UINT");
			break;
		case VT_VOID:
			strRet = _T("VT_VOID");
			break;
		case VT_HRESULT:
			strRet = _T("VT_HRESULT");
			break;
		case VT_PTR:
			strRet = _T("VT_PTR");
			break;
		case VT_SAFEARRAY:
			strRet = _T("VT_SAFEARRAY");
			break;
		case VT_CARRAY:
			strRet = _T("VT_CARRAY");
			break;
		case VT_USERDEFINED:
			strRet = _T("VT_USERDEFINED");
			break;
		case VT_LPSTR:
			strRet = _T("VT_LPSTR");
			break;
		case VT_LPWSTR:
			strRet = _T("VT_LPWSTR");
			break;
		case VT_FILETIME:
			strRet = _T("VT_FILETIME");
			break;
		case VT_BLOB:
			strRet = _T("VT_BLOB");
			break;
		case VT_STREAM:
			strRet = _T("VT_STREAM");
			break;
		case VT_STORAGE:
			strRet = _T("VT_STORAGE");
			break;
		case VT_STREAMED_OBJECT:
			strRet = _T("VT_STREAMED_OBJECT");
			break;
		case VT_STORED_OBJECT:
			strRet = _T("VT_STORED_OBJECT");
			break;
		case VT_BLOB_OBJECT:
			strRet = _T("VT_BLOB_OBJECT");
			break;
		case VT_CF:
			strRet = _T("VT_CF");
			break;
		case VT_CLSID:
			strRet = _T("VT_CLSID");
			break;
    }
    
	WORD vt = var.vt;
    if(vt & VT_ARRAY)
	{
        vt = vt & ~VT_ARRAY;
        strRet = _T("Array of ");
    }
    
	if(vt & VT_BYREF)
	{
        vt = vt & ~VT_BYREF;
        strRet += _T("Pointer to ");
    }
    
	if(vt != var.vt)
	{
        switch(vt)
		{
			case VT_EMPTY:
				strRet += _T("VT_EMPTY");
				break;
			case VT_NULL:
				strRet += _T("VT_NULL");
				break;
			case VT_I2:
				strRet += _T("VT_I2");
				break;
			case VT_I4:
				strRet += _T("VT_I4");
				break;
			case VT_R4:
				strRet += _T("VT_R4");
				break;
			case VT_R8:
				strRet += _T("VT_R8");
				break;
			case VT_CY:
				strRet += _T("VT_CY");
				break;
			case VT_DATE:
				strRet += _T("VT_DATE");
				break;
			case VT_BSTR:
				strRet += _T("VT_BSTR");
				break;
			case VT_DISPATCH:
				strRet += _T("VT_DISPATCH");
				break;
			case VT_ERROR:
				strRet += _T("VT_ERROR");
				break;
			case VT_BOOL:
				strRet += _T("VT_BOOL");
				break;
			case VT_VARIANT:
				strRet += _T("VT_VARIANT");
				break;
			case VT_UNKNOWN:
				strRet += _T("VT_UNKNOWN");
				break;
			case VT_I1:
				strRet += _T("VT_I1");
				break;
			case VT_UI1:
				strRet += _T("VT_UI1");
				break;
			case VT_UI2:
				strRet += _T("VT_UI2");
				break;
			case VT_UI4:
				strRet += _T("VT_UI4");
				break;
			case VT_I8:
				strRet += _T("VT_I8");
				break;
			case VT_UI8:
				strRet += _T("VT_UI8");
				break;
			case VT_INT:
				strRet += _T("VT_INT");
				break;
			case VT_UINT:
				strRet += _T("VT_UINT");
				break;
			case VT_VOID:
				strRet += _T("VT_VOID");
				break;
			case VT_HRESULT:
				strRet += _T("VT_HRESULT");
				break;
			case VT_PTR:
				strRet += _T("VT_PTR");
				break;
			case VT_SAFEARRAY:
				strRet += _T("VT_SAFEARRAY");
				break;
			case VT_CARRAY:
				strRet += _T("VT_CARRAY");
				break;
			case VT_USERDEFINED:
				strRet += _T("VT_USERDEFINED");
				break;
			case VT_LPSTR:
				strRet += _T("VT_LPSTR");
				break;
			case VT_LPWSTR:
				strRet += _T("VT_LPWSTR");
				break;
			case VT_FILETIME:
				strRet += _T("VT_FILETIME");
				break;
			case VT_BLOB:
				strRet += _T("VT_BLOB");
				break;
			case VT_STREAM:
				strRet += _T("VT_STREAM");
				break;
			case VT_STORAGE:
				strRet += _T("VT_STORAGE");
				break;
			case VT_STREAMED_OBJECT:
				strRet += _T("VT_STREAMED_OBJECT");
				break;
			case VT_STORED_OBJECT:
				strRet += _T("VT_STORED_OBJECT");
				break;
			case VT_BLOB_OBJECT:
				strRet += _T("VT_BLOB_OBJECT");
				break;
			case VT_CF:
				strRet += _T("VT_CF");
				break;
			case VT_CLSID:
				strRet += _T("VT_CLSID");
				break;
        }
    }
    
	return strRet;
}

CString CHelpers::GetPropertyAttributes(const int& nPropertyAttributesEnum)
{
	CString strTmp(_T(""));
	
    if(nPropertyAttributesEnum & ADODB::adPropNotSupported)
		strTmp += _T("NotSupported ");
    else if(nPropertyAttributesEnum & ADODB::adPropRequired)
		strTmp += _T("Required ");
    else if(nPropertyAttributesEnum & ADODB::adPropOptional)
		strTmp += _T("Optional ");
    else if(nPropertyAttributesEnum & ADODB::adPropRead)
		strTmp += _T("Read ");
    else if(nPropertyAttributesEnum & ADODB::adPropWrite)
		strTmp += _T("Write ");

    return strTmp;
}