// datetime.h: interface for DDX_FieldDateTime
//

void AFXAPI DDX_FieldDateTime(CDataExchange* pDX, int nIDC, TIMESTAMP_STRUCT& ts, CRecordset* pSet);
BOOL GetDateTime(CWnd* pWnd, TIMESTAMP_STRUCT& ts);
BOOL GetDateTime(HWND hWnd, TIMESTAMP_STRUCT& ts);
void SetDateTime(CWnd* pWnd, TIMESTAMP_STRUCT ts);
void SetDateTime(HWND hWnd, TIMESTAMP_STRUCT ts);
