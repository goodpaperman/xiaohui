// date.h: interface for DDX_FieldDate
//

void AFXAPI DDX_FieldDate(CDataExchange* pDX, int nIDC, TIMESTAMP_STRUCT& ts, CRecordset* pSet);
BOOL GetDate(CWnd* pWnd, TIMESTAMP_STRUCT& ts);
BOOL GetDate(HWND hWnd, TIMESTAMP_STRUCT& ts);
void SetDate(CWnd* pWnd, TIMESTAMP_STRUCT ts);
void SetDate(HWND hWnd, TIMESTAMP_STRUCT ts);
