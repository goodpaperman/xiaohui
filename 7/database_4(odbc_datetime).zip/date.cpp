// Date.cpp : implementation of DDX_FieldDate
//

#include "stdafx.h"

#include "date.h"

/////////////////////////////////////////////////////////////////////////////
// Public functions

void AFXAPI DDX_FieldDate(CDataExchange* pDX, int nIDC, TIMESTAMP_STRUCT& ts, CRecordset* pSet )
{
	HWND hWndCtrl = pDX->PrepareEditCtrl(nIDC);
	if (pDX->m_bSaveAndValidate) {
		if (!GetDate(hWndCtrl, ts)) {
			// unable to get data;
			// delete (or change) following line if you don't want a mesage
			AfxMessageBox("invalid date.");
			// UpdateData return 'false' if pDX->Fail() !!!
			pDX->Fail();
		}
	} else {
		SetDate(hWndCtrl, ts);
	}
}


BOOL GetDate(CWnd* pWnd, TIMESTAMP_STRUCT& ts)
{
	ASSERT(pWnd != NULL);
	return GetDate(pWnd->m_hWnd, ts);
}

BOOL GetDate(HWND hWnd, TIMESTAMP_STRUCT& ts)
{
	const int DATE_SIZE = 64;
	char sBuffer[DATE_SIZE+1];
	CString strBuffer;
	COleDateTime date;
	::GetWindowText(hWnd, sBuffer, DATE_SIZE);
	strBuffer = sBuffer;

	if (strBuffer.IsEmpty()) {
		ts.year = 99;
		ts.month = 99;
		ts.day = 99;
		ts.hour = 99;
		ts.minute = 99;
		ts.second = 99;
		ts.fraction = 99;
		return TRUE;
	}

	// ParseDateTime helps you to test data integrity
	date.ParseDateTime(strBuffer, VAR_DATEVALUEONLY, LANG_USER_DEFAULT );
	if( date.GetStatus() == COleDateTime::valid ) {
		ts.year = date.GetYear();
		ts.month = date.GetMonth();
		ts.day = date.GetDay();
		ts.hour = ts.minute = ts.second = 0;
		ts.fraction = 0;
		return TRUE;
	} else
		return FALSE;
}


void SetDate(CWnd* pWnd, TIMESTAMP_STRUCT ts)
{
	ASSERT(pWnd != NULL);
	SetDate(pWnd->m_hWnd, ts);
}

void SetDate(HWND hWnd, TIMESTAMP_STRUCT ts)
{
	COleDateTime date( ts.year, ts.month, ts.day, 0, 0, 0);
	CString sBuffer;
	// don't forget setlocale(...) in your code
	sBuffer = date.Format("%x");
	// empty string if data is invalid
	if( date.GetStatus() == COleDateTime::invalid )
		sBuffer = "";
	::SetWindowText(hWnd, sBuffer.GetBufferSetLength(sBuffer.GetLength()));
}


