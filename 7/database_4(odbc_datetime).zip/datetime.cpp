// datetime.cpp : implementation of DDX_FieldDateTime
//

#include "stdafx.h"

#include "datetime.h"

/////////////////////////////////////////////////////////////////////////////
// Public functions

void AFXAPI DDX_FieldDateTime(CDataExchange* pDX, int nIDC, TIMESTAMP_STRUCT& ts, CRecordset* pSet )
{
	HWND hWndCtrl = pDX->PrepareEditCtrl(nIDC);
	if (pDX->m_bSaveAndValidate) {
		if (!GetDateTime(hWndCtrl, ts)) {
			AfxMessageBox("Formato data/ora non valido.");
			pDX->Fail();
		}
	} else {
		SetDateTime(hWndCtrl, ts);
	}
}


BOOL GetDateTime(CWnd* pWnd, TIMESTAMP_STRUCT& ts)
{
	ASSERT(pWnd != NULL);
	return GetDateTime(pWnd->m_hWnd, ts);
}

BOOL GetDateTime(HWND hWnd, TIMESTAMP_STRUCT& ts)
{
	const int DATE_SIZE = 64;
	char sBuffer[DATE_SIZE+1];
	CString strBuffer;
	COleDateTime date;
	::GetWindowText(hWnd, sBuffer, DATE_SIZE);
	strBuffer = sBuffer;

	if (strBuffer.IsEmpty()) {
		ts.year = 99;
		ts.month = 99;
		ts.day = 99;
		ts.hour = 99;
		ts.minute = 99;
		ts.second = 99;
		ts.fraction = 99;
		return TRUE;
	}

//	if( date.ParseDateTime(strBuffer, VAR_DATEVALUEONLY, LANG_USER_DEFAULT ) != -1) {
	date.ParseDateTime(strBuffer, 0, LANG_USER_DEFAULT );
	if( date.GetStatus() == COleDateTime::valid ) {
		ts.year = date.GetYear();
		ts.month = date.GetMonth();
		ts.day = date.GetDay();
		ts.hour = date.GetHour();
		ts.minute = date.GetMinute();
		ts.second = date.GetSecond();
		ts.fraction = 0;
		return TRUE;
	} else
		return FALSE;
}


void SetDateTime(CWnd* pWnd, TIMESTAMP_STRUCT ts)
{
	ASSERT(pWnd != NULL);
	SetDateTime(pWnd->m_hWnd, ts);
}

void SetDateTime(HWND hWnd, TIMESTAMP_STRUCT ts)
{
	COleDateTime date( ts.year, ts.month, ts.day, ts.hour, ts.minute, ts.second);
	CString sBuffer;
	sBuffer = date.Format("%c");
	// empty string if data is invalid
	if( date.GetStatus() == COleDateTime::invalid )
		sBuffer = "";
	::SetWindowText(hWnd, sBuffer.GetBufferSetLength(sBuffer.GetLength()));
}


