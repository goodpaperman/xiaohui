// ChooseDirDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SPW.h"
#include "ChooseDirDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChooseDirDlg dialog

CChooseDirDlg::CChooseDirDlg(BOOL bOpenFileDialog, // TRUE for FileOpen, FALSE for FileSaveAs
        LPCSTR lpszDefExt,
        LPCSTR lpszFileName,
        DWORD dwFlags,
        LPCSTR lpszFilter,
        CWnd* pParentWnd) : CFileDialog(bOpenFileDialog, lpszDefExt, lpszFileName,
                                        dwFlags, lpszFilter, pParentWnd)
{
	//{{AFX_DATA_INIT(CChooseDirDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CChooseDirDlg::DoDataExchange(CDataExchange* pDX)
{
	CFileDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CChooseDirDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CChooseDirDlg, CFileDialog)
	//{{AFX_MSG_MAP(CChooseDirDlg)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChooseDirDlg message handlers

BOOL CChooseDirDlg::OnInitDialog() 
{
   CenterWindow();
    
   GetDlgItem(stc2)->ShowWindow(SW_HIDE);
   GetDlgItem(stc3)->ShowWindow(SW_HIDE);
   GetDlgItem(edt1)->ShowWindow(SW_HIDE);
   GetDlgItem(lst1)->ShowWindow(SW_HIDE);
   GetDlgItem(cmb1)->ShowWindow(SW_HIDE);
    
   SetDlgItemText(edt1, "Junk");

   GetDlgItem(lst2)->SetFocus();
   
   m_bDlgJustCameUp = TRUE;
   
   CFileDialog::OnInitDialog();
       
   return FALSE;
}

void CChooseDirDlg::OnPaint() 
{
	CPaintDC dc(this);

    if(m_bDlgJustCameUp)
    {
       m_bDlgJustCameUp = FALSE;
       SendDlgItemMessage(lst2, LB_SETCURSEL, 0, 0L);
    }
}