// GenerateClassDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SPW.h"
#include "GenerateClassDlg.h"
#include "SPWListView.h"
#include "MainFrm.h"
#include "ChooseDirDlg.h"
#include "DirDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW				 
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CSPWApp theApp;
/////////////////////////////////////////////////////////////////////////////
// CGenerateClassDlg dialog

CGenerateClassDlg::CGenerateClassDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGenerateClassDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGenerateClassDlg)
	m_strFileName = _T("");
	m_strClassName = _T("");
	//}}AFX_DATA_INIT

	m_nValuesToStore = 10;
}

CGenerateClassDlg::~CGenerateClassDlg()
{
	::SetCurrentDirectory(m_strOriginalDir);
}

void CGenerateClassDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGenerateClassDlg)
	DDX_Control(pDX, IDC_DIR_COMBO, m_cbDir);
	DDX_Text(pDX, IDC_FILE_NAME, m_strFileName);
	DDX_Text(pDX, IDC_CLASS_NAME, m_strClassName);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CGenerateClassDlg, CDialog)
	//{{AFX_MSG_MAP(CGenerateClassDlg)
	ON_EN_CHANGE(IDC_CLASS_NAME, OnChangeClassName)
	ON_BN_CLICKED(IDC_PROJECT, OnProject)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGenerateClassDlg message handlers

BOOL CGenerateClassDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	::GetCurrentDirectory(256, m_strOriginalDir.GetBuffer(257));
	m_strOriginalDir.ReleaseBuffer();
	
	m_strClassName = GetClassName();
	
	// check for invalid characters, if any
	int nLength = m_strClassName.GetLength();
	
	for(int i = 0; i < nLength; i++)
	{
		int nPos = m_strClassName.Find(_T(' '));
		
		if(nPos != -1)
			m_strClassName.SetAt(nPos, _T('_'));	
	}

	if(!m_strClassName.IsEmpty())
		m_strFileName = m_strClassName + _T(".cpp");
	
	CString sBuff;
	for(int n = 1; n <= m_nValuesToStore; n++)
	{
		sBuff.Format("%s_%d", (LPCTSTR)theApp.m_strProjectDirKey, n);
		m_strDirectoryName = theApp.GetProfileString(theApp.m_strSection, sBuff);
		m_strDirectoryName.TrimRight(); m_strDirectoryName.TrimLeft();
		
		if(!m_strDirectoryName.IsEmpty())
			m_cbDir.AddString(m_strDirectoryName);
	}

	m_strDirectoryName = theApp.GetProfileString(theApp.m_strSection, theApp.m_strInitialDir);

	m_strDirectoryName.TrimRight(); m_strDirectoryName.TrimLeft();
	
	m_cbDir.SetWindowText(m_strDirectoryName);

	GetResultSetInfo(m_Result);

	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CGenerateClassDlg::OnChangeClassName() 
{
	UpdateData(TRUE);
	
	m_strClassName.TrimRight(); m_strClassName.TrimLeft(); 
		
	if(!m_strClassName.IsEmpty())
		m_strFileName = m_strClassName + _T((".cpp"));
	else
		m_strFileName = m_strClassName;
	
	if(m_strClassName.Left(1) == "c" || m_strClassName.Left(1) == "C")
	{
		m_strFileName.SetAt(0, ' ');
		m_strFileName.TrimLeft();
	}
	
	UpdateData(FALSE);
}

void CGenerateClassDlg::OnOK() 
{
	CWaitCursor wait;

	UpdateData(TRUE);
	
	m_strClassName.TrimRight(); m_strClassName.TrimLeft(); 

	if(m_strClassName.IsEmpty())
	{
		AfxMessageBox(_T("<Class Name> is a required field."));
		GetDlgItem(IDC_CLASS_NAME)->SetFocus();
		return;
	}
	
	m_cbDir.GetWindowText(m_strDirectoryName);

	m_strDirectoryName.TrimRight(); m_strDirectoryName.TrimLeft();
		
	if(m_strDirectoryName.IsEmpty())
	{
		AfxMessageBox("<Project Dir> is a required field.");
		GetDlgItem(IDC_DIR_COMBO)->SetFocus();
		return;
	}

	if(!::SetCurrentDirectory(m_strDirectoryName))
	{
		CString sMsg = "The folder <" + m_strDirectoryName + "> does not exist.";
		AfxMessageBox(sMsg);
		GetDlgItem(IDC_DIR_COMBO)->SetFocus();
		return;
	}
	
	int nLength = m_strClassName.GetLength();
		
	for(int j = 0; j < nLength; j++)
	{
		TCHAR ch = m_strClassName.GetAt(j);
			
		if(ch != '_')
		{
		 	if(!isalnum(ch))
			{
				AfxMessageBox("Invalid symbol specified.");
				GetDlgItem(IDC_CLASS_NAME)->SetFocus();
				return;
			}
		}				
	}
		
	if(!GenerateCppFile() || !GenerateHFile())
		return;

#ifdef _CHOOSE_DIR_DLG
	// Project Dir
	if(m_strDirectoryName.GetLength() == 2)
		m_strDirectoryName += _T("\\");
#endif

	CString sBuff, sLBText, sDir;

	int nCount = m_cbDir.GetCount();
	
	BOOL bDuplicateExists = FALSE;
				
	for(int n = 1; n <= m_cbDir.GetCount(); n++)
	{
		m_cbDir.GetLBText(n-1, sLBText);
		
		sBuff = sLBText;
		sDir = m_strDirectoryName;
		
		sBuff.MakeUpper();
		sDir.MakeUpper();

		if(sBuff == sDir)
			bDuplicateExists = TRUE;
	}
	
	if(!bDuplicateExists)
		m_cbDir.InsertString(0, m_strDirectoryName);
	
	nCount = m_cbDir.GetCount();

	if(nCount > m_nValuesToStore)
		nCount = m_cbDir.DeleteString(nCount);	// Store upto 10 values only 
	
	for(n = 1; n <= nCount; n++)
	{
		m_cbDir.GetLBText(n-1, sLBText);
		sBuff.Format("%s_%d", (LPCTSTR)theApp.m_strProjectDirKey, n);
		theApp.WriteProfileString(theApp.m_strSection, sBuff, sLBText);
	}

	theApp.WriteProfileString(theApp.m_strSection, theApp.m_strInitialDir, m_strDirectoryName);
		
	CDialog::OnOK();
}

BOOL CGenerateClassDlg::GenerateCppFile()
{
	CStdioFile file;
	CFileException fileException;
	CFileStatus status;
	CString sPathName;

	if(m_strDirectoryName.GetLength() == 3)
		sPathName.Format("%s%s", (LPCTSTR)m_strDirectoryName, (LPCTSTR)m_strFileName);
	else
		sPathName.Format("%s\\%s", (LPCTSTR)m_strDirectoryName, (LPCTSTR)m_strFileName);
		
	BOOL bRet = TRUE;

	if(file.GetStatus(sPathName, status))
	{
		CString s;
		s.Format("<%s> already exists. Replace existing file?", (LPCTSTR)sPathName);
		if(AfxMessageBox(s, MB_YESNO) == IDNO)
			bRet = FALSE;
	}
	
	if(bRet)
	{
		if(!file.Open(sPathName, CFile::typeText | 
					CFile::modeCreate | CFile::modeWrite, &fileException))
		{
			CString sMsg;
			sMsg.Format("File Path Name: <%s> ", (LPCTSTR)sPathName);
			sMsg += GetFileErrorMessage(fileException.m_cause);
			AfxMessageBox(sMsg);
			GetDlgItem(IDC_DIR_COMBO)->SetFocus();
			bRet = FALSE;
		}
	}
	
	if(bRet)
	{
		WriteIntroStuff(&file);
		WriteConstructor(&file);
		WriteGetDefaultConnect(&file);
		WriteGetDefaultSQL(&file);
		WriteDoFieldExchange(&file);
		
		if(!m_Result.m_nFields)
		{
#ifdef _OVERRIDE_OPEN_
			WriteOpenMemberFunction(&file);
#endif
			WriteMoveMemberFunction(&file);
		}

		WriteExecDirectMemberFunction(&file);
		WriteDiagnosticsStuff(&file);
	}
	
	return bRet;
}

void CGenerateClassDlg::WriteIntroStuff(CStdioFile* pFile)
{
	CString sBuff;
	sBuff.Format("// %s : implementation file\n//", (LPCTSTR)m_strFileName);
	pFile->WriteString(sBuff);
	sBuff = "\n\n";
	pFile->WriteString(sBuff);
	int nPos = m_strFileName.Find(".");
	CString s = m_strFileName.Left(nPos) + ".h";
	sBuff.Format("#include \"StdAfx.h\"\n#include \"%s\"\n\n", (LPCTSTR)s);
	pFile->WriteString(sBuff);
#ifdef _OVERRIDE_OPEN_	
	sBuff.Format("\ninclude <afxpriv.h>");
	pFile->WriteString(sBuff);
#endif
	sBuff = "#ifdef _DEBUG\n#define new DEBUG_NEW\n#undef THIS_FILE\nstatic char THIS_FILE[] = __FILE__;\n#endif\n\n";
	pFile->WriteString(sBuff);
#ifdef _OVERRIDE_OPEN_	
	sBuff.Format("static const TCHAR szDriverNotCapable[] = _T(\"State:S1C00\");\n");
	pFile->WriteString(sBuff);
#endif
	sBuff.Format("/////////////////////////////////////////////////////////////////////////////\n// %s\n\n", (LPCTSTR)m_strClassName);
	pFile->WriteString(sBuff);
	sBuff.Format("IMPLEMENT_DYNAMIC(%s, CRecordset)\n\n%s::%s(CDatabase* pdb)\n\t : CRecordset(pdb)\n{", (LPCTSTR)m_strClassName, (LPCTSTR)m_strClassName, (LPCTSTR)m_strClassName);
	pFile->WriteString(sBuff);
}

void CGenerateClassDlg::WriteConstructor(CStdioFile* pFile)
{
	CString sBuff;
	
	CString sFields;
	CString sParams;
	
	for(int i = 0; i < m_Result.m_nCount; i++)
	{
		CString sColName = GetResultSetString(i, 0);
		CString sVarName = GetValidatedColName(sColName);
	 	CString sColType = GetResultSetString(i, ID_COL_TYPE);
		CString sCPPType = GetResultSetString(i, ID_CPP_TYPE);

		if(sColType == _T("Result_Col"))
		{
			if(sCPPType == _T("BOOL"))
				sFields += "\n\tm_" + sVarName + " = FALSE;";

			if(sCPPType == _T("CString"))
				sFields += "\n\tm_" + sVarName + " = _T(\"\");";

			if(sCPPType == _T("double"))
				sFields += "\n\tm_" + sVarName + " = 0.0;";

			if(sCPPType == _T("long"))
				sFields += "\n\tm_" + sVarName + " = 0;";
			
			if(sCPPType == _T("int"))
				sFields += "\n\tm_" + sVarName + " = 0;";

			if(sCPPType == _T("BYTE"))
				sFields += "\n\tm_" + sVarName + " = 0;";
			
			if(sCPPType == _T("float"))
				sFields += "\n\tm_" + sVarName + " = 0.0f;";
		}

		if(sColType == _T("Return_Value"))
		{
			if(sCPPType == _T("BOOL"))
				sParams += "\n\tm_" + sVarName + " = FALSE;";

			if(sCPPType == _T("CString"))
				sParams += "\n\tm_" + sVarName + " = _T(\"\");";

			if(sCPPType == _T("double"))
				sParams += "\n\tm_" + sVarName + " = 0.0;";

			if(sCPPType == _T("long"))
				sParams += "\n\tm_" + sVarName + " = -1;";
			
			if(sCPPType == _T("int"))
				sParams += "\n\tm_" + sVarName + " = -1;";

			if(sCPPType == _T("BYTE"))
				sParams += "\n\tm_" + sVarName + " = 0;";
			
			if(sCPPType == _T("float"))
				sParams += "\n\tm_" + sVarName + " = 0.0f;";
		}

		if(sColType == _T("Param_Input") || sColType == _T("Param_Input_Output")
							|| sColType == _T("Param_Output"))
		{
			if(sCPPType == _T("BOOL"))
				sParams += "\n\tm_" + sVarName + "Param = FALSE;";

			if(sCPPType == _T("CString"))
				sParams += "\n\tm_" + sVarName + "Param = _T(\"\");";

			if(sCPPType == _T("double"))
				sParams += "\n\tm_" + sVarName + "Param = 0.0;";

			if(sCPPType == _T("long"))
				sParams += "\n\tm_" + sVarName + "Param = 0;";
			
			if(sCPPType == _T("int"))
				sParams += "\n\tm_" + sVarName + "Param = 0;";

			if(sCPPType == _T("BYTE"))
				sParams += "\n\tm_" + sVarName + "Param = 0;";
			
			if(sCPPType == _T("float"))
				sParams += "\n\tm_" + sVarName + "Param = 0.0f;";
		}
	}
		
	if(m_Result.m_nFields)
	{
		sBuff = "\n\t// Field Init";
		pFile->WriteString(sBuff);
		sBuff.Format("%s", (LPCTSTR)sFields);
		pFile->WriteString(sBuff);
		sBuff.Format("\n\tm_nFields = %d;", m_Result.m_nFields);
		pFile->WriteString(sBuff);
	}
		
	if(m_Result.m_nParams || !sParams.IsEmpty() /*Return_Value*/)
	{
		if(m_Result.m_nFields)
			sBuff = "\n\n\t// Param Init";
		else
			sBuff = "\n\t// Param Init";
		
		pFile->WriteString(sBuff);
		
		if(!sParams.IsEmpty())
		{
			sBuff.Format("%s", (LPCTSTR)sParams);
			pFile->WriteString(sBuff);
		}
		
		sBuff.Format("\n\tm_nParams = %d;", m_Result.m_nParams);
		
		pFile->WriteString(sBuff);

		sBuff = "\n\n\tm_nDefaultType = snapshot;";
		pFile->WriteString(sBuff);
	}
	
	sBuff.Format("\n}");
	pFile->WriteString(sBuff);	
}

void CGenerateClassDlg::WriteGetDefaultConnect(CStdioFile* pFile)
{
	CString sBuff;
#ifdef _USE_HARD_CODE
	UCHAR	buffer[200];
	SWORD	cbData;
	
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	ASSERT(pFrame != NULL);
	CSPWDoc* pDoc = (CSPWDoc*)pFrame->GetActiveDocument();
	ASSERT(pDoc != NULL);

	::SQLGetInfo(pDoc->m_database.m_hdbc, SQL_DATA_SOURCE_NAME,
		(PTR)buffer, 200, &cbData);
	
	sBuff.Format("\n\nCString %s::GetDefaultConnect()\n{\n\treturn _T", (LPCTSTR)m_strClassName);
	pFile->WriteString(sBuff);

	sBuff.Format("(\"ODBC;DSN=%s\");\n}", buffer);
	pFile->WriteString(sBuff);
#else
	sBuff.Format("\n\nCString %s::GetDefaultConnect()\n{\n\treturn ODBC_DSN_INFO;\n}", (LPCTSTR)m_strClassName);
	pFile->WriteString(sBuff);
#endif
}

void CGenerateClassDlg::WriteGetDefaultSQL(CStdioFile* pFile)
{
	CString sBuff;
	
	sBuff.Format("\n\nCString %s::GetDefaultSQL()\n{\n\treturn _T(\"", (LPCTSTR)m_strClassName);
	pFile->WriteString(sBuff);

	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	ASSERT(pFrame != NULL);
	
	CSPWListView* pView = pFrame->GetSPListView();
	ASSERT(pView != NULL);

	CString sProcedureName = pView->GetListCtrl().GetItemText(pView->m_nSelectedItem, 0);
	int nPos = sProcedureName.Find(' ');
	if(nPos != -1)
		sProcedureName = "[" + sProcedureName + "]";
	
	CString sPlaceHolders("");
	
	for(int i = 1; i <= m_Result.m_nParams - m_Result.m_nRet; i++)
		sPlaceHolders += "?,";

	int nLength = sPlaceHolders.GetLength();

	if(nLength)
	{
		sPlaceHolders.SetAt(nLength-1, _T(' '));
		sPlaceHolders.TrimRight();
		sBuff.Format("{CALL %s (%s)}\");\n}", (LPCTSTR)sProcedureName, (LPCTSTR)sPlaceHolders);
	}
	else
		sBuff.Format("{CALL %s}\");\n}", (LPCTSTR)sProcedureName);
		
	if(m_Result.m_nRet)
		sBuff = "{? = " + sBuff.Mid(1);

	pFile->WriteString(sBuff);
}

void CGenerateClassDlg::WriteDoFieldExchange(CStdioFile* pFile)
{
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	ASSERT(pFrame != NULL);
	CSPWResultSetView* pView = pFrame->GetSPResultSetView();
	ASSERT(pView != NULL);

	CString sBuff;
	sBuff.Format("\n\nvoid %s::DoFieldExchange(CFieldExchange* pFX)\n{", (LPCTSTR)m_strClassName);
	pFile->WriteString(sBuff);
	
	CString sFields;
	CString sInputParams;
	CString sInputOutputParams;
	CString sOutputParams;
	CString sColName;
	CString sVarName;
	CString sColType;
	CString sSQLType;
	CString sCPPType;
	CString sLength;
	CString sScale;

	for(int i = 0; i < m_Result.m_nCount; i++)
	{
		sColName = GetResultSetString(i, ID_COL_NAME);
		sVarName = GetValidatedColName(sColName);
	 	sColType = GetResultSetString(i, ID_COL_TYPE);
		sSQLType = GetResultSetString(i, ID_SQL_TYPE);
		sCPPType = GetResultSetString(i, ID_CPP_TYPE);
		sLength	 = GetResultSetString(i, ID_COL_LENGTH);
		
		if(sColType == _T("Param_Input"))
		{
			if(sCPPType == _T("CByteArray"))
				sInputParams += "\n\tRFX_Binary(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param, " + sLength + ");";
			
			if(sCPPType == _T("BOOL"))
				sInputParams += "\n\tRFX_Bool(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param);";

			if(sCPPType == _T("CString"))
			{
				if(sSQLType == _T("SQL_NUMERIC"))
				{
					int nScale	= pView->GetListCtrl().GetItemData(i);
					sScale.Format("%d", nScale); 
					sInputParams += "\n\tRFX_Text(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param, " + sLength + ", SQL_NUMERIC, " + sScale + ");";
				}
				else if(sSQLType == _T("SQL_DECIMAL"))
				{
					int nScale	= pView->GetListCtrl().GetItemData(i);
					sScale.Format("%d", nScale); 
					sInputParams += "\n\tRFX_Text(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param, " + sLength + ", SQL_DECIMAL, " + sScale + ");";
				}
				else
					sInputParams += "\n\tRFX_Text(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param, " + sLength + ");";
			}
						
			if(sCPPType == _T("double"))
				sInputParams += "\n\tRFX_Double(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param);";
			
			if(sCPPType == _T("CLongBinary"))
				sInputParams += "\n\tRFX_LongBinary(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param);";
			
			if(sCPPType == _T("long"))
				sInputParams += "\n\tRFX_Long(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param);";

			if(sCPPType == _T("int"))
				sInputParams += "\n\tRFX_Int(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param);";
						
			if(sCPPType == _T("BYTE"))
				sInputParams += "\n\tRFX_Byte(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param);";
			
			if(sCPPType == _T("float"))
				sInputParams += "\n\tRFX_Single(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param);";

			if(sCPPType == _T("CTime"))
				sInputParams += "\n\tRFX_Date(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param);";

			if(sCPPType == _T("TIMESTAMP_STRUCT"))
				sInputParams += "\n\tRFX_Date(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param);";
		}
		
		if(sColType == _T("Param_Input_Output"))
		{
			if(sCPPType == _T("CByteArray"))
				sInputOutputParams += "\n\tRFX_Binary(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param, " + sLength + ");";
			
			if(sCPPType == _T("BOOL"))
				sInputOutputParams += "\n\tRFX_Bool(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param);";

			if(sCPPType == _T("CString"))
			{
				if(sSQLType == _T("SQL_NUMERIC"))
				{
					int nScale	= pView->GetListCtrl().GetItemData(i);
					sScale.Format("%d", nScale); 
					sInputOutputParams += "\n\tRFX_Text(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param, " + sLength + ", SQL_NUMERIC, " + sScale + ");";
				}
				else if(sSQLType == _T("SQL_DECIMAL"))
				{
					int nScale	= pView->GetListCtrl().GetItemData(i);
					sScale.Format("%d", nScale); 
					sInputOutputParams += "\n\tRFX_Text(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param, " + sLength + ", SQL_DECIMAL, " + sScale + ");";
				}
				else
					sInputOutputParams += "\n\tRFX_Text(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param, " + sLength + ");";
			}
						
			if(sCPPType == _T("double"))
				sInputOutputParams += "\n\tRFX_Double(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param);";
			
			if(sCPPType == _T("CLongBinary"))
				sInputOutputParams += "\n\tRFX_LongBinary(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param);";
			
			if(sCPPType == _T("long"))
				sInputOutputParams += "\n\tRFX_Long(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param);";

			if(sCPPType == _T("int"))
				sInputOutputParams += "\n\tRFX_Int(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param);";
						
			if(sCPPType == _T("BYTE"))
				sInputOutputParams += "\n\tRFX_Byte(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param);";
			
			if(sCPPType == _T("float"))
				sInputOutputParams += "\n\tRFX_Single(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param);";

			if(sCPPType == _T("CTime"))
				sInputParams += "\n\tRFX_Date(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param);";

			if(sCPPType == _T("TIMESTAMP_STRUCT"))
				sInputParams += "\n\tRFX_Date(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param);";
		}

		if(sColType == _T("Return_Value"))
		{
			if(sCPPType == _T("CByteArray"))
				sOutputParams += "\n\tRFX_Binary(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param, " + sLength + ");";
			
			if(sCPPType == _T("BOOL"))
				sOutputParams += "\n\tRFX_Bool(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + ");";

			if(sCPPType == _T("CString"))
			{
				if(sSQLType == _T("SQL_NUMERIC"))
				{
					int nScale	= pView->GetListCtrl().GetItemData(i);
					sScale.Format("%d", nScale); 
					sOutputParams += "\n\tRFX_Text(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + ", " + sLength + ", SQL_NUMERIC, " + sScale + ");";
				}
				else if(sSQLType == _T("SQL_DECIMAL"))
				{
					int nScale	= pView->GetListCtrl().GetItemData(i);
					sScale.Format("%d", nScale); 
					sOutputParams += "\n\tRFX_Text(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + ", " + sLength + ", SQL_DECIMAL, " + sScale + ");";
				}
				else
					sOutputParams += "\n\tRFX_Text(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + ", " + sLength + ");";
			}
						
			if(sCPPType == _T("double"))
				sOutputParams += "\n\tRFX_Double(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + ");";
			
			if(sCPPType == _T("CLongBinary"))
				sOutputParams += "\n\tRFX_LongBinary(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + ");";
			
			if(sCPPType == _T("long"))
				sOutputParams += "\n\tRFX_Long(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + ");";

			if(sCPPType == _T("int"))
				sOutputParams += "\n\tRFX_Int(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + ");";
						
			if(sCPPType == _T("BYTE"))
				sOutputParams += "\n\tRFX_Byte(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + ");";
			
			if(sCPPType == _T("float"))
				sOutputParams += "\n\tRFX_Single(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + ");";

			if(sCPPType == _T("CTime"))
				sInputParams += "\n\tRFX_Date(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + ");";

			if(sCPPType == _T("TIMESTAMP_STRUCT"))
				sInputParams += "\n\tRFX_Date(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + ");";
		}
		
		if(sColType == _T("Param_Output"))
		{
			if(sCPPType == _T("CByteArray"))
				sOutputParams += "\n\tRFX_Binary(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param, " + sLength + ");";
			
			if(sCPPType == _T("BOOL"))
				sOutputParams += "\n\tRFX_Bool(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param);";

			if(sCPPType == _T("CString"))
			{
				if(sSQLType == _T("SQL_NUMERIC"))
				{
					int nScale	= pView->GetListCtrl().GetItemData(i);
					sScale.Format("%d", nScale); 
					sOutputParams += "\n\tRFX_Text(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param, " + sLength + ", SQL_NUMERIC, " + sScale + ");";
				}
				else if(sSQLType == _T("SQL_DECIMAL"))
				{
					int nScale	= pView->GetListCtrl().GetItemData(i);
					sScale.Format("%d", nScale); 
					sOutputParams += "\n\tRFX_Text(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param, " + sLength + ", SQL_DECIMAL, " + sScale + ");";
				}
				else
					sOutputParams += "\n\tRFX_Text(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param, " + sLength + ");";
			}
						
			if(sCPPType == _T("double"))
				sOutputParams += "\n\tRFX_Double(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param);";
			
			if(sCPPType == _T("CLongBinary"))
				sOutputParams += "\n\tRFX_LongBinary(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param);";
			
			if(sCPPType == _T("long"))
				sOutputParams += "\n\tRFX_Long(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param);";

			if(sCPPType == _T("int"))
				sOutputParams += "\n\tRFX_Int(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param);";
						
			if(sCPPType == _T("BYTE"))
				sOutputParams += "\n\tRFX_Byte(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param);";
			
			if(sCPPType == _T("float"))
				sOutputParams += "\n\tRFX_Single(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param);";

			if(sCPPType == _T("CTime"))
				sInputParams += "\n\tRFX_Date(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param);";

			if(sCPPType == _T("TIMESTAMP_STRUCT"))
				sInputParams += "\n\tRFX_Date(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + "Param);";
		}

		if(sColType == _T("Result_Col"))
		{
			if(sCPPType == _T("CByteArray"))
				sFields += "\n\tRFX_Binary(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + ", " + sLength + ");";
			
			if(sCPPType == _T("BOOL"))
				sFields += "\n\tRFX_Bool(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + ");";

			if(sCPPType == _T("CString"))
				sFields += "\n\tRFX_Text(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + ", " + sLength + ");";
						
			if(sCPPType == _T("double"))
				sFields += "\n\tRFX_Double(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + ");";
			
			if(sCPPType == _T("CLongBinary"))
				sFields += "\n\tRFX_LongBinary(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + ");";
			
			if(sCPPType == _T("long"))
				sFields += "\n\tRFX_Long(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + ");";

			if(sCPPType == _T("int"))
				sFields += "\n\tRFX_Int(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + ");";
						
			if(sCPPType == _T("BYTE"))
				sFields += "\n\tRFX_Byte(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + ");";
			
			if(sCPPType == _T("float"))
				sFields += "\n\tRFX_Single(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + ");";

			if(sCPPType == _T("CTime"))
				sFields += "\n\tRFX_Date(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + ");";

			if(sCPPType == _T("TIMESTAMP_STRUCT"))
				sFields += "\n\tRFX_Date(pFX, _T(\"[" + sColName + "]\"), m_" + sVarName + ");";
		}
	}

	// <pFX->SetFieldType> must be in the following order:

	// pFX->SetFieldType(CFieldExchange::outputColumn)
	// pFX->SetFieldType(CFieldExchange::outputParam)
	// pFX->SetFieldType(CFieldExchange::inputParam)
	// pFX->SetFieldType(CFieldExchange::inoutParam)

	// The above order is based on the assumption that
	// the input_output (sybase)/output (Microsoft) parameters
	// (CFieldExchange::inoutParam) are listed last in the stored
	// procedure parameter list.

	if(m_Result.m_nFields)
	{
		sBuff.Format("\n\t// RFX field mapping");
		pFile->WriteString(sBuff);
		sBuff.Format("\n\tpFX->SetFieldType(CFieldExchange::outputColumn);");
		pFile->WriteString(sBuff);
		sBuff.Format("%s\n", (LPCTSTR)sFields);
		pFile->WriteString(sBuff);
	}

	if(m_Result.m_nOutputParams || !sOutputParams.IsEmpty())
	{
		sBuff.Format("\n\t// RFX output param mapping");
		pFile->WriteString(sBuff);
		sBuff.Format("\n\tpFX->SetFieldType(CFieldExchange::outputParam);");
		pFile->WriteString(sBuff);
		sBuff.Format("%s\n", (LPCTSTR)sOutputParams);
		pFile->WriteString(sBuff);
	}

	if(m_Result.m_nInputParams)
	{
		sBuff.Format("\n\t// RFX input param mapping");
		pFile->WriteString(sBuff);
		sBuff.Format("\n\tpFX->SetFieldType(CFieldExchange::inputParam);");
		pFile->WriteString(sBuff);
		sBuff.Format("%s\n", (LPCTSTR)sInputParams);
		pFile->WriteString(sBuff);
	}		
	
	if(m_Result.m_nInputOutputParams)
	{
		sBuff.Format("\n\t// RFX input_output param mapping");
		pFile->WriteString(sBuff);
		sBuff.Format("\n\tpFX->SetFieldType(CFieldExchange::inoutParam);");
		pFile->WriteString(sBuff);
		sBuff.Format("%s\n", (LPCTSTR)sInputOutputParams);
		pFile->WriteString(sBuff);
	}

	if(!m_Result.m_nInputParams &&
	   !m_Result.m_nInputOutputParams &&
	   !m_Result.m_nOutputParams &&
	   !m_Result.m_nFields &&
	   !m_Result.m_nRet)
	{
		if(sBuff = "\n}")
			pFile->WriteString(sBuff);
	}
	else
	{
	 	sBuff = "}";
		pFile->WriteString(sBuff);
	}
}

void CGenerateClassDlg::WriteDiagnosticsStuff(CStdioFile* pFile)
{
	CString sBuff;
	sBuff.Format("\n\n/////////////////////////////////////////////////////////////////////////////\n// %s diagnostics", (LPCTSTR)m_strClassName);
	pFile->WriteString(sBuff);
	sBuff.Format("\n\n#ifdef _DEBUG");
	pFile->WriteString(sBuff);
	sBuff.Format("\nvoid %s::AssertValid() const\n{\n\tCRecordset::AssertValid();\n}", (LPCTSTR)m_strClassName);
	pFile->WriteString(sBuff);
	sBuff.Format("\n\nvoid %s::Dump(CDumpContext& dc) const\n{\n\tCRecordset::Dump(dc);\n}", (LPCTSTR)m_strClassName);
	pFile->WriteString(sBuff);
	sBuff.Format("\n#endif //_DEBUG");
	pFile->WriteString(sBuff);
}

void CGenerateClassDlg::WriteOpenMemberFunction(CStdioFile* pFile)
{
	CString sBuff;
	sBuff.Format("\n\nBOOL %s::Open(UINT nOpenType, LPCTSTR lpszSQL, DWORD dwOptions)\n{", (LPCTSTR)m_strClassName);
	pFile->WriteString(sBuff);
	sBuff.Format("\n\tASSERT(!IsOpen());");
	pFile->WriteString(sBuff);
	sBuff.Format("\n\tASSERT_VALID(this);");
	pFile->WriteString(sBuff);
	sBuff.Format("\n\tASSERT(lpszSQL == NULL || AfxIsValidString(lpszSQL));");
	pFile->WriteString(sBuff);
	sBuff.Format("\n\tASSERT(nOpenType == AFX_DB_USE_DEFAULT_TYPE || \n\t\tnOpenType == dynaset || nOpenType == snapshot || \n\t\tnOpenType == forwardOnly || nOpenType == dynamic);\n\tASSERT(!(dwOptions & readOnly && dwOptions & appendOnly));");
	pFile->WriteString(sBuff);
	sBuff.Format("\n\n\t// Can only use optimizeBulkAdd with appendOnly recordsets");
	pFile->WriteString(sBuff);
	sBuff.Format("\n\tASSERT((dwOptions & optimizeBulkAdd && dwOptions & appendOnly) || \n\t\t!(dwOptions & optimizeBulkAdd));");
	pFile->WriteString(sBuff);
	sBuff.Format("\n\n\t// forwardOnly recordsets have limited functionality");
	pFile->WriteString(sBuff);
	sBuff.Format("\n\tASSERT(!(nOpenType == forwardOnly && dwOptions & skipDeletedRecords));");
	pFile->WriteString(sBuff);
	sBuff.Format("\n\n\t// Cache state info and allocate hstmt");
	pFile->WriteString(sBuff);
	sBuff.Format("\n\tSetState(nOpenType, lpszSQL, dwOptions);");
	pFile->WriteString(sBuff);
	sBuff.Format("\n\tif(!AllocHstmt())\n\t\treturn FALSE;");
	pFile->WriteString(sBuff);
	sBuff.Format("\n\n\t// Check if bookmarks supported (CanBookmark depends on open DB)");
	pFile->WriteString(sBuff);
	sBuff.Format("\n\tASSERT(dwOptions & useBookmarks ? CanBookmark() : TRUE);");
	pFile->WriteString(sBuff);
	sBuff.Format("\n\n\tTRY");
	pFile->WriteString(sBuff);
	sBuff.Format("\n\t{\n\t\tOnSetOptions(m_hstmt);");
	pFile->WriteString(sBuff);
	sBuff.Format("\n\n\t\t// Allocate the field/param status arrays, if necessary");
	pFile->WriteString(sBuff);
	sBuff.Format("\n\t\tBOOL bUnbound = FALSE;");
	pFile->WriteString(sBuff);
	sBuff.Format("\n\t\tif (m_nFields > 0 || m_nParams > 0)");
	pFile->WriteString(sBuff);
	sBuff.Format("\n\t\t\tAllocStatusArrays();");
	pFile->WriteString(sBuff);
	sBuff.Format("\n\t\telse");
	pFile->WriteString(sBuff);
	sBuff.Format("\n\t\t\tbUnbound = TRUE;");
	pFile->WriteString(sBuff);
	sBuff.Format("\n\n\t\t// Build SQL and prep/execute or just execute direct");
	pFile->WriteString(sBuff);
	sBuff.Format("\n\t\tBuildSQL(lpszSQL);");
	pFile->WriteString(sBuff);
	sBuff.Format("\n\t\tPrepareAndExecute();");
	pFile->WriteString(sBuff);
	sBuff.Format("\n\n\t\t// Cache some field info and prepare the rowset");
	pFile->WriteString(sBuff);
	sBuff.Format("\n\t\tAllocAndCacheFieldInfo();");
	pFile->WriteString(sBuff);
	sBuff.Format("\n\t\tAllocRowset();");
	pFile->WriteString(sBuff);
	sBuff.Format("\n\n\t\t// If late binding, still need to allocate status arrays");
	pFile->WriteString(sBuff);	
	sBuff.Format("\n\t\tif (bUnbound && (m_nFields > 0 || m_nParams > 0))");
	pFile->WriteString(sBuff);	
	sBuff.Format("\n\t\t\tAllocStatusArrays();");
	pFile->WriteString(sBuff);
#ifdef _OVERRIDE_OPEN_
	if(m_Result.m_nFields)
	{
		sBuff.Format("\n\n\t\t// Fetch the first row of data");
		pFile->WriteString(sBuff);
		sBuff.Format("\n\t\tMoveNext();");
		pFile->WriteString(sBuff);
	}
#endif	
	sBuff.Format("\n\n\t\t// If EOF, then result set empty, so set BOF as well");
	pFile->WriteString(sBuff);	
	sBuff.Format("\n\t\tm_bBOF = m_bEOF;");
	pFile->WriteString(sBuff);	
	sBuff.Format("\n\t}");
	pFile->WriteString(sBuff);
	sBuff.Format("\n\tCATCH_ALL(e)");
	pFile->WriteString(sBuff);
	sBuff.Format("\n\t{");
	pFile->WriteString(sBuff);
	sBuff.Format("\n\t\tClose();");
	pFile->WriteString(sBuff);
	sBuff.Format("\n\t\tTHROW_LAST();");
	pFile->WriteString(sBuff);
	sBuff.Format("\n\t}");
	pFile->WriteString(sBuff);	
	sBuff.Format("\n\tEND_CATCH_ALL\n");
	pFile->WriteString(sBuff);
	sBuff.Format("\n\treturn TRUE;\n}");
	pFile->WriteString(sBuff);
}	 

void CGenerateClassDlg::WriteMoveMemberFunction(CStdioFile* pFile)
{
	CString sBuff;
	sBuff.Format("\n\nvoid %s::Move(long lRows, WORD wFetchType)\n{", (LPCTSTR)m_strClassName);
	pFile->WriteString(sBuff);
	sBuff.Format("\n\tm_bBOF = m_bEOF = TRUE; // By pass CRecordset\n}");
	pFile->WriteString(sBuff);
}	

void CGenerateClassDlg::WriteExecDirectMemberFunction(CStdioFile* pFile)
{
	CString sBuff;
	sBuff.Format("\n\nBOOL %s::ExecDirect()\n{", (LPCTSTR)m_strClassName);
	pFile->WriteString(sBuff);
	sBuff.Format("\n\treturn Open(CRecordset::forwardOnly, NULL, CRecordset::executeDirect);\n}");
	pFile->WriteString(sBuff);
}

BOOL CGenerateClassDlg::GenerateHFile()
{
	int nPos = m_strFileName.Find(".");
	
	CString sInterfaceFile = m_strFileName.Left(nPos) + ".h";
	
	CString sPathName;
	if(m_strDirectoryName.GetLength() == 3)
		sPathName.Format("%s%s", (LPCTSTR)m_strDirectoryName, (LPCTSTR)sInterfaceFile);
	else
		sPathName.Format("%s\\%s", (LPCTSTR)m_strDirectoryName, (LPCTSTR)sInterfaceFile);
	
	BOOL bRet = TRUE;

	CStdioFile file;
	CFileException fileException;
	CFileStatus status;
	if(file.GetStatus(sPathName, status))
	{
		CString s;
		s.Format("<%s> already exists. Replace existing file?", (LPCTSTR)sPathName);
		if(AfxMessageBox(s, MB_YESNO) == IDNO)
			bRet = FALSE;
	}
	
	if(bRet)
	{
		if(!file.Open(sPathName, CFile::typeText | 
					CFile::modeCreate | CFile::modeWrite, &fileException))
		{
			CString sMsg;
			sMsg.Format("File Path Name: <%s> ", (LPCTSTR)sPathName);
			sMsg += GetFileErrorMessage(fileException.m_cause);
			AfxMessageBox(sMsg);
			GetDlgItem(IDC_DIR_COMBO)->SetFocus();
			bRet = FALSE;
		}
	}
	
	if(bRet)
	{
		CString sBuff("");
		CString sMacro = sInterfaceFile;
		int nPos1 = sMacro.Find(".");
		sMacro.SetAt(nPos1, _T('_'));
		sMacro.MakeUpper();
		
		CString sGUID = GetGUID();

		if(sGUID.IsEmpty())
			sBuff.Format("#ifndef\t_%s_\n#define\t_%s_", (LPCTSTR)sMacro, (LPCTSTR)sMacro);
		else
		{
			sMacro += sGUID;
			sBuff.Format("#if !defined(SPCW_%s)\n#define SPCW_%s", (LPCTSTR)sMacro, (LPCTSTR)sMacro);
			TRACE("%s\n", (LPCTSTR)sBuff);
		}

		file.WriteString(sBuff);
		sBuff.Format("\n\n#if _MSC_VER >= 1000\n#pragma once\n#endif // _MSC_VER >= 1000");
		file.WriteString(sBuff);
		sBuff.Format("\n\n// %s : interface file\n//", (LPCTSTR)sInterfaceFile);
		file.WriteString(sBuff);
		sBuff.Format("\n\n/////////////////////////////////////////////////////////////////////////////\n// %s\n", (LPCTSTR)m_strClassName);
		file.WriteString(sBuff);
		sBuff.Format("\nclass %s : public CRecordset", (LPCTSTR)m_strClassName); 
		file.WriteString(sBuff);
		sBuff.Format("\n{");
		file.WriteString(sBuff);
		sBuff.Format("\npublic:");
		file.WriteString(sBuff);
		sBuff.Format("\n\t%s(CDatabase* pDatabase = NULL);", (LPCTSTR)m_strClassName); 
		file.WriteString(sBuff);
		sBuff.Format("\n\tDECLARE_DYNAMIC(%s)", (LPCTSTR)m_strClassName); 
		file.WriteString(sBuff);
				
		CString sFields("");
		CString sParams("");
		
		for(int i = 0; i < m_Result.m_nCount; i++)
		{
			CString sColName = GetResultSetString(i, 0);
			CString sVarName = GetValidatedColName(sColName);
			CString sColType = GetResultSetString(i, ID_COL_TYPE);
			CString sCPPType = GetResultSetString(i, ID_CPP_TYPE);

			if(sColType == _T("Return_Value"))
				sParams += "\n\t" + sCPPType + " m_" + sVarName + ";";

			if(sColType == _T("Param_Input") || sColType == _T("Param_Input_Output")
								|| sColType == _T("Param_Output"))
					sParams += "\n\t" + sCPPType + " m_" + sVarName + "Param;";

			if(sColType == _T("Result_Col"))
				sFields += "\n\t" + sCPPType + " m_" + sVarName + ";";
		}

		if(m_Result.m_nFields)
		{
			sBuff = "\n\n// Field data";
			file.WriteString(sBuff);
			sBuff.Format("%s", (LPCTSTR)sFields);
			file.WriteString(sBuff);
		}

		if(m_Result.m_nParams || !sParams.IsEmpty())
		{
			sBuff = "\n\n// Param data";
			file.WriteString(sBuff);
			
			if(!sParams.IsEmpty())
			{
				sBuff.Format("%s", (LPCTSTR)sParams);
				file.WriteString(sBuff);
			}
		}
		
		sBuff.Format("\n\n\tBOOL ExecDirect(); // For one time execution");
		file.WriteString(sBuff);

		sBuff.Format("\n\n// Overrides");
		file.WriteString(sBuff);
		sBuff.Format("\n\tvirtual CString GetDefaultConnect(); // Default connection string");
		file.WriteString(sBuff);
		sBuff.Format("\n\tvirtual CString GetDefaultSQL(); // Default SQL for Recordset");
		file.WriteString(sBuff);
		sBuff.Format("\n\tvirtual void DoFieldExchange(CFieldExchange* pFX); // RFX support");
		file.WriteString(sBuff);
		
		if(!m_Result.m_nFields)
		{
#ifdef _OVERRIDE_OPEN_			
			sBuff.Format("\n\tvirtual BOOL Open(UINT nOpenType = snapshot, LPCTSTR lpszSql = NULL, DWORD dwOptions = none);");
			file.WriteString(sBuff);
#endif
			sBuff.Format("\n\tvirtual void Move(long lRows, WORD wFetchType = SQL_FETCH_RELATIVE);");
			file.WriteString(sBuff);
		}

		sBuff.Format("\n\n// Implementation");
		file.WriteString(sBuff);
		sBuff.Format("\n#ifdef _DEBUG");
		file.WriteString(sBuff);
		sBuff.Format("\n\tvirtual void AssertValid() const;");
		file.WriteString(sBuff);
		sBuff.Format("\n\tvirtual void Dump(CDumpContext& dc) const;");
		file.WriteString(sBuff);
		sBuff.Format("\n#endif");
		file.WriteString(sBuff);
		sBuff.Format("\n};");
		file.WriteString(sBuff);
		
		if(sGUID.IsEmpty())
			sBuff.Format("\n\n#endif // _%s_", (LPCTSTR)sMacro);
		else
			sBuff.Format("\n\n#endif // !defined(SPCW_%s)", (LPCTSTR)sMacro);

		file.WriteString(sBuff);
	}

	return bRet;
}

CString& CGenerateClassDlg::GetClassName()
{
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();

	if(pFrame)
	{
		CSPWListView* pView = pFrame->GetSPListView();

		if(pView)
			m_strClassName = pView->GetListCtrl().GetItemText(pView->m_nSelectedItem, 0);
	}

	return m_strClassName;
}

void CGenerateClassDlg::OnProject() 
{
#ifdef _CHOOSE_DIR_DLG
	m_cbDir.GetWindowText(m_strDirectoryName);
	::SetCurrentDirectory(m_strDirectoryName);

	CChooseDirDlg dlg(FALSE, NULL, NULL, OFN_HIDEREADONLY |
                      OFN_OVERWRITEPROMPT | OFN_ENABLETEMPLATE, NULL, this);
    dlg.m_ofn.hInstance = AfxGetInstanceHandle();
    dlg.m_ofn.lpTemplateName = MAKEINTRESOURCE(FILEOPENORD);
    dlg.m_ofn.Flags &= ~OFN_EXPLORER;
	
	if(dlg.DoModal() == IDOK)
    {
		WORD wFileOffset;
		wFileOffset = dlg.m_ofn.nFileOffset;
		dlg.m_ofn.lpstrFile[wFileOffset-1]=0; // Nuke the "Junk"
		m_strDirectoryName = (LPSTR)dlg.m_ofn.lpstrFile;
		
		if(m_strDirectoryName.GetLength() == 2)
			m_strDirectoryName += _T("\\");

		m_cbDir.SetWindowText(m_strDirectoryName);
	}
#else
	CDirDialog dlg(this);
	
	dlg.m_strTitle = _T("Select the folder where you want to place the generated class files.");
	m_cbDir.GetWindowText(dlg.m_strSelDir);

	if(dlg.DoBrowse())
	{
		m_strDirectoryName = dlg.m_strPath;
		m_cbDir.SetWindowText(m_strDirectoryName);
	}
#endif
	UpdateData(FALSE);
}

CString CGenerateClassDlg::GetFileErrorMessage(const int& nCause)
{
	CString sBuff(_T("An unspecified error occurred."));
	
	switch(nCause)
	{
		case CFileException::fileNotFound:
			sBuff = _T("The file could not be located.");
			break;
		
		case CFileException::badPath:
			sBuff = _T("All or part of the path is invalid.");
			break;
		
		case CFileException::tooManyOpenFiles:
			sBuff = _T("The permitted number of open files was exceeded.");
			break;
		
		case CFileException::accessDenied:
			sBuff = _T("The file could not be accessed.");
			break;

		case CFileException::invalidFile:
			sBuff = _T("There was an attempt to use an invalid file handle.");
			break;
		
		case CFileException::removeCurrentDir:
			sBuff = _T("The current working directory cannot be removed.");
			break;
		
		case CFileException::directoryFull:
			sBuff = _T("There are no more directory entries.");
			break;
			
		case CFileException::badSeek:
			sBuff = _T("There was an error trying to set the file pointer.");
			break;
			
		case CFileException::hardIO:
			sBuff = _T("There was a hardware error.");
			break;

		case CFileException::sharingViolation:
			sBuff = _T("SHARE.EXE was not loaded, or a shared region was locked.");
			break;
			
		case CFileException::lockViolation:
			sBuff = _T("There was an attempt to lock a region that was already locked.");
			break;
			
		case CFileException::diskFull:
			sBuff = _T("The disk is full.");
			break;
		
		case CFileException::endOfFile:
			sBuff = _T("The end of file was reached."); 
			break;
	}

	return sBuff;
}

CString CGenerateClassDlg::GetResultSetString(const int& nItem, const int& nSubItem)
{
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	ASSERT(pFrame != NULL);
	
	CSPWResultSetView* pView = pFrame->GetSPResultSetView();
	ASSERT(pView != NULL);
	
	return pView->GetListCtrl().GetItemText(nItem, nSubItem);
}

void CGenerateClassDlg::GetResultSetInfo(Result& result)
{
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	ASSERT(pFrame != NULL);
	CSPWResultSetView* pView = pFrame->GetSPResultSetView();
	ASSERT(pView != NULL);
	
	result.m_nFields = pView->m_nFields;
	result.m_nParams = pView->m_nParams;
	result.m_nInputParams = pView->m_nInputParams;
	result.m_nInputOutputParams = pView->m_nInputOutputParams;
	result.m_nOutputParams = pView->m_nOutputParams;
	result.m_nRet = pView->m_nRet;
	result.m_nCount = pView->GetListCtrl().GetItemCount();
}

CString CGenerateClassDlg::GetValidatedColName(CString str)
{
	int nLength = str.GetLength();
	
	int nPos = -1;
		
	// Check for space characters
	for(int i = 0; i < nLength; i++)
	{
		nPos = str.Find(_T(' '));
		
		if(nPos != -1)
			str.SetAt(nPos, _T('_'));	
	}

	// For procs that has joins
	for(int j = 0; j < nLength; j++)
	{
		nPos = str.Find(_T('.'));
		
		if(nPos != -1)
			str.SetAt(nPos, _T('_'));	
	}
			
	// For SQL variables
	nPos = str.Find(_T("@"));

	if(nPos != -1)
		str.SetAt(nPos, _T(' '));
	
	str.TrimLeft(); str.TrimRight();
			
	// Length has changed. Recalculate it.
	nLength = str.GetLength(); 

	// Only letters, digits, and underscores are allowed
	for(int k = 0; k < nLength; k++)
	{
		TCHAR ch = str.GetAt(k);
		
		if(ch != '_')
		{
		 	if(!isalnum(ch))
			{
				nPos = str.Find(ch);
				if(nPos != -1)
					str.SetAt(nPos, _T('X'));
			}
		}				
	}
	
	TRACE("Validated Col Name: %s\n", (LPCTSTR)str);
		
	return str;
}

CString CGenerateClassDlg::GetGUID()
{
	CString sGUID(_T(""));

	GUID guid = GUID_NULL;
	
	::CoCreateGuid(&guid);
		
	if(guid != GUID_NULL)
	{
		sGUID.Format("__%08lX_%04X_%04x_%02X%02X_%02X%02X%02X%02X%02X%02X__INCLUDED_", 
			// first copy...
			guid.Data1, guid.Data2, guid.Data3, 
			guid.Data4[0], guid.Data4[1], guid.Data4[2], guid.Data4[3],
			guid.Data4[4], guid.Data4[5], guid.Data4[6], guid.Data4[7],
			// second copy...
			guid.Data1, guid.Data2, guid.Data3, 
			guid.Data4[0], guid.Data4[1], guid.Data4[2], guid.Data4[3],
			guid.Data4[4], guid.Data4[5], guid.Data4[6], guid.Data4[7]);

		sGUID.MakeUpper();
	}
	
	return sGUID;
}