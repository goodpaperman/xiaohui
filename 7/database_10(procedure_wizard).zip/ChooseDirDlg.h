#if !defined(AFX_CHOOSEDIRDLG_H__FBCE27C1_093A_11D1_B2B9_444553540000__INCLUDED_)
#define AFX_CHOOSEDIRDLG_H__FBCE27C1_093A_11D1_B2B9_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// ChooseDirDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CChooseDirDlg dialog

class CChooseDirDlg : public CFileDialog
{
// Construction
public:
	CChooseDirDlg(BOOL bOpenFileDialog, // TRUE for FileOpen, FALSE for FileSaveAs
               LPCSTR lpszDefExt = NULL,
               LPCSTR lpszFileName = NULL,
               DWORD dwFlags = OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
               LPCSTR lpszFilter = NULL,
               CWnd* pParentWnd = NULL);
     
protected:
   BOOL m_bDlgJustCameUp;

// Dialog Data
	//{{AFX_DATA(CChooseDirDlg)
	enum { IDD = 1536 }; // defined in dlgs.h
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChooseDirDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CChooseDirDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHOOSEDIRDLG_H__FBCE27C1_093A_11D1_B2B9_444553540000__INCLUDED_)