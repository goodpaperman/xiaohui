// SPWDoc.h : interface of the CSPWDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SPWDOC_H__AE3C436B_083C_11D1_B2B9_444553540000__INCLUDED_)
#define AFX_SPWDOC_H__AE3C436B_083C_11D1_B2B9_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CSPWDoc : public CDocument
{
protected: // create from serialization only
	CSPWDoc();
	DECLARE_DYNCREATE(CSPWDoc)

// Attributes
public:
	CString m_strDatabaseName;
	CDatabase m_database;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSPWDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CSPWDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CSPWDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SPWDOC_H__AE3C436B_083C_11D1_B2B9_444553540000__INCLUDED_)