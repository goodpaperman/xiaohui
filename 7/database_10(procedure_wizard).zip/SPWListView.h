// SPWListView.h : interface of the CSPWListView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SPWLISTVIEW_H__AE3C436D_083C_11D1_B2B9_444553540000__INCLUDED_)
#define AFX_SPWLISTVIEW_H__AE3C436D_083C_11D1_B2B9_444553540000__INCLUDED_

#include "SPWDoc.h"
#include "ListVwEx.h"

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CSPWListView : public CListViewEx
{
protected: // create from serialization only
	CSPWListView();
	DECLARE_DYNCREATE(CSPWListView)
	void UpdateSPWResultSetView();

// Attributes
public:
	CSPWDoc* GetDocument();

// Operations
public:
	BOOL Populate();
	int m_nSelectedItem;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSPWListView)
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CSPWListView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	BOOL PopulateMSSQLServerProcedures();
	BOOL PopulateSybaseSQLAnywhereProcedures(const CString& sSQL);
	//{{AFX_MSG(CSPWListView)
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnItemChanged(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDblclk(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnRclick(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnFileExecuteprocedure();
	afx_msg void OnFileGenerateCppClass();
	afx_msg void OnColumnClick(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	bool m_bSort;
};

#ifndef _DEBUG  // debug version in SPWListView.cpp
inline CSPWDoc* CSPWListView::GetDocument()
   { return (CSPWDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SPWLISTVIEW_H__AE3C436D_083C_11D1_B2B9_444553540000__INCLUDED_)