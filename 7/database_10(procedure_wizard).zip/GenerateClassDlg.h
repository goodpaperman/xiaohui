#if !defined(AFX_GENERATECLASSDLG_H__FBCE27C3_093A_11D1_B2B9_444553540000__INCLUDED_)
#define AFX_GENERATECLASSDLG_H__FBCE27C3_093A_11D1_B2B9_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// GenerateClassDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CGenerateClassDlg dialog

struct Result
{
	int m_nFields;
	int m_nParams;
	int m_nInputParams;
	int m_nInputOutputParams;
	int m_nOutputParams;
	int m_nCount;
	int m_nRet;
};

class CGenerateClassDlg : public CDialog
{
// Construction
public:
	CString GetValidatedColName(CString str);
	CGenerateClassDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CGenerateClassDlg();
	
// Dialog Data
	//{{AFX_DATA(CGenerateClassDlg)
	enum { IDD = IDD_GENERATE_CPP };
	CComboBox	m_cbDir;
	CString	m_strFileName;
	CString	m_strClassName;
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGenerateClassDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CString GetGUID();
	int m_nValuesToStore;

	Result m_Result;
	
	CString m_strDirectoryName;
	CString m_strOriginalDir;
	
	void GetResultSetInfo(Result& result);
	
	CString GetResultSetString(const int& nItem, const int& nSubItem);
	CString GetFileErrorMessage(const int& nCause);
	
	void WriteConstructor(CStdioFile* pFile);
	void WriteIntroStuff(CStdioFile* pFile);
	void WriteGetDefaultConnect(CStdioFile* pFile);
	void WriteGetDefaultSQL(CStdioFile* pFile);		
	void WriteDoFieldExchange(CStdioFile* pFile);
	void WriteOpenMemberFunction(CStdioFile* pFile);
	void WriteMoveMemberFunction(CStdioFile* pFile);
	void WriteExecDirectMemberFunction(CStdioFile* pFile);
	void WriteDiagnosticsStuff(CStdioFile* pFile);
	
	CString& GetClassName();
	
	BOOL GenerateCppFile();
	BOOL GenerateHFile();
	
	enum ColumnNames
	{
		ID_COL_NAME = 0,
		ID_COL_TYPE,
		ID_SQL_TYPE,
		ID_CPP_TYPE,
		ID_COL_LENGTH
	};
	
	// Generated message map functions
	//{{AFX_MSG(CGenerateClassDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnChangeClassName();
	virtual void OnOK();
	afx_msg void OnProject();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GENERATECLASSDLG_H__FBCE27C3_093A_11D1_B2B9_444553540000__INCLUDED_)