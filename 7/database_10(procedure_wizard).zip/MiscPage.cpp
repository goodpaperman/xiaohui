// MiscPage.cpp : implementation file
//

#include "stdafx.h"
#include "spw.h"
#include "MiscPage.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CSPWApp theApp;
/////////////////////////////////////////////////////////////////////////////
// CMiscPage property page

IMPLEMENT_DYNCREATE(CMiscPage, CPropertyPage)

CMiscPage::CMiscPage() : CPropertyPage(CMiscPage::IDD)
{
	//{{AFX_DATA_INIT(CMiscPage)
	m_bSSP = FALSE;
	//}}AFX_DATA_INIT
}

CMiscPage::~CMiscPage()
{
}

void CMiscPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMiscPage)
	DDX_Control(pDX, IDC_SSP, m_buttonSSP);
	DDX_Check(pDX, IDC_SSP, m_bSSP);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMiscPage, CPropertyPage)
	//{{AFX_MSG_MAP(CMiscPage)
	ON_BN_CLICKED(IDC_SSP, OnSsp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMiscPage message handlers

BOOL CMiscPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();

	if(pFrame->m_strDBMS.Find(pFrame->m_strSybaseSQLAW) != -1 ||
		pFrame->m_strDBMS.Find(pFrame->m_strSybaseASAAW) != -1)
	{
		m_bSSP = theApp.GetProfileInt(theApp.m_strSection, theApp.m_strSSP, 0);
		m_buttonSSP.SetCheck(m_bSSP);
	}
	else
		m_buttonSSP.EnableWindow(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CMiscPage::OnSsp() 
{
	m_bSSP = m_buttonSSP.GetCheck();	
}