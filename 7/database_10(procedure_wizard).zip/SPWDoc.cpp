// SPWDoc.cpp : implementation of the CSPWDoc class
//

#include "stdafx.h"
#include "SPW.h"
#include "SPWDoc.h"
#include "ReadMeEdit.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSPWDoc

IMPLEMENT_DYNCREATE(CSPWDoc, CDocument)

BEGIN_MESSAGE_MAP(CSPWDoc, CDocument)
	//{{AFX_MSG_MAP(CSPWDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSPWDoc construction/destruction

CSPWDoc::CSPWDoc()
{
	// TODO: add one-time construction code here
}

CSPWDoc::~CSPWDoc()
{
}

BOOL CSPWDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CSPWDoc serialization

void CSPWDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		
	}
	else
	{
		// TODO: add loading code here
		POSITION pos = GetFirstViewPosition();
		while(pos != NULL)	
		{
			CView* pView = GetNextView(pos);
			if(pView != NULL)
			{
				if(pView->IsKindOf(RUNTIME_CLASS(CReadMeEdit))) 
				{
					CReadMeEdit* pEdit = (CReadMeEdit*)pView;
					if(pEdit)
						pEdit->SerializeRaw(ar);
				}
			}
		}
	}
}

/////////////////////////////////////////////////////////////////////////////
// CSPWDoc diagnostics

#ifdef _DEBUG
void CSPWDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CSPWDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSPWDoc commands