// SybaseProcSet.cpp : implementation file
//

#include "stdafx.h"
#include "spw.h"
#include "SybaseProcSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSybaseProcSet

IMPLEMENT_DYNAMIC(CSybaseProcSet, CRecordset)

CSybaseProcSet::CSybaseProcSet(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CSybaseProcSet)
	m_name = _T("");
	//}}AFX_FIELD_INIT

	m_nFields = 1;
	
	m_nDefaultType = snapshot;
}


CString CSybaseProcSet::GetDefaultConnect()
{
	return _T("ODBC;");
}

CString CSybaseProcSet::GetDefaultSQL()
{
	return _T("Passed via open");
}

void CSybaseProcSet::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CSybaseProcSet)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Text(pFX, _T("[name]"), m_name);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CSybaseProcSet diagnostics

#ifdef _DEBUG
void CSybaseProcSet::AssertValid() const
{
	CRecordset::AssertValid();
}

void CSybaseProcSet::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG