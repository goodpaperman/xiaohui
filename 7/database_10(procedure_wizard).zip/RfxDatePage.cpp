// RfxDatePage.cpp : implementation file
//

#include "stdafx.h"
#include "spw.h"
#include "RfxDatePage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CSPWApp theApp;
/////////////////////////////////////////////////////////////////////////////
// CRfxDatePage property page

IMPLEMENT_DYNCREATE(CRfxDatePage, CPropertyPage)

CRfxDatePage::CRfxDatePage() : CPropertyPage(CRfxDatePage::IDD)
{
	//{{AFX_DATA_INIT(CRfxDatePage)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CRfxDatePage::~CRfxDatePage()
{
}

void CRfxDatePage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRfxDatePage)
	DDX_Control(pDX, IDC_TS_COMBO, m_comboTS);
	DDX_Control(pDX, IDC_TIME_COMBO, m_comboTime);
	DDX_Control(pDX, IDC_DATE_COMBO, m_comboDate);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRfxDatePage, CPropertyPage)
	//{{AFX_MSG_MAP(CRfxDatePage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRfxDatePage message handlers

BOOL CRfxDatePage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	CString sValue("");

	// Date
	sValue = theApp.GetProfileString(theApp.m_strSection, theApp.m_strRfxDateKey);
	sValue.TrimRight();	sValue.TrimLeft();
	
	if(sValue.IsEmpty())
		m_comboDate.SelectString(-1, "CString");
	else
		m_comboDate.SelectString(-1, sValue);
	
	// Time
	sValue = theApp.GetProfileString(theApp.m_strSection, theApp.m_strRfxTimeKey);
	sValue.TrimRight(); sValue.TrimLeft();
	
	if(sValue.IsEmpty())
		m_comboTime.SelectString(-1, "CString");
	else
		m_comboTime.SelectString(-1, sValue);
	
	// Time Stamp
	sValue = theApp.GetProfileString(theApp.m_strSection, theApp.m_strRfxTimeStampKey);
	sValue.TrimRight();	sValue.TrimLeft();
	
	if(sValue.IsEmpty())
		m_comboTS.SelectString(-1, "CString");
	else
		m_comboTS.SelectString(-1, sValue);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}