/////////////////////////////////////////////////////////////////////////////
// CStoredProcedureColumns - Implementation file

#include "stdafx.h"
#include "StoredProcedureColumns.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CStoredProcedureColumns

IMPLEMENT_DYNAMIC(CStoredProcedureColumns, CRecordset)

CStoredProcedureColumns::CStoredProcedureColumns(CDatabase* pDatabase)
	: CRecordset(pDatabase)
{
	m_strProcedureQualifier	= _T("");
	m_strProcedureOwner		= _T("");
	m_strProcedureName		= _T("");
	m_strColumnName			= _T("");
	m_fColumnType			= 0;
	m_nDataType				= 0;
	m_strTypeName			= _T("");
	m_nPrecision			= 0;
	m_nLength				= 0;
	m_nScale				= 0;
	m_nRadix				= 0;
	m_fNullable				= 0;
	m_strRemarks			= _T("");
	m_nFields = 13;
}

BOOL CStoredProcedureColumns::Open(LPCSTR pszProcQualifier,
	LPCSTR pszProcOwner,LPCSTR pszProcName,LPCSTR pszColumnName,
	UINT nOpenType)
{
	RETCODE	nRetCode;
	UWORD bFunctionExists;

	// Make sure SQLProcedureColumns exists
	AFX_SQL_SYNC(::SQLGetFunctions(m_pDatabase->m_hdbc,
		SQL_API_SQLPROCEDURECOLUMNS,&bFunctionExists));
	if(!Check(nRetCode) || !bFunctionExists)
	{
		if(!bFunctionExists)
			AfxMessageBox(_T("::SQLProcedureColumns not supported."));
		return FALSE;
	}

	// Cache stat info and allocate hstmt
	SetState(nOpenType, NULL, readOnly);
	if(!AllocHstmt())
		return FALSE;

	TRY
	{
		OnSetOptions(m_hstmt);
		AllocStatusArrays();

		// Call the ODBC function
		AFX_ODBC_CALL(::SQLProcedureColumns(m_hstmt,
			(UCHAR FAR*)pszProcQualifier,SQL_NTS,
			(UCHAR FAR*)pszProcOwner,SQL_NTS,
			(UCHAR FAR*)pszProcName,SQL_NTS,
			(UCHAR FAR*)pszColumnName,SQL_NTS));
		if (!Check(nRetCode))
			ThrowDBException(nRetCode,m_hstmt);
		
		// Allocate memory and cache info
		AllocAndCacheFieldInfo();
		AllocRowset();

		// Fetch the first row of data
		MoveNext();

		// If EOF, result set is empty, set BOF as well
		m_bBOF = m_bEOF;
	}
	CATCH_ALL(e)
	{
		Close();
		//e->ReportError();
		THROW_LAST();
	}
	END_CATCH_ALL

	return TRUE;
}

void CStoredProcedureColumns::DoFieldExchange(CFieldExchange* pFX)
{
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Text(pFX,_T("PROCEDURE_QUALIFIER"),m_strProcedureQualifier);
	RFX_Text(pFX,_T("PROCEDURE_OWNER"),m_strProcedureOwner);
	RFX_Text(pFX,_T("PROCEDURE_NAME"),m_strProcedureName);
	RFX_Text(pFX,_T("COLUMN_NAME"),m_strColumnName);
	RFX_Int(pFX,_T("COLUMN_TYPE"),m_fColumnType);
	RFX_Int(pFX,_T("DATA_TYPE"),m_nDataType);
	RFX_Text(pFX,_T("TYPE_NAME"),m_strTypeName);
	RFX_Long(pFX,_T("PRECISION"),m_nPrecision);
	RFX_Long(pFX,_T("LENGTH"),m_nLength);
	RFX_Int(pFX,_T("SCALE"),m_nScale);
	RFX_Int(pFX,_T("RADIX"),m_nRadix);
	RFX_Int(pFX,_T("NULLABLE"),m_fNullable);
	RFX_Text(pFX,_T("REMARKS"),m_strRemarks);
}

BOOL CStoredProcedureColumns::BindParameter(
						const int& nParamIndex, 
						const int& fColumnType,		// param type
						int& nSQLType,				// SQL data type
						const long& nColumnSize,	// precision
						const int& nScale,			// decimal digits
						const long nBufferLength,	// sizeof(value)
						const int& m_nParam)
{
	// Our purpose is to harvest the result_col info. So pass
	// some proxy values.
	long value = m_nParam;
	void* pValue = &value;
	m_strLen_or_IndPtr = 0;

// BEGIN_To be removed after the release of VC++ 6.0	
	if(nSQLType == SQL_WCHAR || nSQLType == SQL_WVARCHAR ||
		nSQLType == SQL_WLONGVARCHAR)
		nSQLType = SQL_VARCHAR;
// END_To be removed after the release of VC++ 6.0	

	int nDefaultSQL_C_Type = GetDefaultFieldType(nSQLType);
	
	// The following is required to avoid the exceptions:
	// Error in assignment
	// State:22005,Native:0,Origin:[Microsoft][ODBC SQL Server Driver]
	if(nSQLType == SQL_DECIMAL || nSQLType == SQL_NUMERIC)
		nDefaultSQL_C_Type = SQL_C_UTINYINT;
		
	// Numeric value out of range
	// State:22003,Native:0,Origin:[Microsoft][ODBC SQL Server Driver]
	if(nSQLType == SQL_REAL)
		nDefaultSQL_C_Type = SQL_C_STINYINT;
	
	if(nSQLType == SQL_TIMESTAMP)
	{
		// Proxy for datetime and smalldatetime param
		// datetime	- Jan 01, 1753 - Dec 31, 9999
		// smalldatetime - Jan 01, 1900 - Jun 06, 2079
		ts.year = 1900;
        ts.month = 12;
        ts.day = 31;
        ts.hour = 23;
        ts.minute = 59;
        ts.second = 59;
        ts.fraction = 0;
		pValue = &ts;
	}
	
	if(nSQLType == SQL_CHAR || nSQLType == SQL_VARCHAR)
	{
		int nLen = GetTextLen(nSQLType, nBufferLength);
		pValue = m_strString.GetBufferSetLength(nLen);
	}
			
	TRY
	{
		RETCODE nRetCode;

		// Call the ODBC function
		AFX_ODBC_CALL(::SQLBindParameter(
						m_hstmt,
						nParamIndex,
						fColumnType,
						nDefaultSQL_C_Type,
						nSQLType,
						nColumnSize,
						nScale,
						pValue,
						sizeof(pValue),
						&m_strLen_or_IndPtr));
			
		if(!Check(nRetCode))
			ThrowDBException(nRetCode, m_hstmt);
	}
	CATCH_ALL(e)
	{
		Close();
		THROW_LAST();
	}
	END_CATCH_ALL
	
	return TRUE;
}

BOOL CStoredProcedureColumns::ExecDirect(LPCSTR pszProcName)
{
	TRY
	{
		RETCODE nRetCode;
		
		// Call the ODBC function
		AFX_ODBC_CALL(::SQLExecDirect(m_hstmt,
			(UCHAR*)pszProcName, SQL_NTS));
				
		if(!Check(nRetCode))
			ThrowDBException(nRetCode, m_hstmt);
	}
	CATCH_ALL(e)
	{
		Close();
		THROW_LAST();
	}
	END_CATCH_ALL
	
	return TRUE;
}

SWORD CStoredProcedureColumns::GetNumResultCols()
{
	SWORD nCols = -1;

	TRY
	{
		RETCODE nRetCode;
		
		// Call the ODBC function
		AFX_ODBC_CALL(::SQLNumResultCols(m_hstmt, &nCols));
			
		if(!Check(nRetCode))
			ThrowDBException(nRetCode, m_hstmt);
	}
	CATCH_ALL(e)
	{
		Close();
		THROW_LAST();
	}
	END_CATCH_ALL
	
	return nCols;
}

BOOL CStoredProcedureColumns::GetResultColumnInfo(int nColNum, 
										ResultColumnInfo& result)
{
	UCHAR buffer[200];
	short NameLength;
	short DataType;
	unsigned long ColumnSize;
	short DecimalDigits;
	short Nullable;

	TRY
	{
		RETCODE nRetCode;
		
		// Call the ODBC function
		AFX_ODBC_CALL(::SQLDescribeCol(m_hstmt, nColNum,
			buffer, 200, &NameLength, &DataType, &ColumnSize,
					 &DecimalDigits, &Nullable));

		if(!Check(nRetCode))
			ThrowDBException(nRetCode, m_hstmt);
	}
	CATCH_ALL(e)
	{
		Close();
		THROW_LAST();
	}
	END_CATCH_ALL
		
	result.sColumnName = buffer;
	result.DataType = DataType;
	result.ColumnSize =	ColumnSize;
	result.Nullable = Nullable;
	
	return TRUE;
}

CString CStoredProcedureColumns::GetDefaultConnect()
{ 
	return _T("ODBC;");
}

CString CStoredProcedureColumns::GetDefaultSQL()
{ 
	return "!"; // Direct ODBC call
}

/////////////////////////////////////////////////////////////////////////////
// CStoredProcedureColumns diagnostics

#ifdef _DEBUG
void CStoredProcedureColumns::AssertValid() const
{
	CRecordset::AssertValid();
}

void CStoredProcedureColumns::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG