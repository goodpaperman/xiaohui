// OptionsSheet.cpp : implementation file
//

#include "stdafx.h"
#include "spw.h"
#include "OptionsSheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CSPWApp theApp;
/////////////////////////////////////////////////////////////////////////////
// COptionsSheet

IMPLEMENT_DYNAMIC(COptionsSheet, CPropertySheet)

COptionsSheet::COptionsSheet(UINT nIDCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(nIDCaption, pParentWnd, iSelectPage)
{
}

COptionsSheet::COptionsSheet(LPCTSTR pszCaption, CWnd* pParentWnd, UINT iSelectPage)
	:CPropertySheet(pszCaption, pParentWnd, iSelectPage)
{
	AddPage(&m_pageRfxDate);
	AddPage(&m_pageMisc);
}

COptionsSheet::~COptionsSheet()
{
}


BEGIN_MESSAGE_MAP(COptionsSheet, CPropertySheet)
	//{{AFX_MSG_MAP(COptionsSheet)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	ON_BN_CLICKED(IDOK, OnOK)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COptionsSheet message handlers

BOOL COptionsSheet::OnInitDialog() 
{
	BOOL bResult = CPropertySheet::OnInitDialog();
	
	CWnd* pWnd = GetDlgItem(ID_APPLY_NOW);
	CRect rectApplyNow;
	pWnd->GetWindowRect(rectApplyNow);
	ScreenToClient(&rectApplyNow);
	pWnd->ShowWindow(SW_HIDE);
	
	pWnd = GetDlgItem(IDCANCEL);
	CRect rectCancel;
	pWnd->GetWindowRect(rectCancel);
	ScreenToClient(&rectCancel);
	pWnd->MoveWindow(rectApplyNow.left, rectApplyNow.top, rectApplyNow.Width(),
						rectApplyNow.Height());
	
	GetDlgItem(IDOK)->MoveWindow(rectCancel.left, rectCancel.top, rectCancel.Width(),
						rectCancel.Height());
	return bResult;
}

void COptionsSheet::OnOK()
{
	CWaitCursor wait;

	UpdateData(TRUE);

	CString sValue;
	
	// Date
	m_pageRfxDate.m_comboDate.GetWindowText(sValue);
	theApp.WriteProfileString(theApp.m_strSection, theApp.m_strRfxDateKey, sValue);

	// Time
	m_pageRfxDate.m_comboTime.GetWindowText(sValue);
	theApp.WriteProfileString(theApp.m_strSection, theApp.m_strRfxTimeKey, sValue);

	// Time Stamp
	m_pageRfxDate.m_comboTS.GetWindowText(sValue);
	theApp.WriteProfileString(theApp.m_strSection, theApp.m_strRfxTimeStampKey, sValue);
	
	// Show system procedures
	theApp.WriteProfileInt(theApp.m_strSection, theApp.m_strSSP, m_pageMisc.m_bSSP);
	
	EndDialog(IDOK);
}