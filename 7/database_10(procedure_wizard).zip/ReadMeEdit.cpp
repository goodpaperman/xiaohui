// ReadMeEdit.cpp : implementation file
//

#include "stdafx.h"
#include "SPW.h"
#include "ReadMeEdit.h"
#include "MainFrm.h"
#include "SPWDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CReadMeEdit

IMPLEMENT_DYNCREATE(CReadMeEdit, CEditView)

CReadMeEdit::CReadMeEdit()
{
}

CReadMeEdit::~CReadMeEdit()
{
}


BEGIN_MESSAGE_MAP(CReadMeEdit, CEditView)
	//{{AFX_MSG_MAP(CReadMeEdit)
	ON_COMMAND(ID_FILE_PRINT, OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, OnFilePrintPreview)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CReadMeEdit drawing

void CReadMeEdit::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// CReadMeEdit diagnostics

#ifdef _DEBUG
void CReadMeEdit::AssertValid() const
{
	CEditView::AssertValid();
}

void CReadMeEdit::Dump(CDumpContext& dc) const
{
	CEditView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CReadMeEdit message handlers

void CReadMeEdit::OnInitialUpdate() 
{
	CWaitCursor wait;

	CEditView::OnInitialUpdate();

	GetEditCtrl().SetReadOnly();

	OpenReadMeTxt();
}

void CReadMeEdit::OpenReadMeTxt()
{
	CWaitCursor wait;

	CMainFrame* pFrame = (CMainFrame*)GetParentFrame();
	
	if(pFrame)
	{
		CSPWDoc* pDoc = (CSPWDoc*)pFrame->GetActiveDocument();
		
		if(pDoc)
		{	
			// Get the current working directory
			CString sBuff;
			::GetCurrentDirectory(256, sBuff.GetBuffer(256));
			sBuff.ReleaseBuffer();

			CString str;
			str.Format("%s\\Readme.txt", (LPCTSTR)sBuff);
						
			CFileFind find;
			if(find.FindFile(str))
				pDoc->OnOpenDocument(str);
			else
			{
				CString sMsg = _T("Readme.txt not found in the current working directory.");
				GetEditCtrl().SetWindowText(sMsg);
			}
		}
	}
}

void CReadMeEdit::OnFilePrint() 
{
	CWaitCursor wait;
	CEditView::OnFilePrint();
}

void CReadMeEdit::OnFilePrintPreview() 
{
	CWaitCursor wait;
	CEditView::OnFilePrintPreview();
}