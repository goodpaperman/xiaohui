// CStoredProcedureColumns - Interface file

/////////////////////////////////////////////////////////////////////////////
// CStoredProcedureColumns - results from ::SQLProcedureColumns

#ifndef _STORED_PROCEDURE_COLUMNS_H
#define _STORED_PROCEDURE_COLUMNS_H

struct ResultColumnInfo
{
	CString sColumnName;
	short DataType;
	unsigned long ColumnSize;
	short DecimalDigits;
	short Nullable;
};

class CStoredProcedureColumns : public CRecordset
{
public:
	CStoredProcedureColumns(CDatabase* pDatabase);
	DECLARE_DYNAMIC(CStoredProcedureColumns)

// Field Data
	CString	m_strProcedureQualifier;
	CString	m_strProcedureOwner;
	CString	m_strProcedureName;
	CString	m_strColumnName;
	int		m_fColumnType;
	int		m_nDataType;
	CString	m_strTypeName;
	long	m_nPrecision;
	long	m_nLength;
	int		m_nScale;
	int		m_nRadix;
	int		m_fNullable;
	CString	m_strRemarks;
				
// Operations
	BOOL Open(LPCSTR pszProcQualifier = NULL,
				LPCSTR pszProcOwner = NULL,
				LPCSTR pszProcName = NULL,
				LPCSTR pszColumnName = NULL,
				UINT nOpenType = AFX_DB_USE_DEFAULT_TYPE);

	BOOL BindParameter(
					const int& nParamIndex, 
					const int& fColumnType,		// param type
					int& nSQLType,				// SQL data type
					const long& nColumnSize,	// precision
					const int& nScale,			// decimal digits
					const long nBufferLength,	// sizeof(value)
					const int& m_nParam
					);
	
	BOOL ExecDirect(LPCSTR pszProcName);
	SWORD GetNumResultCols();
	BOOL GetResultColumnInfo(int nColumnNum, ResultColumnInfo& result);

// Overrides
	virtual CString GetDefaultConnect();
	virtual CString GetDefaultSQL();
	virtual void DoFieldExchange(CFieldExchange*);

protected:
	long m_strLen_or_IndPtr;
	TIMESTAMP_STRUCT ts;
	CString m_strString;

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

#endif // end if _STORED_PROCEDURE_COLUMNS_H