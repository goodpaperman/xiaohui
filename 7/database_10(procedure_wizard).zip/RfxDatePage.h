#if !defined(AFX_RFXDATEPAGE_H__BE382446_1069_11D2_BB75_204C4F4F5020__INCLUDED_)
#define AFX_RFXDATEPAGE_H__BE382446_1069_11D2_BB75_204C4F4F5020__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// RfxDatePage.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CRfxDatePage dialog

class CRfxDatePage : public CPropertyPage
{
	DECLARE_DYNCREATE(CRfxDatePage)

// Construction
public:
	CRfxDatePage();
	~CRfxDatePage();

// Dialog Data
	//{{AFX_DATA(CRfxDatePage)
	enum { IDD = IDD_RFX_DATE };
	CComboBox	m_comboTS;
	CComboBox	m_comboTime;
	CComboBox	m_comboDate;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CRfxDatePage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CRfxDatePage)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RFXDATEPAGE_H__BE382446_1069_11D2_BB75_204C4F4F5020__INCLUDED_)