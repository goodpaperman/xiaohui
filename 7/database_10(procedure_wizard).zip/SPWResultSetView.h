#if !defined(AFX_SPWRESULTSETVIEW_H__AE3C4376_083C_11D1_B2B9_444553540000__INCLUDED_)
#define AFX_SPWRESULTSETVIEW_H__AE3C4376_083C_11D1_B2B9_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// SPWResultSetView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSPWResultSetView view

#include "ListVwEx.h"
#include "SPWListView.h"

class CParamInfo : public CObject
{
public:	
	int	m_fColumnType;
	int	m_nDataType;
	long m_nPrecision;
	long m_nLength;
	int	m_nScale;
};	

class CSPWResultSetView : public CListViewEx
{
protected:
	CSPWResultSetView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CSPWResultSetView)
	
	CString GetColumnType(const int& nColumnType);
	CString GetCPPType(const int& nSQLDataType, const BOOL& bSQLTypeAsString = FALSE);

	BOOL Insert(CString sRow, const int& nIndex);
	
	int m_nSelectedItem;
	int nIndex;

	void InitializeResultSetInfo();
	CObList m_listParamInfo;
	void CleanUpParamInfoList();

// Attributes
public:
	CString m_strResultSetInfo;
	CString m_strProcedureName;

// Operations
public:
	BOOL PopulateSybaseSQLAnywhere();
	BOOL PopulateMicrosoftSQLServer();
	BOOL ExecuteProcedure();

	int m_nFields;
	int m_nParams; // Total no. of params
	
	// Used for writing DoFieldExchange member function
	int m_nInputParams;
	int m_nInputOutputParams;
	int m_nOutputParams;
	int m_nRet;
		
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSPWResultSetView)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CSPWResultSetView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CSPWResultSetView)
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnItemchanging(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeleteallitems(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SPWRESULTSETVIEW_H__AE3C4376_083C_11D1_B2B9_444553540000__INCLUDED_)