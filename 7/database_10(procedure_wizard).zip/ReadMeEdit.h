#if !defined(AFX_READMEEDIT_H__AE3C4375_083C_11D1_B2B9_444553540000__INCLUDED_)
#define AFX_READMEEDIT_H__AE3C4375_083C_11D1_B2B9_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// ReadMeEdit.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CReadMeEdit view

class CReadMeEdit : public CEditView
{
protected:
	CReadMeEdit();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CReadMeEdit)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CReadMeEdit)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CReadMeEdit();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
public:
	void OpenReadMeTxt();
	//{{AFX_MSG(CReadMeEdit)
	afx_msg void OnFilePrint();
	afx_msg void OnFilePrintPreview();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

protected:
	HBRUSH m_hBrush;
	CFont m_font;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_READMEEDIT_H__AE3C4375_083C_11D1_B2B9_444553540000__INCLUDED_)