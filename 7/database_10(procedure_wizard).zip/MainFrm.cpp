// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "SPW.h"
#include "MainFrm.h"
#include "GenerateClassDlg.h"
#include "OptionsSheet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CSPWApp theApp;
/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_COMMAND(ID_FILE_GENERATE_CPP_CLASS, OnFileGenerateCppClass)
	ON_COMMAND(ID_VIEW_REFRESH, OnViewRefresh)
	ON_COMMAND(ID_FILE_PRINT, OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, OnFilePrintPreview)
	ON_UPDATE_COMMAND_UI(ID_FILE_GENERATE_CPP_CLASS, OnUpdateFileGenerateCppClass)
	ON_COMMAND(ID_FILE_CONNECT, OnFileConnect)
	ON_COMMAND(ID_FILE_DISCONNECT, OnFileDisconnect)
	ON_UPDATE_COMMAND_UI(ID_FILE_DISCONNECT, OnUpdateFileDisconnect)
	ON_UPDATE_COMMAND_UI(ID_FILE_CONNECT, OnUpdateFileConnect)
	ON_UPDATE_COMMAND_UI(ID_VIEW_REFRESH, OnUpdateViewRefresh)
	ON_COMMAND(ID_VIEW_OPTIONS, OnViewOptions)
	ON_COMMAND(ID_FILE_EXECUTEPROCEDURE, OnFileExecuteProcedure)
	ON_UPDATE_COMMAND_UI(ID_FILE_EXECUTEPROCEDURE, OnUpdateFileExecuteProcedure)
	ON_UPDATE_COMMAND_UI(ID_VIEW_OPTIONS, OnUpdateViewOptions)
	ON_WM_SIZE()
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
	ON_UPDATE_COMMAND_UI(ID_INDICATOR_RESULT_SET, OnUpdateIndicatorResultSetInfo)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_RESULT_SET,
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	m_bRefresh = FALSE;
	
	m_strSybaseSQLServer = _T("SQL SERVER");
	m_strMSSQLServer = _T("MICROSOFT SQL SERVER");
	m_strSybaseSQLAW = _T("SYBASE SQL ANYWHERE");
	m_strSybaseASAAW = _T("ADAPTIVE SERVER ANYWHERE"); 
	
	m_bOKToSize = FALSE;
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if(CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if(!m_wndToolBar.Create(this) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if(!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Remove this if you don't want tool tips or a resizeable toolbar
	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);

	m_wndToolBar.ModifyStyle(0, TBSTYLE_FLAT);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	cs.style = WS_OVERLAPPED | WS_CAPTION | /*FWS_ADDTOTITLE
		|*/ WS_THICKFRAME | WS_SYSMENU | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_MAXIMIZE;
	
	return CFrameWnd::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext) 
{
	if(!m_wndSplitter.CreateStatic(this, 2, 1))
	{
		TRACE0("Failed to CreateStaticSplitter\n");
		return FALSE;
	}
 		
	if(!m_wndSplitter.CreateView(1, 0,
		RUNTIME_CLASS(CSPWResultSetView), CSize(0, 0), pContext))
	{
		TRACE0("Failed to create first pane\n");
		return FALSE;
	}
		
	if(!m_wndSplitter2.CreateStatic(&m_wndSplitter, 1, 2, WS_CHILD | WS_VISIBLE,
											m_wndSplitter.IdFromRowCol(0, 0)))
	{
		TRACE0("Failed to create nested splitter\n");
		return FALSE;
	}

	if(!m_wndSplitter2.CreateView(0, 1,
		RUNTIME_CLASS(CReadMeEdit), CSize(0, 0), pContext))
	{
		TRACE0("Failed to create second pane\n");
		return FALSE;
	}
	
	CRect rect;
	GetWindowRect(&rect);
	CSize size = rect.Size();
	size.cx = size.cx/2;
	size.cy = size.cy/3;

	if(!m_wndSplitter2.CreateView(0, 0,
		RUNTIME_CLASS(CSPWListView), size, pContext))
	{
		TRACE0("Failed to create third pane\n");
		return FALSE;
	}
	
	SizeSplitter(rect);

	CSPWListView* pView = GetSPListView();
	
	if(pView)
		pView->SetFocus();

	m_bOKToSize = TRUE;
	
	return TRUE;
}

void CMainFrame::OnFileConnect() 
{
	CWaitCursor wait;
	
	CSPWDoc* pDoc = (CSPWDoc*)GetActiveDocument();
	
	if(pDoc)
	{
		BOOL bOpen = FALSE;
		BOOL bCaughtException = FALSE;
		
		try
		{	
			pDoc->m_database.SetLoginTimeout(0);
			bOpen = pDoc->m_database.Open(NULL, FALSE, TRUE, "ODBC;");
			if(bOpen)
				pDoc->m_database.SetQueryTimeout(0);
		}
		catch(CDBException* e)
		{
		   if(e)
		   {
			   e->ReportError(MB_ICONEXCLAMATION);
			   e->Delete();
		   }

		   bCaughtException = TRUE;
		}
		catch(CMemoryException* e)
		{
		   if(e)
		   {
			   e->ReportError(MB_ICONEXCLAMATION);
			   e->Delete();
		   }

		   bCaughtException = TRUE;
		}
	
		if(bOpen && !bCaughtException)
		{
			if(IsDBMSSupported())
			{
				pDoc->m_strDatabaseName = pDoc->m_database.GetDatabaseName();

				if(!pDoc->m_strDatabaseName.IsEmpty())
				{
					CString strTitle, strBuff;
					strBuff.LoadString(AFX_IDS_APP_TITLE);
					strTitle.Format("%s - %s", (LPCTSTR)pDoc->m_strDatabaseName,
										(LPCTSTR)strBuff);
					SetWindowText(strTitle);
				}
				
				CSPWListView* pView = GetSPListView();
				
				if(pView)
				{
					if(!pView->Populate())
						pView->GetListCtrl().DeleteAllItems();
					else
						pView->GetListCtrl().SetItemState(pView->m_nSelectedItem,
							LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
				
				} // End if(pView)
			
			} // End if(IsDBMSSupported()
		
		} // End if(bOpen && !bCaughtException)
	
	} //End if(pDoc)
}

void CMainFrame::OnFileDisconnect() 
{
	CWaitCursor wait;

	CSPWDoc* pDoc = (CSPWDoc*)GetActiveDocument();
	
	if(pDoc)
	{
		if(pDoc->m_database.IsOpen())
		{
			pDoc->m_database.Close();
					
			CString strBuff;
			strBuff.LoadString(AFX_IDS_APP_TITLE);
			SetWindowText(strBuff);
			
			CSPWResultSetView* pSetView = GetSPResultSetView();
			
			if(pSetView)
				pSetView->GetListCtrl().DeleteAllItems();
			
			CSPWListView* pView = GetSPListView();
			
			if(pView)
				pView->GetListCtrl().DeleteAllItems();
		}
	}
}

void CMainFrame::OnFileGenerateCppClass() 
{
	CGenerateClassDlg dlg;
	dlg.DoModal();
}

void CMainFrame::OnFileExecuteProcedure() 
{
	CWaitCursor wait;
	
	CSPWResultSetView* pView = GetSPResultSetView();
	
	if(pView)
		pView->ExecuteProcedure();
}

void CMainFrame::OnFilePrint() 
{
	CWaitCursor wait;
	
	CReadMeEdit* pView = GetReadMeEditView();
	
	if(pView)
		pView->OnFilePrint();
}

void CMainFrame::OnFilePrintPreview() 
{
	CWaitCursor wait;
	
	CReadMeEdit* pView = GetReadMeEditView();
	
	if(pView)
		pView->OnFilePrintPreview();
}

void CMainFrame::OnViewRefresh() 
{
	CWaitCursor wait;
		
	m_bRefresh = TRUE;
	
	CSPWListView* pView = GetSPListView();
	
	if(pView)
	{
		if(!pView->Populate())
		{
			pView->GetListCtrl().DeleteAllItems();
			GetSPResultSetView()->GetListCtrl().DeleteAllItems();
		}
	}
	
	m_bRefresh = FALSE;
}

void CMainFrame::OnViewOptions() 
{
	CWaitCursor wait;

	COptionsSheet sheet("Options");
	
	if(sheet.DoModal() == IDOK)
	{
		CSPWDoc* pDoc = (CSPWDoc*)GetActiveDocument();
	
		if(pDoc)
		{
			if(pDoc->m_database.IsOpen())
				OnViewRefresh();
		}
	}
}

void CMainFrame::OnUpdateFileConnect(CCmdUI* pCmdUI) 
{
	CSPWDoc* pDoc = (CSPWDoc*)GetActiveDocument();
	
	if(pDoc)
		pCmdUI->Enable(!pDoc->m_database.IsOpen());
}

void CMainFrame::OnUpdateFileDisconnect(CCmdUI* pCmdUI) 
{
	CSPWDoc* pDoc = (CSPWDoc*)GetActiveDocument();
	
	if(pDoc)
		pCmdUI->Enable(pDoc->m_database.IsOpen());
}

void CMainFrame::OnUpdateFileExecuteProcedure(CCmdUI* pCmdUI) 
{
	CSPWListView* pView = GetSPListView();
	if(pView)
		pCmdUI->Enable((m_strDBMS.Find(m_strMSSQLServer) != -1 ||
			m_strDBMS.Find(m_strSybaseSQLServer) != -1) &&
			pView->GetListCtrl().GetItemCount());
}

void CMainFrame::OnUpdateFileGenerateCppClass(CCmdUI* pCmdUI) 
{
	CSPWListView* pView = GetSPListView();

	if(pView)
		pCmdUI->Enable(pView->GetListCtrl().GetItemCount());
}

void CMainFrame::OnUpdateViewRefresh(CCmdUI* pCmdUI) 
{
	CSPWDoc* pDoc = (CSPWDoc*)GetActiveDocument();
	
	if(pDoc)
		pCmdUI->Enable(pDoc->m_database.IsOpen());
}

void CMainFrame::SetResultSetInfo(const CString& str)
{
	HGDIOBJ hOldFont = NULL;
	HFONT hFont = (HFONT)m_wndStatusBar.SendMessage(WM_GETFONT);
	
	CClientDC dc(NULL);
	
	if(hFont != NULL) 
		hOldFont = dc.SelectObject(hFont);
	
	CSize size;
	size = dc.GetTextExtent(str);
	
	if(hOldFont != NULL) 
		dc.SelectObject(hOldFont);

	UINT nID, nStyle;
	int nWidth;
	m_wndStatusBar.GetPaneInfo(1, nID, nStyle, nWidth);
	m_wndStatusBar.SetPaneInfo(1, nID, nStyle, size.cx);
	m_wndStatusBar.SetPaneText(1, str);
}

void CMainFrame::OnUpdateIndicatorResultSetInfo(CCmdUI* pCmdUI)
{
	CSPWResultSetView* pSetView = GetSPResultSetView();

	if(pSetView)
	{
		if(!GetSPListView()->GetListCtrl().GetItemCount())
			pSetView->m_strResultSetInfo.LoadString(ID_INDICATOR_RESULT_SET);

		SetResultSetInfo(pSetView->m_strResultSetInfo);
	}
}

CSPWListView* CMainFrame::GetSPListView()
{
	CWnd* pWnd = m_wndSplitter2.GetPane(0, 0);
	
	CSPWListView* pView = NULL;

	if(pWnd)
		pView = (CSPWListView*)pWnd;

	return pView;
}

CSPWResultSetView* CMainFrame::GetSPResultSetView()
{
	CWnd* pWnd = m_wndSplitter.GetPane(1, 0);
	
	CSPWResultSetView* pView = NULL;

	if(pWnd)
		pView = (CSPWResultSetView*)pWnd;

	return pView;
}

CReadMeEdit* CMainFrame::GetReadMeEditView()
{
	CWnd* pWnd = m_wndSplitter2.GetPane(0, 1);
	
	CReadMeEdit* pView = NULL;

	if(pWnd)
		pView = (CReadMeEdit*)pWnd;

	return pView;
}

BOOL CMainFrame::IsDBMSSupported()
{
	UCHAR	buffer[200];
	SWORD	cbData;
	BOOL bYes = FALSE;

	CSPWDoc* pDoc = (CSPWDoc*)GetActiveDocument();
	if(pDoc)
	{
		::SQLGetInfo(pDoc->m_database.m_hdbc, SQL_DBMS_NAME,
			(PTR)buffer, 200, &cbData);
		m_strDBMS = buffer;
		m_strDBMS.MakeUpper();

		::SQLGetInfo(pDoc->m_database.m_hdbc, SQL_DATA_SOURCE_NAME,
			(PTR)buffer, 200, &cbData);
		CString sDSN = buffer;

		// Supported DBMS
		if(m_strDBMS.Find(m_strSybaseSQLServer) != -1 ||
			m_strDBMS.Find(m_strMSSQLServer) != -1 || 
			m_strDBMS.Find(m_strSybaseSQLAW) != -1 ||
			m_strDBMS.Find(m_strSybaseASAAW) != -1)
			bYes = TRUE;
		
		if(!bYes)
		{
			OnFileDisconnect();

			CString strMsg;
			strMsg.Format(
				"DSN: %s; DBMS: %s\nCurrently SPCW supports MS SQL Server, Sybase SQL Server, Sybase SQL Anywhere, and\nAdaptive Server Anywhere only.",
				(LPCTSTR)sDSN, (LPCTSTR)m_strDBMS
				);
			::MessageBeep(MB_ICONEXCLAMATION);
			AfxMessageBox(strMsg);
		}
	}
		
	return bYes;
}

void CMainFrame::OnUpdateViewOptions(CCmdUI* pCmdUI) 
{
	CSPWDoc* pDoc = (CSPWDoc*)GetActiveDocument();
	
	if(pDoc)
		pCmdUI->Enable(pDoc->m_database.IsOpen());
}

void CMainFrame::OnSize(UINT nType, int cx, int cy) 
{
	if(m_bOKToSize)
	{
		CRect rect;
		GetWindowRect(&rect);
		SizeSplitter(rect);
	}
	
	CFrameWnd::OnSize(nType, cx, cy);	
}

/////////////////////////////////////////////////////////////////////////////
// Helpers for saving/restoring window state

static TCHAR BASED_CODE szSection[] = _T("Settings");
static TCHAR BASED_CODE szWindowPos[] = _T("WindowPos");
static TCHAR szFormat[] = _T("%u,%u,%d,%d,%d,%d,%d,%d,%d,%d");

static BOOL PASCAL NEAR ReadWindowPlacement(LPWINDOWPLACEMENT pwp)
{
	CString strBuffer = AfxGetApp()->GetProfileString(szSection, szWindowPos);

	if(strBuffer.IsEmpty())
		return FALSE;

	WINDOWPLACEMENT wp;
	int nRead = _stscanf(strBuffer, szFormat,
		&wp.flags, &wp.showCmd,
		&wp.ptMinPosition.x, &wp.ptMinPosition.y,
		&wp.ptMaxPosition.x, &wp.ptMaxPosition.y,
		&wp.rcNormalPosition.left, &wp.rcNormalPosition.top,
		&wp.rcNormalPosition.right, &wp.rcNormalPosition.bottom);

	if(nRead != 10)
		return FALSE;

	wp.length = sizeof(wp);
	*pwp = wp;
	
	return TRUE;
}

static void PASCAL NEAR WriteWindowPlacement(LPWINDOWPLACEMENT pwp)
{
	TCHAR szBuffer[sizeof("-32767")*8 + sizeof("65535")*2];

	wsprintf(szBuffer, szFormat,
		pwp->flags, pwp->showCmd,
		pwp->ptMinPosition.x, pwp->ptMinPosition.y,
		pwp->ptMaxPosition.x, pwp->ptMaxPosition.y,
		pwp->rcNormalPosition.left, pwp->rcNormalPosition.top,
		pwp->rcNormalPosition.right, pwp->rcNormalPosition.bottom);
	
	AfxGetApp()->WriteProfileString(szSection, szWindowPos, szBuffer);
}

/////////////////////////////////////////////////////////////////////////////

void CMainFrame::InitialShowWindow(UINT nCmdShow)
{
	WINDOWPLACEMENT wp;
	if(!ReadWindowPlacement(&wp))
		CenterWindow();
	else
	{
		if(nCmdShow != SW_SHOWNORMAL) 
			wp.showCmd = nCmdShow;
		else
			nCmdShow = wp.showCmd;

		SetWindowPlacement(&wp);
	}
	
	ShowWindow(nCmdShow);
	UpdateWindow();
}

void CMainFrame::OnClose() 
{
	WINDOWPLACEMENT wp;
	wp.length = sizeof(wp);
	if(GetWindowPlacement(&wp))
	{
		wp.flags = 0;
	
		if(IsZoomed())
			wp.flags |= WPF_RESTORETOMAXIMIZED;
		
		if(wp.showCmd != SW_SHOWMINIMIZED)
			WriteWindowPlacement(&wp);
	}
		
	CFrameWnd::OnClose();
}

void CMainFrame::SizeSplitter(const CRect& rect)
{
	m_wndSplitter.SetRowInfo(0, 4*rect.Height()/9, 0);
	m_wndSplitter2.SetColumnInfo(0, rect.Width()/2, 0);
}