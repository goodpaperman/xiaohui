// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINFRM_H__AE3C4369_083C_11D1_B2B9_444553540000__INCLUDED_)
#define AFX_MAINFRM_H__AE3C4369_083C_11D1_B2B9_444553540000__INCLUDED_

#include "SPWResultSetView.h"
#include "SPWListView.h"
#include "ReadMeEdit.h"

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CMainFrame : public CFrameWnd
{
protected: // create from serialization only
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)
	CSplitterWnd m_wndSplitter, m_wndSplitter2;
	CReadMeEdit* GetReadMeEditView();
	void SetResultSetInfo(const CString& str);
	BOOL IsDBMSSupported();

// Attributes
public:
	BOOL m_bRefresh;
	CString m_strDBMS;
	CString m_strSybaseSQLServer;
	CString m_strMSSQLServer;
	CString m_strSybaseSQLAW;
	CString m_strSybaseASAAW;

// Operations
public:
	CSPWResultSetView* GetSPResultSetView();
	CSPWListView* GetSPListView();
	void InitialShowWindow(UINT nCmdShow);
	
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	void SizeSplitter(const CRect& rect);
	BOOL m_bOKToSize;
	CStatusBar  m_wndStatusBar;
	CToolBar    m_wndToolBar;

// Generated message map functions
public:
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnFileGenerateCppClass();
	afx_msg void OnViewRefresh();
	afx_msg void OnFilePrint();
	afx_msg void OnFilePrintPreview();
	afx_msg void OnUpdateFileGenerateCppClass(CCmdUI* pCmdUI);
	afx_msg void OnFileConnect();
	afx_msg void OnFileDisconnect();
	afx_msg void OnUpdateFileDisconnect(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFileConnect(CCmdUI* pCmdUI);
	afx_msg void OnUpdateViewRefresh(CCmdUI* pCmdUI);
	afx_msg void OnViewOptions();
	afx_msg void OnFileExecuteProcedure();
	afx_msg void OnUpdateFileExecuteProcedure(CCmdUI* pCmdUI);
	afx_msg void OnUpdateViewOptions(CCmdUI* pCmdUI);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnClose();
	//}}AFX_MSG
	afx_msg void OnUpdateIndicatorResultSetInfo(CCmdUI* pCmdUI);
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRM_H__AE3C4369_083C_11D1_B2B9_444553540000__INCLUDED_)