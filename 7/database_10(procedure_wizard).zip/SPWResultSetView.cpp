// SPWResultSetView.cpp : implementation file
//

#include "stdafx.h"
#include "SPW.h"
#include "SPWResultSetView.h"
#include "MainFrm.h"
#include "StoredProcedureColumns.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CSPWApp theApp;
/////////////////////////////////////////////////////////////////////////////
// CSPWResultSetView

IMPLEMENT_DYNCREATE(CSPWResultSetView, CListViewEx)

CSPWResultSetView::CSPWResultSetView()
{
	m_nSelectedItem = -1;
	InitializeResultSetInfo();
}

CSPWResultSetView::~CSPWResultSetView()
{
	// Scenario: User executed a procedure that has params
	// and exit the app
	CleanUpParamInfoList();
}

BEGIN_MESSAGE_MAP(CSPWResultSetView, CListView)
	//{{AFX_MSG_MAP(CSPWResultSetView)
	ON_WM_KILLFOCUS()
	ON_WM_SETFOCUS()
	ON_NOTIFY_REFLECT(LVN_ITEMCHANGING, OnItemchanging)
	ON_NOTIFY_REFLECT(LVN_DELETEALLITEMS, OnDeleteallitems)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSPWResultSetView drawing

void CSPWResultSetView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// CSPWResultSetView diagnostics

#ifdef _DEBUG
void CSPWResultSetView::AssertValid() const
{
	CListViewEx::AssertValid();
}

void CSPWResultSetView::Dump(CDumpContext& dc) const
{
	CListViewEx::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSPWResultSetView message handlers

BOOL CSPWResultSetView::PopulateSybaseSQLAnywhere()
{
	CWaitCursor wait;

	GetListCtrl().DeleteAllItems();
	
	InitializeResultSetInfo();
	
	int nIndex = 0;
		
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	ASSERT(pFrame != NULL);
	
	CSPWListView* pView = pFrame->GetSPListView();
	ASSERT(pView != NULL);
	
	CSPWDoc* pDoc = (CSPWDoc*)pView->GetDocument();
	ASSERT(pDoc != NULL);
		
	m_strProcedureName = pView->GetListCtrl().GetItemText(pView->m_nSelectedItem, 0);
	
	CStoredProcedureColumns sp(&pDoc->m_database);

	BOOL bRet = TRUE;

	try
	{
		if(sp.Open(NULL, NULL, m_strProcedureName))
		{
			if(!sp.IsBOF())
			{
				sp.MoveFirst();
				
				while(!sp.IsEOF())
				{
					CString sRow;
					CString sBuff;
					sRow  = sp.m_strColumnName + "\t";
					sRow +=	GetColumnType(sp.m_fColumnType) + "\t";
					sRow += GetCPPType(sp.m_nDataType, TRUE) + "\t";
					sRow += GetCPPType(sp.m_nDataType) + "\t";
					sBuff.Format("%d\t", sp.m_nLength);
					sRow += sBuff;
					if(sp.m_fNullable)
						sRow += "Yes\t";
					else
						sRow += "No\t";
								
					Insert(sRow, nIndex);

					// For SQL_NUMERIC and SQL_DECIMAL
					if(m_nParams)
						GetListCtrl().SetItemData(nIndex, sp.m_nScale);
										
					sp.MoveNext();
					
					nIndex++;
				}
			}
		}
	}
	catch(CDBException* e)
	{
		if(e)
		{
			e->ReportError(MB_ICONEXCLAMATION);
			e->Delete();
		}

		bRet = FALSE;
	}
	catch(CMemoryException* e)
	{
		if(e)
		{
			e->ReportError(MB_ICONEXCLAMATION);
			e->Delete();
		}

		bRet = FALSE;
	}
		
	m_strResultSetInfo.Format("Procedure Name: %s; m_nFields = %d; m_nParams = %d",
							(LPCTSTR)m_strProcedureName, m_nFields, m_nParams);

	return bRet;
}

void CSPWResultSetView::OnInitialUpdate() 
{
	CListViewEx::OnInitialUpdate();

	CRect rect;
	GetListCtrl().GetClientRect(&rect);
	CSize size = rect.Size();
	int nWidth = size.cx/6;

	LV_COLUMN lvcColumn;
	lvcColumn.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	lvcColumn.fmt = LVCFMT_LEFT;
		
	lvcColumn.pszText = "Column Name";
	lvcColumn.iSubItem = 0;
	GetListCtrl().InsertColumn(0, &lvcColumn);

	lvcColumn.pszText = "Column Type";
	lvcColumn.iSubItem = 1;
	GetListCtrl().InsertColumn(1, &lvcColumn);

	lvcColumn.pszText = "SQL Data Type";
	lvcColumn.iSubItem = 2;
	GetListCtrl().InsertColumn(2, &lvcColumn);

	lvcColumn.pszText = "C++ Data Type";
	lvcColumn.iSubItem = 3;
	GetListCtrl().InsertColumn(3, &lvcColumn);

	lvcColumn.pszText = "Length";
	lvcColumn.iSubItem = 4;
	GetListCtrl().InsertColumn(4, &lvcColumn);

	lvcColumn.pszText = "Is Nullable";
	lvcColumn.iSubItem = 5;
	GetListCtrl().InsertColumn(5, &lvcColumn);

	for(int i = 0; i <= 5; i++)
		GetListCtrl().SetColumnWidth(i, nWidth);

	UpdateData(FALSE);
}

CString CSPWResultSetView::GetColumnType(const int& nColumnType)
{
	CString strColumnType(_T("<Param_Type_Unknown>"));

	switch(nColumnType)
	{
		case SQL_PARAM_INPUT:
			strColumnType = _T("Param_Input");
			m_nInputParams++;
			m_nParams++;
			break;

		case SQL_PARAM_INPUT_OUTPUT:
			strColumnType = _T("Param_Input_Output");
			m_nInputOutputParams++;
			m_nParams++;
			break;

		case SQL_RESULT_COL:
			strColumnType = _T("Result_Col");
			m_nFields++;
			break;
		
		case SQL_PARAM_OUTPUT:
			strColumnType = _T("Param_Output");
			m_nOutputParams++;
			m_nParams++;
			break;
				
		case SQL_RETURN_VALUE:
			strColumnType = _T("Return_Value");
			m_nRet++;
			m_nParams++;
			break;
	}

	return strColumnType;
}

BOOL CSPWResultSetView::Insert(CString sRow, const int& nIndex)
{
	LV_ITEM lvItem;
	int iItemIndex;
	CString sColVal;
	
	int nEnd = sRow.Find("\t");
	
	if(nEnd != -1)
	{
		int i 			= 0;
		lvItem.mask 	= LVIF_TEXT;
		lvItem.iItem 	= nIndex;
		lvItem.iSubItem = i++;
		sColVal 		= sRow.Mid(0, nEnd);
		lvItem.pszText 	= sColVal.GetBuffer(sColVal.GetLength()+1);
		sColVal.ReleaseBuffer();

		iItemIndex 	= GetListCtrl().InsertItem(&lvItem);

		if(iItemIndex != -1)
		{
			while(sRow.GetLength() > nEnd) 
			{  		
				sRow = sRow.Mid(nEnd + 1);
				nEnd = sRow.Find("\t");
				if(nEnd == -1) break;
				lvItem.iItem = iItemIndex;
				lvItem.iSubItem = i++;
				sColVal = sRow.Mid(0, nEnd);
				lvItem.pszText = sColVal.GetBuffer(sColVal.GetLength()+1);
				sColVal.ReleaseBuffer();
						
				GetListCtrl().SetItem(&lvItem);
			}
		}
	}

	return TRUE;
}

void CSPWResultSetView::OnKillFocus(CWnd* pNewWnd) 
{
	CListViewEx::OnKillFocus(pNewWnd);
	
	if(m_nSelectedItem != -1)
	{
		GetListCtrl().SetItemState(m_nSelectedItem, LVIS_SELECTED, LVIS_SELECTED);
		
		RepaintSelectedItems();
	}
}

void CSPWResultSetView::OnSetFocus(CWnd* pOldWnd) 
{
	CListViewEx::OnSetFocus(pOldWnd);

	if(m_nSelectedItem != -1)
	{
		GetListCtrl().SetItemState(m_nSelectedItem, LVIS_SELECTED | LVIS_FOCUSED,
							LVIS_SELECTED | LVIS_FOCUSED); 	
		RepaintSelectedItems();
	}
}

void CSPWResultSetView::OnItemchanging(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;

	m_nSelectedItem = pNMListView->iItem;
	
	*pResult = 0;
}

void CSPWResultSetView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	if(pSender != NULL)
	{
		if(pSender->IsKindOf(RUNTIME_CLASS(CSPWListView)))
		{		
			CSPWListView* pListView = (CSPWListView*)pSender->
								IsKindOf(RUNTIME_CLASS(CSPWListView));
		
			CMainFrame* pFrame = (CMainFrame*)GetParentFrame();

			if(pFrame)
			{
				BOOL bPopulate = FALSE;
				
				if(pFrame->m_strDBMS.Find(pFrame->m_strSybaseSQLAW) != -1 ||
					pFrame->m_strDBMS.Find(pFrame->m_strSybaseASAAW) != -1)
					bPopulate = PopulateSybaseSQLAnywhere();
				
				if(pFrame->m_strDBMS.Find(pFrame->m_strSybaseSQLServer) != -1 ||
					pFrame->m_strDBMS.Find(pFrame->m_strMSSQLServer) != -1)
					bPopulate = PopulateMicrosoftSQLServer();

				if(!bPopulate)
				{
					GetListCtrl().DeleteAllItems();
					m_strResultSetInfo.LoadString(ID_INDICATOR_RESULT_SET);

				} // End if(!bPopulate)
			
			} // End if(pFrame)
		
		} // End if(pSender->IsKindOf(RUNTIME_CLASS(CSPWListView)))
	
	} // End if(pSender != NULL)
}

void CSPWResultSetView::OnDeleteallitems(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;

	// Make sure that we re-initialize every time
	// when we delete items
	InitializeResultSetInfo();
	CleanUpParamInfoList();
	
	*pResult = 0;
}

CString CSPWResultSetView::GetCPPType(const int& nSQLDataType,
									const BOOL& bSQLTypeAsString/* = FALSE*/)
{
	CString sBuff("");

	switch(nSQLDataType)
	{
		case SQL_BIGINT:
			if(!bSQLTypeAsString)
				sBuff = _T("CString");
			else
				sBuff = _T("SQL_BIGINT");
			break;

		case SQL_BINARY:
			if(!bSQLTypeAsString)
				sBuff = _T("CByteArray");
			else
				sBuff = _T("SQL_BINARY");
			break;
		
		case SQL_BIT:
			if(!bSQLTypeAsString)
				sBuff = _T("BOOL");
			else
				sBuff = _T("SQL_BIT");
			break;
		
		case SQL_CHAR:
			if(!bSQLTypeAsString)
				sBuff = _T("CString");
			else
				sBuff = _T("SQL_CHAR");
			break;
				
		case SQL_DECIMAL:
			if(!bSQLTypeAsString)
				sBuff = _T("CString");
			else
				sBuff = _T("SQL_DECIMAL");
			break;
		
		case SQL_DOUBLE:
			if(!bSQLTypeAsString)
				sBuff = _T("double");
			else
				sBuff = _T("SQL_DOUBLE");
			break;
		
		case SQL_FLOAT:
			if(!bSQLTypeAsString)
				sBuff = _T("double");
			else
				sBuff = _T("SQL_FLOAT");
			break;
		
		case SQL_INTEGER:
			if(!bSQLTypeAsString)
				sBuff = _T("long");
			else
				sBuff = _T("SQL_INTEGER");
			break;
		
		case SQL_LONGVARBINARY:
			if(!bSQLTypeAsString)
				sBuff = _T("CLongBinary");
			else
				sBuff = _T("SQL_LONGVARBINARY");
			break;
		
		case SQL_LONGVARCHAR:
			if(!bSQLTypeAsString)
				sBuff = _T("CString");
			else
				sBuff = _T("SQL_LONGVARCHAR");
			break;
		
		case SQL_NUMERIC:
			if(!bSQLTypeAsString)
				sBuff = _T("CString");
			else
				sBuff = _T("SQL_NUMERIC");
			break;
		
		case SQL_REAL:
			if(!bSQLTypeAsString)
				sBuff = _T("float");
			else
				sBuff = _T("SQL_REAL");
			break;
		
		case SQL_SMALLINT:
			if(!bSQLTypeAsString)
				sBuff = _T("int");
			else
				sBuff = _T("SQL_SMALLINT");
			break;
		
		case SQL_DATE:
			if(bSQLTypeAsString)
				sBuff = _T("SQL_DATE");
			else
			{
				sBuff = theApp.GetProfileString(theApp.m_strSection, theApp.m_strRfxDateKey);
				sBuff.TrimRight(); sBuff.TrimLeft();
					
				if(sBuff.IsEmpty())
					sBuff = _T("CString");
			}
			break;
		
		case SQL_TIME:
			if(bSQLTypeAsString)
				sBuff = _T("SQL_TIME");
			else
			{
				sBuff = theApp.GetProfileString(theApp.m_strSection, theApp.m_strRfxTimeKey);
				sBuff.TrimRight(); sBuff.TrimLeft();
					
				if(sBuff.IsEmpty())
					sBuff = _T("CString");
			}
			break;
		
		case SQL_TIMESTAMP:
			if(bSQLTypeAsString)
				sBuff = _T("SQL_TIMESTAMP");
			else
			{
				sBuff = theApp.GetProfileString(theApp.m_strSection, theApp.m_strRfxTimeStampKey);
				sBuff.TrimRight(); sBuff.TrimLeft();
				
				if(sBuff.IsEmpty())
					sBuff = _T("CString");
			}
			break;
		
		case SQL_TINYINT:
			if(!bSQLTypeAsString)
				sBuff = _T("BYTE");
			else
				sBuff = _T("SQL_TINYINT");
			break;
		
		case SQL_VARBINARY:
			if(!bSQLTypeAsString)
				sBuff = _T("CByteArray");
			else
				sBuff = _T("SQL_VARBINARY");
			break;
		
		case SQL_VARCHAR:
			if(!bSQLTypeAsString)
				sBuff = _T("CString");
			else
				sBuff = _T("SQL_VARCHAR");
			break;
		
		/*case SQL_UNICODE_CHAR:
			if(!bSQLTypeAsString)
				sBuff = _T("CString");
			else
				sBuff = _T("SQL_UNICODE_CHAR");
			break;

		case SQL_UNICODE_VARCHAR:
			if(!bSQLTypeAsString)
				sBuff = _T("CString");
			else
				sBuff = _T("SQL_UNICODE_VARCHAR");
			break;

		case SQL_UNICODE_LONGVARCHAR:
			if(!bSQLTypeAsString)
				sBuff = _T("CString");
			else
				sBuff = _T("SQL_UNICODE_LONGVARCHAR");
			break;*/

		case SQL_WCHAR:
			if(!bSQLTypeAsString)
				sBuff = _T("CString");
			else
				sBuff = _T("SQL_WCHAR");
			break;

		case SQL_WVARCHAR:
			if(!bSQLTypeAsString)
				sBuff = _T("CString");
			else
				sBuff = _T("SQL_WVARCHAR");
			break;

		case SQL_WLONGVARCHAR:
			if(!bSQLTypeAsString)
				sBuff = _T("CString");
			else
				sBuff = _T("SQL_WLONGVARCHAR");
			break;

		default:
			sBuff = _T("<Type_Unknown>");
			break;
	}
				
	return sBuff;
}

BOOL CSPWResultSetView::PopulateMicrosoftSQLServer()
{
	CWaitCursor wait;
	
	GetListCtrl().DeleteAllItems();
	
	int nIndex = 0;
		
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	ASSERT(pFrame != NULL);

	CSPWListView* pView = pFrame->GetSPListView();
	ASSERT(pView != NULL);
	
	CSPWDoc* pDoc = (CSPWDoc*)pView->GetDocument();
	ASSERT(pDoc != NULL);
	
	m_strProcedureName = pView->GetListCtrl().GetItemText(pView->m_nSelectedItem, 0);
	TRACE("Procedure Name = %s\n", (LPCTSTR)m_strProcedureName);
	
	CStoredProcedureColumns sp(&pDoc->m_database);
	
	BOOL bRet = TRUE;
	
	try
	{
		if(sp.Open(NULL, NULL, m_strProcedureName))
		{
			if(!sp.IsBOF())
			{
				sp.MoveFirst();
				
				while(!sp.IsEOF())
				{
					CString sRow;
					CString sBuff;
					sRow  = sp.m_strColumnName + "\t";
					sRow +=	GetColumnType(sp.m_fColumnType) + "\t";
					sRow += GetCPPType(sp.m_nDataType, TRUE) + "\t";
					sRow += GetCPPType(sp.m_nDataType) + "\t";
					sBuff.Format("%d\t", sp.m_nLength);
					sRow += sBuff;

					if(sp.m_fNullable)
						sRow += "Yes\t";
					else
						sRow += "No\t";
								
					// Store the param info (excluding the return value) in a list for later use,
					// if any
					if(m_nParams - m_nRet)
					{	
						CParamInfo* pParamInfo = new CParamInfo();
						
						if(pParamInfo)
						{
							pParamInfo->m_fColumnType = sp.m_fColumnType;
							pParamInfo->m_nDataType = sp.m_nDataType;
							pParamInfo->m_nPrecision = sp.m_nPrecision;
							pParamInfo->m_nScale = sp.m_nScale;
							pParamInfo->m_nLength = sp.m_nLength;

							m_listParamInfo.AddTail(pParamInfo);
						}
					}
										
					Insert(sRow, nIndex);
					
					// For SQL_NUMERIC and SQL_DECIMAL
					if(m_nParams)
						GetListCtrl().SetItemData(nIndex, sp.m_nScale);
										
					sp.MoveNext();
					
					nIndex++;
				}
			}
		}
	}
	catch(CDBException* e)
	{
		if(e)
		{
			e->ReportError(MB_ICONEXCLAMATION);
			e->Delete();
		}

		bRet = FALSE;
	}
	catch(CMemoryException* e)
	{
		if(e)
		{
			e->ReportError(MB_ICONEXCLAMATION);
			e->Delete();
		}

		bRet = FALSE;
	}
		
	m_strResultSetInfo.Format("Procedure Name: %s; m_nFields = %d; m_nParams = %d",
							(LPCTSTR)m_strProcedureName, m_nFields, m_nParams);
	
	return bRet;
}

void CSPWResultSetView::InitializeResultSetInfo()
{
	m_nFields = 0;
	m_nParams = 0;
	m_nInputParams = 0;
	m_nInputOutputParams = 0;
	m_nOutputParams = 0;
	m_nRet = 0;
}

BOOL CSPWResultSetView::ExecuteProcedure()
{
	CWaitCursor wait;
	
	int nCount = GetListCtrl().GetItemCount();
	int nIndex = nCount;
	int nDeleteFrom = m_nParams;
	
	// Delete result_cols, if any
	// For nDeleteFrom times delete nDeleteFrom, i.e.,
	// delete the same index
	for(int k = nDeleteFrom; k <= nCount - 1; k++)
		GetListCtrl().DeleteItem(nDeleteFrom);
	
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	ASSERT(pFrame != NULL);

	CSPWListView* pView = pFrame->GetSPListView();
	ASSERT(pView != NULL);	

	CSPWDoc* pDoc = (CSPWDoc*)pView->GetDocument();
	ASSERT(pDoc != NULL);
	
	CStoredProcedureColumns sp(&pDoc->m_database);
	
	// Prepare procedure
	CString sPlaceHolders;
	CString sBuff;
	for(int i = 1; i <= m_nParams - m_nRet; i++)
		sPlaceHolders += "?,";

	int nLength = sPlaceHolders.GetLength();

	if(nLength)
	{
		sPlaceHolders.SetAt(nLength-1, _T(' '));
		sPlaceHolders.TrimRight();
		int nPos = m_strProcedureName.Find(' ');
		if(nPos != -1) // MS SQL Server scenario
			sBuff.Format("{CALL [%s] (%s)}", (LPCTSTR)m_strProcedureName, (LPCTSTR)sPlaceHolders);
		else
			sBuff.Format("{CALL %s (%s)}", (LPCTSTR)m_strProcedureName, (LPCTSTR)sPlaceHolders);
	}
	else
	{
		int nPos = m_strProcedureName.Find(' ');
		if(nPos != -1) // MS SQL Server scenario
			sBuff.Format("{CALL [%s]}", (LPCTSTR)m_strProcedureName);
		else
			sBuff.Format("{CALL %s}", (LPCTSTR)m_strProcedureName);
	}

	
	TRACE("Procedure name: %s\n", (LPCTSTR)sBuff);

	// Bind params, execute procedure, enum and describe
	// Result_Cols, and insert Result_Col info
	
	BOOL bRet = TRUE;

	try
	{
		for(int j = 1; j <= m_nParams; j++)
		{
			POSITION pos = m_listParamInfo.FindIndex(j-1);

			if(pos != NULL)
			{
				CParamInfo* pParamInfo = (CParamInfo*)m_listParamInfo.GetAt(pos);
				
				if(pParamInfo)
					sp.BindParameter(
								j,
								pParamInfo->m_fColumnType,
								pParamInfo->m_nDataType,
								pParamInfo->m_nPrecision,
								pParamInfo->m_nScale,
								pParamInfo->m_nLength,
								j /*proxy for actual param values*/);
			}
		}
				
		TRACE("Executing <%s>... \n", (LPCTSTR)sBuff);
				
		if(sp.ExecDirect(sBuff))
		{
			m_nFields = sp.GetNumResultCols();
						
			for(int i = 1; i <= m_nFields; i++)
			{
				ResultColumnInfo result;
				CString sRow;
				CString sBuff;

				sp.GetResultColumnInfo(i, result);
								
				sRow  = result.sColumnName + "\t";
				sRow +=	"Result_Col\t";
				sRow += GetCPPType(result.DataType, TRUE) + "\t";
				sRow += GetCPPType(result.DataType) + "\t";
				sBuff.Format("%d\t", result.ColumnSize);
				sRow += sBuff;

				if(result.Nullable)
					sRow += "Yes\t";
				else
					sRow += "No\t";
								
				Insert(sRow, nIndex);
										
				nIndex++;
			}
		}
	}
	catch(CDBException* e)
	{
		if(e)
		{
			e->ReportError(MB_ICONEXCLAMATION);
			e->Delete();
		}

		bRet = FALSE;
	}
	catch(CMemoryException* e)
	{
		if(e)
		{
			e->ReportError(MB_ICONEXCLAMATION);
			e->Delete();
		}

		bRet = FALSE;
	}
		
	m_strResultSetInfo.Format("Procedure Name: %s; m_nFields = %d; m_nParams = %d",
				(LPCTSTR)m_strProcedureName, m_nFields, m_nParams);

	return bRet;
}

void CSPWResultSetView::CleanUpParamInfoList()
{
	for(POSITION pos = m_listParamInfo.GetHeadPosition(); pos != NULL;)
	{
		CParamInfo* pParamInfo =  (CParamInfo*)m_listParamInfo.GetNext(pos);
		
		if(pParamInfo)
			delete pParamInfo;
	}
		
	if(!m_listParamInfo.IsEmpty())
		m_listParamInfo.RemoveAll();
}