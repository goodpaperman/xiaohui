// SPWListView.cpp : implementation of the CSPWListView class
//

#include "stdafx.h"
#include "SPW.h"
#include "MainFrm.h"
#include "SPWListView.h"
#include "StoredProcedures.h"
#include "SybaseProcSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CSPWApp theApp;
/////////////////////////////////////////////////////////////////////////////
// CSPWListView

IMPLEMENT_DYNCREATE(CSPWListView, CListViewEx)

BEGIN_MESSAGE_MAP(CSPWListView, CListView)
	//{{AFX_MSG_MAP(CSPWListView)
	ON_WM_KILLFOCUS()
	ON_WM_SETFOCUS()
	ON_NOTIFY_REFLECT(LVN_ITEMCHANGED, OnItemChanged)
	ON_NOTIFY_REFLECT(NM_DBLCLK, OnDblclk)
	ON_NOTIFY_REFLECT(NM_RCLICK, OnRclick)
	ON_COMMAND(ID_FILE_EXECUTEPROCEDURE, OnFileExecuteprocedure)
	ON_COMMAND(ID_FILE_GENERATE_CPP_CLASS, OnFileGenerateCppClass)
	ON_NOTIFY_REFLECT(LVN_COLUMNCLICK, OnColumnClick)
	//}}AFX_MSG_MAP
	// Standard printing commands
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSPWListView construction/destruction

CSPWListView::CSPWListView()
{
	m_nSelectedItem = 0;

	m_bSort = true;
}

CSPWListView::~CSPWListView()
{
}

/////////////////////////////////////////////////////////////////////////////
// CSPWListView drawing

void CSPWListView::OnInitialUpdate()
{
	CListViewEx::OnInitialUpdate();
	
	CRect rect;
	GetListCtrl().GetClientRect(&rect);
	CSize size = rect.Size();

	LV_COLUMN lvcColumn;
	lvcColumn.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	lvcColumn.fmt = LVCFMT_LEFT;

	lvcColumn.cx = size.cx;
	lvcColumn.pszText = "Procedure Name";
	lvcColumn.iSubItem = 0;
	GetListCtrl().InsertColumn(0, &lvcColumn);
	
	UpdateData(FALSE);
}

/////////////////////////////////////////////////////////////////////////////
// CSPWListView diagnostics

#ifdef _DEBUG
void CSPWListView::AssertValid() const
{
	CListViewEx::AssertValid();
}

void CSPWListView::Dump(CDumpContext& dc) const
{
	CListViewEx::Dump(dc);
}

CSPWDoc* CSPWListView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CSPWDoc)));
	return (CSPWDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSPWListView message handlers

void CSPWListView::OnKillFocus(CWnd* pNewWnd) 
{
	CListViewEx::OnKillFocus(pNewWnd);
	
	GetListCtrl().SetItemState(m_nSelectedItem, LVIS_SELECTED, LVIS_SELECTED);
	
	RepaintSelectedItems();
}

void CSPWListView::OnSetFocus(CWnd* pOldWnd) 
{
	CListViewEx::OnSetFocus(pOldWnd);

	GetListCtrl().SetItemState(m_nSelectedItem, LVIS_SELECTED | LVIS_FOCUSED,
							LVIS_SELECTED | LVIS_FOCUSED); 	
	RepaintSelectedItems();
}

void CSPWListView::OnItemChanged(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;

	if(pNMListView)
	{
		if(pNMListView->uNewState)
		{
			m_nSelectedItem = pNMListView->iItem;
			UpdateSPWResultSetView();
		}
	}
		
	*pResult = 0;
}

BOOL CSPWListView::Populate()
{
	CWaitCursor wait;
	
	GetListCtrl().SetRedraw(FALSE);
	
	BOOL bRet = TRUE;

	GetListCtrl().DeleteAllItems();
	
	CSPWDoc* pDoc = GetDocument();
	
	if(pDoc)
	{
		CMainFrame* pFrame = (CMainFrame*)GetParentFrame();

		if(pFrame)
		{
			CStoredProcedures sp(&pDoc->m_database);
					
			if(pFrame->m_strDBMS.Find(pFrame->m_strSybaseSQLAW) != -1 ||
				pFrame->m_strDBMS.Find(pFrame->m_strSybaseASAAW) != -1)
			{
				CString sSQL = "SELECT name FROM sysobjects WHERE type = 'p'";

				if(!theApp.GetProfileInt(theApp.m_strSection, theApp.m_strSSP, 0))
					sSQL += " AND UID = 1";
				
				bRet = PopulateSybaseSQLAnywhereProcedures(sSQL);
			}
			
			if(pFrame->m_strDBMS.Find(pFrame->m_strSybaseSQLServer) != -1 ||
				pFrame->m_strDBMS.Find(pFrame->m_strMSSQLServer) != -1)
				bRet = PopulateMSSQLServerProcedures();
		
			if(!bRet)
			{
				GetListCtrl().DeleteAllItems();
				pFrame->GetSPResultSetView()->m_strResultSetInfo.LoadString(ID_INDICATOR_RESULT_SET);

			} // End if(!bPopulate)

		} // End if(pFrame)
	
	} // End if(pDoc)
	
	GetListCtrl().SetRedraw(TRUE);

	return bRet;
}

void CSPWListView::UpdateSPWResultSetView()
{
	CSPWDoc* pDoc = (CSPWDoc*)GetDocument();
	
	if(pDoc)
		pDoc->UpdateAllViews(this);
}

void CSPWListView::OnDblclk(NMHDR* pNMHDR, LRESULT* pResult) 
{
	CWaitCursor wait;

	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();

	if(pFrame)
		if(pFrame->m_strDBMS.Find(pFrame->m_strSybaseSQLServer) != -1 ||
			pFrame->m_strDBMS.Find(pFrame->m_strMSSQLServer) != -1)
			pFrame->OnFileExecuteProcedure();

	*pResult = 0;
}


void CSPWListView::OnRclick(NMHDR* pNMHDR, LRESULT* pResult) 
{
	if(GetListCtrl().GetItemCount())
	{
		CMenu menu;

		if(menu.LoadMenu(IDR_SPWLISTVW))
		{
			CPoint pt;
			GetCursorPos(&pt);

			CMenu* pMenu = menu.GetSubMenu(0);

			if(pMenu)
			{
				CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
				
				if(pFrame)
					if(pFrame->m_strDBMS.Find(pFrame->m_strSybaseSQLAW) != -1 ||
						pFrame->m_strDBMS.Find(pFrame->m_strSybaseASAAW) != -1)
							pMenu->EnableMenuItem(ID_FILE_EXECUTEPROCEDURE,
										MF_BYCOMMAND | MF_GRAYED);
				pMenu->TrackPopupMenu(0, pt.x, pt.y, this);
			}	
		}
	}
	
	*pResult = 0;
}

void CSPWListView::OnFileExecuteprocedure() 
{
	CWaitCursor wait;
	
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	
	if(pFrame)
		pFrame->OnFileExecuteProcedure();
}

void CSPWListView::OnFileGenerateCppClass() 
{
	CWaitCursor wait;
	
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	
	if(pFrame)
		pFrame->OnFileGenerateCppClass();
}

void CSPWListView::OnColumnClick(NMHDR* pNMHDR, LRESULT* pResult) 
{
	CWaitCursor wait;

	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;

	CSortColumn sort(&GetListCtrl(), pNMListView->iSubItem, false);
	sort.Sort(m_bSort = !m_bSort);
	m_nSelectedItem = GetListCtrl().GetNextItem(-1, LVNI_SELECTED | LVNI_SELECTED);
	
	*pResult = 0; // Framework stuff
}

BOOL CSPWListView::PopulateSybaseSQLAnywhereProcedures(const CString& sSQL)
{
	CWaitCursor wait;

	BOOL bRet = FALSE;

	CSPWDoc* pDoc = GetDocument();
	
	if(pDoc)
	{
		CMainFrame* pFrame = (CMainFrame*)GetParentFrame();

		if(pFrame)
		{
			CSybaseProcSet set(&pDoc->m_database);
				
			try
			{	
				bRet = set.Open(AFX_DB_USE_DEFAULT_TYPE, sSQL, CRecordset::executeDirect);
			
				if(bRet)
				{
					if(!set.IsBOF())
					{
						set.MoveFirst();

						int nIndex = 0;

						while(!set.IsEOF())
						{
							GetListCtrl().InsertItem(nIndex, set.m_name);
									
							set.MoveNext();

							nIndex++;
						}
						
						if(pFrame->m_bRefresh)
						{
							GetListCtrl().SetItemState(m_nSelectedItem, LVIS_SELECTED | 
								LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
							GetListCtrl().EnsureVisible(m_nSelectedItem, 0);
						}		
						else
							GetListCtrl().SetItemState(0, LVIS_SELECTED | LVIS_FOCUSED,
									LVIS_SELECTED | LVIS_FOCUSED);
					
					} // End if(sp.IsBOF())
					else
						pFrame->GetSPResultSetView()->GetListCtrl().DeleteAllItems();
								
				} // End if(bRet)
			}
			catch(CDBException* e)
			{
				if(e)
				{
					e->ReportError(MB_ICONEXCLAMATION);
					e->Delete();
					bRet = FALSE;
				}
			}
			catch(CMemoryException* e)
			{
				if(e)
				{
					e->ReportError(MB_ICONEXCLAMATION);
					e->Delete();
					bRet = FALSE;
				}
			}
		
		} // End if(pFrame)
		
	} // End if(pDoc)

	return bRet;
}

BOOL CSPWListView::PopulateMSSQLServerProcedures()
{
	CWaitCursor wait;
	
	BOOL bRet = FALSE;

	CSPWDoc* pDoc = GetDocument();
	
	if(pDoc)
	{
		CMainFrame* pFrame = (CMainFrame*)GetParentFrame();

		if(pFrame)
		{
			CStoredProcedures sp(&pDoc->m_database);
					
			try
			{	
				bRet = sp.Open();
			
				if(bRet)
				{
					if(!sp.IsBOF())
					{
						sp.MoveFirst();

						int nIndex = 0;

						while(!sp.IsEOF())
						{
							CString sBuff;
							
							int nPos = sp.m_strProcedureName.Find(_T(";"));
							
							if(nPos != -1)
								sBuff = sp.m_strProcedureName.Left(nPos);
							else
								sBuff = sp.m_strProcedureName;	
							
							GetListCtrl().InsertItem(nIndex, sBuff);
							
							TRACE("%s\n", (LPCTSTR)sp.m_strProcedureName);
									
							sp.MoveNext();

							nIndex++;
						}
						
						if(pFrame->m_bRefresh)
						{
							GetListCtrl().SetItemState(m_nSelectedItem, LVIS_SELECTED | 
								LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
							GetListCtrl().EnsureVisible(m_nSelectedItem, 0);
						}		
						else
							GetListCtrl().SetItemState(0, LVIS_SELECTED | LVIS_FOCUSED,
									LVIS_SELECTED | LVIS_FOCUSED);
					
					} // End if(sp.IsBOF())
					else
						pFrame->GetSPResultSetView()->GetListCtrl().DeleteAllItems();
				
				} // End if(bOpen)
			}
			catch(CDBException* e)
			{
				if(e)
				{
					e->ReportError(MB_ICONEXCLAMATION);
					e->Delete();
					bRet = FALSE;
				}
			}
			catch(CMemoryException* e)
			{
				if(e)
				{
					e->ReportError(MB_ICONEXCLAMATION);
					e->Delete();
					bRet = FALSE;
				}
			}
		
		} // End if(pFrame)
		
	} // End if(pDoc)

	return bRet;
}