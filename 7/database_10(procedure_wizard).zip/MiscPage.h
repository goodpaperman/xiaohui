#if !defined(AFX_MISCPAGE_H__BE382445_1069_11D2_BB75_204C4F4F5020__INCLUDED_)
#define AFX_MISCPAGE_H__BE382445_1069_11D2_BB75_204C4F4F5020__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// MiscPage.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMiscPage dialog

class CMiscPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CMiscPage)

// Construction
public:
	CMiscPage();
	~CMiscPage();

// Dialog Data
	//{{AFX_DATA(CMiscPage)
	enum { IDD = IDD_MISC };
	CButton	m_buttonSSP;
	BOOL	m_bSSP;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CMiscPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CMiscPage)
	virtual BOOL OnInitDialog();
	afx_msg void OnSsp();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MISCPAGE_H__BE382445_1069_11D2_BB75_204C4F4F5020__INCLUDED_)