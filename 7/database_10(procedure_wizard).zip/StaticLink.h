#if !defined(AFX_STATICLINK_H__9EDF4AF4_5F73_11D1_B94C_204C4F4F5020__INCLUDED_)
#define AFX_STATICLINK_H__9EDF4AF4_5F73_11D1_B94C_204C4F4F5020__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// StaticLink.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CStaticLink window

class CStaticLink : public CStatic
{
// Construction
public:
	CStaticLink();

// Attributes
public:
   BOOL m_bVisited;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CStaticLink)
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CStaticLink();

	// Generated message map functions
protected:
	//{{AFX_MSG(CStaticLink)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	
	CString	 m_strLink;		
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STATICLINK_H__9EDF4AF4_5F73_11D1_B94C_204C4F4F5020__INCLUDED_)