// StaticLink.cpp : implementation file
//

#include "stdafx.h"
#include "spw.h"
#include "StaticLink.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CStaticLink

CStaticLink::CStaticLink()
{
	m_bVisited = FALSE;
	m_strLink = _T("http://home.att.net/~gpoulose/");
}

CStaticLink::~CStaticLink()
{
}

BEGIN_MESSAGE_MAP(CStaticLink, CStatic)
	//{{AFX_MSG_MAP(CStaticLink)
	ON_WM_LBUTTONDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStaticLink message handlers

BOOL CStaticLink::PreCreateWindow(CREATESTRUCT& cs) 
{
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW | CS_VREDRAW,
			AfxGetApp()->LoadCursor(IDC_MY_CURSOR), NULL);
	
	return CStatic::PreCreateWindow(cs);
}

void CStaticLink::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CWaitCursor wait;

	HINSTANCE h = ::ShellExecute(NULL, _T("open"), m_strLink, NULL, NULL, SW_SHOWNORMAL);
	
	if((UINT)h > 32)
		m_bVisited = TRUE;	
	else
		MessageBeep(0); // unable to execute file!
	
	CStatic::OnLButtonDown(nFlags, point);
}