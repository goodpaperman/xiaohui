// ver10.h : main header file for the VER10 DLL
//


/*--------------------------------------------------*/
//HERE WE DEFINET THE WINDOW MESSAGE 
//
const UINT WM_SHOWTHREADBEGIN	= RegisterWindowMessage("ShowThreadBegin");
const UINT WM_SHOWTHREADSETTING = RegisterWindowMessage("ShowThreadSetting");
const UINT WM_SHOWTHREADPLAY	= RegisterWindowMessage("ShowThreadPlay");
const UINT WM_SHOWTHREADSTOP	= RegisterWindowMessage("ShowThreadStop");
const UINT WM_SHOWTHREADCLEAR	= RegisterWindowMessage("ShowThreadClear");
const UINT WM_SHOWTHREADEND		= RegisterWindowMessage("ShowThreadEnd");

//const UINT WM_FLICNOTIFY		= RegisterWindowMessage("Flic Play Notify");

const UINT WM_COMM_CTS_DETECTED = RegisterWindowMessage("CommuDetect");
const UINT WM_COMM_RXFLAG_DETECTED=RegisterWindowMessage("CommuRfxflag");
const UINT WM_COMM_BREAK_DETECTED=RegisterWindowMessage("CommuBreak");
const UINT WM_COMM_ERR_DETECTED=RegisterWindowMessage("CommuErr");
const UINT WM_COMM_RING_DETECTED=RegisterWindowMessage("CommuRing");
const UINT WM_COMM_RXCHAR=RegisterWindowMessage("CommuRxchar");

/*
const UINT WM_CHANGEWINDOWPOS	= RegisterWindowMessage("ChangeWindowPos");
const UINT WM_CHANGENETPARAMETERS=RegisterWindowMessage("ServeSocket Parameters Changed");
const UINT WM_SERVERECEIVEDATA	= RegisterWindowMessage("ServeSocket Received Data");
const UINT WM_CLOSESOCKET		= RegisterWindowMessage("ServeSocket is Closeed");
const UINT WM_CLIENTSTATIC    	= RegisterWindowMessage("Client Socket Static is Changed");
const UINT WM_DATACHANGE		 =RegisterWindowMessage("String Data Changed");

*/





//-----------------------------------------------------------------------------


#if !defined(AFX_VER10_H__D9916CE6_EEC9_11D3_84B8_0080C866EAF1__INCLUDED_)
#define AFX_VER10_H__D9916CE6_EEC9_11D3_84B8_0080C866EAF1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CVer10App
// See ver10.cpp for the implementation of this class
//

class CVer10App : public CWinApp
{
public:
	int test();
	int close();
	int gooo();
	int runcomm();
	CVer10App();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CVer10App)
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CVer10App)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_VER10_H__D9916CE6_EEC9_11D3_84B8_0080C866EAF1__INCLUDED_)
