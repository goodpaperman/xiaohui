// ver10.cpp : Defines the initialization routines for the DLL.
//

#include "stdafx.h"
#include "ver10.h"
#include "serialPort.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//export the function 




extern "C"  _declspec(dllexport)  int  close(void);
extern "C"  _declspec(dllexport)  int test(void);
//extern "C"  _declspec(dllexport)  int gooo(void);//
//extern "C"  _declspec(dllexport)  int runcomm(void);

//wrapper funcitons 
//extern "C"  _declspec(dllexport)  int test(void)

//	Note!
//
//		If this DLL is dynamically linked against the MFC
//		DLLs, any functions exported from this DLL which
//		call into MFC must have the AFX_MANAGE_STATE macro
//		added at the very beginning of the function.
//
//		For example:
//
//		extern "C" BOOL PASCAL EXPORT ExportedFunction()
//		{
//			AFX_MANAGE_STATE(AfxGetStaticModuleState());
//			// normal function body here
//		}
//
//		It is very important that this macro appear in each
//		function, prior to any calls into MFC.  This means that
//		it must appear as the first statement within the 
//		function, even before any object variable declarations
//		as their constructors may generate calls into the MFC
//		DLL.
//
//		Please see MFC Technical Notes 33 and 58 for additional
//		details.
//

/////////////////////////////////////////////////////////////////////////////
// CVer10App

BEGIN_MESSAGE_MAP(CVer10App, CWinApp)
	//{{AFX_MSG_MAP(CVer10App)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CVer10App construction

CVer10App::CVer10App()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CVer10App object

CVer10App theApp;

extern "C"  _declspec(dllexport)  int runcomm(void)
{
	CSerialPort* go;
	go->InitPort(NULL,1,19200,'N',8,1);
	go->StartMonitoring();
	return 0;
}


int CVer10App::gooo()
{
	CSerialPort* go;
	go->InitPort(NULL,1,19200,'N',8,1);
	go->StartMonitoring();
	return 1;
}



extern "C"  _declspec(dllexport)  int  close(void)
{
	CSerialPort* end;
	end->InitPort(NULL,1,19200,'N',8,1);
	end->StopMonitoring();
	return 1;

}


