// MiscDlg.cpp : implementation file
//

#include "stdafx.h"
#include "GLDemo.h"
#include "MiscDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChangeMapName dialog


CChangeMapName::CChangeMapName(CWnd* pParent /*=NULL*/)
	: CDialog(CChangeMapName::IDD, pParent)
{
	//{{AFX_DATA_INIT(CChangeMapName)
	m_nEdNameFrom = _T("");
	m_nEdNameTo = _T("");
	//}}AFX_DATA_INIT
}


void CChangeMapName::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CChangeMapName)
	DDX_Text(pDX, IDC_EDNAMEFROM, m_nEdNameFrom);
	DDX_Text(pDX, IDC_EDNAMETO, m_nEdNameTo);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CChangeMapName, CDialog)
	//{{AFX_MSG_MAP(CChangeMapName)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChangeMapName message handlers
