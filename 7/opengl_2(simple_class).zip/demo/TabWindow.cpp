// TabWindow.cpp : implementation file
//

#include "stdafx.h"
#include "TabWindow.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTabWindow

BEGIN_MESSAGE_MAP(CTabWindow, CTabCtrl)
	//{{AFX_MSG_MAP(CTabWindow)
	ON_NOTIFY_REFLECT(TCN_SELCHANGE, OnSelchange)
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTabWindow message handlers

CWnd* CTabWindow::GetTabView(int nTab)
{
    TC_ITEM TCI;
    TCI.mask = TCIF_PARAM; 
    GetItem(nTab, &TCI);
    CWnd* pWnd = (CWnd*)TCI.lParam;
    ASSERT(pWnd != NULL && pWnd->IsKindOf(RUNTIME_CLASS(CWnd)));
    return pWnd;
}

int CTabWindow::ShowSelTabView()
{    
    int nSel = GetCurSel();   
    ASSERT(nSel != -1);
    
    for (int i = 0; i < GetItemCount(); i++)
        GetTabView(i)->ShowWindow(i == nSel ? SW_SHOW : SW_HIDE);

	return nSel;
}

void CTabWindow::MoveTabView(CRect& rect)
{    
	// reposition the tab control.
    MoveWindow(&rect);
    AdjustRect(FALSE, &rect);

    for (int i = 0; i < GetItemCount(); i++)
        GetTabView(i)->MoveWindow(&rect);
}

CView* CTabWindow::AddTabView(CRuntimeClass* pViewClass, CDocument* pDoc, CWnd* pParentWnd,
							  int i, LPSTR pszText, BOOL HasImage)
{
	ASSERT_VALID(this);
	ASSERT(pViewClass != NULL);
	ASSERT(pViewClass->IsDerivedFrom(RUNTIME_CLASS(CView)));
	ASSERT(AfxIsValidAddress(pViewClass, sizeof(CRuntimeClass), FALSE));

	CView* pView;
	TRY
	{
		pView = (CView*)pViewClass->CreateObject();
		if (pView == NULL)
			AfxThrowMemoryException();
	}
	CATCH_ALL(e)
	{
		TRACE0(_T("Out of memory creating a view\n"));
		return NULL;
	}
	END_CATCH_ALL
		
	ASSERT_KINDOF(CView, pView);
	ASSERT(pView->m_hWnd == NULL);

	if (!pView->Create(NULL, NULL, AFX_WS_DEFAULT_VIEW, CRect(0, 0, 0, 0), pParentWnd, NULL))
        return NULL;    
	
	if (pDoc)
		pDoc->AddView(pView);

    TC_ITEM TCI;
	if(HasImage)
		TCI.mask = TCIF_TEXT | TCIF_PARAM | TCIF_IMAGE;
	else
		TCI.mask = TCIF_TEXT | TCIF_PARAM;
    TCI.pszText = pszText;
    TCI.lParam = (LPARAM)pView;
    TCI.iImage = i;
    VERIFY(InsertItem(i, &TCI) != -1);

	return pView;
}

void CTabWindow::OnSelchange(NMHDR* pNMHDR, LRESULT* pResult) 
{
	ShowSelTabView();
	*pResult = 0;
}

BOOL CTabWindow::OnEraseBkgnd(CDC* pDC) 
{
	// prevent the table control from paining the view area,
	// especially for CTreeView.
	CRect rcRect;
	GetClientRect(rcRect);
	rcRect.DeflateRect(4, 4);	// border area
	rcRect.bottom -= 18;		// tab selector area
	pDC->ExcludeClipRect(rcRect);

	return CTabCtrl::OnEraseBkgnd(pDC);
}
