#if !defined(AFX_MISCDLG_H__81AF4B03_003C_11D4_85DD_0008C777FFEE__INCLUDED_)
#define AFX_MISCDLG_H__81AF4B03_003C_11D4_85DD_0008C777FFEE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MiscDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CChangeMapName dialog

class CChangeMapName : public CDialog
{
// Construction
public:
	CChangeMapName(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CChangeMapName)
	enum { IDD = IDD_CHANGEMAPNAME };
	CString	m_nEdNameFrom;
	CString	m_nEdNameTo;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChangeMapName)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CChangeMapName)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MISCDLG_H__81AF4B03_003C_11D4_85DD_0008C777FFEE__INCLUDED_)
