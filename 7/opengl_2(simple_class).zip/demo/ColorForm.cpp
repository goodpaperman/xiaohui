// ColorForm.cpp : implementation file
//

#include "stdafx.h"
#include "GLDemo.h"
#include "ColorForm.h"
#include "ChildFrm.h"
#include "GLDemoView.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CColorForm

IMPLEMENT_DYNCREATE(CColorForm, CFormView)

CColorForm::CColorForm()
	: CFormView(CColorForm::IDD)
{
	//{{AFX_DATA_INIT(CColorForm)
	m_nAutoDiv = 10;
	m_nCustDiv = 10;
	//}}AFX_DATA_INIT
}

CColorForm::~CColorForm()
{
}

void CColorForm::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CColorForm)
	DDX_Control(pDX, IDC_FGRADIENTCR, m_GradientCr);
	DDX_Control(pDX, IDC_FCUSTOMCR, m_FCostomCr);
	DDX_Control(pDX, IDC_BUBORDERCOLOR, m_nBuBorderColor);
	DDX_Control(pDX, IDC_BUBACKCOLOR, m_nBuBackColor);
	DDX_Control(pDX, IDC_BUMAXCOLOR, m_nBuMaxColor);
	DDX_Control(pDX, IDC_BUMINCOLOR, m_nBuMinColor);
	DDX_Control(pDX, IDC_EDAUTODIV, m_nEdAutoDiv);
	DDX_Control(pDX, IDC_EDCUSTDIV, m_nEdCustDiv);
	DDX_Control(pDX, IDC_LIUSERCOLOR, m_nLiUserColor);
	DDX_Control(pDX, IDC_RAAUTOMATION, m_nRaAutomation);
	DDX_Control(pDX, IDC_SPAUTODIV, m_nSpAutoDiv);
	DDX_Control(pDX, IDC_SPCUSTDIV, m_nSpCustDiv);
	DDX_Control(pDX, IDC_RACUSTOM, m_nRaCustom);
	DDX_Text(pDX, IDC_EDAUTODIV, m_nAutoDiv);
	DDX_Text(pDX, IDC_EDCUSTDIV, m_nCustDiv);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CColorForm, CFormView)
	//{{AFX_MSG_MAP(CColorForm)
	ON_BN_CLICKED(IDC_BUBACKCOLOR, OnBubackcolor)
	ON_BN_CLICKED(IDC_BUBORDERCOLOR, OnBubordercolor)
	ON_BN_CLICKED(IDC_BUMINCOLOR, OnBumincolor)
	ON_BN_CLICKED(IDC_BUMAXCOLOR, OnBumaxcolor)
	ON_BN_CLICKED(IDC_RAAUTOMATION, OnRaautomation)
	ON_BN_CLICKED(IDC_RACUSTOM, OnRacustom)
	ON_EN_CHANGE(IDC_EDAUTODIV, OnChangeEdautodiv)
	ON_EN_CHANGE(IDC_EDCUSTDIV, OnChangeEdcustdiv)
	ON_LBN_DBLCLK(IDC_LIUSERCOLOR, OnDblclkLiusercolor)
	//}}AFX_MSG_MAP
	ON_MESSAGE(CPN_SELCHANGE, OnSelChange)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CColorForm diagnostics

#ifdef _DEBUG
void CColorForm::AssertValid() const
{
	CFormView::AssertValid();
}

void CColorForm::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CGLDemoDoc* CColorForm::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CGLDemoDoc)));
	return (CGLDemoDoc*)m_pDocument;
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CColorForm message handlers

CWnd* CColorForm::GetOpenGLView()
{
	return GetDocument()->GetGLDemoView();
}

void CColorForm::InitColorForm()
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_pOpenGL->m_pDS)
		return;

	m_nRaAutomation.SetCheck(pView->m_pOpenGL->m_pDS->m_bAutoCr);
	m_nRaCustom.SetCheck(!pView->m_pOpenGL->m_pDS->m_bAutoCr);

	m_nRaAutomation.EnableWindow(true);
	m_nRaCustom.EnableWindow(true);
	m_nBuMinColor.EnableWindow(pView->m_pOpenGL->m_pDS->m_bAutoCr);
	m_nBuMaxColor.EnableWindow(pView->m_pOpenGL->m_pDS->m_bAutoCr);
	m_nEdAutoDiv.EnableWindow(pView->m_pOpenGL->m_pDS->m_bAutoCr);
	m_nSpAutoDiv.EnableWindow(pView->m_pOpenGL->m_pDS->m_bAutoCr);
	m_GradientCr.EnableWindow(pView->m_pOpenGL->m_pDS->m_bAutoCr);
	m_nLiUserColor.EnableWindow(!pView->m_pOpenGL->m_pDS->m_bAutoCr);
	m_nEdCustDiv.EnableWindow(!pView->m_pOpenGL->m_pDS->m_bAutoCr);
	m_nSpCustDiv.EnableWindow(!pView->m_pOpenGL->m_pDS->m_bAutoCr);
	m_FCostomCr.EnableWindow(!pView->m_pOpenGL->m_pDS->m_bAutoCr);

	int n = pView->m_pOpenGL->m_pDS->m_UserCr.GetSize();
	ASSERT(n>0);
	m_nLiUserColor.ResetContent();
	for(int i=0; i<n; i++)
		m_nLiUserColor.AddString((LPCTSTR)i);

	COLORREF color = RGB((int)(pView->m_pOpenGL->m_pDS->m_BackCr.r*255), 
						(int)(pView->m_pOpenGL->m_pDS->m_BackCr.g*255), 
						(int)(pView->m_pOpenGL->m_pDS->m_BackCr.b*255));
	m_nBuBackColor.SetColour(color);
	color = RGB((int)(pView->m_pOpenGL->m_pDS->m_MaxCr.r*255), 
				(int)(pView->m_pOpenGL->m_pDS->m_MaxCr.g*255), 
				(int)(pView->m_pOpenGL->m_pDS->m_MaxCr.b*255));
	m_nBuMaxColor.SetColour(color);

	color = RGB((int)(pView->m_pOpenGL->m_pDS->m_MinCr.r*255), 
				(int)(pView->m_pOpenGL->m_pDS->m_MinCr.g*255), 
				(int)(pView->m_pOpenGL->m_pDS->m_MinCr.b*255));
	m_nBuMinColor.SetColour(color);

	color = RGB((int)(pView->m_pOpenGL->m_pDS->m_BorderCr.r*255), 
				(int)(pView->m_pOpenGL->m_pDS->m_BorderCr.g*255), 
				(int)(pView->m_pOpenGL->m_pDS->m_BorderCr.b*255));
	m_nBuBorderColor.SetColour(color);

	m_nAutoDiv = pView->m_pOpenGL->m_pDS->m_nCrLevel;
	m_nCustDiv = pView->m_pOpenGL->m_pDS->m_nUserCrNum;
	m_nSpAutoDiv.SetRange(2, 30);
	m_nSpCustDiv.SetRange(2, 20);
	m_nSpAutoDiv.SetPos(m_nAutoDiv);
	m_nSpCustDiv.SetPos(m_nCustDiv);
}

void CColorForm::OnBubackcolor() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_pOpenGL->m_pDS)
		return;

	COLORREF color = m_nBuBackColor.GetColour();
	pView->m_pOpenGL->m_pDS->m_BackCr.r = GetRValue(color) / 255.f;
	pView->m_pOpenGL->m_pDS->m_BackCr.g = GetGValue(color) / 255.f;
	pView->m_pOpenGL->m_pDS->m_BackCr.b = GetBValue(color) / 255.f;
	pView->InvalidateRect(NULL, FALSE);
}

void CColorForm::OnBubordercolor() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_pOpenGL->m_pDS)
		return;

	COLORREF color = m_nBuBorderColor.GetColour();
	pView->m_pOpenGL->m_pDS->m_BorderCr.r = GetRValue(color) / 255.f;
	pView->m_pOpenGL->m_pDS->m_BorderCr.g = GetGValue(color) / 255.f;
	pView->m_pOpenGL->m_pDS->m_BorderCr.b = GetBValue(color) / 255.f;
	pView->InvalidateRect(NULL, FALSE);
}

void CColorForm::OnBumincolor() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_pOpenGL->m_pDS)
		return;

	COLORREF color = m_nBuMinColor.GetColour();
	pView->m_pOpenGL->m_pDS->m_MinCr.r = GetRValue(color) / 255.f;
	pView->m_pOpenGL->m_pDS->m_MinCr.g = GetGValue(color) / 255.f;
	pView->m_pOpenGL->m_pDS->m_MinCr.b = GetBValue(color) / 255.f;
	pView->InvalidateRect(NULL, FALSE);
}

void CColorForm::OnBumaxcolor() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_pOpenGL->m_pDS)
		return;

	COLORREF color = m_nBuMaxColor.GetColour();
	pView->m_pOpenGL->m_pDS->m_MaxCr.r = GetRValue(color) / 255.f;
	pView->m_pOpenGL->m_pDS->m_MaxCr.g = GetGValue(color) / 255.f;
	pView->m_pOpenGL->m_pDS->m_MaxCr.b = GetBValue(color) / 255.f;
	pView->InvalidateRect(NULL, FALSE);
}

void CColorForm::OnRaautomation() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_pOpenGL->m_pDS)
		return;

	pView->m_pOpenGL->m_pDS->m_bAutoCr = true;
	m_nRaAutomation.SetCheck(TRUE);
	m_nRaCustom.SetCheck(FALSE);

	m_nBuMinColor.EnableWindow(TRUE);
	m_nBuMaxColor.EnableWindow(TRUE);
	m_nEdAutoDiv.EnableWindow(TRUE);
	m_nSpAutoDiv.EnableWindow(TRUE);
	m_GradientCr.EnableWindow(TRUE);

	m_nLiUserColor.EnableWindow(FALSE);
	m_nEdCustDiv.EnableWindow(FALSE);
	m_nSpCustDiv.EnableWindow(FALSE);
	m_FCostomCr.EnableWindow(FALSE);
	pView->InvalidateRect(NULL, FALSE);
}

void CColorForm::OnRacustom() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_pOpenGL->m_pDS)
		return;

	pView->m_pOpenGL->m_pDS->m_bAutoCr = false;
	m_nRaAutomation.SetCheck(FALSE);
	m_nRaCustom.SetCheck(TRUE);

	m_nBuMinColor.EnableWindow(FALSE);
	m_nBuMaxColor.EnableWindow(FALSE);
	m_nEdAutoDiv.EnableWindow(FALSE);
	m_nSpAutoDiv.EnableWindow(FALSE);
	m_GradientCr.EnableWindow(FALSE);

	m_nLiUserColor.EnableWindow(TRUE);
	m_nEdCustDiv.EnableWindow(TRUE);
	m_nSpCustDiv.EnableWindow(TRUE);
	m_FCostomCr.EnableWindow(TRUE);
	pView->InvalidateRect(NULL, FALSE);
}

void CColorForm::OnChangeEdautodiv() 
{
	if (!::IsWindow(m_nSpAutoDiv.m_hWnd))
		return;

	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_pOpenGL->m_pDS)
		return;

	m_nAutoDiv = m_nSpAutoDiv.GetPos();
	pView->m_pOpenGL->m_pDS->m_nCrLevel = m_nAutoDiv;
	pView->InvalidateRect(NULL, FALSE);
}

void CColorForm::OnChangeEdcustdiv() 
{
	if (!::IsWindow(m_nSpCustDiv.m_hWnd))
		return;

	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_pOpenGL->m_pDS)
		return;
	
	m_nCustDiv = m_nSpCustDiv.GetPos();
	pView->m_pOpenGL->m_pDS->m_nUserCrNum = m_nCustDiv;
	m_nLiUserColor.InvalidateRect(NULL, true);
	pView->InvalidateRect(NULL, FALSE);
}

LONG CColorForm::OnSelChange(UINT lParam, LONG wParam)
{
	switch(wParam)
	{
		case IDC_BUBACKCOLOR:
			OnBubackcolor();
			break;
		case IDC_BUMAXCOLOR:
			OnBumaxcolor();
			break;
		case IDC_BUMINCOLOR:
			OnBumincolor();
			break;
		case IDC_BUBORDERCOLOR:
			OnBubordercolor();
			break;
	}
	
	return true;
}

void CColorForm::OnDblclkLiusercolor() 
{
	CColorDialog  clrDlg;   
	
	if( clrDlg.DoModal() == IDOK )
	{              
	    DWORD color = (DWORD)clrDlg.GetColor();
		int k = m_nLiUserColor.GetCount();
		int j = m_nLiUserColor.GetCurSel();
		if(k<=j)	return;

		CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
		if (!pView || !pView->m_pOpenGL->m_pDS)
			return;

		pView->m_pOpenGL->m_pDS->m_UserCr.SetAt(j, color);
		m_nLiUserColor.InvalidateRect(NULL, FALSE);
		pView->InvalidateRect(NULL, FALSE);
    }
}
