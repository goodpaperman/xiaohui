// Form4D.cpp : implementation file
//

#include "stdafx.h"
#include "GLDemo.h"
#include "ChildFrm.h"
#include "TabView.h"
#include "GLDemoView.h"
#include "MiscDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CForm4D

IMPLEMENT_DYNCREATE(CForm4D, CFormView)

CForm4D::CForm4D()
	: CFormView(CForm4D::IDD)
{
	//{{AFX_DATA_INIT(CForm4D)
	m_nChX = FALSE;
	m_nChY = FALSE;
	m_nChZ = FALSE;
	m_nRaLinkXYZ = -1;
	m_nRaNoLinking = 1;
	m_nRaXLinkY = -1;
	m_nRaXLinkZ = -1;
	m_nRaYLinkZ = -1;
	m_nChNoCutting = TRUE;
	m_nRaCut1 = -1;
	m_nRaCut2 = -1;
	m_nRaCut3 = -1;
	//}}AFX_DATA_INIT
}

CForm4D::~CForm4D()
{
}

void CForm4D::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CForm4D)
	DDX_Control(pDX, IDC_CHLEGEND4D, m_ChLegend);
	DDX_Control(pDX, IDC_CHBORDER, m_ChBorder);
	DDX_Control(pDX, IDC_LINAMEOFMAPS, m_nLiNameOfMaps);
	DDX_Control(pDX, IDC_RACUTTYPE3, m_RaCut3);
	DDX_Control(pDX, IDC_RACUTTYPE2, m_RaCut2);
	DDX_Control(pDX, IDC_RACUTTYPE1, m_RaCut1);
	DDX_Control(pDX, IDC_CHNOCUTTING, m_ChNoCutting);
	DDX_Control(pDX, IDC_SLZ, m_SLZ);
	DDX_Control(pDX, IDC_SLY, m_SLY);
	DDX_Control(pDX, IDC_SLX, m_SLX);
	DDX_Control(pDX, IDC_RAYLINKZ, m_RaYLinkZ);
	DDX_Control(pDX, IDC_RAXLINKZ, m_RaXLinkZ);
	DDX_Control(pDX, IDC_RAXLINKY, m_RaXLinkY);
	DDX_Control(pDX, IDC_RANOLINKING, m_RaNoLinking);
	DDX_Control(pDX, IDC_RALINKXYZ, m_RaLinkXYZ);
	DDX_Control(pDX, IDC_CHZ, m_ChZ);
	DDX_Control(pDX, IDC_CHY, m_ChY);
	DDX_Control(pDX, IDC_CHX, m_ChX);
	DDX_Check(pDX, IDC_CHX, m_nChX);
	DDX_Check(pDX, IDC_CHY, m_nChY);
	DDX_Check(pDX, IDC_CHZ, m_nChZ);
	DDX_Radio(pDX, IDC_RALINKXYZ, m_nRaLinkXYZ);
	DDX_Radio(pDX, IDC_RANOLINKING, m_nRaNoLinking);
	DDX_Radio(pDX, IDC_RAXLINKY, m_nRaXLinkY);
	DDX_Radio(pDX, IDC_RAXLINKZ, m_nRaXLinkZ);
	DDX_Radio(pDX, IDC_RAYLINKZ, m_nRaYLinkZ);
	DDX_Check(pDX, IDC_CHNOCUTTING, m_nChNoCutting);
	DDX_Radio(pDX, IDC_RACUTTYPE1, m_nRaCut1);
	DDX_Radio(pDX, IDC_RACUTTYPE2, m_nRaCut2);
	DDX_Radio(pDX, IDC_RACUTTYPE3, m_nRaCut3);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CForm4D, CFormView)
	//{{AFX_MSG_MAP(CForm4D)
	ON_BN_CLICKED(IDC_CHX, OnChx)
	ON_BN_CLICKED(IDC_CHY, OnChy)
	ON_BN_CLICKED(IDC_CHZ, OnChz)
	ON_BN_CLICKED(IDC_RALINKXYZ, OnRalinkxyz)
	ON_BN_CLICKED(IDC_RANOLINKING, OnRanolinking)
	ON_BN_CLICKED(IDC_RAXLINKY, OnRaxlinky)
	ON_BN_CLICKED(IDC_RAXLINKZ, OnRaxlinkz)
	ON_BN_CLICKED(IDC_RAYLINKZ, OnRaylinkz)
	ON_WM_HSCROLL()
	ON_BN_CLICKED(IDC_CHNOCUTTING, OnChnocutting)
	ON_BN_CLICKED(IDC_RACUTTYPE1, OnRacuttype1)
	ON_BN_CLICKED(IDC_RACUTTYPE2, OnRacuttype2)
	ON_BN_CLICKED(IDC_RACUTTYPE3, OnRacuttype3)
	ON_LBN_SELCHANGE(IDC_LINAMEOFMAPS, OnSelchangeLinameofmaps)
	ON_LBN_DBLCLK(IDC_LINAMEOFMAPS, OnDblclkLinameofmaps)
	ON_BN_CLICKED(IDC_CHBORDER, OnChborder)
	ON_BN_CLICKED(IDC_CHLEGEND4D, OnChlegend4d)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CForm4D diagnostics

#ifdef _DEBUG
void CForm4D::AssertValid() const
{
	CFormView::AssertValid();
}

void CForm4D::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CGLDemoDoc* CForm4D::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CGLDemoDoc)));
	return (CGLDemoDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CForm4D message handlers

CWnd* CForm4D::GetOpenGLView()
{
	return GetDocument()->GetGLDemoView();
}

void CForm4D::WhichCutting()
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL4D.m_p4D)
		return;
	
	int x = pView->m_OpenGL4D.m_p4D->m_xBackForward = m_ChX.GetCheck();
	int y = pView->m_OpenGL4D.m_p4D->m_yBackForward = m_ChY.GetCheck();
	int z = pView->m_OpenGL4D.m_p4D->m_zBackForward = m_ChZ.GetCheck();

	if(m_nChNoCutting)
		pView->m_OpenGL4D.m_p4D->Cut4DType = NoCutting;
	else if(x == 1 && y == 1 && z == 1 && m_nRaCut1 == 1)
		pView->m_OpenGL4D.m_p4D->Cut4DType = TopFrontRightCorner;
	else if(x == 0 && y == 1 && z == 1 && m_nRaCut1 == 1)
		pView->m_OpenGL4D.m_p4D->Cut4DType = TopBackRightCorner;
	else if(x == 1 && y == 0 && z == 1 && m_nRaCut1 == 1)
		pView->m_OpenGL4D.m_p4D->Cut4DType = TopFrontLeftCorner;
	else if(x == 0 && y == 0 && z == 1 && m_nRaCut1 == 1)
		pView->m_OpenGL4D.m_p4D->Cut4DType = TopBackLeftCorner;
	else if(x == 1 && y == 1 && z == 0 && m_nRaCut1 == 1)
		pView->m_OpenGL4D.m_p4D->Cut4DType = BottomFrontRightCorner;
	else if(x == 0 && y == 1 && z == 0 && m_nRaCut1 == 1)
		pView->m_OpenGL4D.m_p4D->Cut4DType = BottomBackRightCorner;
	else if(x == 1 && y == 0 && z == 0 && m_nRaCut1 == 1)
		pView->m_OpenGL4D.m_p4D->Cut4DType = BottomFrontLeftCorner;
	else if(x == 0 && y == 0 && z == 0 && m_nRaCut1 == 1)
		pView->m_OpenGL4D.m_p4D->Cut4DType = BottomBackLeftCorner;
	else if(x == 0 && y == 1 && z == 0 && m_nRaCut3 == 1)
		pView->m_OpenGL4D.m_p4D->Cut4DType = RightCutFromTopToBottom;
	else if(x == 1 && y == 0 && z == 1 && m_nRaCut3 == 1)
		pView->m_OpenGL4D.m_p4D->Cut4DType = LeftCutFromTopToBottom;
	else if(x == 1 && y == 0 && z == 0 && m_nRaCut3 == 1)
		pView->m_OpenGL4D.m_p4D->Cut4DType = FrontCutFromTopToBottom;
	else if(x == 0 && y == 1 && z == 1 && m_nRaCut3 == 1)
		pView->m_OpenGL4D.m_p4D->Cut4DType = BackCutFromTopToBottom;
	else if(x == 0 && y == 0 && z == 1 && m_nRaCut3 == 1)
		pView->m_OpenGL4D.m_p4D->Cut4DType = CutFromMiddleToTop;
	else if(x == 1 && y == 1 && z == 0 && m_nRaCut3 == 1)
		pView->m_OpenGL4D.m_p4D->Cut4DType = CutFromMiddleToBottom;
	else if(x == 1 && y == 1 && z == 1 && m_nRaCut3 == 1)
		pView->m_OpenGL4D.m_p4D->Cut4DType = CutFromOutsideToInside;
	else if(x == 0 && y == 0 && z == 0 && m_nRaCut3 == 1)
		pView->m_OpenGL4D.m_p4D->Cut4DType = CutFromInsideToOutSide;

	else if(x == 0 && y == 0 && z == 0 && m_nRaCut2 == 1)
		pView->m_OpenGL4D.m_p4D->Cut4DType = xBottomBackLeftCorner;
	else if(x == 0 && y == 1 && z == 0 && m_nRaCut2 == 1)
		pView->m_OpenGL4D.m_p4D->Cut4DType = xBottomBackRightCorner;
	else if(x == 1 && y == 0 && z == 1 && m_nRaCut2 == 1)
		pView->m_OpenGL4D.m_p4D->Cut4DType = xTopFrontLeftCorner;
	else if(x == 1 && y == 0 && z == 0 && m_nRaCut2 == 1)
		pView->m_OpenGL4D.m_p4D->Cut4DType = xBottomFrontLeftCorner;
	else if(x == 0 && y == 1 && z == 1 && m_nRaCut2 == 1)
		pView->m_OpenGL4D.m_p4D->Cut4DType = xTopBackRightCorner;
	else if(x == 0 && y == 0 && z == 1 && m_nRaCut2 == 1)
		pView->m_OpenGL4D.m_p4D->Cut4DType = xTopBackLeftCorner;
	else if(x == 1 && y == 1 && z == 0 && m_nRaCut2 == 1)
		pView->m_OpenGL4D.m_p4D->Cut4DType = xBottomFrontRightCorner;
	else if(x == 1 && y == 1 && z == 1 && m_nRaCut2 == 1)
		pView->m_OpenGL4D.m_p4D->Cut4DType = xTopFrontRightCorner;
}

void CForm4D::OnChnocutting() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL4D.m_p4D)
		return;

	m_nChNoCutting = m_ChNoCutting.GetCheck();
	if(!m_nChNoCutting)
	{
		pView->m_OpenGL4D.m_p4D->Cut4DType = pView->m_OpenGL4D.m_p4D->OldCutting;

		m_ChX.EnableWindow(true);
		m_ChY.EnableWindow(true);
		m_ChZ.EnableWindow(true);

		m_RaLinkXYZ.EnableWindow(true);
		m_RaNoLinking.EnableWindow(true);
		m_RaXLinkY.EnableWindow(true);
		m_RaXLinkZ.EnableWindow(true);
		m_RaYLinkZ.EnableWindow(true);
		m_RaCut1.EnableWindow(true);
		m_RaCut2.EnableWindow(true);
		m_RaCut3.EnableWindow(true);

		m_SLX.EnableWindow(true);
		int GetState = m_RaNoLinking.GetCheck();
		if(GetState)
		{
			m_SLY.EnableWindow(true);
			m_SLZ.EnableWindow(true);
		}
		GetState = m_RaXLinkY.GetCheck();
		if(GetState)
			m_SLZ.EnableWindow(true);
		GetState = m_RaXLinkZ.GetCheck();
		if(GetState)
			m_SLY.EnableWindow(true);
		GetState = m_RaYLinkZ.GetCheck();
		if(GetState)
			m_SLY.EnableWindow(true);

		WhichCutting();
	}
	else
	{
		pView->m_OpenGL4D.m_p4D->OldCutting = pView->m_OpenGL4D.m_p4D->Cut4DType;
		pView->m_OpenGL4D.m_p4D->Cut4DType = NoCutting;
		m_SLX.EnableWindow(false);
		m_SLY.EnableWindow(false);
		m_SLZ.EnableWindow(false);

		m_ChX.EnableWindow(false);
		m_ChY.EnableWindow(false);
		m_ChZ.EnableWindow(false);
		m_RaCut1.EnableWindow(false);
		m_RaCut2.EnableWindow(false);
		m_RaCut3.EnableWindow(false);

		m_RaLinkXYZ.EnableWindow(false);
		m_RaNoLinking.EnableWindow(false);
		m_RaXLinkY.EnableWindow(false);
		m_RaXLinkZ.EnableWindow(false);
		m_RaYLinkZ.EnableWindow(false);
	}

	pView->InvalidateRect(NULL, FALSE);
}

void CForm4D::OnChx() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL4D.m_p4D)
		return;

	WhichCutting();

	pView->InvalidateRect(NULL, FALSE);
}

void CForm4D::OnChy() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL4D.m_p4D)
		return;

	WhichCutting();
	
	pView->InvalidateRect(NULL, FALSE);
}

void CForm4D::OnChz() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL4D.m_p4D)
		return;

	WhichCutting();
	
	pView->InvalidateRect(NULL, FALSE);
}

void CForm4D::OnRalinkxyz() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL4D.m_p4D)
		return;
	
	pView->m_OpenGL4D.m_p4D->m_CutingLink = XYZLink;
	
	m_RaLinkXYZ.SetCheck(TRUE);
	m_RaNoLinking.SetCheck(FALSE);
	m_RaXLinkY.SetCheck(FALSE);
	m_RaXLinkZ.SetCheck(FALSE);
	m_RaYLinkZ.SetCheck(FALSE);

	m_SLY.SetPos(m_SLX.GetPos());
	m_SLZ.SetPos(m_SLX.GetPos());
	pView->m_OpenGL4D.m_p4D->m_yCutting = pView->m_OpenGL4D.m_p4D->m_xCutting;
	pView->m_OpenGL4D.m_p4D->m_zCutting = pView->m_OpenGL4D.m_p4D->m_xCutting;

	m_SLX.EnableWindow(true);
	m_SLY.EnableWindow(false);
	m_SLZ.EnableWindow(false);

	GetCutPosition();

	pView->InvalidateRect(NULL, FALSE);
}

void CForm4D::OnRanolinking() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL4D.m_p4D)
		return;
	
	pView->m_OpenGL4D.m_p4D->m_CutingLink = NoLink;
	
	m_RaLinkXYZ.SetCheck(FALSE);
	m_RaNoLinking.SetCheck(TRUE);
	m_RaXLinkY.SetCheck(FALSE);
	m_RaXLinkZ.SetCheck(FALSE);
	m_RaYLinkZ.SetCheck(FALSE);

	m_SLX.EnableWindow(true);
	m_SLY.EnableWindow(true);
	m_SLZ.EnableWindow(true);

	pView->InvalidateRect(NULL, FALSE);
}

void CForm4D::OnRaxlinky() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL4D.m_p4D)
		return;
	
	pView->m_OpenGL4D.m_p4D->m_CutingLink = XYLink;
	
	m_RaLinkXYZ.SetCheck(FALSE);
	m_RaNoLinking.SetCheck(FALSE);
	m_RaXLinkY.SetCheck(TRUE);
	m_RaXLinkZ.SetCheck(FALSE);
	m_RaYLinkZ.SetCheck(FALSE);

	m_SLY.SetPos(m_SLX.GetPos());
	pView->m_OpenGL4D.m_p4D->m_yCutting = pView->m_OpenGL4D.m_p4D->m_xCutting;

	m_SLX.EnableWindow(true);
	m_SLY.EnableWindow(false);
	m_SLZ.EnableWindow(true);

	GetCutPosition();

	pView->InvalidateRect(NULL, FALSE);
}

void CForm4D::OnRaxlinkz() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL4D.m_p4D)
		return;
	
	pView->m_OpenGL4D.m_p4D->m_CutingLink = XZLink;
	
	m_RaLinkXYZ.SetCheck(FALSE);
	m_RaNoLinking.SetCheck(FALSE);
	m_RaXLinkY.SetCheck(FALSE);
	m_RaXLinkZ.SetCheck(TRUE);
	m_RaYLinkZ.SetCheck(FALSE);

	m_SLZ.SetPos(m_SLX.GetPos());
	pView->m_OpenGL4D.m_p4D->m_zCutting = pView->m_OpenGL4D.m_p4D->m_xCutting;

	m_SLX.EnableWindow(true);
	m_SLY.EnableWindow(true);
	m_SLZ.EnableWindow(false);

	GetCutPosition();

	pView->InvalidateRect(NULL, FALSE);
}

void CForm4D::OnRaylinkz() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL4D.m_p4D)
		return;
	
	pView->m_OpenGL4D.m_p4D->m_CutingLink = YZLink;
	
	m_RaLinkXYZ.SetCheck(FALSE);
	m_RaNoLinking.SetCheck(FALSE);
	m_RaXLinkY.SetCheck(FALSE);
	m_RaXLinkZ.SetCheck(FALSE);
	m_RaYLinkZ.SetCheck(TRUE);

	m_SLZ.SetPos(m_SLY.GetPos());
	pView->m_OpenGL4D.m_p4D->m_zCutting = pView->m_OpenGL4D.m_p4D->m_yCutting;

	m_SLX.EnableWindow(true);
	m_SLY.EnableWindow(true);
	m_SLZ.EnableWindow(false);

	GetCutPosition();

	pView->InvalidateRect(NULL, FALSE);
}

void CForm4D::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL4D.m_p4D)
	{
		CFormView::OnHScroll(nSBCode, nPos, pScrollBar);
		return;
	}

	switch( nSBCode )
	{
		case TB_PAGEDOWN:
		case TB_PAGEUP:
		case TB_THUMBTRACK:
			pView->m_OpenGL4D.m_p4D->m_xCutting = ((float)m_SLX.GetPos())/100;
			pView->m_OpenGL4D.m_p4D->m_yCutting = ((float)m_SLY.GetPos())/100;
			pView->m_OpenGL4D.m_p4D->m_zCutting = ((float)m_SLZ.GetPos())/100;

			if(pView->m_OpenGL4D.m_p4D->m_CutingLink == XYZLink)
			{
				m_SLY.SetPos(m_SLX.GetPos());
				m_SLZ.SetPos(m_SLX.GetPos());
				pView->m_OpenGL4D.m_p4D->m_yCutting = pView->m_OpenGL4D.m_p4D->m_xCutting;
				pView->m_OpenGL4D.m_p4D->m_zCutting = pView->m_OpenGL4D.m_p4D->m_xCutting;
			}
			else if(pView->m_OpenGL4D.m_p4D->m_CutingLink == XYLink)
			{
				m_SLY.SetPos(m_SLX.GetPos());
				pView->m_OpenGL4D.m_p4D->m_yCutting = pView->m_OpenGL4D.m_p4D->m_xCutting;
			}
			else if(pView->m_OpenGL4D.m_p4D->m_CutingLink == XZLink)
			{
				m_SLZ.SetPos(m_SLX.GetPos());
				pView->m_OpenGL4D.m_p4D->m_zCutting = pView->m_OpenGL4D.m_p4D->m_xCutting;
			}
			else if(pView->m_OpenGL4D.m_p4D->m_CutingLink == YZLink)
			{
				m_SLZ.SetPos(m_SLY.GetPos());
				pView->m_OpenGL4D.m_p4D->m_zCutting = pView->m_OpenGL4D.m_p4D->m_yCutting;
			}

			GetCutPosition();
			pView->InvalidateRect(NULL, FALSE); 
			break;
	}

	CFormView::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CForm4D::Init4DForm()
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL4D.m_p4D)
		return;

	SetMaps();

	m_ChLegend.SetCheck(pView->m_OpenGL4D.m_pDS->m_bLegend);
	m_ChBorder.SetCheck(pView->m_OpenGL4D.m_pDS->m_bBorder);

	m_SLX.SetPos((int)(pView->m_OpenGL4D.m_p4D->m_xCutting*100));
	m_SLY.SetPos((int)(pView->m_OpenGL4D.m_p4D->m_yCutting*100));
	m_SLZ.SetPos((int)(pView->m_OpenGL4D.m_p4D->m_zCutting*100));

	m_ChX.SetCheck(pView->m_OpenGL4D.m_p4D->m_xBackForward);
	m_ChY.SetCheck(pView->m_OpenGL4D.m_p4D->m_yBackForward);
	m_ChZ.SetCheck(pView->m_OpenGL4D.m_p4D->m_zBackForward);
	m_nRaCut1 = pView->m_OpenGL4D.m_p4D->m_CutCorner;
	m_RaCut1.SetCheck(m_nRaCut1);
	m_nRaCut2 = pView->m_OpenGL4D.m_p4D->m_KeepCorner;
	m_RaCut2.SetCheck(m_nRaCut2);
	m_nRaCut3 = pView->m_OpenGL4D.m_p4D->m_Parallel;
	m_RaCut3.SetCheck(m_nRaCut3);

	if(pView->m_OpenGL4D.m_p4D->Cut4DType == NoCutting) 
		m_nChNoCutting = true;
	else
		m_nChNoCutting = false;
	m_ChNoCutting.SetCheck(m_nChNoCutting);
	
	if(pView->m_OpenGL4D.m_p4D->m_CutingLink == XYZLink)
	{
		m_RaLinkXYZ.SetCheck(TRUE);
		m_RaNoLinking.SetCheck(FALSE);
		m_RaXLinkY.SetCheck(FALSE);
		m_RaXLinkZ.SetCheck(FALSE);
		m_RaYLinkZ.SetCheck(FALSE);
	}
	else if(pView->m_OpenGL4D.m_p4D->m_CutingLink == XYLink)
	{
		m_RaLinkXYZ.SetCheck(FALSE);
		m_RaNoLinking.SetCheck(FALSE);
		m_RaXLinkY.SetCheck(TRUE);
		m_RaXLinkZ.SetCheck(FALSE);
		m_RaYLinkZ.SetCheck(FALSE);
	}
	else if(pView->m_OpenGL4D.m_p4D->m_CutingLink == XZLink)
	{
		m_RaLinkXYZ.SetCheck(FALSE);
		m_RaNoLinking.SetCheck(FALSE);
		m_RaXLinkY.SetCheck(FALSE);
		m_RaXLinkZ.SetCheck(TRUE);
		m_RaYLinkZ.SetCheck(FALSE);
	}
	else if(pView->m_OpenGL4D.m_p4D->m_CutingLink == YZLink)
	{
		m_RaLinkXYZ.SetCheck(FALSE);
		m_RaNoLinking.SetCheck(FALSE);
		m_RaXLinkY.SetCheck(FALSE);
		m_RaXLinkZ.SetCheck(FALSE);
		m_RaYLinkZ.SetCheck(TRUE);
	}
	else
	{
		m_RaLinkXYZ.SetCheck(FALSE);
		m_RaNoLinking.SetCheck(TRUE);
		m_RaXLinkY.SetCheck(FALSE);
		m_RaXLinkZ.SetCheck(FALSE);
		m_RaYLinkZ.SetCheck(FALSE);
	}

	//if(pView->m_OpenGL4D.m_p4D->DisplayType == pView->MapType::Is4D)
	{
		m_ChNoCutting.EnableWindow(true);
		if(pView->m_OpenGL4D.m_p4D->Cut4DType != NoCutting)
		{
			m_SLX.EnableWindow(true);
			m_SLY.EnableWindow(true);
			m_SLZ.EnableWindow(true);

			m_ChX.EnableWindow(true);
			m_ChY.EnableWindow(true);
			m_ChZ.EnableWindow(true);
			m_RaCut1.EnableWindow(true);
			m_RaCut2.EnableWindow(true);
			m_RaCut3.EnableWindow(true);

			m_RaLinkXYZ.EnableWindow(true);
			m_RaNoLinking.EnableWindow(true);
			m_RaXLinkY.EnableWindow(true);
			m_RaXLinkZ.EnableWindow(true);
			m_RaYLinkZ.EnableWindow(true);
		}
		else
		{
			m_SLX.EnableWindow(false);
			m_SLY.EnableWindow(false);
			m_SLZ.EnableWindow(false);

			m_ChX.EnableWindow(false);
			m_ChY.EnableWindow(false);
			m_ChZ.EnableWindow(false);
			m_RaCut1.EnableWindow(false);
			m_RaCut2.EnableWindow(false);
			m_RaCut3.EnableWindow(false);

			m_RaLinkXYZ.EnableWindow(false);
			m_RaNoLinking.EnableWindow(false);
			m_RaXLinkY.EnableWindow(false);
			m_RaXLinkZ.EnableWindow(false);
			m_RaYLinkZ.EnableWindow(false);
		}
	}
	/*else
	{
		m_ChNoCutting.EnableWindow(false);
		m_SLX.EnableWindow(false);
		m_SLY.EnableWindow(false);
		m_SLZ.EnableWindow(false);

		m_ChX.EnableWindow(false);
		m_ChY.EnableWindow(false);
		m_ChZ.EnableWindow(false);
		m_RaCut1.EnableWindow(false);
		m_RaCut2.EnableWindow(false);
		m_RaCut3.EnableWindow(false);

		m_RaLinkXYZ.EnableWindow(false);
		m_RaNoLinking.EnableWindow(false);
		m_RaXLinkY.EnableWindow(false);
		m_RaXLinkZ.EnableWindow(false);
		m_RaYLinkZ.EnableWindow(false);
	}*/
	GetCutPosition();
}

void CForm4D::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();
	
	m_SLX.SetRange(0,100,TRUE);
	m_SLY.SetRange(0,100,TRUE);
	m_SLZ.SetRange(0,100,TRUE);

	m_SLX.SetPos(0);
	m_SLY.SetPos(0);
	m_SLZ.SetPos(0);

	Init4DForm();
}

void CForm4D::GetCutPosition()
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL4D.m_p4D)
		return;

	pView->m_OpenGL4D.m_p4D->xSE = (int)(pView->m_OpenGL4D.m_p4D->m_xCutting * pView->m_OpenGL4D.m_p4D->nX);
	pView->m_OpenGL4D.m_p4D->ySE = (int)(pView->m_OpenGL4D.m_p4D->m_yCutting * pView->m_OpenGL4D.m_p4D->nY);
	pView->m_OpenGL4D.m_p4D->zSE = (int)(pView->m_OpenGL4D.m_p4D->m_zCutting * pView->m_OpenGL4D.m_p4D->nZ);

	if(pView->m_OpenGL4D.m_p4D->xSE < 0) pView->m_OpenGL4D.m_p4D->xSE = 0;
	if(pView->m_OpenGL4D.m_p4D->xSE > pView->m_OpenGL4D.m_p4D->nX - 1) pView->m_OpenGL4D.m_p4D->xSE = pView->m_OpenGL4D.m_p4D->nX - 1;
	if(pView->m_OpenGL4D.m_p4D->ySE < 0) pView->m_OpenGL4D.m_p4D->ySE = 0;
	if(pView->m_OpenGL4D.m_p4D->ySE > pView->m_OpenGL4D.m_p4D->nY - 1) pView->m_OpenGL4D.m_p4D->ySE = pView->m_OpenGL4D.m_p4D->nY - 1;
	if(pView->m_OpenGL4D.m_p4D->zSE < 0) pView->m_OpenGL4D.m_p4D->zSE = 0;
	if(pView->m_OpenGL4D.m_p4D->zSE > pView->m_OpenGL4D.m_p4D->nZ - 1) pView->m_OpenGL4D.m_p4D->zSE = pView->m_OpenGL4D.m_p4D->nZ - 1;
}

void CForm4D::OnRacuttype1() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL4D.m_p4D)
		return;

	m_nRaCut1 = m_RaCut1.GetCheck();
	m_nRaCut2 = !m_nRaCut1;
	m_nRaCut3 = !m_nRaCut1;
	pView->m_OpenGL4D.m_p4D->m_CutCorner = m_nRaCut1;
	pView->m_OpenGL4D.m_p4D->m_KeepCorner = m_nRaCut2;
	pView->m_OpenGL4D.m_p4D->m_Parallel = m_nRaCut3;
	m_RaCut1.SetCheck(m_nRaCut1);
	m_RaCut2.SetCheck(m_nRaCut2);
	m_RaCut3.SetCheck(m_nRaCut3);
	WhichCutting();
	pView->InvalidateRect(NULL, FALSE);
}

void CForm4D::OnRacuttype2() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL4D.m_p4D)
		return;

	m_nRaCut2 = m_RaCut2.GetCheck();
	m_nRaCut3 = !m_nRaCut2;
	m_nRaCut1 = !m_nRaCut2;
	pView->m_OpenGL4D.m_p4D->m_CutCorner = m_nRaCut1;
	pView->m_OpenGL4D.m_p4D->m_KeepCorner = m_nRaCut2;
	pView->m_OpenGL4D.m_p4D->m_Parallel = m_nRaCut3;
	m_RaCut1.SetCheck(m_nRaCut1);
	m_RaCut2.SetCheck(m_nRaCut2);
	m_RaCut3.SetCheck(m_nRaCut3);
	WhichCutting();
	pView->InvalidateRect(NULL, FALSE);
}

void CForm4D::OnRacuttype3() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL4D.m_p4D)
		return;

	m_nRaCut3 = m_RaCut3.GetCheck();
	m_nRaCut2 = !m_nRaCut3;
	m_nRaCut1 = !m_nRaCut3;
	pView->m_OpenGL4D.m_p4D->m_CutCorner = m_nRaCut1;
	pView->m_OpenGL4D.m_p4D->m_KeepCorner = m_nRaCut2;
	pView->m_OpenGL4D.m_p4D->m_Parallel = m_nRaCut3;
	m_RaCut1.SetCheck(m_nRaCut1);
	m_RaCut2.SetCheck(m_nRaCut2);
	m_RaCut3.SetCheck(m_nRaCut3);
	WhichCutting();
	pView->InvalidateRect(NULL, FALSE); 
}

void CForm4D::SetMaps()
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL4D.m_pDS)
		return;

	m_nLiNameOfMaps.ResetContent();
	int n = pView->m_OpenGL4D.m_DS.GetSize();
	for(int i=0; i<n; i++)
		m_nLiNameOfMaps.AddString(pView->m_OpenGL4D.m_DS[i].m_MapName);
	m_nLiNameOfMaps.SetCurSel(0);
}

void CForm4D::OnSelchangeLinameofmaps() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL4D.m_pDS)
		return;
		
	int i = m_nLiNameOfMaps.GetCount();
	if( i<=0 )  return;

    i = m_nLiNameOfMaps.GetCurSel();
    if(i != LB_ERR)
    { 
		if(&(pView->m_OpenGL4D.m_DS[i]) != pView->m_OpenGL4D.m_pDS)
		{
			pView->m_OpenGL4D.KillOpenGLTimer(pView->m_OpenGL4D.m_pDS->m_Rotate);
			pView->m_OpenGL4D.m_p4D = &(pView->m_OpenGL4D.m_DS[i]);
			pView->m_OpenGL4D.m_pDS = pView->m_OpenGL4D.m_p4D;
			pView->m_pOpenGL->m_pDS = pView->m_OpenGL4D.m_p4D;
			CTabView* pWnd = (CTabView*)GetParent();
			((CTabView*)GetParent())->Init4DSetting();
			pView->InvalidateRect(NULL, FALSE);
			if((pView->m_OpenGL4D.m_pDS->m_Move == RANDROTAT || 
				pView->m_OpenGL4D.m_pDS->m_Move == CENTERROTAT) &&
				pView->m_OpenGL4D.m_pDS->m_Rotate != NONE)
				pView->m_OpenGL4D.SetOpenGLTimer(pView->m_OpenGL4D.m_pDS->m_Rotate);
			m_nLiNameOfMaps.SetCurSel(i);
		}
	}
}

void CForm4D::OnDblclkLinameofmaps() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL4D.m_pDS)
		return;

	int i = m_nLiNameOfMaps.GetCount();
	if( i<=0 )  return;

    i = m_nLiNameOfMaps.GetCurSel();
    if(i != LB_ERR)
    { 
		CString str;
		m_nLiNameOfMaps.GetText(i, str);
		
		CChangeMapName Name;

		Name.m_nEdNameFrom = str;
		Name.m_nEdNameTo   = str;

		if( Name.DoModal() == IDOK )
		{
			pView->m_OpenGL4D.m_pDS->m_MapName = Name.m_nEdNameTo;
			m_nLiNameOfMaps.ResetContent();
			int n = pView->m_OpenGL4D.m_DS.GetSize();
			for(int j=0; j<n; j++)
				m_nLiNameOfMaps.AddString(pView->m_OpenGL4D.m_DS[j].m_MapName);
			m_nLiNameOfMaps.SetCurSel(i);
		}
	}
}

void CForm4D::OnChborder() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL4D.m_pDS)
		return;

	pView->m_OpenGL4D.m_pDS->m_bBorder = m_ChBorder.GetCheck();
	if(!pView->m_OpenGL4D.m_pDS->m_bBorder)
		pView->m_OpenGL4D.m_pDS->m_bAxes = 0;
	else
		pView->m_OpenGL4D.m_pDS->m_bAxes = 1;
	pView->InvalidateRect(NULL, FALSE);
}

void CForm4D::OnChlegend4d() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL4D.m_pDS)
		return;

	pView->m_OpenGL4D.m_pDS->m_bLegend = m_ChLegend.GetCheck();
	pView->InvalidateRect(NULL, FALSE);
}
