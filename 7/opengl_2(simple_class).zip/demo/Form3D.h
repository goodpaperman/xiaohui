#if !defined(AFX_FORM3D_H__9DA38EE8_FADB_11D3_85D8_0008C777FFEE__INCLUDED_)
#define AFX_FORM3D_H__9DA38EE8_FADB_11D3_85D8_0008C777FFEE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Form3D.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CForm3D form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "GLDemoDoc.h"
#include "ColourPicker.h"

class CForm3D : public CFormView
{
protected:
	CForm3D();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CForm3D)

// Form Data
public:
	//{{AFX_DATA(CForm3D)
	enum { IDD = IDD_DLG3D };
	CButton	m_nChMarkLine;
	CSliderCtrl	m_nSlMark;
	CComboBox	m_nCoMark;
	CColourPicker	m_nBuColor;
	CButton	m_nChLable;
	CButton	m_nChMark;
	CListBox	m_nLiNameOfMaps;
	CButton	m_nChAxis;
	CButton	m_nChBase;
	CButton	m_nChSide;
	CButton	m_nChLegend;
	CButton	m_nChBox;
	CButton	m_nRa2D;
	CButton	m_nRaGrid;
	CButton	m_nRaSurface;
	//}}AFX_DATA

// Attributes
public:
	CGLDemoDoc* GetDocument();

// Operations
public:
	void  Init3DForm();
	CWnd* GetOpenGLView();
	void SetMaps();
	void EnableMarker();
	void DisableMarker();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CForm3D)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CForm3D();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CForm3D)
	afx_msg void OnChaxis();
	afx_msg void OnChbase();
	afx_msg void OnChbaseside();
	afx_msg void OnChlegend();
	afx_msg void OnChline();
	afx_msg void OnRa2d();
	afx_msg void OnRagrid();
	afx_msg void OnRasurface();
	afx_msg void OnDblclkLinameofmaps();
	afx_msg void OnChmark();
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnSelchangeComark();
	afx_msg void OnBucolor();
	afx_msg void OnChlable();
	afx_msg void OnChmarkline();
	afx_msg void OnSelchangeLinameofmaps();
	//}}AFX_MSG
	afx_msg LONG OnSelChange(UINT lParam, LONG wParam);
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in GLDemoView.cpp
inline CGLDemoDoc* CForm3D::GetDocument()
   { return (CGLDemoDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FORM3D_H__9DA38EE8_FADB_11D3_85D8_0008C777FFEE__INCLUDED_)
