// GLDemoView.cpp : implementation of the CGLDemoView class
//

#include "stdafx.h"
#include "GLDemo.h"

#include "GLDemoDoc.h"
#include "GLDemoView.h"
#include "ChildFrm.h"
#include "TabView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGLDemoView

IMPLEMENT_DYNCREATE(CGLDemoView, CView)

BEGIN_MESSAGE_MAP(CGLDemoView, CView)
	//{{AFX_MSG_MAP(CGLDemoView)
	ON_WM_SIZE()
	ON_WM_TIMER()
	ON_WM_ERASEBKGND()
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_COMMAND(ID_FILE_PRINT, OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, OnFilePrintPreview)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGLDemoView construction/destruction

CGLDemoView::CGLDemoView()
{
	// TODO: add construction code here
	m_pOpenGL  = &m_OpenGL3D;
	hDIB	   = NULL;
	m_palDIB   = new CPalette;

	m_bSaveRectBMP	   = FALSE;
	m_nSaveBMPFlag = BMPCLIENT;
}

CGLDemoView::~CGLDemoView()
{
	if( hDIB != NULL )
    {
        ::GlobalUnlock(hDIB);
	    ::GlobalFree(hDIB);
	    hDIB = NULL;
	}  
	if (m_palDIB != NULL)
	{
		delete m_palDIB;
		m_palDIB = NULL;
	}
}

BOOL CGLDemoView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	cs.style |= WS_CLIPSIBLINGS | WS_CLIPCHILDREN;
	return CView::PreCreateWindow(cs);
}

void CGLDemoView::EnableTabView()
{
	CChildFrame* pChild = (CChildFrame*)GetParent()->GetParent();
	pChild->m_wndSplitter.EnableWindow();
	CTabView* pTabView  = (CTabView*)(pChild->m_wndSplitter.GetPane(0, 0));
	pChild->m_wndSplitter.SetColumnInfo(0, pTabView->m_TabWidth, 30);
	pChild->m_wndSplitter.RecalcLayout();
}

void CGLDemoView::PrintDIB(CDC* pDC)
{
	if(hDIB == NULL || m_palDIB == NULL) return;

	int cxPage = pDC->GetDeviceCaps(HORZRES);
	int cxInch = pDC->GetDeviceCaps(LOGPIXELSX);
	int cyInch = pDC->GetDeviceCaps(LOGPIXELSY);
	
	char* pDIB = (char*)::GlobalLock(hDIB);
	int cxDIB  = (int)  ::DIBWidth(pDIB);
	int cyDIB  = (int)  ::DIBHeight(pDIB);
	if( cxDIB <= 0 || cyDIB <= 0 ) return;

	RECT rcDst, rcDIB;
	rcDIB.top    = 0;
	rcDIB.left	 = 0;
	rcDIB.right  = cxDIB;
	rcDIB.bottom = cyDIB;
	rcDst.left   = 0;
	rcDst.top    = 0;
	rcDst.right  = cxPage;
	rcDst.bottom = (int)(1.0 * cyDIB * cxPage * cyInch / cxDIB / cxInch);

	::PaintDIB(pDC->m_hDC, &rcDst, (HDIB)hDIB, &rcDIB, (HPALETTE)m_palDIB->m_hObject);
}

/////////////////////////////////////////////////////////////////////////////
// CGLDemoView drawing

void CGLDemoView::OnDraw(CDC* pDC)
{
	CGLDemoDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	
	if (pDC->IsPrinting()) 
		PrintDIB(pDC);
	else
		m_pOpenGL->OpenGLRendering();
}

/////////////////////////////////////////////////////////////////////////////
// CGLDemoView printing

BOOL CGLDemoView::OnPreparePrinting(CPrintInfo* pInfo)
{
	pInfo->SetMaxPage(1);
	m_nSaveBMPFlag = BMPCLIENT;
	return DoPreparePrinting(pInfo);
}

void CGLDemoView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CGLDemoView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

void CGLDemoView::GetDIB()
{
	if(hDIB != NULL)
	{
		::GlobalUnlock(hDIB);
		::GlobalFree(hDIB);
		hDIB = NULL;
	}
	switch(m_nSaveBMPFlag)
	{
	case BMPWINDOW:
		hDIB = ::CopyWindowToDIB(AfxGetApp()->m_pMainWnd->GetSafeHwnd(), m_nSaveBMPFlag);
		break;
	case BMPCLIENT:
		hDIB = ::CopyWindowToDIB(GetSafeHwnd(), m_nSaveBMPFlag);
		break;
	case BMPRECT:
		hDIB = ::CopyRectToDIB(GetSafeHwnd(), &m_Rect);
		break;
	}
}

void CGLDemoView::FreeDIB()
{
	::GlobalUnlock(hDIB);
	::GlobalFree(hDIB);
	hDIB = NULL;
}

void CGLDemoView::OnFilePrint() 
{
	m_nSaveBMPFlag = BMPCLIENT;
	GetDIB();

	CView::OnFilePrint();
}

void CGLDemoView::OnFilePrintPreview() 
{
	m_nSaveBMPFlag = BMPCLIENT;
	GetDIB();

	CView::OnFilePrintPreview();
}

void CGLDemoView::SaveToBMP()
{
	GetDIB();
	if( hDIB == NULL )
	{
		MessageBox("HDIB handle is NULL, save abort !!!");
		return;
	}
	CFileDialog  dilg(FALSE, NULL, "*.bmp", OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT,
					  "Bitmap Files (*.bmp)|*.bmp|All Files (*.*)|*.*||");
												   
	dilg.m_ofn.lpstrTitle="Save Bitmap Dialog";
	if( dilg.DoModal() != IDOK )
	{
		FreeDIB();
		return;
	}
	CString pszPathName = dilg.GetPathName();

	CFile file;
	CFileException fe;

	if (!file.Open(pszPathName, CFile::modeCreate |
	  CFile::modeReadWrite | CFile::shareExclusive, &fe))
	{
		FreeDIB();
		MessageBox("Cannot save the BMP file <" + pszPathName + "> !!!");
		return;
	}

	BOOL bSuccess = FALSE;
	TRY
	{
		BeginWaitCursor();
		bSuccess = ::SaveDIB(hDIB, (HANDLE)file.m_hFile);
		file.Close();
	}
	CATCH (CException, eSave)
	{
		file.Abort(); // will not throw an exception
		EndWaitCursor();
		FreeDIB();
		MessageBox("Cannot save the BMP file <" + pszPathName + "> !!!");
		return;
	}
	END_CATCH
	EndWaitCursor();
	if (!bSuccess)  
	{
		FreeDIB();
		MessageBox("Cannot save the BMP file <" + pszPathName + "> !!!");
	}

	FreeDIB();
}

/////////////////////////////////////////////////////////////////////////////
// CGLDemoView diagnostics

#ifdef _DEBUG
void CGLDemoView::AssertValid() const
{
	CView::AssertValid();
}

void CGLDemoView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CGLDemoDoc* CGLDemoView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CGLDemoDoc)));
	return (CGLDemoDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CGLDemoView message handlers

void CGLDemoView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	m_pOpenGL->OpenGLSize(cx, cy);
}

void CGLDemoView::OnTimer(UINT nIDEvent) 
{
	m_pOpenGL->OpenGLTimer((CRotateType)nIDEvent);
	
	CView::OnTimer(nIDEvent);
}

BOOL CGLDemoView::OnEraseBkgnd(CDC* pDC) 
{
	return FALSE;
}

int CGLDemoView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	m_pOpenGL->InitOpenGL(GetSafeHwnd());

	return 0;
}

void CGLDemoView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	if (!m_bSaveRectBMP)
		m_pOpenGL->LButtonDown(point);
	else
	{
		c_down = point;
		c_last = point;
		Zoom_in_First = point;        //���������������Ͻ�����
		SetCapture();                 //�������뽹��
		::SetCursor ( AfxGetApp()->LoadStandardCursor( IDC_SIZENWSE ) ); //�ı������״̬
	}
	
	CView::OnLButtonDown(nFlags, point);
}

void CGLDemoView::OnMouseMove(UINT nFlags, CPoint point) 
{
	if (!m_bSaveRectBMP)
		m_pOpenGL->MouseMove(nFlags, point);
	else if (GetCapture() == this)
	{
		CClientDC dc(this);
		OnPrepareDC(&dc);
		dc.DPtoLP(&point);
		//��������Ƥ������һ�����ο�
	    CRect rect(c_down.x, c_down.y, c_last.x, c_last.y);
	    rect.NormalizeRect();
	    dc.DrawFocusRect(rect);
	    rect.SetRect(c_down.x, c_down.y, point.x, point.y);
	    rect.NormalizeRect();
        dc.DrawFocusRect(rect);
	    c_last = point;
	}
	
	CView::OnMouseMove(nFlags, point);
}

void CGLDemoView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	if (!m_bSaveRectBMP)
	{
		m_pOpenGL->LButtonUp(point);
		GetDocument()->SetModifiedFlag(GetDocument()->m_bModifiedFlag);
	}
	else
	{
		Zoom_in_Last = point;           //���������������½�����
        ::SetCursor ( AfxGetApp()->LoadStandardCursor( IDC_ARROW ) ); //�ı������״̬
        ReleaseCapture();               //�ͷ�������뽹��
		m_bSaveRectBMP = FALSE;
		m_Rect.left	  = Zoom_in_First.x + 1;
		m_Rect.top    = Zoom_in_First.y + 1;
		m_Rect.right  = Zoom_in_Last.x  - 1;
		m_Rect.bottom = Zoom_in_Last.y  - 1;
		c_down.x = c_down.y = 0;
		c_last.x = c_last.y = 0;
		SaveToBMP();
	}

	CView::OnLButtonUp(nFlags, point);
}

void CGLDemoView::OnDestroy() 
{
	m_pOpenGL->DestroyOpenGL();

	CView::OnDestroy();
}

BOOL CGLDemoView::ConfirmOverWrite()
{
	if (m_pOpenGL->m_DataGroup < G4D)
	{
		if(m_OpenGL3D.m_p3D)
		{
			int yn = AfxMessageBox("Are you sure to replace the current map using new data?", MB_YESNO);
			if(yn == IDNO)
			   return FALSE;
		}
	}
	else
	{
		if(m_OpenGL4D.m_p4D)
		{
			int yn = AfxMessageBox("Are you sure to replace the current map using new data?", MB_YESNO);
			if(yn == IDNO)
			   return FALSE;
		}
	}

	return TRUE;
}

void CGLDemoView::LoadMarkerData(const char* FileName)
{
	if (m_pOpenGL->LoadMarkerData(FileName))
	{
		CMDIFrameWnd* pWnd  = (CMDIFrameWnd*)(AfxGetApp()->m_pMainWnd);
		CChildFrame* pChild = (CChildFrame*)(pWnd->MDIGetActive());
		CTabView* pTabView  = (CTabView*)(pChild->m_wndSplitter.GetPane(0, 0));
		if (m_pOpenGL->m_DataGroup < G4D)
			pTabView->m_p3D->Init3DForm();
		else
			pTabView->m_p4D->Init4DForm();
		pTabView->m_pZoom->InitZoomForm();
		pTabView->m_pColor->InitColorForm();
	}
}

void CGLDemoView::Show3DForm()
{
	CChildFrame* pChild = (CChildFrame*)GetParent()->GetParent();
	if (!pChild)
		return;

	if (m_pOpenGL->m_pDS && m_pOpenGL->m_pDS->m_Rotate != NONE)
		m_pOpenGL->KillOpenGLTimer(m_pOpenGL->m_pDS->m_Rotate);
	if (m_pOpenGL->m_DataGroup == G4D)
	{
		if(m_OpenGL4D.m_p4D != NULL)
			((CTabView*)(pChild->m_wndSplitter.GetPane(0, 0)))->Remove4DForm();
		m_pOpenGL->DestroyOpenGL();
		m_pOpenGL = &m_OpenGL3D;
		m_pOpenGL->InitOpenGL(GetSafeHwnd());
	}

	CTabView* pTabView  = (CTabView*)(pChild->m_wndSplitter.GetPane(0, 0));
	if (!pTabView->m_p3D)
		pTabView->m_p3D = (CForm3D*)pTabView->m_TabCtrl.AddTabView(RUNTIME_CLASS(CForm3D), 
						   GetDocument(), pTabView, 0, "3D");
	pTabView->m_pZoom->OnInitialUpdate();
	pTabView->m_pZoom->InitZoomForm();
	pTabView->m_pColor->OnInitialUpdate();
	pTabView->m_pColor->InitColorForm();
	pTabView->m_TabCtrl.SetCurSel(0);        
	pTabView->m_TabCtrl.ShowSelTabView();
	pTabView->m_p3D->OnInitialUpdate();
	pTabView->m_p3D->Init3DForm();
	EnableTabView();
}

void CGLDemoView::Load3DData(FILE* fp, char type)
{
	if (!ConfirmOverWrite())
	   return;

	m_OpenGL3D.Load3DData(fp, type);
	Show3DForm();
}

void CGLDemoView::Show4DForm()
{
	CChildFrame* pChild = (CChildFrame*)GetParent()->GetParent();
	if (!pChild)
		return;

	if (m_pOpenGL->m_pDS && m_pOpenGL->m_pDS->m_Rotate != NONE)
		m_pOpenGL->KillOpenGLTimer(m_pOpenGL->m_pDS->m_Rotate);
	if (m_pOpenGL->m_DataGroup < G4D)
	{
		if(m_OpenGL3D.m_p3D != NULL)
			((CTabView*)(pChild->m_wndSplitter.GetPane(0, 0)))->Remove3DForm();
		m_pOpenGL->DestroyOpenGL();
		m_pOpenGL = &m_OpenGL4D;
		m_pOpenGL->InitOpenGL(GetSafeHwnd());
	}

	CTabView* pTabView  = (CTabView*)(pChild->m_wndSplitter.GetPane(0, 0));
	if (!pTabView->m_p4D)
		pTabView->m_p4D = (CForm4D*)pTabView->m_TabCtrl.AddTabView(RUNTIME_CLASS(CForm4D), 
						   GetDocument(), pTabView, 0, "4D");
	pTabView->m_pZoom->OnInitialUpdate();
	pTabView->m_pZoom->InitZoomForm();
	pTabView->m_pColor->OnInitialUpdate();
	pTabView->m_pColor->InitColorForm();
	pTabView->m_TabCtrl.SetCurSel(0);        
	pTabView->m_TabCtrl.ShowSelTabView();
	pTabView->m_p4D->OnInitialUpdate();
	pTabView->m_p4D->Init4DForm();
	EnableTabView();
}

void CGLDemoView::Load4DData(FILE* fp, char type)
{
	if (!ConfirmOverWrite())
	   return;

	m_OpenGL4D.Load4DData(fp, type);
	Show4DForm();
}
