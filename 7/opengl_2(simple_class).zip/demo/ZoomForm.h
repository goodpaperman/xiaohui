#if !defined(AFX_ZOOMFORM_H__9DA38EE7_FADB_11D3_85D8_0008C777FFEE__INCLUDED_)
#define AFX_ZOOMFORM_H__9DA38EE7_FADB_11D3_85D8_0008C777FFEE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ZoomForm.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CZoomForm form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "GLDemoDoc.h"

class CZoomForm : public CFormView
{
protected:
	CZoomForm();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CZoomForm)

// Form Data
public:
	//{{AFX_DATA(CZoomForm)
	enum { IDD = IDD_DLGZOOM };
	CButton	m_RCENTER;
	CButton	m_RRANDOM;
	CButton	m_RMOVE;
	CSliderCtrl	m_SSpeed;
	CComboBox	m_CRType;
	CSliderCtrl	m_SZ;
	CSliderCtrl	m_SY;
	CSliderCtrl	m_SX;
	CButton	m_RXYZ;
	CButton	m_RYZ;
	CButton	m_RXZ;
	CButton	m_RXY;
	CButton	m_RNO;
	//}}AFX_DATA

// Attributes
public:
	CGLDemoDoc* GetDocument();

// Operations
public:
	void  InitZoomForm();
	CWnd* GetOpenGLView();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CZoomForm)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CZoomForm();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CZoomForm)
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnRno();
	afx_msg void OnRxy();
	afx_msg void OnRxz();
	afx_msg void OnRyz();
	afx_msg void OnRxyz();
	afx_msg void OnSelchangeCrtype();
	afx_msg void OnRmove();
	afx_msg void OnRrandom();
	afx_msg void OnRcenter();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in GLDemoView.cpp
inline CGLDemoDoc* CZoomForm::GetDocument()
   { return (CGLDemoDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ZOOMFORM_H__9DA38EE7_FADB_11D3_85D8_0008C777FFEE__INCLUDED_)
