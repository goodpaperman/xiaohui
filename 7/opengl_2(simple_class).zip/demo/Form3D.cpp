// Form3D.cpp : implementation file
//

#include "stdafx.h"
#include "GLDemo.h"
#include "ChildFrm.h"
#include "TabView.h"
#include "GLDemoView.h"
#include "MiscDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CForm3D

IMPLEMENT_DYNCREATE(CForm3D, CFormView)

CForm3D::CForm3D()
	: CFormView(CForm3D::IDD)
{
	//{{AFX_DATA_INIT(CForm3D)
	//}}AFX_DATA_INIT
}

CForm3D::~CForm3D()
{
}

void CForm3D::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CForm3D)
	DDX_Control(pDX, IDC_CHMARKLINE, m_nChMarkLine);
	DDX_Control(pDX, IDC_SLMARK, m_nSlMark);
	DDX_Control(pDX, IDC_COMARK, m_nCoMark);
	DDX_Control(pDX, IDC_BUCOLOR, m_nBuColor);
	DDX_Control(pDX, IDC_CHLABLE, m_nChLable);
	DDX_Control(pDX, IDC_CHMARK, m_nChMark);
	DDX_Control(pDX, IDC_LINAMEOFMAPS, m_nLiNameOfMaps);
	DDX_Control(pDX, IDC_CHAXIS, m_nChAxis);
	DDX_Control(pDX, IDC_CHBASE, m_nChBase);
	DDX_Control(pDX, IDC_CHBASESIDE, m_nChSide);
	DDX_Control(pDX, IDC_CHLEGEND, m_nChLegend);
	DDX_Control(pDX, IDC_CHLINE, m_nChBox);
	DDX_Control(pDX, IDC_RA2D, m_nRa2D);
	DDX_Control(pDX, IDC_RAGRID, m_nRaGrid);
	DDX_Control(pDX, IDC_RASURFACE, m_nRaSurface);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CForm3D, CFormView)
	//{{AFX_MSG_MAP(CForm3D)
	ON_BN_CLICKED(IDC_CHAXIS, OnChaxis)
	ON_BN_CLICKED(IDC_CHBASE, OnChbase)
	ON_BN_CLICKED(IDC_CHBASESIDE, OnChbaseside)
	ON_BN_CLICKED(IDC_CHLEGEND, OnChlegend)
	ON_BN_CLICKED(IDC_CHLINE, OnChline)
	ON_BN_CLICKED(IDC_RA2D, OnRa2d)
	ON_BN_CLICKED(IDC_RAGRID, OnRagrid)
	ON_BN_CLICKED(IDC_RASURFACE, OnRasurface)
	ON_LBN_DBLCLK(IDC_LINAMEOFMAPS, OnDblclkLinameofmaps)
	ON_BN_CLICKED(IDC_CHMARK, OnChmark)
	ON_WM_VSCROLL()
	ON_CBN_SELCHANGE(IDC_COMARK, OnSelchangeComark)
	ON_BN_CLICKED(IDC_BUCOLOR, OnBucolor)
	ON_BN_CLICKED(IDC_CHLABLE, OnChlable)
	ON_BN_CLICKED(IDC_CHMARKLINE, OnChmarkline)
	ON_LBN_SELCHANGE(IDC_LINAMEOFMAPS, OnSelchangeLinameofmaps)
	//}}AFX_MSG_MAP
	ON_MESSAGE(CPN_SELCHANGE, OnSelChange)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CForm3D diagnostics

#ifdef _DEBUG
void CForm3D::AssertValid() const
{
	CFormView::AssertValid();
}

void CForm3D::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CGLDemoDoc* CForm3D::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CGLDemoDoc)));
	return (CGLDemoDoc*)m_pDocument;
}

#endif //_DEBUG

CWnd* CForm3D::GetOpenGLView()
{
	return GetDocument()->GetGLDemoView();
}

void CForm3D::Init3DForm()
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL3D.m_pDS)
		return;

	SetMaps();
	m_nChAxis.SetCheck(pView->m_OpenGL3D.m_pDS->m_bAxes);
	m_nChSide.SetCheck(pView->m_OpenGL3D.m_pDS->m_bSide);
	m_nChLegend.SetCheck(pView->m_OpenGL3D.m_pDS->m_bLegend);
	m_nChBox.SetCheck(pView->m_OpenGL3D.m_pDS->m_bBorder);
	m_nChBase.SetCheck(pView->m_OpenGL3D.m_pDS->m_bBase);
	m_nChAxis.EnableWindow(pView->m_OpenGL3D.m_pDS->m_bBorder);

	m_nChMark.SetCheck(pView->m_OpenGL3D.m_pDS->m_bMark);
	m_nChMarkLine.SetCheck(pView->m_OpenGL3D.m_pDS->m_bMarkLine);
	m_nChLable.SetCheck(pView->m_OpenGL3D.m_pDS->m_bLable);

	if(pView->m_OpenGL3D.m_pDS->m_MapType == SURFACE)
	{
		m_nRaSurface.SetCheck(1);
		m_nChSide.EnableWindow(true);
		m_nChBase.EnableWindow(true);
	}
	else
		m_nRaSurface.SetCheck(0);
	if(pView->m_OpenGL3D.m_pDS->m_MapType == GRID)
	{
		m_nRaGrid.SetCheck(1);
		m_nChSide.EnableWindow(false);
		m_nChBase.EnableWindow(false);
	}
	else
		m_nRaGrid.SetCheck(0);
	if(pView->m_OpenGL3D.m_pDS->m_MapType == FLAT)
	{
		m_nRa2D.SetCheck(1);
		m_nChSide.EnableWindow(false);
		m_nChBase.EnableWindow(false);
		m_nChBox.EnableWindow(false);
		m_nChAxis.EnableWindow();
	}
	else
		m_nRa2D.SetCheck(0);
	
	m_nRa2D.EnableWindow(true);
	m_nRaSurface.EnableWindow(true);
	m_nRaGrid.EnableWindow(true);

	int n = pView->m_OpenGL3D.m_pDS->m_Marker.GetSize();
	if(n > 0)
	{
		m_nChMark.EnableWindow(true);
		if(m_nChMark.GetCheck())
			EnableMarker();
		else
			DisableMarker();
		m_nCoMark.ResetContent();

		for(int i=0; i<n; i++)
			m_nCoMark.AddString(pView->m_OpenGL3D.m_pDS->m_Marker[i].Name);
		int hi = pView->m_OpenGL3D.m_pDS->m_nMarkIndex;
		m_nCoMark.SelectString(-1, pView->m_OpenGL3D.m_pDS->m_Marker[hi].Name);
		hi = 100 - (int)(100 * pView->m_OpenGL3D.m_pDS->m_Marker[hi].Hight);
		m_nSlMark.SetPos(hi);
		m_nSlMark.Invalidate();

		COLORREF color = RGB((int)(pView->m_OpenGL3D.m_pDS->m_MarkerCr.r*255), 
							(int)(pView->m_OpenGL3D.m_pDS->m_MarkerCr.g*255), 
							(int)(pView->m_OpenGL3D.m_pDS->m_MarkerCr.b*255));
		m_nBuColor.SetColour(color);
	}
	else
	{
		DisableMarker();
		m_nChMark.EnableWindow(false);
	}
}

/////////////////////////////////////////////////////////////////////////////
// CForm3D message handlers

void CForm3D::OnChaxis() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL3D.m_pDS)
		return;

	pView->m_OpenGL3D.m_pDS->m_bAxes = m_nChAxis.GetCheck();
	pView->InvalidateRect(NULL, FALSE);
}

void CForm3D::OnChbase() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL3D.m_pDS)
		return;

	pView->m_OpenGL3D.m_pDS->m_bBase = m_nChBase.GetCheck();
	pView->InvalidateRect(NULL, FALSE);
}

void CForm3D::OnChbaseside() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL3D.m_pDS)
		return;

	pView->m_OpenGL3D.m_pDS->m_bSide = m_nChSide.GetCheck();
	pView->InvalidateRect(NULL, FALSE);
}

void CForm3D::OnChlegend() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL3D.m_pDS)
		return;

	pView->m_OpenGL3D.m_pDS->m_bLegend = m_nChLegend.GetCheck();
	pView->InvalidateRect(NULL, FALSE);
}

void CForm3D::OnChline() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL3D.m_pDS)
		return;

	pView->m_OpenGL3D.m_pDS->m_bBorder = m_nChBox.GetCheck();
	if(!pView->m_OpenGL3D.m_pDS->m_bBorder)
		pView->m_OpenGL3D.m_pDS->m_bAxes = 0;
	else
		pView->m_OpenGL3D.m_pDS->m_bAxes = m_nChAxis.GetCheck();
	m_nChAxis.EnableWindow(pView->m_OpenGL3D.m_pDS->m_bBorder);
	pView->InvalidateRect(NULL, FALSE);
}

void CForm3D::OnChmark() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL3D.m_pDS)
		return;

	pView->m_OpenGL3D.m_pDS->m_bMark = m_nChMark.GetCheck();
	if(m_nChMark.GetCheck())
		EnableMarker();
	else
		DisableMarker();
	pView->InvalidateRect(NULL, FALSE);	
}

void CForm3D::OnRa2d() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL3D.m_pDS)
		return;

	int m_State = m_nRa2D.GetCheck();
	if(m_State)
	{
		pView->m_OpenGL3D.m_pDS->m_MapType = FLAT;
		m_nRaSurface.SetCheck(0);	
		m_nRaGrid.SetCheck(0);	
		m_nChBase.EnableWindow(FALSE);
		m_nChBase.SetCheck(0);
		pView->m_OpenGL3D.m_pDS->m_bBase = 0;
		m_nChSide.EnableWindow(FALSE);	
		m_nChSide.SetCheck(0);
		pView->m_OpenGL3D.m_pDS->m_bSide = 0;
		m_nChBox.EnableWindow(FALSE);
		m_nChBox.SetCheck(1);
		pView->m_OpenGL3D.m_pDS->m_bBorder = 1;
		pView->m_OpenGL3D.m_pDS->m_bMark = m_nChMark.GetCheck();
		if(pView->m_OpenGL3D.m_pDS->m_Marker.GetSize())
		{
			m_nChMark.EnableWindow(TRUE);
			if(pView->m_OpenGL3D.m_pDS->m_bMark)
				EnableMarker();
			else
				DisableMarker();
		}
		else
		{
			DisableMarker();
			m_nChMark.EnableWindow(false);
		}
	}
	pView->InvalidateRect(NULL, FALSE);
}

void CForm3D::OnRagrid() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL3D.m_pDS)
		return;

	int m_State = m_nRaGrid.GetCheck();
	if(m_State)
	{
		pView->m_OpenGL3D.m_pDS->m_MapType = GRID;
		m_nRaSurface.SetCheck(0);	
		m_nRa2D.SetCheck(0);	
		m_nChBase.EnableWindow(FALSE);	
		m_nChBase.SetCheck(0);
		pView->m_OpenGL3D.m_pDS->m_bBase = 0;
		m_nChSide.EnableWindow(FALSE);
		m_nChSide.SetCheck(0);
		pView->m_OpenGL3D.m_pDS->m_bSide = 0;
		pView->m_OpenGL3D.m_pDS->m_bBorder = m_nChBox.GetCheck();
		if (!pView->m_OpenGL3D.m_pDS->m_bBorder)
			pView->m_OpenGL3D.m_pDS->m_bAxes = 0;
		m_nChBox.EnableWindow(TRUE);	
		m_nChAxis.EnableWindow(pView->m_OpenGL3D.m_pDS->m_bBorder);	
		pView->m_OpenGL3D.m_pDS->m_bMark = m_nChMark.GetCheck();
		if(pView->m_OpenGL3D.m_pDS->m_Marker.GetSize())
		{
			m_nChMark.EnableWindow(TRUE);
			if(pView->m_OpenGL3D.m_pDS->m_bMark)
				EnableMarker();
			else
				DisableMarker();
		}
		else
		{
			DisableMarker();
			m_nChMark.EnableWindow(false);
		}
	}
	pView->InvalidateRect(NULL, FALSE);
}

void CForm3D::OnRasurface() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL3D.m_pDS)
		return;

	int m_State = m_nRaSurface.GetCheck();
	if(m_State)
	{
		pView->m_OpenGL3D.m_pDS->m_MapType = SURFACE;
		m_nRaGrid.SetCheck(0);	
		m_nRa2D.SetCheck(0);	
		pView->m_OpenGL3D.m_pDS->m_bBase = m_nChBase.GetCheck();
		m_nChBase.EnableWindow(TRUE);	
		pView->m_OpenGL3D.m_pDS->m_bSide = m_nChSide.GetCheck();
		m_nChSide.EnableWindow(TRUE);	
		pView->m_OpenGL3D.m_pDS->m_bBorder = m_nChBox.GetCheck();
		m_nChBox.EnableWindow(TRUE);	
		m_nChAxis.EnableWindow(pView->m_OpenGL3D.m_pDS->m_bBorder);
		pView->m_OpenGL3D.m_pDS->m_bMark = m_nChMark.GetCheck();
		if(pView->m_OpenGL3D.m_pDS->m_Marker.GetSize())
		{
			m_nChMark.EnableWindow(TRUE);
			if(pView->m_OpenGL3D.m_pDS->m_bMark)
				EnableMarker();
			else
				DisableMarker();
		}
		else
		{
			DisableMarker();
			m_nChMark.EnableWindow(false);
		}
	}
	pView->InvalidateRect(NULL, FALSE);
}

void CForm3D::SetMaps()
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL3D.m_pDS)
		return;

	m_nLiNameOfMaps.ResetContent();
	int n = pView->m_OpenGL3D.m_DS.GetSize();
	for(int i=0; i<n; i++)
		m_nLiNameOfMaps.AddString(pView->m_OpenGL3D.m_DS[i].m_MapName);
	m_nLiNameOfMaps.SetCurSel(0);
}

void CForm3D::OnDblclkLinameofmaps() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL3D.m_pDS)
		return;

	int i = m_nLiNameOfMaps.GetCount();
	if( i<=0 )  return;

    i = m_nLiNameOfMaps.GetCurSel();
    if(i != LB_ERR)
    { 
		CString str;
		m_nLiNameOfMaps.GetText(i, str);
		
		CChangeMapName Name;

		Name.m_nEdNameFrom = str;
		Name.m_nEdNameTo   = str;

		if( Name.DoModal() == IDOK )
		{
			pView->m_OpenGL3D.m_pDS->m_MapName = Name.m_nEdNameTo;
			m_nLiNameOfMaps.ResetContent();
			int n = pView->m_OpenGL3D.m_DS.GetSize();
			for(int j=0; j<n; j++)
				m_nLiNameOfMaps.AddString(pView->m_OpenGL3D.m_DS[j].m_MapName);
			m_nLiNameOfMaps.SetCurSel(i);
		}
	}
}

void CForm3D::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL3D.m_pDS || !(pView->m_OpenGL3D.m_pDS->m_Marker.GetSize()))
	{
		CFormView::OnVScroll(nSBCode, nPos, pScrollBar);
		return;
	}

	switch( nSBCode )
	{
		case TB_PAGEDOWN:
		case TB_PAGEUP:
		case TB_THUMBTRACK:
			pView->m_OpenGL3D.m_pDS->m_Marker[pView->m_OpenGL3D.m_pDS->m_nMarkIndex].Hight = 1 - ((float)m_nSlMark.GetPos())/100;
			pView->InvalidateRect(NULL, FALSE); 
			break;
	}
	
	CFormView::OnVScroll(nSBCode, nPos, pScrollBar);
}

void CForm3D::OnSelchangeComark() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL3D.m_pDS)
		return;

	int n = m_nCoMark.GetCurSel();
	if(pView->m_OpenGL3D.m_pDS->m_nMarkIndex == n) // Should never occur
		return;
	pView->m_OpenGL3D.m_pDS->m_nMarkIndex = n;

	n = 100 - (int)(100 * pView->m_OpenGL3D.m_pDS->m_Marker[n].Hight);
	m_nSlMark.SetPos(n);
}

void CForm3D::OnBucolor() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL3D.m_pDS)
		return;

	COLORREF color = m_nBuColor.GetColour();
	pView->m_OpenGL3D.m_pDS->m_MarkerCr.r = GetRValue(color) / 255.f;
	pView->m_OpenGL3D.m_pDS->m_MarkerCr.g = GetGValue(color) / 255.f;
	pView->m_OpenGL3D.m_pDS->m_MarkerCr.b = GetBValue(color) / 255.f;
	pView->InvalidateRect(NULL, FALSE);
}

void CForm3D::OnChlable() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL3D.m_pDS)
		return;

	pView->m_OpenGL3D.m_pDS->m_bLable = m_nChLable.GetCheck();
	pView->InvalidateRect(NULL, FALSE);
}

void CForm3D::OnChmarkline() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL3D.m_pDS)
		return;

	pView->m_OpenGL3D.m_pDS->m_bMarkLine = m_nChMarkLine.GetCheck();
	pView->InvalidateRect(NULL, FALSE);
}

void CForm3D::EnableMarker()
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL3D.m_pDS)
		return;

	m_nChMarkLine.EnableWindow(true);
	m_nCoMark.EnableWindow(true);
	m_nBuColor.EnableWindow(true);
	COLORREF color = RGB((int)(pView->m_OpenGL3D.m_pDS->m_MarkerCr.r*255), 
						(int)(pView->m_OpenGL3D.m_pDS->m_MarkerCr.g*255), 
						(int)(pView->m_OpenGL3D.m_pDS->m_MarkerCr.b*255));
	m_nBuColor.SetColour(color);
	m_nBuColor.InvalidateRect(NULL);
	m_nChLable.EnableWindow(true);
	m_nSlMark.EnableWindow(true);
}

void CForm3D::DisableMarker()
{
	m_nChMarkLine.EnableWindow(FALSE);
	m_nCoMark.EnableWindow(FALSE);
	m_nBuColor.EnableWindow(FALSE);
	m_nChLable.EnableWindow(FALSE);
	m_nSlMark.EnableWindow(FALSE);
}

LONG CForm3D::OnSelChange(UINT lParam, LONG wParam)
{
	switch(wParam)
	{
		case IDC_BUCOLOR:
			OnBucolor();
			break;
	}
	
	return wParam;
}

void CForm3D::OnSelchangeLinameofmaps() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_OpenGL3D.m_pDS)
		return;
		
	int i = m_nLiNameOfMaps.GetCount();
	if( i<=0 )  return;

    i = m_nLiNameOfMaps.GetCurSel();
    if(i != LB_ERR)
    { 
		if(&(pView->m_OpenGL3D.m_DS[i]) != pView->m_OpenGL3D.m_pDS)
		{
			pView->m_OpenGL3D.KillOpenGLTimer(pView->m_OpenGL3D.m_pDS->m_Rotate);
			pView->m_OpenGL3D.m_p3D = &(pView->m_OpenGL3D.m_DS[i]);
			pView->m_OpenGL3D.m_pDS = pView->m_OpenGL3D.m_p3D;
			pView->m_pOpenGL->m_pDS = pView->m_OpenGL3D.m_p3D;
			CTabView* pWnd = (CTabView*)GetParent();
			((CTabView*)GetParent())->Init3DSetting();
			pView->InvalidateRect(NULL, FALSE);
			if((pView->m_OpenGL3D.m_pDS->m_Move == RANDROTAT || pView->m_OpenGL3D.m_pDS->m_Move == CENTERROTAT) &&
				pView->m_OpenGL3D.m_pDS->m_Rotate != NONE)
				pView->m_OpenGL3D.SetOpenGLTimer(pView->m_OpenGL3D.m_pDS->m_Rotate);
			m_nLiNameOfMaps.SetCurSel(i);
		}
	}
}
