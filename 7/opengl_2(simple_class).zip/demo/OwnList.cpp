// OwnList.cpp : implementation file
// See OwnList.h for details on how to use this class
//

#include "stdafx.h"
#include "OwnList.h"
#include "GLDemoDoc.h"
#include "GLDemoView.h"
#include "ChildFrm.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COwnerDrawListBox

COwnerDrawListBox::COwnerDrawListBox()
{
	// You can't actually add anything to the list box here since the
	// associated CWnd hasn't been created yet.  Save any initialization
	// you need to do for after the CWnd has been constructed.  The TODO: 
	// comments in OwnList.h explain how to do this for 
	// COwnerDrawListBox as implemented here.
}

COwnerDrawListBox::~COwnerDrawListBox()
{
}


BEGIN_MESSAGE_MAP(COwnerDrawListBox, CDragListBox)
	//{{AFX_MSG_MAP(COwnerDrawListBox)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// COwnerDrawListBox message handlers

// This function draws a color bar in the client space of this list box 
// item.  If your list box item contains something other than color bars, 
// you need to replace the contents of this function with your own code 
// for drawing it.  If you are working with strings, the default MFC
// implementation of this function will probably work just fine for you.  
// (Example of a string where you need to do the drawing yourself: one 
// displayed in a different font than the rest of the dialog.)
void COwnerDrawListBox::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	CDC* pDC = CDC::FromHandle(lpDrawItemStruct->hDC);
	int Index = (int)lpDrawItemStruct->itemData; // Index in item data
	if (Index < 0 || Index >= 20)
		return;

	CRect rcItem(lpDrawItemStruct->rcItem);
	
	CMDIFrameWnd* pWnd  = (CMDIFrameWnd*)(AfxGetApp()->m_pMainWnd);
	CChildFrame* pChild = (CChildFrame*)(pWnd->MDIGetActive());
	CGLDemoView* pView  = (CGLDemoView*)(pChild->m_wndSplitter.GetPane(0, 1));

	if(!pView || !pView->m_pOpenGL->m_pDS)	
		return;

	COLORREF color = pView->m_pOpenGL->m_pDS->m_UserCr.GetAt(Index);
	rcItem.right /= 5;
	// White space
	rcItem.InflateRect(-2, -2);

	// Paint the color item in the color requested
	static COLORREF bcr = pDC->GetBkColor();
	CBrush brush(color);
	pDC->FillRect(rcItem, &brush);
	pDC->Draw3dRect(rcItem, GetSysColor(COLOR_BTNHIGHLIGHT),
        GetSysColor(COLOR_BTNSHADOW));
	
	if(Index < pView->m_pOpenGL->m_pDS->m_nUserCrNum)
	{
		char ch[20];
		if (pView->m_pOpenGL->m_DataGroup == G3D)
			sprintf(ch, "%2.2f - %2.2f", pView->m_pOpenGL->m_pDS->m_fZmin + Index * (pView->m_pOpenGL->m_pDS->m_fZmax - 
				pView->m_pOpenGL->m_pDS->m_fZmin) / pView->m_pOpenGL->m_pDS->m_nUserCrNum, pView->m_pOpenGL->m_pDS->m_fZmin + 
			    (Index + 1) * (pView->m_pOpenGL->m_pDS->m_fZmax - pView->m_pOpenGL->m_pDS->m_fZmin) / pView->m_pOpenGL->m_pDS->m_nUserCrNum);
		else
			sprintf(ch, "%2.2f - %2.2f", pView->m_pOpenGL->m_pDS->m_fWmin + Index * (pView->m_pOpenGL->m_pDS->m_fWmax - 
				pView->m_pOpenGL->m_pDS->m_fWmin) / pView->m_pOpenGL->m_pDS->m_nUserCrNum, pView->m_pOpenGL->m_pDS->m_fWmin + 
			    (Index + 1) * (pView->m_pOpenGL->m_pDS->m_fWmax - pView->m_pOpenGL->m_pDS->m_fWmin) / pView->m_pOpenGL->m_pDS->m_nUserCrNum);
		pDC->SetBkColor(bcr);
		pDC->TextOut( rcItem.right + 10, rcItem.top + 3, ch);
	}

	// Focus rect
	if (lpDrawItemStruct->itemAction & ODA_FOCUS)
		pDC->DrawFocusRect(&lpDrawItemStruct->rcItem);
}

// This function compares two colors to each other. If you're doing 
// something different, like comparing two bitmaps to each other, use 
// a different algorithm.  If you are working with strings, the default 
// implementation provided by MFC will probably do the job just fine.  
// (Example of a string where you need to do your own comparisons: if 
// your sorting scheme is different than a standard collating sequence, 
// such as one where the comparisons need to be case-insensitive.)
int COwnerDrawListBox::CompareItem(LPCOMPAREITEMSTRUCT lpCompareItemStruct) 
{
	int Index1 = (int)lpCompareItemStruct->itemData1;
	int Index2 = (int)lpCompareItemStruct->itemData2;
	if (Index1 > Index2)	return 1;
	else if (Index1 == Index2)	return 0;       // exact match
	else	return -1;
}

#define COLOR_ITEM_HEIGHT   20

// We made our color bars all be the same height for simplicity.  You 
// can actually specify variable heights as long as you set the 
// CBS_OWNERDRAWVARIABLE style.
void COwnerDrawListBox::MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct)
{
	// all items are of fixed size
	// must use LBS_OWNERDRAWVARIABLE for this to work
	lpMeasureItemStruct->itemHeight = COLOR_ITEM_HEIGHT;
}

void COwnerDrawListBox::Dropped(int nSrcIndex, CPoint pt)
{
	DrawInsert(-1);
	int nDestIndex = ItemFromPt(pt);

	if (nSrcIndex == -1 || nDestIndex == -1)
		return;
	if (nDestIndex == nSrcIndex || nDestIndex == nSrcIndex+1)
		return; //didn't move
	CString str;
	DWORD dwData;
	GetText(nSrcIndex, str);
	dwData = GetItemData(nSrcIndex);
	DeleteString(nSrcIndex);
	if (nSrcIndex < nDestIndex)
		nDestIndex--;
	nDestIndex = InsertString(nDestIndex, str);
	SetItemData(nDestIndex, dwData);
	SetCurSel(nDestIndex);

	RefreshViews();
}

void COwnerDrawListBox::RefreshViews()
{
	CMDIFrameWnd* pWnd  = (CMDIFrameWnd*)(AfxGetApp()->m_pMainWnd);
	CChildFrame* pChild = (CChildFrame*)(pWnd->MDIGetActive());
	CGLDemoView* pView  = (CGLDemoView*)(pChild->m_wndSplitter.GetPane(0, 1));

	int n = pView->m_pOpenGL->m_pDS->m_UserCr.GetSize();
	int m = GetCount();
	if( m != n)	return;
	CDWordArray TempArray; 
	for(int i=0; i<n; i++)
	{
		m = (int)GetItemData(i);
		TempArray.SetAtGrow(i, pView->m_pOpenGL->m_pDS->m_UserCr.GetAt(m));
	}
	for( i=0; i<n; i++)
		pView->m_pOpenGL->m_pDS->m_UserCr[i] = TempArray.GetAt(i);
	pView->InvalidateRect(NULL, FALSE);
	ResetContent();
	for( i=0; i<n; i++)
		AddString((LPCTSTR)i);
}
