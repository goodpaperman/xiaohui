// GLDemoDoc.cpp : implementation of the CGLDemoDoc class
//

#include "stdafx.h"
#include "GLDemo.h"

#include "GLDemoDoc.h"
#include "GLDemoView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGLDemoDoc

IMPLEMENT_DYNCREATE(CGLDemoDoc, CDocument)

BEGIN_MESSAGE_MAP(CGLDemoDoc, CDocument)
	//{{AFX_MSG_MAP(CGLDemoDoc)
	ON_COMMAND(ID_FILE_SAVETOBMP_WINDOWBMP, OnFileSavetobmpWindowbmp)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVETOBMP_WINDOWBMP, OnUpdateFileSavetobmpWindowbmp)
	ON_COMMAND(ID_FILE_SAVETOBMP_CLIENTBMP, OnFileSavetobmpClientbmp)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVETOBMP_CLIENTBMP, OnUpdateFileSavetobmpClientbmp)
	ON_COMMAND(ID_FILE_SAVETOBMP_RECTANGLEBMP, OnFileSavetobmpRectanglebmp)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVETOBMP_RECTANGLEBMP, OnUpdateFileSavetobmpRectanglebmp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGLDemoDoc construction/destruction

CGLDemoDoc::CGLDemoDoc()
{
	m_bModifiedFlag = FALSE;
}

CGLDemoDoc::~CGLDemoDoc()
{
}

BOOL CGLDemoDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}

CView* CGLDemoDoc::GetGLDemoView()
{
	CView* pView;
	POSITION pos = GetFirstViewPosition();
	while (pos != NULL)
	{
		pView = GetNextView(pos);
		if (pView->IsKindOf(RUNTIME_CLASS(CGLDemoView)))
			return pView;
	}
	return NULL;
}

/////////////////////////////////////////////////////////////////////////////
// CGLDemoDoc serialization

void CGLDemoDoc::Serialize(CArchive& ar)
{
	CGLDemoView* pView = (CGLDemoView*)GetGLDemoView();
	if(!pView)	return;

	CFile* fp = ar.GetFile();
	if (ar.IsStoring())
	{
		if (pView->m_pOpenGL->m_pDS)
			pView->m_pOpenGL->SaveMaps(fp->m_hFile);
		else
			AfxMessageBox("No map can be saved.\nLoad data first from View/Grid Data menu please.");
	}
	else
	{
		char str[12];
		fp->Read(str, 12);
		if (pView->m_pOpenGL->m_Version != str)
		{
			AfxMessageBox("The format of the file is wrong");
			return;
		}

		fp->Read(&pView->m_pOpenGL->m_DataGroup, sizeof(CDataGroup));
		if (pView->m_pOpenGL->m_DataGroup > GTRUE3D)
		{
			pView->m_pOpenGL->DestroyOpenGL();
			pView->m_pOpenGL = &pView->m_OpenGL4D;
			pView->m_pOpenGL->InitOpenGL(pView->GetSafeHwnd());
			pView->m_pOpenGL->OpenMaps(fp->m_hFile);
			pView->Show4DForm();
		}
		else
		{
			pView->m_pOpenGL->OpenMaps(fp->m_hFile);
			pView->Show3DForm();
		}
		m_bModifiedFlag = TRUE;
	}
}

/////////////////////////////////////////////////////////////////////////////
// CGLDemoDoc diagnostics

#ifdef _DEBUG
void CGLDemoDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CGLDemoDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CGLDemoDoc commands

void CGLDemoDoc::OnFileSavetobmpWindowbmp() 
{
	CGLDemoView* pView = (CGLDemoView*)GetGLDemoView();
	pView->m_nSaveBMPFlag = pView->BMPWINDOW;
	pView->SaveToBMP();
}

void CGLDemoDoc::OnUpdateFileSavetobmpWindowbmp(CCmdUI* pCmdUI) 
{
	CGLDemoView* pView = (CGLDemoView*)GetGLDemoView();
	pCmdUI->Enable(pView && pView->m_pOpenGL->m_pDS);
}

void CGLDemoDoc::OnFileSavetobmpClientbmp() 
{
	CGLDemoView* pView = (CGLDemoView*)GetGLDemoView();
	pView->m_nSaveBMPFlag = pView->BMPCLIENT;
	pView->SaveToBMP();
}

void CGLDemoDoc::OnUpdateFileSavetobmpClientbmp(CCmdUI* pCmdUI) 
{
	CGLDemoView* pView = (CGLDemoView*)GetGLDemoView();
	pCmdUI->Enable(pView && pView->m_pOpenGL->m_pDS);
}

void CGLDemoDoc::OnFileSavetobmpRectanglebmp() 
{
	CGLDemoView* pView = (CGLDemoView*)GetGLDemoView();
	pView->m_nSaveBMPFlag = pView->BMPRECT;
	pView->m_bSaveRectBMP = TRUE;
}

void CGLDemoDoc::OnUpdateFileSavetobmpRectanglebmp(CCmdUI* pCmdUI) 
{
	CGLDemoView* pView = (CGLDemoView*)GetGLDemoView();
	pCmdUI->Enable(pView && pView->m_pOpenGL->m_pDS);
}
