// ChildFrm.cpp : implementation of the CChildFrame class
//

#include "stdafx.h"
#include "GLDemo.h"

#include "ChildFrm.h"

#include "TabView.h"
#include "GLDemoView.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChildFrame

IMPLEMENT_DYNCREATE(CChildFrame, CMDIChildWnd)

BEGIN_MESSAGE_MAP(CChildFrame, CMDIChildWnd)
	//{{AFX_MSG_MAP(CChildFrame)
	ON_COMMAND(ID_VIEW_MAKERDATA, OnViewMakerdata)
	ON_UPDATE_COMMAND_UI(ID_VIEW_MAKERDATA, OnUpdateViewMakerdata)
	ON_COMMAND(ID_VIEW_GRIDDATA, OnViewGriddata)
	ON_UPDATE_COMMAND_UI(ID_VIEW_GRIDDATA, OnUpdateViewGriddata)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChildFrame construction/destruction

CChildFrame::CChildFrame()
{
	// TODO: add member initialization code here
	
}

CChildFrame::~CChildFrame()
{
}

BOOL CChildFrame::OnCreateClient( LPCREATESTRUCT /*lpcs*/,
	CCreateContext* pContext)
{
	BOOL bSuccess;
	CSize size(0, 0);

	if (!(bSuccess = m_wndSplitter.CreateStatic(this, 1, 2, WS_CHILD|WS_VISIBLE, AFX_IDW_PANE_FIRST)))
	{
		TRACE("Failed to CreateStaticSplitter\n");
		return FALSE;
	}
                    
    if (!(bSuccess &= m_wndSplitter.CreateView(0, 0, RUNTIME_CLASS(CTabView), size, pContext)))
	{
		TRACE("Failed to create base pane\n");
		return FALSE;
	}  

	if (!(bSuccess &= m_wndSplitter.CreateView(0, 1, RUNTIME_CLASS(CGLDemoView), size, pContext)))
	{
		TRACE("Failed to create base pane\n");
		return FALSE;
	}  

   	m_wndSplitter.SetActivePane(0, 1);
	m_wndSplitter.EnableWindow(FALSE);

    return TRUE;
}

BOOL CChildFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	if( !CMDIChildWnd::PreCreateWindow(cs) )
		return FALSE;

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CChildFrame diagnostics

#ifdef _DEBUG
void CChildFrame::AssertValid() const
{
	CMDIChildWnd::AssertValid();
}

void CChildFrame::Dump(CDumpContext& dc) const
{
	CMDIChildWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CChildFrame message handlers

void CChildFrame::OnViewMakerdata() 
{
	CFileDialog  dilg(TRUE, NULL, "*.mrk",    //OPENFILENAME
	                  OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT,
	                  "Text Files (*.mrk)|*.mrk|All Files (*.*)|*.*||");
	                                               
	dilg.m_ofn.lpstrTitle="Load Marker Data";
	if( dilg.DoModal() != IDOK )  
		return;

    CString FileName = dilg.GetPathName();
	if(FileName.IsEmpty())
	{
		AfxMessageBox( "Please select a file" );
		return;
	}

	CGLDemoView* pView = (CGLDemoView*)(m_wndSplitter.GetPane(0, 1));
	pView->LoadMarkerData((LPCTSTR)FileName);
	pView->Invalidate();
}

void CChildFrame::OnUpdateViewMakerdata(CCmdUI* pCmdUI) 
{
	CGLDemoView* pView = (CGLDemoView*)m_wndSplitter.GetPane(0, 1);
	pCmdUI->Enable(pView->m_pOpenGL->m_pDS != NULL && pView->m_pOpenGL->m_pDS->m_MapType <= SURFACE);
}

void CChildFrame::OnViewGriddata() 
{
	CFileDialog  dilg(TRUE, NULL, "*.grd",    //OPENFILENAME
	                  OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT,
	                  "Grid Files (*.grd)|*.grd|All Files (*.*)|*.*||");
	                                               
	dilg.m_ofn.lpstrTitle="Load Grid File";
	if(dilg.DoModal() != IDOK)
		return;

    CString FileName = dilg.GetPathName();
	if(FileName.IsEmpty())
	{
		MessageBox("Please select a file");
		return;
	}

	FILE* fp;
	if((fp = fopen(FileName, "rb")) == NULL)
	{
		MessageBox("Can not open the file: " + FileName);
		return;
	}

	char type;
	fread(&type, sizeof(char), 1, fp);
	if (type != 'D' && type != 'V')
	{
		MessageBox("Bad format has been detected in " + FileName);
		fclose(fp);
		return;
	}
	CGLDemoView* pView = (CGLDemoView*)(m_wndSplitter.GetPane(0, 1));
	fseek(fp, 3L, SEEK_SET);
	fread(&type, sizeof(char), 1, fp);
	switch(type)
	{
	case 'A':
	case 'B':
	case 'C':
	case 'D':
		pView->Load3DData(fp, type);
		pView->GetDocument()->SetTitle(dilg.GetFileTitle());
		break;
	case 'E':
	case 'F':
	case 'G':
		pView->Load4DData(fp, type);
		pView->GetDocument()->SetTitle(dilg.GetFileTitle());
		break;
	default:
		MessageBox("Bad format has been detected in " + FileName);
		fclose(fp);
		return;
	}

	pView->Invalidate();
	fclose(fp);
	pView->GetDocument()->m_bModifiedFlag = FALSE;
}

void CChildFrame::OnUpdateViewGriddata(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	
}
