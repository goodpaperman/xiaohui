#if !defined(AFX_TABVIEW_H__9DA38EE3_FADB_11D3_85D8_0008C777FFEE__INCLUDED_)
#define AFX_TABVIEW_H__9DA38EE3_FADB_11D3_85D8_0008C777FFEE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TabView.h : header file
//

#include "TabWindow.h"
#include "ColorForm.h"
#include "ZoomForm.h"
#include "Form3D.h"
#include "Form4D.h"

/////////////////////////////////////////////////////////////////////////////
// CTabView view
class CTabView : public CView
{
protected:
	CTabView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CTabView)

// Attributes
public:
	CTabWindow	m_TabCtrl;
	CImageList	m_ImgList;
	CFont		m_Font;

	CColorForm*	m_pColor;
	CZoomForm*	m_pZoom;
	CForm3D*	m_p3D;
	CForm4D*	m_p4D;

	int			m_TabWidth;

// Operations
public:
	CGLDemoDoc* GetDocument();
	void AddView();
	void Init3DSetting();
	void Init4DSetting();
	void Remove3DForm();
	void Remove4DForm();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTabView)
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CTabView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CTabView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in GLDemoView.cpp
inline CGLDemoDoc* CTabView::GetDocument()
   { return (CGLDemoDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TABVIEW_H__9DA38EE3_FADB_11D3_85D8_0008C777FFEE__INCLUDED_)
