//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by GLDemo.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_GLDEMOTYPE                  129
#define IDD_DLGCOLOR                    130
#define IDD_DLGZOOM                     131
#define IDD_DLG3D                       132
#define IDB_TAB                         133
#define IDD_DLD4D                       133
#define IDD_CHANGEMAPNAME               135
#define IDC_SX                          1000
#define IDC_SY                          1001
#define IDC_SZ                          1002
#define IDC_RNO                         1003
#define IDC_RXY                         1004
#define IDC_RXZ                         1005
#define IDC_RYZ                         1006
#define IDC_RXYZ                        1007
#define IDC_SLX                         1008
#define IDC_RASURFACE                   1009
#define IDC_SLY                         1009
#define IDC_RAGRID                      1010
#define IDC_SLZ                         1010
#define IDC_CRTYPE                      1011
#define IDC_RA2D                        1011
#define IDC_BUBACKCOLOR                 1012
#define IDC_BUMINCOLOR                  1013
#define IDC_SSPEED                      1014
#define IDC_BUMAXCOLOR                  1014
#define IDC_RMOVE                       1015
#define IDC_EDAUTODIV                   1015
#define IDC_RRANDOM                     1016
#define IDC_SPAUTODIV                   1016
#define IDC_RCENTER                     1017
#define IDC_EDCUSTDIV                   1017
#define IDC_SPCUSTDIV                   1018
#define IDC_LIUSERCOLOR                 1019
#define IDC_RAAUTOMATION                1020
#define IDC_RACUSTOM                    1021
#define IDC_LINAMEOFMAPS                1021
#define IDC_FGRADIENTCR                 1022
#define IDC_FCUSTOMCR                   1023
#define IDC_CHBORDER                    1024
#define IDC_CHLEGEND4D                  1025
#define IDC_RANOLINKING                 1026
#define IDC_RALINKXYZ                   1028
#define IDC_RAXLINKY                    1029
#define IDC_CHAXIS                      1030
#define IDC_RAXLINKZ                    1030
#define IDC_CHLEDGEND                   1031
#define IDC_CHX                         1031
#define IDC_CHLEGEND                    1031
#define IDC_CHMARK                      1032
#define IDC_CHNOCUTTING                 1032
#define IDC_CHLINE                      1033
#define IDC_RACUTTYPE1                  1033
#define IDC_BUBORDERCOLOR               1034
#define IDC_CHBASESIDE                  1034
#define IDC_RAYLINKZ                    1034
#define IDC_CHBASE                      1035
#define IDC_RACUTTYPE2                  1035
#define IDC_BUCOLOR                     1036
#define IDC_RACUTTYPE3                  1036
#define IDC_SLMARK                      1037
#define IDC_RANOCUT                     1037
#define IDC_CHLABLE                     1038
#define IDC_COMARK                      1039
#define IDC_CHMARKLINE                  1040
#define IDC_CHY                         1041
#define IDC_CHZ                         1042
#define IDC_EDNAMEFROM                  1042
#define IDC_EDNAMETO                    1043
#define ID_VIEW_SURFERDATA              32771
#define ID_VIEW_MAKERDATA               32772
#define ID_VIEW_4DDATA                  32773
#define ID_VIEW_3DDATA                  32774
#define ID_VIEW_GRIDDATA                32775
#define ID_FILE_SAVETOBMP               32776
#define ID_FILE_SAVETOBMP_WINDOWBMP     32777
#define ID_FILE_SAVETOBMP_CLIENTBMP     32778
#define ID_FILE_SAVETOBMP_RECTANGLEBMP  32779

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32781
#define _APS_NEXT_CONTROL_VALUE         1025
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
