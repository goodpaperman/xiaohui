#if !defined(AFX_FORM4D_H__9DA38EE9_FADB_11D3_85D8_0008C777FFEE__INCLUDED_)
#define AFX_FORM4D_H__9DA38EE9_FADB_11D3_85D8_0008C777FFEE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Form4D.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CForm4D form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "GLDemoDoc.h"

class CForm4D : public CFormView
{
protected:
	CForm4D();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CForm4D)

// Form Data
public:
	//{{AFX_DATA(CForm4D)
	enum { IDD = IDD_DLD4D };
	CButton	m_ChLegend;
	CButton	m_ChBorder;
	CListBox	m_nLiNameOfMaps;
	CButton	m_RaCut3;
	CButton	m_RaCut2;
	CButton	m_RaCut1;
	CButton	m_ChNoCutting;
	CSliderCtrl	m_SLZ;
	CSliderCtrl	m_SLY;
	CSliderCtrl	m_SLX;
	CButton	m_RaYLinkZ;
	CButton	m_RaXLinkZ;
	CButton	m_RaXLinkY;
	CButton	m_RaNoLinking;
	CButton	m_RaLinkXYZ;
	CButton	m_ChZ;
	CButton	m_ChY;
	CButton	m_ChX;
	BOOL	m_nChX;
	BOOL	m_nChY;
	BOOL	m_nChZ;
	int		m_nRaLinkXYZ;
	int		m_nRaNoLinking;
	int		m_nRaXLinkY;
	int		m_nRaXLinkZ;
	int		m_nRaYLinkZ;
	BOOL	m_nChNoCutting;
	int		m_nRaCut1;
	int		m_nRaCut2;
	int		m_nRaCut3;
	//}}AFX_DATA

// Attributes
public:
	CGLDemoDoc* GetDocument();

// Operations
public:
	CWnd* GetOpenGLView();
	void SetMaps();
	void Init4DForm();
	void WhichCutting();
	void GetCutPosition();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CForm4D)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CForm4D();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CForm4D)
	afx_msg void OnChx();
	afx_msg void OnChy();
	afx_msg void OnChz();
	afx_msg void OnRalinkxyz();
	afx_msg void OnRanolinking();
	afx_msg void OnRaxlinky();
	afx_msg void OnRaxlinkz();
	afx_msg void OnRaylinkz();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnChnocutting();
	afx_msg void OnRacuttype1();
	afx_msg void OnRacuttype2();
	afx_msg void OnRacuttype3();
	afx_msg void OnSelchangeLinameofmaps();
	afx_msg void OnDblclkLinameofmaps();
	afx_msg void OnChborder();
	afx_msg void OnChlegend4d();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in GLDemoView.cpp
inline CGLDemoDoc* CForm4D::GetDocument()
   { return (CGLDemoDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FORM4D_H__9DA38EE9_FADB_11D3_85D8_0008C777FFEE__INCLUDED_)
