#if !defined(AFX_TABWINDOW_H__BE74B060_F01A_11D2_99BD_244004C10000__INCLUDED_)
#define AFX_TABWINDOW_H__BE74B060_F01A_11D2_99BD_244004C10000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TabWindow.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTabWindow window

class CTabWindow : public CTabCtrl
{
// Construction
public:
	CTabWindow(){};

// Attributes
public:

// Operations
public:
	// helper functions.
    CWnd* GetTabView(int nTab);
    int   ShowSelTabView();
	void  MoveTabView(CRect& rect);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTabWindow)
	//}}AFX_VIRTUAL

// Implementation
public:
	CView* AddTabView(CRuntimeClass* pView, CDocument* pDoc, CWnd* pParentWnd, int i, LPSTR pszText, BOOL HasImage = TRUE);
	virtual ~CTabWindow(){};

	// Generated message map functions
protected:
	//{{AFX_MSG(CTabWindow)
	afx_msg void OnSelchange(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TABWINDOW_H__BE74B060_F01A_11D2_99BD_244004C10000__INCLUDED_)
