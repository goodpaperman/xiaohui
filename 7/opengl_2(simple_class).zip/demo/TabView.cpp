// TabView.cpp : implementation file
//

#include "stdafx.h"
#include "GLDemo.h"
#include "GLDemoDoc.h"
#include "GLDemoView.h"
#include "ChildFrm.h"
#include "TabView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTabView

IMPLEMENT_DYNCREATE(CTabView, CView)

CTabView::CTabView()
{
	m_pColor = NULL;
	m_pZoom  = NULL;
	m_p3D	 = NULL;
	m_p4D	 = NULL;
}

CTabView::~CTabView()
{
}


BEGIN_MESSAGE_MAP(CTabView, CView)
	//{{AFX_MSG_MAP(CTabView)
	ON_WM_CREATE()
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTabView drawing

void CTabView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// CTabView diagnostics

#ifdef _DEBUG
void CTabView::AssertValid() const
{
	CView::AssertValid();
}

void CTabView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CGLDemoDoc* CTabView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CGLDemoDoc)));
	return (CGLDemoDoc*)m_pDocument;
}

#endif //_DEBUG

void CTabView::AddView()
{
    // Add view to the tab control ....
	m_pColor = (CColorForm*)m_TabCtrl.AddTabView(RUNTIME_CLASS(CColorForm), GetDocument(), this, 1, "Color");
	m_pZoom  = (CZoomForm*)m_TabCtrl.AddTabView(RUNTIME_CLASS(CZoomForm), GetDocument(), this, 2, "Zoom");
}

/////////////////////////////////////////////////////////////////////////////
// CTabView message handlers

int CTabView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_TabCtrl.Create(WS_VISIBLE | WS_CHILD | TCS_BOTTOM | TCS_FORCELABELLEFT /*| TCS_MULTILINE*/,
                          CRect(0, 0, 0, 0), this, 0))
    {
        TRACE("Failed to create Tab control\n");
        return -1;
    }

    m_ImgList.Create(IDB_TAB, 16, 1, RGB(192, 192, 192));
    
    m_TabCtrl.SetFont(CFont::FromHandle((HFONT)GetStockObject(DEFAULT_GUI_FONT))); 
    m_TabCtrl.SetImageList(&m_ImgList);

	AddView();

	TEXTMETRIC   tm ;
	CDC* hdc = GetDC();
    hdc->GetTextMetrics(&tm);
    int cxChar = tm.tmAveCharWidth;
    ReleaseDC(hdc);
	m_TabWidth = 100 * cxChar / 4;
	
	return 0;
}

BOOL CTabView::OnEraseBkgnd(CDC* pDC) 
{
	return FALSE;
}

void CTabView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	if (::IsWindow(m_TabCtrl.m_hWnd))
	{
		if (m_TabWidth < cx)
		{
			CSplitterWnd* pWnd = (CSplitterWnd*)GetParent();
			CGLDemoView* pView = (CGLDemoView*)pWnd->GetPane(0, 1);
			if (pView->m_pOpenGL->m_pDS)
			{
				pWnd->SetColumnInfo(0, m_TabWidth, 30);
				pWnd->RecalcLayout();
			}
		}

		CRect rect;
		GetClientRect(rect);
		
		m_TabCtrl.MoveTabView(rect);
	}
}

void CTabView::Init3DSetting()
{
	m_pColor->InitColorForm();
	m_pZoom->InitZoomForm();
	m_p3D->Init3DForm();
}

void CTabView::Init4DSetting()
{
	m_pColor->InitColorForm();
	m_pZoom->InitZoomForm();
	m_p4D->Init4DForm();
}


void CTabView::Remove3DForm()
{
	CSplitterWnd* pWnd = (CSplitterWnd*)GetParent();
	pWnd->SetColumnInfo(0, 0, 30);
	pWnd->RecalcLayout();
	m_TabCtrl.SetCurSel(1);        
	m_TabCtrl.ShowSelTabView();
	m_TabCtrl.DeleteItem(0);
	GetDocument()->RemoveView(m_p3D);

	CGLDemoView* pView = (CGLDemoView*)pWnd->GetPane(0, 1);
	if (pView->m_OpenGL3D.m_p3D)
	{
		pView->m_pOpenGL->m_pDS->m_Marker.SetSize(0);
		pView->m_pOpenGL->m_pDS->m_UserCr.SetSize(0);
		pView->m_pOpenGL->m_pDS = NULL;
		pView->m_OpenGL3D.m_p3D = NULL;
		pView->m_OpenGL3D.m_DS.SetSize(0);
	}
	m_p3D = NULL;
	pWnd->EnableWindow(FALSE);
	pView->Invalidate();
}

void CTabView::Remove4DForm()
{
	CSplitterWnd* pWnd = (CSplitterWnd*)GetParent();
	pWnd->SetColumnInfo(0, 0, 30);
	pWnd->RecalcLayout();
	m_TabCtrl.SetCurSel(1);        
	m_TabCtrl.ShowSelTabView();
	m_TabCtrl.DeleteItem(0);
	GetDocument()->RemoveView(m_p4D);

	CGLDemoView* pView = (CGLDemoView*)pWnd->GetPane(0, 1);
	if (pView->m_OpenGL4D.m_p4D)
	{	
		pView->m_pOpenGL->m_pDS->m_Marker.SetSize(0);
		pView->m_pOpenGL->m_pDS->m_UserCr.SetSize(0);
		pView->m_pOpenGL->m_pDS = NULL;
		pView->m_OpenGL4D.m_p4D = NULL;
		pView->m_OpenGL4D.m_DS.SetSize(0);
	}
	m_p4D = NULL;
	pWnd->EnableWindow(FALSE);
	pView->Invalidate();
}
