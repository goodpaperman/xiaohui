// ZoomForm.cpp : implementation file
//

#include "stdafx.h"
#include "GLDemo.h"
#include "ZoomForm.h"
#include "ChildFrm.h"
#include "GLDemoView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CZoomForm

IMPLEMENT_DYNCREATE(CZoomForm, CFormView)

CZoomForm::CZoomForm()
	: CFormView(CZoomForm::IDD)
{
	//{{AFX_DATA_INIT(CZoomForm)
	//}}AFX_DATA_INIT
}

CZoomForm::~CZoomForm()
{
}

void CZoomForm::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CZoomForm)
	DDX_Control(pDX, IDC_RCENTER, m_RCENTER);
	DDX_Control(pDX, IDC_RRANDOM, m_RRANDOM);
	DDX_Control(pDX, IDC_RMOVE, m_RMOVE);
	DDX_Control(pDX, IDC_SSPEED, m_SSpeed);
	DDX_Control(pDX, IDC_CRTYPE, m_CRType);
	DDX_Control(pDX, IDC_SZ, m_SZ);
	DDX_Control(pDX, IDC_SY, m_SY);
	DDX_Control(pDX, IDC_SX, m_SX);
	DDX_Control(pDX, IDC_RXYZ, m_RXYZ);
	DDX_Control(pDX, IDC_RYZ, m_RYZ);
	DDX_Control(pDX, IDC_RXZ, m_RXZ);
	DDX_Control(pDX, IDC_RXY, m_RXY);
	DDX_Control(pDX, IDC_RNO, m_RNO);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CZoomForm, CFormView)
	//{{AFX_MSG_MAP(CZoomForm)
	ON_WM_HSCROLL()
	ON_BN_CLICKED(IDC_RNO, OnRno)
	ON_BN_CLICKED(IDC_RXY, OnRxy)
	ON_BN_CLICKED(IDC_RXZ, OnRxz)
	ON_BN_CLICKED(IDC_RYZ, OnRyz)
	ON_BN_CLICKED(IDC_RXYZ, OnRxyz)
	ON_CBN_SELCHANGE(IDC_CRTYPE, OnSelchangeCrtype)
	ON_BN_CLICKED(IDC_RMOVE, OnRmove)
	ON_BN_CLICKED(IDC_RRANDOM, OnRrandom)
	ON_BN_CLICKED(IDC_RCENTER, OnRcenter)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CZoomForm diagnostics

#ifdef _DEBUG
void CZoomForm::AssertValid() const
{
	CFormView::AssertValid();
}

void CZoomForm::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CGLDemoDoc* CZoomForm::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CGLDemoDoc)));
	return (CGLDemoDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CZoomForm message handlers
CWnd* CZoomForm::GetOpenGLView()
{
	return GetDocument()->GetGLDemoView();
}

void CZoomForm::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !(pView->m_pOpenGL->m_pDS))
	{
		CFormView::OnHScroll(nSBCode, nPos, pScrollBar);
		return;
	}

	switch(nSBCode)
	{
	case TB_PAGEDOWN:
	case TB_PAGEUP:
	case TB_THUMBTRACK:
		if (pScrollBar == (CScrollBar*)&m_SSpeed)
		{
			pView->m_pOpenGL->m_nTimerSpeed = 2010 - m_SSpeed.GetPos();
			pView->m_pOpenGL->KillOpenGLTimer(pView->m_pOpenGL->m_pDS->m_Rotate);
			pView->m_pOpenGL->SetOpenGLTimer(pView->m_pOpenGL->m_pDS->m_Rotate);
		}
		else
		{
			pView->m_pOpenGL->m_pDS->m_xScale = (float)m_SX.GetPos()/50.0f;
			pView->m_pOpenGL->m_pDS->m_yScale = (float)m_SY.GetPos()/50.0f;
			pView->m_pOpenGL->m_pDS->m_zScale = (float)m_SZ.GetPos()/50.0f;

			switch(pView->m_pOpenGL->m_pDS->m_Link)
			{
			case XYLink:
				m_SY.SetPos(m_SX.GetPos());
				pView->m_pOpenGL->m_pDS->m_yScale = pView->m_pOpenGL->m_pDS->m_xScale;
				break;
			case XZLink:
				m_SZ.SetPos(m_SX.GetPos());
				pView->m_pOpenGL->m_pDS->m_zScale = pView->m_pOpenGL->m_pDS->m_xScale;
				break;
			case YZLink:
				m_SZ.SetPos(m_SY.GetPos());
				pView->m_pOpenGL->m_pDS->m_zScale = pView->m_pOpenGL->m_pDS->m_yScale;
				break;
			case XYZLink:
				m_SY.SetPos(m_SX.GetPos());
				m_SZ.SetPos(m_SX.GetPos());
				pView->m_pOpenGL->m_pDS->m_zScale = pView->m_pOpenGL->m_pDS->m_yScale = pView->m_pOpenGL->m_pDS->m_xScale;
				break;
			}
		}
		pView->InvalidateRect(NULL, FALSE); 
		break;
	}

	CFormView::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CZoomForm::OnRno() 
{
	m_RNO.SetCheck(1);
	m_RXY.SetCheck(0);
	m_RXZ.SetCheck(0);
	m_RYZ.SetCheck(0);
	m_RXYZ.SetCheck(0);

	m_SX.EnableWindow();
	m_SY.EnableWindow();
	m_SZ.EnableWindow();

	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (pView && pView->m_pOpenGL->m_pDS)
		pView->m_pOpenGL->m_pDS->m_Link = NoLink;
}

void CZoomForm::OnRxy() 
{
	m_RNO.SetCheck(0);
	m_RXY.SetCheck(1);
	m_RXZ.SetCheck(0);
	m_RYZ.SetCheck(0);
	m_RXYZ.SetCheck(0);

	m_SX.EnableWindow();
	m_SY.EnableWindow(FALSE);
	m_SZ.EnableWindow();
	m_SY.SetPos(m_SX.GetPos());

	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (pView && pView->m_pOpenGL->m_pDS)
		pView->m_pOpenGL->m_pDS->m_Link = XYLink;
}

void CZoomForm::OnRxz() 
{
	m_RNO.SetCheck(0);
	m_RXY.SetCheck(0);
	m_RXZ.SetCheck(1);
	m_RYZ.SetCheck(0);
	m_RXYZ.SetCheck(0);

	m_SX.EnableWindow();
	m_SY.EnableWindow();
	m_SZ.EnableWindow(FALSE);
	m_SZ.SetPos(m_SX.GetPos());

	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (pView && pView->m_pOpenGL->m_pDS)
		pView->m_pOpenGL->m_pDS->m_Link = XZLink;
}

void CZoomForm::OnRyz() 
{
	m_RNO.SetCheck(0);
	m_RXY.SetCheck(0);
	m_RXZ.SetCheck(0);
	m_RYZ.SetCheck(1);
	m_RXYZ.SetCheck(0);

	m_SX.EnableWindow();
	m_SY.EnableWindow();
	m_SZ.EnableWindow(FALSE);
	m_SZ.SetPos(m_SY.GetPos());

	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (pView && pView->m_pOpenGL->m_pDS)
		pView->m_pOpenGL->m_pDS->m_Link = YZLink;
}

void CZoomForm::OnRxyz() 
{
	m_RNO.SetCheck(0);
	m_RXY.SetCheck(0);
	m_RXZ.SetCheck(0);
	m_RYZ.SetCheck(0);
	m_RXYZ.SetCheck(1);

	m_SX.EnableWindow();
	m_SY.EnableWindow(FALSE);
	m_SZ.EnableWindow(FALSE);
	m_SY.SetPos(m_SX.GetPos());
	m_SZ.SetPos(m_SX.GetPos());

	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (pView && pView->m_pOpenGL->m_pDS)
		pView->m_pOpenGL->m_pDS->m_Link = XYZLink;
}

void CZoomForm::InitZoomForm()
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_pOpenGL->m_pDS)
		return;
	
	m_SX.SetPos((int)(pView->m_pOpenGL->m_pDS->m_xScale * 50));
	m_SY.SetPos((int)(pView->m_pOpenGL->m_pDS->m_yScale * 50));
	m_SZ.SetPos((int)(pView->m_pOpenGL->m_pDS->m_zScale * 50));

	if (pView->m_pOpenGL->m_pDS->m_Link == NoLink)
		m_RNO.SetCheck(1);
	else
		m_RNO.SetCheck(0);
	if (pView->m_pOpenGL->m_pDS->m_Link == XYLink)
		m_RXY.SetCheck(1);
	else
		m_RXY.SetCheck(0);
	if (pView->m_pOpenGL->m_pDS->m_Link == XZLink)
		m_RXZ.SetCheck(1);
	else
		m_RXZ.SetCheck(0);
	if (pView->m_pOpenGL->m_pDS->m_Link == YZLink)
		m_RYZ.SetCheck(1);
	else
		m_RYZ.SetCheck(0);
	if (pView->m_pOpenGL->m_pDS->m_Link == XYZLink)
		m_RXYZ.SetCheck(1);
	else
		m_RXYZ.SetCheck(0);

	if(pView->m_pOpenGL->m_pDS->m_Move == MOVE)
		m_RMOVE.SetCheck(1);
	else
		m_RMOVE.SetCheck(0);
	if(pView->m_pOpenGL->m_pDS->m_Move == RANDROTAT)
		m_RRANDOM.SetCheck(1);
	else
		m_RRANDOM.SetCheck(0);
	if(pView->m_pOpenGL->m_pDS->m_Move == CENTERROTAT)
		m_RCENTER.SetCheck(1);
	else
		m_RCENTER.SetCheck(0);

	switch(pView->m_pOpenGL->m_pDS->m_Move)
	{
		case MOVE:
			m_CRType.EnableWindow(FALSE);
			m_SSpeed.EnableWindow(FALSE);
			break;
		case RANDROTAT:
		case CENTERROTAT:
			m_CRType.EnableWindow();
			m_SSpeed.EnableWindow();
			break;
	}

	m_CRType.SetCurSel(pView->m_pOpenGL->m_pDS->m_Rotate);
}

void CZoomForm::OnInitialUpdate() 
{
	CFormView::OnInitialUpdate();

	m_SX.SetRange(1,100,TRUE);
	m_SY.SetRange(1,100,TRUE);
	m_SZ.SetRange(1,100,TRUE);

	m_SX.SetPos(50);
	m_SY.SetPos(50);
	m_SZ.SetPos(50);

	m_RNO.SetCheck(1);
	m_RXY.SetCheck(0);
	m_RXZ.SetCheck(0);
	m_RYZ.SetCheck(0);
	m_RXYZ.SetCheck(0);	

	m_RMOVE.SetCheck(1);
	m_RRANDOM.SetCheck(0);
	m_RCENTER.SetCheck(0);
	
	m_SSpeed.SetRange(10, 2000, TRUE);
	m_SSpeed.SetPos(1000);
}

void CZoomForm::OnSelchangeCrtype() 
{
	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (!pView || !pView->m_pOpenGL->m_pDS)
		return;

	int n = m_CRType.GetCurSel();
	if (pView->m_pOpenGL->m_pDS->m_Rotate != NONE)
		pView->m_pOpenGL->KillOpenGLTimer(pView->m_pOpenGL->m_pDS->m_Rotate);
	if (n != (int)NONE)
		pView->m_pOpenGL->SetOpenGLTimer(n);
	pView->m_pOpenGL->m_pDS->m_Rotate = (CRotateType)n;
}

void CZoomForm::OnRmove() 
{
	m_RMOVE.SetCheck(1);
	m_RRANDOM.SetCheck(0);
	m_RCENTER.SetCheck(0);

	m_CRType.EnableWindow(FALSE);
	m_SSpeed.EnableWindow(FALSE);

	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (pView && pView->m_pOpenGL->m_pDS)
	{
		pView->m_pOpenGL->KillOpenGLTimer(m_CRType.GetCurSel());
		pView->m_pOpenGL->m_pDS->m_Move = MOVE;
		pView->m_pOpenGL->m_nD			= 30;
		pView->m_pOpenGL->m_pDS->m_zTrans = -4;
		pView->InvalidateRect(NULL, FALSE);
	}
}

void CZoomForm::OnRrandom() 
{
	m_RMOVE.SetCheck(0);
	m_RRANDOM.SetCheck(1);
	m_RCENTER.SetCheck(0);

	m_CRType.EnableWindow(TRUE);
	m_SSpeed.EnableWindow(TRUE);

	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (pView && pView->m_pOpenGL->m_pDS)
	{
		pView->m_pOpenGL->m_pDS->m_Move = RANDROTAT;
		pView->m_pOpenGL->SetOpenGLTimer(m_CRType.GetCurSel());
		pView->m_pOpenGL->m_nD		    = 30;
		pView->m_pOpenGL->m_pDS->m_zTrans = -4;
		pView->InvalidateRect(NULL, FALSE);
	}
}

void CZoomForm::OnRcenter() 
{
	m_RMOVE.SetCheck(0);
	m_RRANDOM.SetCheck(0);
	m_RCENTER.SetCheck(1);

	m_CRType.EnableWindow(TRUE);
	m_SSpeed.EnableWindow(TRUE);

	CGLDemoView* pView = (CGLDemoView*)GetOpenGLView();
	if (pView && pView->m_pOpenGL->m_pDS)
	{
		pView->m_pOpenGL->m_pDS->m_Move = CENTERROTAT;
		pView->m_pOpenGL->m_nD			= 20;
		pView->m_pOpenGL->m_pDS->m_zTrans = -2.5f;
		pView->m_pOpenGL->SetOpenGLTimer(m_CRType.GetCurSel());
		pView->InvalidateRect(NULL, FALSE);
	}
}
