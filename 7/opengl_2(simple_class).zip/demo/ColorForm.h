#if !defined(AFX_COLORFORM_H__9DA38EE6_FADB_11D3_85D8_0008C777FFEE__INCLUDED_)
#define AFX_COLORFORM_H__9DA38EE6_FADB_11D3_85D8_0008C777FFEE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ColorForm.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CColorForm form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

#include "GLDemoDoc.h"
#include "OwnList.h"
#include "ColourPicker.h"

class CColorForm : public CFormView
{
protected:
	CColorForm();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CColorForm)

// Form Data
public:
	//{{AFX_DATA(CColorForm)
	enum { IDD = IDD_DLGCOLOR };
	CButton	m_GradientCr;
	CButton	m_FCostomCr;
	CColourPicker	m_nBuBorderColor;
	CColourPicker	m_nBuBackColor;  //CColourPicker replaces CColorButton
	CColourPicker	m_nBuMaxColor;
	CColourPicker	m_nBuMinColor;
	CEdit	m_nEdAutoDiv;
	CEdit	m_nEdCustDiv;
	COwnerDrawListBox	m_nLiUserColor;
	CButton	m_nRaAutomation;
	CSpinButtonCtrl	m_nSpAutoDiv;
	CSpinButtonCtrl	m_nSpCustDiv;
	CButton	m_nRaCustom;
	int		m_nAutoDiv;
	int		m_nCustDiv;
	//}}AFX_DATA

// Attributes
public:
	CGLDemoDoc* GetDocument();

// Operations
public:
	void  InitColorForm();
	CWnd* GetOpenGLView();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CColorForm)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CColorForm();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CColorForm)
	afx_msg void OnBubackcolor();
	afx_msg void OnBubordercolor();
	afx_msg void OnBumincolor();
	afx_msg void OnBumaxcolor();
	afx_msg void OnRaautomation();
	afx_msg void OnRacustom();
	afx_msg void OnChangeEdautodiv();
	afx_msg void OnChangeEdcustdiv();
	afx_msg void OnDblclkLiusercolor();
	//}}AFX_MSG
	afx_msg LONG OnSelChange(UINT lParam, LONG wParam);
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in GLDemoView.cpp
inline CGLDemoDoc* CColorForm::GetDocument()
   { return (CGLDemoDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COLORFORM_H__9DA38EE6_FADB_11D3_85D8_0008C777FFEE__INCLUDED_)
