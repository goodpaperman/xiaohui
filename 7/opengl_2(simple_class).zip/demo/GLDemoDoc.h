// GLDemoDoc.h : interface of the CGLDemoDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_GLDEMODOC_H__D1DD87EE_F9F0_11D3_99BD_C08908C10000__INCLUDED_)
#define AFX_GLDEMODOC_H__D1DD87EE_F9F0_11D3_99BD_C08908C10000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CGLDemoDoc : public CDocument
{
protected: // create from serialization only
	CGLDemoDoc();
	DECLARE_DYNCREATE(CGLDemoDoc)

// Attributes
public:
	BOOL	  m_bModifiedFlag;

// Operations
public:
	CView* GetGLDemoView();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGLDemoDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CGLDemoDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CGLDemoDoc)
	afx_msg void OnFileSavetobmpWindowbmp();
	afx_msg void OnUpdateFileSavetobmpWindowbmp(CCmdUI* pCmdUI);
	afx_msg void OnFileSavetobmpClientbmp();
	afx_msg void OnUpdateFileSavetobmpClientbmp(CCmdUI* pCmdUI);
	afx_msg void OnFileSavetobmpRectanglebmp();
	afx_msg void OnUpdateFileSavetobmpRectanglebmp(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GLDEMODOC_H__D1DD87EE_F9F0_11D3_99BD_C08908C10000__INCLUDED_)
