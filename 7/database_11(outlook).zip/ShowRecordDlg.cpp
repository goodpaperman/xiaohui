// ShowRecordDlg.cpp : implementation file
//

#include "stdafx.h"
#include "mdbViewer.h"
#include "ShowRecordDlg.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CShowRecordDlg dialog


CShowRecordDlg::CShowRecordDlg(CWnd* pParent /*=NULL*/,
								   CmdbViewerDoc* ipDoc,CDaoRecordset* pSet,int editID)
	: CDialog(CShowRecordDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CShowRecordDlg)
	m_fieldValue1 = _T("");
	m_fieldValue2 = _T("");
	m_fieldValue3 = _T("");
	m_fieldValue4 = _T("");
	m_fieldValue5 = _T("");
	m_fieldValue6 = _T("");
	m_fieldValue7 = _T("");
	m_fieldValue8 = _T("");
	m_fieldName1 = _T("");
	m_fieldName2 = _T("");
	m_fieldName3 = _T("");
	m_fieldName4 = _T("");
	m_fieldName5 = _T("");
	m_fieldName6 = _T("");
	m_fieldName7 = _T("");
	m_fieldName8 = _T("");
	//}}AFX_DATA_INIT

	//m_pSet=pSet;
	//pDoc=ipDoc;
	m_pageNum=1; // set the first page by default
	m_editid=editID;

	CmdbViewerView* pView =
		((CMainFrame*)AfxGetMainWnd())->GetmdbViewerView();
	pDoc=pView->GetDocument();
	m_pSet=pDoc->GetRecordSet();

	m_pageCount=pView->m_nFields/8;
	if(!(pView->m_nFields%8==0))
		m_pageCount++;
	pParentW=pParent;

	m_fieldValues.SetSize(40);
	m_fieldNames.SetSize(40);
	for (int i=0;i<40;i++)
	{
			m_fieldValues[i]=_T("");
	}
}


void CShowRecordDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CShowRecordDlg)
	DDX_Text(pDX, IDC_AR_ED1, m_fieldValue1);
	DDX_Text(pDX, IDC_AR_ED2, m_fieldValue2);
	DDX_Text(pDX, IDC_AR_ED3, m_fieldValue3);
	DDX_Text(pDX, IDC_AR_ED4, m_fieldValue4);
	DDX_Text(pDX, IDC_AR_ED5, m_fieldValue5);
	DDX_Text(pDX, IDC_AR_ED6, m_fieldValue6);
	DDX_Text(pDX, IDC_AR_ED7, m_fieldValue7);
	DDX_Text(pDX, IDC_AR_ED8, m_fieldValue8);
	DDX_Text(pDX, IDC_AR_LABEL1, m_fieldName1);
	DDX_Text(pDX, IDC_AR_LABEL2, m_fieldName2);
	DDX_Text(pDX, IDC_AR_LABEL3, m_fieldName3);
	DDX_Text(pDX, IDC_AR_LABEL4, m_fieldName4);
	DDX_Text(pDX, IDC_AR_LABEL5, m_fieldName5);
	DDX_Text(pDX, IDC_AR_LABEL6, m_fieldName6);
	DDX_Text(pDX, IDC_AR_LABEL7, m_fieldName7);
	DDX_Text(pDX, IDC_AR_LABEL8, m_fieldName8);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CShowRecordDlg, CDialog)
	//{{AFX_MSG_MAP(CShowRecordDlg)
	ON_BN_CLICKED(IDC_AR_NEXTPAGE, OnArNextpage)
	ON_BN_CLICKED(IDC_AR_PREVPAGE, OnArPrevpage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CShowRecordDlg message handlers

void CShowRecordDlg::OnArNextpage() 
{
	SaveInput();
	m_pageNum++;
	if(m_pageNum>m_pageCount) m_pageNum=m_pageCount;
	UpdateARDialog(m_pageNum);	
}

void CShowRecordDlg::UpdateARDialog(int nDlgW)
{
	int np=8*(nDlgW-1);

	SetDlgItemText(IDC_AR_ED1, m_fieldValues[np+0]);
	SetDlgItemText(IDC_AR_ED2, m_fieldValues[np+1]);
	SetDlgItemText(IDC_AR_ED3, m_fieldValues[np+2]);
	SetDlgItemText(IDC_AR_ED4, m_fieldValues[np+3]);
	SetDlgItemText(IDC_AR_ED5, m_fieldValues[np+4]);
	SetDlgItemText(IDC_AR_ED6, m_fieldValues[np+5]);
	SetDlgItemText(IDC_AR_ED7, m_fieldValues[np+6]);
	SetDlgItemText(IDC_AR_ED8, m_fieldValues[np+7]);

	SetDlgItemText(IDC_AR_LABEL1, m_fieldNames[np+0]);
	SetDlgItemText(IDC_AR_LABEL2, m_fieldNames[np+1]);
	SetDlgItemText(IDC_AR_LABEL3, m_fieldNames[np+2]);
	SetDlgItemText(IDC_AR_LABEL4, m_fieldNames[np+3]);
	SetDlgItemText(IDC_AR_LABEL5, m_fieldNames[np+4]);
	SetDlgItemText(IDC_AR_LABEL6, m_fieldNames[np+5]);
	SetDlgItemText(IDC_AR_LABEL7, m_fieldNames[np+6]);
	SetDlgItemText(IDC_AR_LABEL8, m_fieldNames[np+7]);
}

void CShowRecordDlg::OnArPrevpage() 
{
	SaveInput();
	m_pageNum--;
	if(m_pageNum==0) m_pageNum=1;
	UpdateARDialog(m_pageNum);
	
}

void CShowRecordDlg::PassFieldNames(int nf,CString strName)
{
	m_fieldNames.SetAt(nf,strName);
}

CString CShowRecordDlg::GetFieldValues(int nf)
{
	return m_fieldValues[nf];
}

void CShowRecordDlg::SaveInput()
{
	int np=8*(m_pageNum-1);
	GetDlgItemText(IDC_AR_ED1, m_fieldValues[np+0]);
	GetDlgItemText(IDC_AR_ED2, m_fieldValues[np+1]);
	GetDlgItemText(IDC_AR_ED3, m_fieldValues[np+2]);
	GetDlgItemText(IDC_AR_ED4, m_fieldValues[np+3]);
	GetDlgItemText(IDC_AR_ED5, m_fieldValues[np+4]);
	GetDlgItemText(IDC_AR_ED6, m_fieldValues[np+5]);
	GetDlgItemText(IDC_AR_ED7, m_fieldValues[np+6]);
	GetDlgItemText(IDC_AR_ED8, m_fieldValues[np+7]);
}

void CShowRecordDlg::OnOK() 
{
	
	CmdbViewerView* pView =
		((CMainFrame*)AfxGetMainWnd())->GetmdbViewerView();

	SaveInput();
	
	for (int i=0; i<pView->m_nFields;i++)
	{
		CString strDataType="Text";
		CString strExample="Burnaby";
		CDaoFieldInfo fi;
		COleVariant var;
		m_pSet->GetFieldInfo(i, fi);
		switch (fi.m_nType) {
			case dbText:
				strDataType=_T("Text");
				strExample="Burnaby";
				break;
			case dbDate:
				strDataType=_T("Date");
				strExample="22/03/99";
				break;
			case dbInteger:
				strDataType=_T("Integer");
				strExample="34";
				break;
			case dbLong:
				strDataType=_T("Integer");
				strExample="15684";
				break;
			case dbBoolean:
				strDataType=_T("BOOL");
				strExample="TRUE";
				break;
			case dbSingle:
				strDataType=_T("Single");
				strExample="3.1415";
				break;
			case dbDouble:
				strDataType=_T("Double");
				strExample="3.14159261517";
				break;
			case dbCurrency:
				strDataType=_T("Currency");
				strExample="1,234.50";
				break;
			default:
				strDataType=_T("Sorry! It is not considered");
				strExample="N/A";
				break;
		}

		if (m_fieldValues[i].IsEmpty () ) {
			// all fields MUST contain a value
			// If empty then messages should be provided
			AfxMessageBox (_T("You must supply a value to this field\n\nField Name : [")
				+m_fieldNames[i]+_T("]\nData Type  : ")+strDataType
				+_T("\nExample      : ")+strExample
				+_T("\n\nUse [-->] and [<--] to search fields"), MB_ICONEXCLAMATION );
			return;
		} else {
			// Check data type
			CString fValue=GetFieldValues(i);
			var=COleVariant(LPCTSTR (fValue), VT_BSTRT);
			try {
				m_pSet->SetFieldValue(i,var);
			}
			catch ( CDaoException* e ) { // catch DAO exceptions
				AfxMessageBox (_T("Date type error for this field\n\nField Name : [")
								+m_fieldNames[i]+_T("]\nData Type  : ")+strDataType
								+_T("\nExample      : ")+strExample
								+_T("\n\nUse [--->] and [<---] to search fields"), MB_ICONEXCLAMATION );
				char szBuffer [ 256 ];
				CString strExceptDesc =
				CString ( "JET Database Engine Error:\n\n Error Code: " ) +
				CString ( ltoa ( e -> m_pErrorInfo -> m_lErrorCode, szBuffer, 10 ) ) +
				CString ( "\nDescription: " ) +
				CString ( e -> m_pErrorInfo -> m_strDescription );
				AfxMessageBox ( strExceptDesc, MB_ICONEXCLAMATION );

				var.Clear();  // clear the current COleVariant object
				return;
			}
			var.Clear();  // clear the current COleVariant object
		} // finish check
	}		// loop on i

	try {
		BeginWaitCursor();
		m_pSet->Update();
		// should send message to statusbar
		EndWaitCursor();
		// If add new record, the new record will be the last record,
		// listview then is added a last line
		//
		if(!pView->UpdateListView(m_editid,&m_fieldValues))
				AfxMessageBox(_T("Fail to update list view"));
	} catch ( CDaoException* e ) { // catch DAO exceptions
		char szBuffer [ 256 ];
		CString strExceptDesc =
		CString ( "JET Database Engine Error:\n\n Error Code: " ) +
		CString ( ltoa ( e -> m_pErrorInfo -> m_lErrorCode, szBuffer, 10 ) ) +
		CString ( "\nDescription: " ) +
		CString ( e -> m_pErrorInfo -> m_strDescription )+
		CString ( "\n\nAdd Record failed");
		AfxMessageBox ( strExceptDesc, MB_ICONEXCLAMATION );
		return;
	}
	
	CDialog::OnOK();
}

CString CShowRecordDlg::GetFieldType(int nf)
{
	CDaoFieldInfo fi;
	m_pSet->GetFieldInfo(nf, fi);
	CString strDataType;
	switch (fi.m_nType) {
		case dbText:
			strDataType=_T("Text");
			break;
		case dbDate:
			strDataType=_T("Date");
			break;
		case dbInteger:
			strDataType=_T("Integer");
			break;
		case dbLong:
			strDataType=_T("Integer");
			break;
		case dbBoolean:
			strDataType=_T("BOOL");
			break;
		case dbSingle:
			strDataType=_T("Single");
			break;
		case dbDouble:
			strDataType=_T("Double");
			break;
		case dbCurrency:
			strDataType=_T("Currency");
			break;
		default:
			strDataType=_T("Sorry! It is not considered");
			break;
	}

	return strDataType;
}

void CShowRecordDlg::PassFieldValues(int nf, CString strValue)
{
	m_fieldValues.SetAt(nf,strValue);
}
