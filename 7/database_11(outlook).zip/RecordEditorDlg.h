#if !defined(AFX_RECORDEDITORDLG_H__8E40EAC2_DD10_11D2_9313_0060080F2D70__INCLUDED_)
#define AFX_RECORDEDITORDLG_H__8E40EAC2_DD10_11D2_9313_0060080F2D70__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// RecordEditorDlg.h : header file
//
#include "mdbViewerDoc.h"
#include "mdbViewerView.h"

/////////////////////////////////////////////////////////////////////////////
// CRecordEditorDlg dialog

class CRecordEditorDlg : public CDialog
{
// Construction
public:
	void PassFieldValues(int nf,CString strValue);
	void PassFieldNames(int nf,CString fdname);
	int m_pageCount;
	CRecordEditorDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CRecordEditorDlg)
	enum { IDD = IDD_RECORDEDITDLG };
	CString	m_fieldValue1;
	CString	m_fieldValue2;
	CString	m_fieldValue3;
	CString	m_fieldValue4;
	CString	m_fieldValue5;
	CString	m_fieldValue6;
	CString	m_fieldValue7;
	CString	m_fieldValue8;
	CString	m_fieldName1;
	CString	m_fieldName2;
	CString	m_fieldName3;
	CString	m_fieldName4;
	CString	m_fieldName5;
	CString	m_fieldName6;
	CString	m_fieldName7;
	CString	m_fieldName8;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRecordEditorDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	void UpdateStatubar();
	int m_pageNum;
	void UpdateREDDialog(int nDlgW);
	// Generated message map functions
	//{{AFX_MSG(CRecordEditorDlg)
	afx_msg void OnRedNext();
	afx_msg void OnRecordPrev();
	afx_msg void OnRecordFirst();
	afx_msg void OnRedLast();
	afx_msg void OnRedAddnew();
	afx_msg void OnRedPrevpage();
	afx_msg void OnRedNextpage();
	afx_msg void OnRedDelete();
	afx_msg void OnRedModify();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	CStringArray m_fieldNames;
	CStringArray m_fieldValues;
	void ReadRecord(BOOL nFlag=TRUE);
	CmdbViewerDoc* pDoc;
	CmdbViewerView* pView;
	CDaoRecordset* m_pSet;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RECORDEDITORDLG_H__8E40EAC2_DD10_11D2_9313_0060080F2D70__INCLUDED_)
