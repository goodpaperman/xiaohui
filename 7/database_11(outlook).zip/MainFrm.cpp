// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "mdbViewer.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CCJFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CCJFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		// DO NOT EDIT what you see in these blocks of generated code !
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
	ON_CBN_SELENDOK(IDC_COMBO, OnSelendokFlatCombo)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_LISTVIEWROW_NUM,
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CCJFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.Create(this) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// Add a drop down to button
	m_wndToolBar.AddDropDownButton(ID_FILE_OPEN, IDR_FILEDROPDOWN, TRUE);

	// TODO: Remove this if you don't want tool tips or a resizeable toolbar
	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);


	// Insert the CCJFlatComboBox control
	m_pComboBox = (CCJFlatComboBox*)m_wndToolBar.InsertControl(
		RUNTIME_CLASS(CCJFlatComboBox), _T(""), CRect(-165,-200,0,0), IDC_COMBO,
		WS_CHILD | CBS_DROPDOWN | CBS_AUTOHSCROLL | WS_VSCROLL | CBS_HASSTRINGS );

	//m_pComboBox->AddString("");
	//m_pComboBox->SetCurSel(0);

	// install/load cool menus
	m_menuManager.Install(this);
	m_menuManager.LoadToolbar(IDR_MAINFRAME);

	// To set up the status bar to display list view row numbers
	CClientDC dc(this);
	SIZE size=dc.GetTextExtent(_T("Record: 0000 of 0000"));
	int index=m_wndStatusBar.CommandToIndex(ID_LISTVIEWROW_NUM);
	m_wndStatusBar.SetPaneInfo(index,ID_LISTVIEWROW_NUM,SBPS_NORMAL,size.cx);


	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CCJFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CCJFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CCJFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers


BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext) 
{
  // Create the splitter window with two columns
  if (!m_wndSplitter.CreateStatic(this, 1, 2))
  {
    TRACE0("Failed to create splitter window\n");
    return FALSE;
  }

  // "Outlook" view first
  if (!m_wndSplitter.CreateView(0, 0, RUNTIME_CLASS(CContainerView),
		CSize(300, 0), pContext))
  {
    TRACE0("Failed to create CContainerView\n"); 
    return FALSE;
  }

  // "Flexible pane": The second pane may present its own
  // splitter windows.
  if (!m_wndSplitter.CreateView(0, 1, RUNTIME_CLASS(CmdbViewerView),
		CSize(0, 0), pContext))
  {
    TRACE0("Failed to create CmdbViewerView\n"); 
    return FALSE;
  }
 
  // Set the active view
  SetActiveView((CView*) m_wndSplitter.GetPane(0, 0));

  return TRUE;
}

void CMainFrame::OnSelendokFlatCombo() 
{
	// This is not fully implemented
	AfxMessageBox(_T("Flat Combo Box selection made..."));
}

CmdbViewerView* CMainFrame::GetmdbViewerView()
{
	return (CmdbViewerView*)m_wndSplitter.GetPane(0,1);
}

CContainerView* CMainFrame::GetContainerView()
{
	return (CContainerView*)m_wndSplitter.GetPane(0,0);
}

void CMainFrame::AddNewQuery(CString strquery)
{
	m_pComboBox->AddString(strquery);
	m_pComboBox->SetCurSel(0);
}
