#if !defined(AFX_OUTLOOKBARVIEW_H__FC539904_AE66_11D2_AB9F_A08556C10000__INCLUDED_)
#define AFX_OUTLOOKBARVIEW_H__FC539904_AE66_11D2_AB9F_A08556C10000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OutlookBarView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// COutlookBarView view

class COutlookBarView : public CView
{
protected:
	COutlookBarView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(COutlookBarView)

// Attributes
public:
protected:
	CCJOutlookBar	m_OutBar;
	CCJPagerCtrl	m_Pager;
	CFont			m_Font;
	CRect			m_pRect;

// Operations
public:
	void InitializeMenuControl();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COutlookBarView)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~COutlookBarView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(COutlookBarView)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	afx_msg BOOL OnOutbarNotify(WPARAM wParam, LPARAM lParam);
	
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OUTLOOKBARVIEW_H__FC539904_AE66_11D2_AB9F_A08556C10000__INCLUDED_)
