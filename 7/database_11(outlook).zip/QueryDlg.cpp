// QueryDlg.cpp : implementation file
//

#include "stdafx.h"
#include "mdbViewer.h"
#include "QueryDlg.h"
#include "mdbViewerDoc.h"
#include "mdbViewerView.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CQueryDlg dialog


CQueryDlg::CQueryDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CQueryDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CQueryDlg)
	m_label = _T("Enter query string here:");
	m_queryString = _T("");
	//}}AFX_DATA_INIT
}


void CQueryDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CQueryDlg)
	DDX_Control(pDX, IDC_QUERY_TABLE, m_CombCtrl);
	DDX_Text(pDX, IDC_QUERY_LABLE, m_label);
	DDX_Text(pDX, IDC_QUERY_TEXT, m_queryString);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CQueryDlg, CDialog)
	//{{AFX_MSG_MAP(CQueryDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CQueryDlg message handlers

void CQueryDlg::PopulateList()
{
	CmdbViewerView* pView =
		((CMainFrame*)AfxGetMainWnd())->GetmdbViewerView();
	CmdbViewerDoc* pDoc=pView->GetDocument();
	CDaoRecordset* pSet=pDoc->GetRecordSet();


	if(pSet!= NULL)
	{
		ASSERT_VALID(pSet);
		int nFields = (int) pSet->GetFieldCount();
		CDaoFieldInfo fi;
		for(int i = 0; i < nFields; i++) {
			pSet->GetFieldInfo(i, fi);
			m_CombCtrl.AddString(fi.m_strName);
		}
	
		int count = m_CombCtrl.GetCount();
		if(count != CB_ERR || count != 0)
		m_CombCtrl.SetCurSel(0);
	}
}

BOOL CQueryDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	PopulateList();	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CQueryDlg::OnOK() 
{
	int count = m_CombCtrl.GetCount();
	if(count == LB_ERR || count == 0)
		EndDialog(IDCANCEL);
	m_CombCtrl.GetLBText(m_CombCtrl.GetCurSel(), m_queryField);
	CDialog::OnOK();
}
