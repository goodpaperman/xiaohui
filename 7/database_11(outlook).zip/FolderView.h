#if !defined(AFX_FOLDERVIEW_H__FC539903_AE66_11D2_AB9F_A08556C10000__INCLUDED_)
#define AFX_FOLDERVIEW_H__FC539903_AE66_11D2_AB9F_A08556C10000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FolderView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFolderView view
class CmdbViewerDoc;
class CFolderView : public CTreeView
{
protected:
	CFolderView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CFolderView)

// Attributes
public:
	CTreeCtrl* m_pTreeCtrl;	
protected:
	CFont	   m_Font;
	CImageList m_ImageList;
	
// Operations
public:
	HTREEITEM m_htiDatabase;
	CmdbViewerDoc* GetDocument();
	void UpdateTree();
	HTREEITEM GetLastItem( HTREEITEM hItem );
	HTREEITEM GetNextItem( HTREEITEM hItem );
	HTREEITEM GetPrevItem( HTREEITEM hItem );
	HTREEITEM FindItem(CString &sSearch, 
				BOOL bCaseSensitive = FALSE, 
				BOOL bDownDir = TRUE, 
				BOOL bWholeWord = FALSE, 
				HTREEITEM hItem = NULL);
protected:
	virtual BOOL IsFindValid( HTREEITEM );

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFolderView)
	public:
	virtual void OnInitialUpdate();
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CFolderView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CFolderView)
	afx_msg void OnItemexpanding(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSelchanged(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDblclk(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOLDERVIEW_H__FC539903_AE66_11D2_AB9F_A08556C10000__INCLUDED_)
