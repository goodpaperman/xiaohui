// mdbViewerView.h : interface of the CmdbViewerView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MDBVIEWERVIEW_H__252C8B2D_AD54_11D2_AB9F_F0B24BC19807__INCLUDED_)
#define AFX_MDBVIEWERVIEW_H__252C8B2D_AD54_11D2_AB9F_F0B24BC19807__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CmdbViewerDoc;
class CmdbViewerView : public CCJListView
{
protected: // create from serialization only
	CmdbViewerView();
	DECLARE_DYNCREATE(CmdbViewerView)

// Attributes
public:
	CmdbViewerDoc* GetDocument();

protected:
	CListCtrl* m_pListCtrl;
	CImageList m_ImageList;
	CImageList m_ImageListNormal;
	CFont	   m_Font;
	CStatic    m_Caption;
	
	
// Operations
public:
		
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CmdbViewerView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation

public:
	void ExecuteQuery();
	void Enquery();
	void Navigation();
	BOOL UpdateListView(int nFlag,CStringArray* fieldValues);
	CString GetCurrentTableName() { return m_TableName;};
	int GetCurrentRecordIndex() { return m_nCurrentItemIndex;};
	int m_nFields;
	int m_nRecords;
	int m_nCurrentItemIndex;
	void SetSelectedItemIndex();
	CString formatedValue(COleVariant var);
	void ShowDBTable();
	void ClearListView();
	virtual ~CmdbViewerView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

// Generated message map functions
protected:
	//{{AFX_MSG(CmdbViewerView)
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnCancelMode();
	afx_msg void OnFilePrintPreview();
	//}}AFX_MSG
	// Update list row number to the statusbar pane (XL)
	afx_msg void OnUpdateListRowNum(CCmdUI* pCmdUI);
	DECLARE_MESSAGE_MAP()
private:
	void ProcessUpdating(CString strProcess);
	CUIntArray m_selectedRecords;
	BOOL m_IsQuery;
	CString m_queryField;
	int m_queryFieldIndex;
	CString m_queryString;
	CDaoRecordset* m_pSet;
	CString m_TableName;
	int m_nColsmax;
	
};

#ifndef _DEBUG  // debug version in mdbViewerView.cpp
inline CmdbViewerDoc* CmdbViewerView::GetDocument()
   { return (CmdbViewerDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MDBVIEWERVIEW_H__252C8B2D_AD54_11D2_AB9F_F0B24BC19807__INCLUDED_)
