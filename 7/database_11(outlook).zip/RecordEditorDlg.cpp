// RecordEditorDlg.cpp : implementation file
//

#include "stdafx.h"
#include "mdbViewer.h"
#include "RecordEditorDlg.h"
#include "ShowRecordDlg.h"
#include "MainFrm.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRecordEditorDlg dialog


CRecordEditorDlg::CRecordEditorDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CRecordEditorDlg::IDD, pParent)

{
	//{{AFX_DATA_INIT(CRecordEditorDlg)
	m_fieldValue1 = _T("");
	m_fieldValue2 = _T("");
	m_fieldValue3 = _T("");
	m_fieldValue4 = _T("");
	m_fieldValue5 = _T("");
	m_fieldValue6 = _T("");
	m_fieldValue7 = _T("");
	m_fieldValue8 = _T("");
	m_fieldName1 = _T("");
	m_fieldName2 = _T("");
	m_fieldName3 = _T("");
	m_fieldName4 = _T("");
	m_fieldName5 = _T("");
	m_fieldName6 = _T("");
	m_fieldName7 = _T("");
	m_fieldName8 = _T("");
	//}}AFX_DATA_INIT

	
	pView =
		((CMainFrame*)AfxGetMainWnd())->GetmdbViewerView();
	pDoc=pView->GetDocument();
	m_pSet=pDoc->GetRecordSet();

		
	m_fieldValues.SetSize(40);
	m_fieldNames.SetSize(40);
	m_pageNum=1; // set the first page by default
	m_pageCount=pView->m_nFields/8; // at least has one page
	if(!(pView->m_nFields%8==0))
		m_pageCount++;

		
}


void CRecordEditorDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	char buffer[20];
	CString str1=_T("Record No.: ");
	str1+=_itoa(pView->GetCurrentRecordIndex()+1,buffer,10);
	CString str2=_T("Table        : ")+pView->GetCurrentTableName();
	CString str3=_T("Database  : ")+pDoc->m_strDatabasePath;

	//{{AFX_DATA_MAP(CRecordEditorDlg)
	DDX_Text(pDX, IDC_EDIT_FD1, m_fieldValue1);
	DDX_Text(pDX, IDC_EDIT_FD2, m_fieldValue2);
	DDX_Text(pDX, IDC_EDIT_FD3, m_fieldValue3);
	DDX_Text(pDX, IDC_EDIT_FD4, m_fieldValue4);
	DDX_Text(pDX, IDC_EDIT_FD5, m_fieldValue5);
	DDX_Text(pDX, IDC_EDIT_FD6, m_fieldValue6);
	DDX_Text(pDX, IDC_EDIT_FD7, m_fieldValue7);
	DDX_Text(pDX, IDC_EDIT_FD8, m_fieldValue8);
	DDX_Text(pDX, IDC_STATIC_FD1, m_fieldName1);
	DDX_Text(pDX, IDC_STATIC_FD2, m_fieldName2);
	DDX_Text(pDX, IDC_STATIC_FD3, m_fieldName3);
	DDX_Text(pDX, IDC_STATIC_FD4, m_fieldName4);
	DDX_Text(pDX, IDC_STATIC_FD5, m_fieldName5);
	DDX_Text(pDX, IDC_STATIC_FD6, m_fieldName6);
	DDX_Text(pDX, IDC_STATIC_FD7, m_fieldName7);
	DDX_Text(pDX, IDC_STATIC_FD8, m_fieldName8);
		
	DDX_Text(pDX, IDC_RED_RECORDNO,str1);
	DDX_Text(pDX, IDC_RED_TABLENAME,str2);
	DDX_Text(pDX, IDC_RED_DATABASENAME,str3);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRecordEditorDlg, CDialog)
	//{{AFX_MSG_MAP(CRecordEditorDlg)
	ON_BN_CLICKED(IDC_RED_NEXT, OnRedNext)
	ON_COMMAND(IDC_RED_PREV, OnRecordPrev)
	ON_COMMAND(IDC_RED_FIRST, OnRecordFirst)
	ON_BN_CLICKED(IDC_RED_LAST, OnRedLast)
	ON_BN_CLICKED(IDC_RED_ADDNEW, OnRedAddnew)
	ON_BN_CLICKED(IDC_RED_PREVPAGE, OnRedPrevpage)
	ON_BN_CLICKED(IDC_RED_NEXTPAGE, OnRedNextpage)
	ON_BN_CLICKED(IDC_RED_DELETE, OnRedDelete)
	ON_BN_CLICKED(IDC_RED_MODIFY, OnRedModify)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRecordEditorDlg message handlers


void CRecordEditorDlg::OnRedNext() 
{
	// Due to switch from one table to another or
	// recordset reloading, the pDoc->m_pRecordset
	// will change from time to time, so that before
	// navigating the database, call m_pSet=pDoc->GetRecordSet()
	// to avoid errors occurd
 	m_pSet=pDoc->GetRecordSet();
	if(m_pSet!=NULL) {
		ASSERT_VALID(m_pSet);
		m_pSet->MoveNext();
		pView->m_nCurrentItemIndex++;
		if(m_pSet->IsEOF())
		{
			if(!m_pSet->CanScroll())
				m_pSet->SetFieldNull(NULL);
				m_pSet->MoveLast();
				pView->m_nCurrentItemIndex--;
			return;
		}
		ReadRecord();
		UpdateREDDialog(1);
	}
						
}
void CRecordEditorDlg::OnRecordPrev() 
{
	m_pSet=pDoc->GetRecordSet();
	if(m_pSet!=NULL) {
		ASSERT_VALID(m_pSet);
		m_pSet->MovePrev();
		pView->m_nCurrentItemIndex--;
		if(m_pSet->IsBOF())
		{
			m_pSet->MoveNext();
			pView->m_nCurrentItemIndex++;
			return;
		}
		ReadRecord();
		UpdateREDDialog(1);

	}
	
}

void CRecordEditorDlg::OnRecordFirst() 
{
	m_pSet=pDoc->GetRecordSet();
	m_pSet->MoveFirst();
	ReadRecord();
	UpdateREDDialog(1);
	pView->m_nCurrentItemIndex=0;
}


void CRecordEditorDlg::OnRedLast() 
{
	m_pSet=pDoc->GetRecordSet();
	m_pSet->MoveLast();
	ReadRecord();
	UpdateREDDialog(1);
	pView->m_nCurrentItemIndex=m_pSet->GetAbsolutePosition();

}

void CRecordEditorDlg::UpdateREDDialog(int nDlgW)
{

	int np=8*(nDlgW-1);

	SetDlgItemText(IDC_EDIT_FD1, m_fieldValues[np+0]);
	SetDlgItemText(IDC_EDIT_FD2, m_fieldValues[np+1]);
	SetDlgItemText(IDC_EDIT_FD3, m_fieldValues[np+2]);
	SetDlgItemText(IDC_EDIT_FD4, m_fieldValues[np+3]);
	SetDlgItemText(IDC_EDIT_FD5, m_fieldValues[np+4]);
	SetDlgItemText(IDC_EDIT_FD6, m_fieldValues[np+5]);
	SetDlgItemText(IDC_EDIT_FD7, m_fieldValues[np+6]);
	SetDlgItemText(IDC_EDIT_FD8, m_fieldValues[np+7]);

	SetDlgItemText(IDC_STATIC_FD1, m_fieldNames[np+0]);
	SetDlgItemText(IDC_STATIC_FD2, m_fieldNames[np+1]);
	SetDlgItemText(IDC_STATIC_FD3, m_fieldNames[np+2]);
	SetDlgItemText(IDC_STATIC_FD4, m_fieldNames[np+3]);
	SetDlgItemText(IDC_STATIC_FD5, m_fieldNames[np+4]);
	SetDlgItemText(IDC_STATIC_FD6, m_fieldNames[np+5]);
	SetDlgItemText(IDC_STATIC_FD7, m_fieldNames[np+6]);
	SetDlgItemText(IDC_STATIC_FD8, m_fieldNames[np+7]);

	char buffer[20];
	m_pSet=pDoc->GetRecordSet();
	CString msg=_itoa(m_pSet->GetAbsolutePosition()+1,buffer,10);
	SetDlgItemText(IDC_RED_RECORDNO,  _T("Record No.: "+msg));

}

void CRecordEditorDlg::ReadRecord(BOOL bFlag /*TRUE*/)
{
		COleVariant var;
		CString str;
			
		for (int i=0;i<pView->m_nFields;i++) {
			m_fieldValues[i]=_T("");
		}
		if(!bFlag) return;

		CDaoFieldInfo fi;
		m_pSet=pDoc->GetRecordSet();
		for (i = 0; i < pView->m_nFields; i++) {
			  var = m_pSet->GetFieldValue(i);
			  m_pSet->GetFieldInfo(i, fi);
			  m_fieldNames[i] = fi.m_strName;
			  switch (var.vt) {
			  case VT_BSTR:
				str = (LPCSTR) var.bstrVal; // narrow characters in DAO
				break;
			  case VT_I2:
				str.Format("%d", (int) var.iVal);
				break;
			  case VT_I4:
				str.Format("%d", var.lVal);
				break;
			  case VT_R4:
				str.Format("%10.2f", (double) var.fltVal);
				break;
			  case VT_R8:
				str.Format("%10.2f", var.dblVal);
				break;
			  case VT_CY:
				str = COleCurrency(var).Format();
				break;
			  case VT_DATE:
				str = COleDateTime(var).Format();
				break;
			  case VT_BOOL:
				str = (var.boolVal == 0) ? "FALSE" : "TRUE";
				break;
			  case VT_NULL:
				str =  "N/A";
				break;
			  default:
				str.Format("Unk type %d\n", var.vt);
				TRACE("Unknown type %d\n", var.vt);
			  }

			  m_fieldValues[i]=str;
			  			
		} // Loop on i
}

void CRecordEditorDlg::OnRedAddnew() 
{
	m_pSet=pDoc->GetRecordSet();
	if(m_pSet->CanUpdate()) {
		m_pSet->AddNew();
		// clear contexts of edit fields
		for (int i=0;i<pView->m_nFields;i++) {
			m_fieldValues[i]=_T("");
		}
		CShowRecordDlg* ARdlg=new CShowRecordDlg(this,pDoc,m_pSet,1);
		for (i=0;i<pView->m_nFields;i++) {
			ARdlg->PassFieldNames(i,m_fieldNames[i]);
		}
		ARdlg->m_fieldName1=m_fieldNames[0];
		ARdlg->m_fieldName2=m_fieldNames[1];
		ARdlg->m_fieldName3=m_fieldNames[2];
		ARdlg->m_fieldName4=m_fieldNames[3];
		ARdlg->m_fieldName5=m_fieldNames[4];
		ARdlg->m_fieldName6=m_fieldNames[5];
		ARdlg->m_fieldName7=m_fieldNames[6];
		ARdlg->m_fieldName8=m_fieldNames[7];

		if(ARdlg->DoModal()==IDOK)
		{
			pView->m_nRecords++;
			UpdateStatubar();
		}
	}
		
}

void CRecordEditorDlg::OnRedPrevpage() 
{
	m_pageNum--;
	if(m_pageNum==0) m_pageNum=1;
	ReadRecord();
	UpdateREDDialog(m_pageNum);
	
}

void CRecordEditorDlg::OnRedNextpage() 
{
	m_pageNum++;
	if(m_pageNum>m_pageCount) m_pageNum=m_pageCount;
	ReadRecord();
	UpdateREDDialog(m_pageNum);
	
}

void CRecordEditorDlg::PassFieldNames(int nf,CString fdname)
{
	m_fieldNames.SetAt(nf,fdname);
}

void CRecordEditorDlg::OnRedDelete() 
{
	m_pSet=pDoc->GetRecordSet();
	try {
	    m_pSet->Delete();
		m_pSet->MoveNext();
		if(m_pSet->IsEOF()) m_pSet->MovePrev();
	}
    catch(CDBException* e) {
		AfxMessageBox(_T("Here"));
        AfxMessageBox(e->m_strError);
        e->Delete();
		m_pSet->MoveFirst();
        return;
    }
	// if deleting fails, the following will not be done
	ReadRecord(FALSE);
	UpdateREDDialog(1);
	if(!pView->UpdateListView(3,&m_fieldValues))
		AfxMessageBox(_T("Fail to delete item from the list view"));
	pView->m_nRecords--;
	// need to update statusbar
	UpdateStatubar();
	
}

void CRecordEditorDlg::OnRedModify() 
{
	m_pSet=pDoc->GetRecordSet();
	if(m_pSet->CanUpdate()) {
		m_pSet->Edit( );
		
		CShowRecordDlg* ARdlg=new CShowRecordDlg(this,pDoc,m_pSet,2);
		for (int i=0;i<pView->m_nFields;i++) {
			ARdlg->PassFieldNames(i,m_fieldNames[i]);
			ARdlg->PassFieldValues(i,m_fieldValues[i]);
		}
		ARdlg->m_fieldName1=m_fieldNames[0];
		ARdlg->m_fieldName2=m_fieldNames[1];
		ARdlg->m_fieldName3=m_fieldNames[2];
		ARdlg->m_fieldName4=m_fieldNames[3];
		ARdlg->m_fieldName5=m_fieldNames[4];
		ARdlg->m_fieldName6=m_fieldNames[5];
		ARdlg->m_fieldName7=m_fieldNames[6];
		ARdlg->m_fieldName8=m_fieldNames[7];
		ARdlg->m_fieldValue1=m_fieldValues[0];
		ARdlg->m_fieldValue2=m_fieldValues[1];
		ARdlg->m_fieldValue3=m_fieldValues[2];
		ARdlg->m_fieldValue4=m_fieldValues[3];
		ARdlg->m_fieldValue5=m_fieldValues[4];
		ARdlg->m_fieldValue6=m_fieldValues[5];
		ARdlg->m_fieldValue7=m_fieldValues[6];
		ARdlg->m_fieldValue8=m_fieldValues[7];

		if(ARdlg->DoModal()==IDOK)
		{
			for (i=0;i<pView->m_nFields;i++) m_fieldValues[i]=ARdlg->GetFieldValues(i);
			UpdateREDDialog(1);
		}
	}
	
}

void CRecordEditorDlg::PassFieldValues(int nf, CString strValue)
{
	m_fieldValues.SetAt(nf,strValue);
}

void CRecordEditorDlg::UpdateStatubar()
{
	CMainFrame* pFrame=(CMainFrame*) AfxGetApp()->m_pMainWnd;
	CStatusBar* pStatus=&pFrame->m_wndStatusBar;
	CString strRowInfo;
	strRowInfo.Format(_T("Record: %d of %d"), pView->GetCurrentRecordIndex()+1, pView->m_nRecords);
	if(pStatus) {
		pStatus->SetPaneText(pStatus->CommandToIndex(ID_LISTVIEWROW_NUM),strRowInfo);
	}
}
