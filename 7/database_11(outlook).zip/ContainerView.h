#if !defined(AFX_CONTAINERVIEW_H__FC539902_AE66_11D2_AB9F_A08556C10000__INCLUDED_)
#define AFX_CONTAINERVIEW_H__FC539902_AE66_11D2_AB9F_A08556C10000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ContainerView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CContainerView view

#include "OutlookBarView.h"
#include "FolderView.h"

class CContainerView : public CView
{
protected:
	CContainerView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CContainerView)

// Attributes
public:
protected:
	CSplitterWnd		m_wndSplitter;

// Operations
public:
	CFolderView* GetFolderView();
	COutlookBarView* GetOutlookBarView();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CContainerView)
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CContainerView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CContainerView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONTAINERVIEW_H__FC539902_AE66_11D2_AB9F_A08556C10000__INCLUDED_)
