// mdbViewerDoc.cpp : implementation of the CmdbViewerDoc class
//

#include "stdafx.h"
#include "mdbViewer.h"
#include "mdbViewerDoc.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CmdbViewerDoc
// global helper function to display an error message
void DaoErrorMsg(CDaoException* e)
{
    char errorMsg[301];
   	wsprintf(errorMsg, "DAO error %d, SOURCE = %s, DESCR = %s",
        e->m_pErrorInfo->m_lErrorCode,
        (const char*) e->m_pErrorInfo->m_strSource,
        (const char*) e->m_pErrorInfo->m_strDescription);
   	AfxMessageBox(errorMsg);
}

IMPLEMENT_DYNCREATE(CmdbViewerDoc, CDocument)

BEGIN_MESSAGE_MAP(CmdbViewerDoc, CDocument)
	//{{AFX_MSG_MAP(CmdbViewerDoc)
	ON_COMMAND(ID_FILE_OPENMDB, OnFileOpenmdb)
	ON_COMMAND(ID_FILE_NEWMDB, OnFileNewmdb)
	ON_COMMAND(ID_FILE_NEW, OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CmdbViewerDoc construction/destruction

CmdbViewerDoc::CmdbViewerDoc()
{
	m_pRecordset=NULL;
	m_tableNames.SetSize(1);
}

CmdbViewerDoc::~CmdbViewerDoc()
{
}


BOOL CmdbViewerDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;
	
	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CmdbViewerDoc serialization

void CmdbViewerDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CmdbViewerDoc diagnostics

#ifdef _DEBUG
void CmdbViewerDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CmdbViewerDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CmdbViewerDoc commands


//  by XL

void CmdbViewerDoc::OnFileOpenmdb() 
{	
	// initialization of database pointers 
	m_strDatabasePath.Empty();
    if(m_pRecordset != NULL)
	{
		ASSERT_VALID(m_pRecordset);
		if(m_pRecordset->IsOpen())
			m_pRecordset->Close();
		delete m_pRecordset;
		m_pRecordset = NULL;
	}

	if(&m_mdbDatabase != NULL)
	{
		ASSERT_VALID(&m_mdbDatabase);
		if(m_mdbDatabase.IsOpen())
			m_mdbDatabase.Close();
	}

	DaoOpenMdb();
	
}

void CmdbViewerDoc::DaoOpenMdb()
{
	if (m_strDatabasePath.IsEmpty()) {
      CFileDialog dlg(TRUE, ".mdb", "*.mdb");
      if (dlg.DoModal() == IDCANCEL) return;
      m_strDatabasePath = dlg.GetPathName();
    }

    BeginWaitCursor();
    try {
      // nonexclusive, can update(not read-only)
      m_mdbDatabase.Open(m_strDatabasePath, FALSE, FALSE);
    }
    catch (CDaoException* e) {
      ::DaoErrorMsg(e);
      EndWaitCursor();
      e->Delete();
      return;
    }
    
	GetTableInfo();

	CContainerView* pContainer = 
				((CMainFrame*)AfxGetMainWnd())->GetContainerView();
	CFolderView* pFolderView = pContainer->GetFolderView();

	pFolderView->UpdateTree();

	UpdateAllViews(NULL);   
  	EndWaitCursor();
}

void CmdbViewerDoc::GetTableInfo()
{
	// find out number of tables and names
	CDaoTableDefInfo tabInfo;
	int ntables = m_mdbDatabase.GetTableDefCount();
	int k=0;
	for (int i = 0; i < ntables; i++)
	{
		m_mdbDatabase.GetTableDefInfo(i,tabInfo);
		if (tabInfo.m_lAttributes & dbSystemObject)
			continue;
		//Call this member function to set the array
		//element at the specified index. The array grows automatically if necessary
		m_tableNames.SetAtGrow(k,tabInfo.m_strName);
		k++;
	}
	m_ntables=k;
	// These are the tables we concern.
	// They are the tables provided by the Microsoft
	// Jet database engine	
}

void CmdbViewerDoc::LoadRecordset()
{
	
	if(m_pRecordset != NULL)
	{
		//ASSERT_VALID(m_pRecordset);
		if(m_pRecordset->IsOpen())
			m_pRecordset->Close();
		delete m_pRecordset;
		m_pRecordset = NULL;
	}
	// So you can see, after call for this method,
	// the pDoc->m_pRecordset is renewed
	// and therefore you must update your local variables associated
	// with pDoc->m_pRecordset, for example m_pSet.

	CString strQuery;
	strQuery.Format("select * from [%s]", m_tableName);
	m_pRecordset = new CDaoRecordset(&m_mdbDatabase);
    try {	
       m_pRecordset->Open(dbOpenDynaset, strQuery, dbInconsistent);
	 }
    catch (CDaoException* e) {
      ::DaoErrorMsg(e);
         e->Delete();
		return;
    }
    if (!m_pRecordset->IsBOF()) {
	  m_pRecordset->MoveFirst(); // point to the first record
    }
}

CString CmdbViewerDoc::IntoStr(int n)
{
	char buf[30];
	return _itoa(n,buf,10);
}
CString CmdbViewerDoc::IntoStr(long n)
{
	char buf[30];
	return _ltoa(n,buf,15);
}

CString CmdbViewerDoc::GetTableName(int ntb)
{
	return m_tableNames.GetAt(ntb);
}


void CmdbViewerDoc::SetTableName(CString tableName)
{
	m_tableName=tableName;
}

void CmdbViewerDoc::OnFileNewmdb() 
{
	AfxMessageBox(_T("On how to create a new MDB please\nsee MFC Sample daotable"));
	return;	
}

void CmdbViewerDoc::OnFileNew() 
{
	OnFileNewmdb();
	
}

void CmdbViewerDoc::OnFileOpen() 
{
	OnFileOpenmdb();	
}
