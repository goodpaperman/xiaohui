// ContainerView.cpp : implementation file
//

#include "stdafx.h"
#include "mdbViewer.h"
#include "ContainerView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CContainerView

IMPLEMENT_DYNCREATE(CContainerView, CView)

CContainerView::CContainerView()
{
}

CContainerView::~CContainerView()
{
}


BEGIN_MESSAGE_MAP(CContainerView, CView)
	//{{AFX_MSG_MAP(CContainerView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CContainerView drawing

void CContainerView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// CContainerView diagnostics

#ifdef _DEBUG
void CContainerView::AssertValid() const
{
	CView::AssertValid();
}

void CContainerView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CContainerView message handlers

int CContainerView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// CPaneContainerView is used to control the right pane that CMainFrame
	// sets up. In this case we create a second splitter window.
	m_wndSplitter.CreateStatic(this, 1,2);
	
	// The context information is passed on from the framework
	CCreateContext *pContext = (CCreateContext*)lpCreateStruct->lpCreateParams;
	
	// Create two views
	if (!m_wndSplitter.CreateView(0,0,RUNTIME_CLASS(COutlookBarView),
		CSize(100,0), pContext))
	{
		TRACE0("Failed to create COutlookBarView\n");
		return -1;
	}

	if (!m_wndSplitter.CreateView(0,1,RUNTIME_CLASS(CFolderView),
		CSize(0,0), pContext))
	{
		TRACE0("Failed to create CFolderView\n");
		return -1;
	}
	
	return 0;
}

void CContainerView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	m_wndSplitter.MoveWindow(-2,-2,cx+4,cy+4);
}

COutlookBarView* CContainerView::GetOutlookBarView()
{
	return (COutlookBarView*)m_wndSplitter.GetPane(0,0);
}

CFolderView* CContainerView::GetFolderView()
{
	return (CFolderView*)m_wndSplitter.GetPane(0,1);
}
