// mdbViewerDoc.h : interface of the CmdbViewerDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MDBVIEWERDOC_H__252C8B2B_AD54_11D2_AB9F_F0B24BC19807__INCLUDED_)
#define AFX_MDBVIEWERDOC_H__252C8B2B_AD54_11D2_AB9F_F0B24BC19807__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

extern void DaoErrorMsg(CDaoException* e);


class CmdbViewerDoc : public CDocument
{
protected: // create from serialization only
	CmdbViewerDoc();
	DECLARE_DYNCREATE(CmdbViewerDoc)
	
// Attributes
public:
	CString m_strDatabasePath;

private:
	int m_ntables;
	int m_fieldNumber[40];
	CString m_tableName;
	CStringArray m_tableNames;
	CDaoRecordset* m_pRecordset;
	CDaoDatabase  m_mdbDatabase;
	void DaoOpenMdb();
	void GetTableInfo();
	

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CmdbViewerDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	void SetTableName(CString tableName);
	CString GetTableName(int ntb);
	CString IntoStr(int n);
	CString IntoStr(long n);
	CDaoRecordset* GetRecordSet(){return m_pRecordset;};
	CString GetTableName() { return m_tableName; };
	int GetTableNumber() { return m_ntables; };
	void LoadRecordset();
	virtual ~CmdbViewerDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

// Generated message map functions
protected:
	//{{AFX_MSG(CmdbViewerDoc)
	afx_msg void OnFileOpenmdb();
	afx_msg void OnFileNewmdb();
	afx_msg void OnFileNew();
	afx_msg void OnFileOpen();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MDBVIEWERDOC_H__252C8B2B_AD54_11D2_AB9F_F0B24BC19807__INCLUDED_)
