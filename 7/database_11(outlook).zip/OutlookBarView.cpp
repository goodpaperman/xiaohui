// OutlookBarView.cpp : implementation file
//

#include "stdafx.h"
#include "mdbViewer.h"
#include "OutlookBarView.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COutlookBarView

IMPLEMENT_DYNCREATE(COutlookBarView, CView)

COutlookBarView::COutlookBarView()
{
}

COutlookBarView::~COutlookBarView()
{
}


BEGIN_MESSAGE_MAP(COutlookBarView, CView)
	//{{AFX_MSG_MAP(COutlookBarView)
	ON_WM_SIZE()
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_OUTLOOKBAR_NOTIFY, OnOutbarNotify)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COutlookBarView drawing

void COutlookBarView::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// COutlookBarView diagnostics

#ifdef _DEBUG
void COutlookBarView::AssertValid() const
{
	CView::AssertValid();
}

void COutlookBarView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

// Menu Information for the Content Bar
CContentItems ContentInfo[] =
{
	CContentItems (0, _T("Navigation")),
	CContentItems (1, _T("Query")),
	CContentItems (2, _T("Statistic")),
	CContentItems (3, _T("Contact"))
};

/////////////////////////////////////////////////////////////////////////////
// COutlookBarView message handlers

void COutlookBarView::OnInitialUpdate() 
{
	CView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	InitializeMenuControl();
}

void COutlookBarView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	// Size the outlook style menu, and set 
	// the column size same as view
	m_Pager.MoveWindow(0,0,cx,cy);
	m_OutBar.Invalidate(true);
}

int COutlookBarView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// Create the pager control and set its parent to 'this'
	if (!m_Pager.Create(WS_CHILD|WS_VISIBLE|PGS_VERT,
		CRect(0,0,0,0), this, IDC_PAGER_CONTROL ))
	{
		TRACE0("Failed to create CPagerCtrl...\n");
		return -1;
	}

	// Define the style to use with the COutlookBar.
	DWORD dwStyle = WS_CHILD | WS_VISIBLE | LBS_OWNERDRAWVARIABLE | 
		LBS_NOINTEGRALHEIGHT | WS_TABSTOP;

	// Create the COutlookBar, and set its parent to CPagerCtrl.
	if (!m_OutBar.Create( dwStyle, CRect(0,0,0,0),
		&m_Pager, IDC_OUTLOOK_BAR ))
	{
		TRACE0("Failed to create COutlookBar...\n");
		return -1;
	}
	
	// Set the CWnd object you want messages sent to.
	m_OutBar.SetOwner (this);

	// Set the Vert/Horz scroll area for pager.
	m_Pager.SetScrollArea(0,300);

	// Set the child HWND to COutlookBar, and button size to 15.
	m_Pager.SetChild(m_OutBar.m_hWnd);
	m_Pager.SetButtonSize(15);
	
	return 0;
}

void COutlookBarView::InitializeMenuControl()
{
    // Define the font to be used for the menu control
	m_Font.CreatePointFont (85, _T("Tahoma"));
    m_OutBar.SetFont(&m_Font);
	m_OutBar.SetImageLists(&theApp.m_ImageListSmall, &theApp.m_ImageListLarge);
	m_OutBar.SetItems(ContentInfo, sizeof(ContentInfo)/sizeof(CContentItems));
}

BOOL COutlookBarView::OnOutbarNotify(WPARAM wParam, LPARAM lParam)
{
	// Get the pointer of GetmdbViewerView() from CMainFrame.
	CmdbViewerView* pView =
		((CMainFrame*)AfxGetMainWnd())->GetmdbViewerView();
	//CListCtrl& refListCtrl = pView->GetListCtrl();

	CString str;
	switch (wParam)
	{
		case OBM_ITEMCLICK:
		{
			switch ((int)lParam)
			{
			case 0:
				pView->Navigation();
				break;
			case 1:
				pView->Enquery();
				break;
			case 2:
				AfxMessageBox(_T("I will use this for my project\nwith a specific database."));
				break;
			case 3:
				AfxMessageBox(_T("If you got any idea about this program,\nbugs or improvements,please notify me in details \nXiaojian.liu@port.ac.uk"));
			default:
				break;
			}
			
			return TRUE;
		}
	}
	
	return FALSE;
}
