#if !defined(AFX_SHOWRECORDDLG_H__7B1B7183_E04F_11D2_9313_0060080F2D70__INCLUDED_)
#define AFX_SHOWRECORDDLG_H__7B1B7183_E04F_11D2_9313_0060080F2D70__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ShowRecordDlg.h : header file
//
#include "mdbViewerDoc.h"
/////////////////////////////////////////////////////////////////////////////
// CShowRecordDlg dialog

class CShowRecordDlg : public CDialog
{
// Construction
public:
	void PassFieldValues(int nf,CString strValue);
	CString GetFieldValues(int nf);
	void PassFieldNames(int nf,CString strName);
	CShowRecordDlg(CWnd* pParent = NULL,CmdbViewerDoc* ipDoc=NULL,
		CDaoRecordset* pSet=NULL,int editID=1);   // constructor

// Dialog Data
	//{{AFX_DATA(CShowRecordDlg)
	enum { IDD = IDD_SHOWRECORDDLG };
	CString	m_fieldValue1;
	CString	m_fieldValue2;
	CString	m_fieldValue3;
	CString	m_fieldValue4;
	CString	m_fieldValue5;
	CString	m_fieldValue6;
	CString	m_fieldValue7;
	CString	m_fieldValue8;
	CString	m_fieldName1;
	CString	m_fieldName2;
	CString	m_fieldName3;
	CString	m_fieldName4;
	CString	m_fieldName5;
	CString	m_fieldName6;
	CString	m_fieldName7;
	CString	m_fieldName8;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CShowRecordDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	void SaveInput();
	void UpdateARDialog(int nDlgW);
	// Generated message map functions
	//{{AFX_MSG(CShowRecordDlg)
	afx_msg void OnArNextpage();
	afx_msg void OnArPrevpage();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	int m_editid;
	CString GetFieldType(int nf);
	CWnd* pParentW;
	CStringArray m_fieldNames;
	CStringArray m_fieldValues;
	CmdbViewerDoc* pDoc;
	CDaoRecordset* m_pSet;
	int m_pageNum;
	int m_pageCount;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SHOWRECORDDLG_H__7B1B7183_E04F_11D2_9313_0060080F2D70__INCLUDED_)
