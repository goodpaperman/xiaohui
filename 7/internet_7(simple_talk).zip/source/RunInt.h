// RunInt.h : Declaration of the CRunInt

#ifndef __RUNINT_H_
#define __RUNINT_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CRunInt
class ATL_NO_VTABLE CRunInt : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CRunInt, &CLSID_RunInt>,
	public IDispatchImpl<IRunInt, &IID_IRunInt, &LIBID_UNITALK2Lib>
{
public:
	CRunInt()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_RUNINT)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CRunInt)
	COM_INTERFACE_ENTRY(IRunInt)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// IRunInt
public:
};

#endif //__RUNINT_H_
