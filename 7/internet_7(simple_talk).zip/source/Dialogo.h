// Dialogo.h : Declaration of the CDialogo

#ifndef __DIALOGO_H_
#define __DIALOGO_H_

#include "resource.h"       // main symbols
#include <atlhost.h>
#include <windowsx.h>

#include "UniTalk2.h"
/////////////////////////////////////////////////////////////////////////////
// CDialogo
class CRx2;
class CCall2;
//class CWriteOnTx;

class CDialogo : public CAxDialogImpl<CDialogo>
{
public:
	CDialogo(bool ConnectBool)
	{
		mConnectBool = ConnectBool;
		
	}
	

	~CDialogo()
	{
	}
	
	enum { IDD = IDD_DIALOGO };

BEGIN_MSG_MAP(CDialogo)
	MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
	COMMAND_ID_HANDLER(IDOK, OnOK)
	COMMAND_ID_HANDLER(IDCANCEL, OnCancel)
	COMMAND_HANDLER(IDC_WRITE, EN_CHANGE, OnChangeWrite)
	COMMAND_HANDLER(IDC_ADDRESS, CB_GETCURSEL, OnSelectIpaddress)
	COMMAND_HANDLER(IDC_ADDRESS, CBN_SELENDOK, OnSelendokIpaddress)
	COMMAND_HANDLER(IDC_ADDRESS, CBN_SELCHANGE, OnSelchangeIpaddress)
	COMMAND_HANDLER(IDC_ADDRESS, CBN_DROPDOWN, OnDropdownIpaddress)
	COMMAND_HANDLER(IDC_NOCOM, BN_CLICKED, OnClickedNocom)
	COMMAND_HANDLER(IDC_YESCOM, BN_CLICKED, OnClickedYescom)
END_MSG_MAP()
// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

	LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
	
		EnableControls(mConnectBool);

		res = 0;
		mpRx2 = NULL;
		pCall2 = NULL;
		pConnPtContainer = NULL;
		m_pIRx2ConnectionPoint = NULL;

		m_dwCookie = 0;
		ZeroMemory(SelectedIp,sizeof(SelectedIp));
		mWriteOnReturn = false;
		AnswerforDialog = false;

	return 1;  // Let the system set the focus
	}

	LRESULT OnOK(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		//EndDialog(wID);
		return 0;
	}

	LRESULT OnCancel(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		if (mpRx2 != NULL)
		{
		#ifdef _DEBUG
			_ASSERT(((IRx2*)mpRx2)->Release() == 0);
		#else
			((IRx2*)mpRx2)->Release();
		#endif
			mpRx2 = NULL;
		}
		
		if(m_pIRx2ConnectionPoint != NULL)
		{
		hr = m_pIRx2ConnectionPoint->Unadvise(m_dwCookie);
		}
		if(SUCCEEDED(hr))
		{
			m_dwCookie = 0;
		}
		
		if(pCall2 != NULL )
		hr = pCall2->Release();
		if(m_pIRx2ConnectionPoint != NULL )
		hr = m_pIRx2ConnectionPoint->Release();

		if(mConnectBool)
			EndDialog(wID);
		else
			DestroyWindow();
		return 0;
	}

	LRESULT OnChangeWrite(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);

	LRESULT OnClickedConnect(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
	
	

private:
	bool mConnectBool;
	bool mWriteOnReturn;
	bool AnswerforDialog;
	
	
public:
	HWND mhCombo ;
	void ShowOnReadMon(BSTR mWord);
	void RunCombo();
	void EnableControls(bool mConn);
	void RunConnection();
	void Agree(int* mrVal);
	void ShowCaller(BSTR mTheCaller);

	typedef struct ipaddress 
					{
						char utente[64];
						char address[64];
					} _IpAddress;
		

	_IpAddress ArrAddr[25];
	
	int CurrIndex;
	char SelectedIp[20];

	static bool mLocalTalk;

	
///////////////////////////  RX  //////////////////
	int i, res;
	HRESULT hr;

	CCall2*  mpCall2;
	void SetCaller(CCall2* mp_Call2) {  mpCall2 = mp_Call2;  }
	inline void SetBoolOfReturnWrite(bool mRetWrit) { mWriteOnReturn = mRetWrit;}
	//static IRx2* g_pRx2;

///////////////////////////  TX  //////////////////
	ICall2*	pCall2;
	CRx2*		mpRx2;
	DWORD       m_dwCookie;
	IConnectionPointContainer* pConnPtContainer;
	IConnectionPoint*          m_pIRx2ConnectionPoint; 
//	IWriteOnTx*	pWriteOnTx;
/////////////////////////////////////////
	LRESULT OnSelectIpaddress(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		//ATLTRACE("il numero e' %d",wNotifyCode);
		::MessageBox(NULL,"OnSelectIpaddress","ivan",MB_OK);
		return 0;
	}

	LRESULT OnSelendokIpaddress(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		//::MessageBox(NULL,"OnSelendokIpaddress","ivan",MB_OK);
		//int a = ComboBox_GetCurSel(GetDlgItem(IDC_ADDRESS));
		CurrIndex = ::SendMessage(mhCombo,CB_GETCURSEL ,0,0);
		::SetWindowText(GetDlgItem(IDC_IP),ArrAddr[CurrIndex].address);
		strcpy(SelectedIp,ArrAddr[CurrIndex].address);

	 RunConnection();

		return 0;
	}

	LRESULT OnSelchangeIpaddress(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		//::MessageBox(NULL,"OnSelchangeIpaddress","ivan",MB_OK);
		return 0;
	}
	LRESULT OnDropdownIpaddress(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		return 0;
	}


LRESULT OnClickedNocom(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
LRESULT OnClickedYescom(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);

};

#endif //__DIALOGO_H_
