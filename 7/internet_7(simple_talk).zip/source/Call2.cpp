// Call2.cpp : Implementation of CCall2
#include "stdafx.h"
#include "UniTalk2.h"
#include "Call2.h"


/////////////////////////////////////////////////////////////////////////////
// CCall2

////////////////////////////////////////
CDialogo* CCall2::mpDialo1 = NULL;
CDialogo* CCall2::mpDialo2 = NULL;
////////////////////////////////////////

CCall2::CCall2()
{
	MainBool = false;
}

STDMETHODIMP CCall2::Advise(IUnknown* pUnk, DWORD* pdwCookie)
{
	HRESULT hr = CProxyIRx2<CCall2>::Advise(pUnk, pdwCookie);
	if (SUCCEEDED(hr))
	{}

	return S_OK;
}

STDMETHODIMP CCall2::Unadvise(DWORD dwCookie)
{
	HRESULT hr = CProxyIRx2<CCall2>::Unadvise(dwCookie);

	return S_OK;
}


STDMETHODIMP CCall2::Run(int *mstart)
{
//se il programma gira in locale instanzia un nuovo dialogo con  cui
//comunicare; naturalmente il 2� dialogo sar� modeless;

	//	MainBool = false;
	if(!MainBool)
		{
			
		if(CDialogo::mLocalTalk) {
			CCall2::mpDialo2 = new CDialogo(false);
			_ASSERTE(CCall2::mpDialo2 != NULL);
			CCall2::mpDialo2->Create(NULL);
			CCall2::mpDialo2->ShowWindow(SW_SHOWNORMAL);
			//CCall2::mpDialo2->ShowCaller(TheCaller);
			}else			
				{	
				//CCall2::mpDialo2 = new CDialogo(false);
				//_ASSERTE(CCall2::mpDialo2 != NULL);
				//CCall2::mpDialo2->DoModal();
				}
				
			if(CCall2::mpDialo2 != NULL)
			CCall2::mpDialo2->SetCaller(this);
		}	
	
	*mstart = 180572;
	return S_OK;
}

STDMETHODIMP CCall2::ShowWords(BSTR mWords)
{
	CCall2::mpDialo2->ShowOnReadMon(mWords);
	return S_OK;
}

STDMETHODIMP CCall2::SetBoolForWriteOnReturn(int WriteRetBool)
{
	if( WriteRetBool == 1)
		CCall2::mpDialo2->SetBoolOfReturnWrite(true);
	else
	if( WriteRetBool == 0)
		CCall2::mpDialo2->SetBoolOfReturnWrite(false);
	
	return S_OK;
}

