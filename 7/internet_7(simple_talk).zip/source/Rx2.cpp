// Rx22.cpp : Implementation of CRx22
#include "stdafx.h"
#include "UniTalk2.h"
#include "Rx2.h"
#include "Call2.h"

/////////////////////////////////////////////////////////////////////////////
// CRx2


STDMETHODIMP CRx2::WriteOnTheReturn(BSTR mRetWords)
{
	CCall2::mpDialo1->ShowOnReadMon(mRetWords);

	return S_OK;
}

STDMETHODIMP CRx2::IAgree(int *rVal)
{

	CCall2::mpDialo1->Agree(rVal);
	
	return S_OK;
}
