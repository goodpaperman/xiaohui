///////////////////////////////////////////////////////////////////////////////////
// IDrawServ : IDispatch (Dual)
//
// This is a part of the Active Template Library.
// Copyright (C) 1996-1998 Microsoft Corporation
// All rights reserved.
//
// This source code is only intended as a supplement to the
// Active Template Library Reference and related
// electronic documentation provided with the library.
// See these sources for detailed information regarding the
// Active Template Library product.

extern const IID IID_IRx2;

template <class T>
class CProxyIRx2 :
	public IConnectionPointImpl<T, &IID_IRx2, CComDynamicUnkArray>
{

public:
	HRESULT ReturnWrite( BSTR mBstr )
	{
		T* pT = (T*)this;
		pT->Lock();
		HRESULT hr = S_OK;
		IUnknown** pp = m_vec.begin();
		IUnknown** ppEnd = m_vec.end();
		while (pp < ppEnd && hr == S_OK)
		{
			if (*pp != NULL)
			{
				IRx2* pIRx2 = (IRx2*)*pp;
				hr = pIRx2->WriteOnTheReturn(mBstr);

			}
			pp++;
		}
		pT->Unlock();
		return hr;
	}

	HRESULT ReturnAgree(int* mRVal )
	{
		T* pT = (T*)this;
		pT->Lock();
		HRESULT hr = S_OK;
		IUnknown** pp = m_vec.begin();
		IUnknown** ppEnd = m_vec.end();
		while (pp < ppEnd && hr == S_OK)
		{
			if (*pp != NULL)
			{
				IRx2* pIRx2 = (IRx2*)*pp;
				hr = pIRx2->IAgree(mRVal);

			}
			pp++;
		}
		pT->Unlock();
		return hr;
	}
	
	
	
};
