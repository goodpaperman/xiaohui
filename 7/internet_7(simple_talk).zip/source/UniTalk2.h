/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Wed Nov 03 15:21:58 1999
 */
/* Compiler settings for C:\ivan\projects\1999-09-11\UniTalk2\UniTalk2.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __UniTalk2_h__
#define __UniTalk2_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IRunInt_FWD_DEFINED__
#define __IRunInt_FWD_DEFINED__
typedef interface IRunInt IRunInt;
#endif 	/* __IRunInt_FWD_DEFINED__ */


#ifndef __ICall2_FWD_DEFINED__
#define __ICall2_FWD_DEFINED__
typedef interface ICall2 ICall2;
#endif 	/* __ICall2_FWD_DEFINED__ */


#ifndef __IRx2_FWD_DEFINED__
#define __IRx2_FWD_DEFINED__
typedef interface IRx2 IRx2;
#endif 	/* __IRx2_FWD_DEFINED__ */


#ifndef __RunInt_FWD_DEFINED__
#define __RunInt_FWD_DEFINED__

#ifdef __cplusplus
typedef class RunInt RunInt;
#else
typedef struct RunInt RunInt;
#endif /* __cplusplus */

#endif 	/* __RunInt_FWD_DEFINED__ */


#ifndef __Call2_FWD_DEFINED__
#define __Call2_FWD_DEFINED__

#ifdef __cplusplus
typedef class Call2 Call2;
#else
typedef struct Call2 Call2;
#endif /* __cplusplus */

#endif 	/* __Call2_FWD_DEFINED__ */


#ifndef __Rx2_FWD_DEFINED__
#define __Rx2_FWD_DEFINED__

#ifdef __cplusplus
typedef class Rx2 Rx2;
#else
typedef struct Rx2 Rx2;
#endif /* __cplusplus */

#endif 	/* __Rx2_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IRunInt_INTERFACE_DEFINED__
#define __IRunInt_INTERFACE_DEFINED__

/* interface IRunInt */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IRunInt;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("29ADA38F-616A-11D5-9488-00104B55AD91")
    IRunInt : public IDispatch
    {
    public:
    };
    
#else 	/* C style interface */

    typedef struct IRunIntVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IRunInt __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IRunInt __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IRunInt __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IRunInt __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IRunInt __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IRunInt __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IRunInt __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        END_INTERFACE
    } IRunIntVtbl;

    interface IRunInt
    {
        CONST_VTBL struct IRunIntVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IRunInt_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IRunInt_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IRunInt_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IRunInt_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IRunInt_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IRunInt_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IRunInt_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __IRunInt_INTERFACE_DEFINED__ */


#ifndef __ICall2_INTERFACE_DEFINED__
#define __ICall2_INTERFACE_DEFINED__

/* interface ICall2 */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ICall2;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("29ADA391-616A-11D5-9488-00104B55AD91")
    ICall2 : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Run( 
            int __RPC_FAR *mstart) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ShowWords( 
            BSTR mWords) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetBoolForWriteOnReturn( 
            int WriteRetBool) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ICall2Vtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ICall2 __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ICall2 __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ICall2 __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ICall2 __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ICall2 __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ICall2 __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ICall2 __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Run )( 
            ICall2 __RPC_FAR * This,
            int __RPC_FAR *mstart);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ShowWords )( 
            ICall2 __RPC_FAR * This,
            BSTR mWords);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetBoolForWriteOnReturn )( 
            ICall2 __RPC_FAR * This,
            int WriteRetBool);
        
        END_INTERFACE
    } ICall2Vtbl;

    interface ICall2
    {
        CONST_VTBL struct ICall2Vtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ICall2_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ICall2_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ICall2_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ICall2_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ICall2_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ICall2_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ICall2_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ICall2_Run(This,mstart)	\
    (This)->lpVtbl -> Run(This,mstart)

#define ICall2_ShowWords(This,mWords)	\
    (This)->lpVtbl -> ShowWords(This,mWords)

#define ICall2_SetBoolForWriteOnReturn(This,WriteRetBool)	\
    (This)->lpVtbl -> SetBoolForWriteOnReturn(This,WriteRetBool)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICall2_Run_Proxy( 
    ICall2 __RPC_FAR * This,
    int __RPC_FAR *mstart);


void __RPC_STUB ICall2_Run_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICall2_ShowWords_Proxy( 
    ICall2 __RPC_FAR * This,
    BSTR mWords);


void __RPC_STUB ICall2_ShowWords_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICall2_SetBoolForWriteOnReturn_Proxy( 
    ICall2 __RPC_FAR * This,
    int WriteRetBool);


void __RPC_STUB ICall2_SetBoolForWriteOnReturn_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ICall2_INTERFACE_DEFINED__ */


#ifndef __IRx2_INTERFACE_DEFINED__
#define __IRx2_INTERFACE_DEFINED__

/* interface IRx2 */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IRx2;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("29ADA395-616A-11D5-9488-00104B55AD91")
    IRx2 : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE WriteOnTheReturn( 
            BSTR mRetWords) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IAgree( 
            int __RPC_FAR *rVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IRx2Vtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IRx2 __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IRx2 __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IRx2 __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IRx2 __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IRx2 __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IRx2 __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IRx2 __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *WriteOnTheReturn )( 
            IRx2 __RPC_FAR * This,
            BSTR mRetWords);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *IAgree )( 
            IRx2 __RPC_FAR * This,
            int __RPC_FAR *rVal);
        
        END_INTERFACE
    } IRx2Vtbl;

    interface IRx2
    {
        CONST_VTBL struct IRx2Vtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IRx2_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IRx2_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IRx2_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IRx2_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IRx2_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IRx2_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IRx2_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IRx2_WriteOnTheReturn(This,mRetWords)	\
    (This)->lpVtbl -> WriteOnTheReturn(This,mRetWords)

#define IRx2_IAgree(This,rVal)	\
    (This)->lpVtbl -> IAgree(This,rVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IRx2_WriteOnTheReturn_Proxy( 
    IRx2 __RPC_FAR * This,
    BSTR mRetWords);


void __RPC_STUB IRx2_WriteOnTheReturn_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IRx2_IAgree_Proxy( 
    IRx2 __RPC_FAR * This,
    int __RPC_FAR *rVal);


void __RPC_STUB IRx2_IAgree_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IRx2_INTERFACE_DEFINED__ */



#ifndef __UNITALK2Lib_LIBRARY_DEFINED__
#define __UNITALK2Lib_LIBRARY_DEFINED__

/* library UNITALK2Lib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_UNITALK2Lib;

EXTERN_C const CLSID CLSID_RunInt;

#ifdef __cplusplus

class DECLSPEC_UUID("29ADA390-616A-11D5-9488-00104B55AD91")
RunInt;
#endif

EXTERN_C const CLSID CLSID_Call2;

#ifdef __cplusplus

class DECLSPEC_UUID("29ADA392-616A-11D5-9488-00104B55AD91")
Call2;
#endif

EXTERN_C const CLSID CLSID_Rx2;

#ifdef __cplusplus

class DECLSPEC_UUID("29ADA396-616A-11D5-9488-00104B55AD91")
Rx2;
#endif
#endif /* __UNITALK2Lib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
