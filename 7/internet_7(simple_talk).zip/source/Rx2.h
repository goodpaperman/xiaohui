// Rx2.h : Declaration of the CRx2

#ifndef __RX2_H_
#define __RX2_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CRx2
class ATL_NO_VTABLE CRx2 : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CRx2, &CLSID_Rx2>,
	public IDispatchImpl<IRx2, &IID_IRx2, &LIBID_UNITALK2Lib>
{
public:
	CRx2()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_RX2)
DECLARE_NOT_AGGREGATABLE(CRx2)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CRx2)
	COM_INTERFACE_ENTRY(IRx2)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// IRx2
public:
	STDMETHOD(IAgree)(int* rVal);
	STDMETHOD(WriteOnTheReturn)(BSTR mRetWords);

};

#endif //__RX2_H_
