// RunInt.cpp : Implementation of CRunInt
#include "stdafx.h"
#include "UniTalk2.h"
#include "RunInt.h"

/////////////////////////////////////////////////////////////////////////////
// CRunInt

