// Call2.h : Declaration of the CCall2

#ifndef __CALL2_H_
#define __CALL2_H_

#include "resource.h"       // main symbols
#include "Dialogo.h"
#include "CPIRx2.h"

/////////////////////////////////////////////////////////////////////////////
// CCall2
class ATL_NO_VTABLE CCall2 : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CCall2, &CLSID_Call2>,
	public CProxyIRx2< CCall2 >,
	public IConnectionPointContainerImpl<CCall2>,
	public IDispatchImpl<ICall2, &IID_ICall2, &LIBID_UNITALK2Lib>
{
public:
	CCall2();
	

DECLARE_REGISTRY_RESOURCEID(IDR_CALL2)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CCall2)
	COM_INTERFACE_ENTRY(ICall2)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IConnectionPointContainer)
END_COM_MAP()
BEGIN_CONNECTION_POINT_MAP(CCall2)
CONNECTION_POINT_ENTRY(IID_IRx2)
END_CONNECTION_POINT_MAP()


public:
	STDMETHOD(Advise)(IUnknown* pUnk, DWORD* pdwCookie);
	STDMETHOD(Unadvise)(DWORD dwCookie);

public:
	STDMETHOD(SetBoolForWriteOnReturn)(int WriteRetBool);
	STDMETHOD(ShowWords)(BSTR mWords);
	STDMETHOD(Run)(int* mstart);

static CDialogo* mpDialo1;
static CDialogo* mpDialo2;
};

#endif //__CALL2_H_
