// Dialogo.cpp : Implementation of CDialogo
#include "stdafx.h"
#include "Dialogo.h"
#include "Rx2.h"
#include "Call2.h"


//IRx2* CDialogo::g_pRx2 = NULL;
bool CDialogo::mLocalTalk = false;	

void CDialogo::ShowOnReadMon(BSTR mWord)
{
	USES_CONVERSION;
	char	Appstr[1024];
	ZeroMemory(Appstr,sizeof(Appstr));
	/*
	::GetWindowText(GetDlgItem(IDC_READ),Appstr,1000);
	strcat(Appstr,OLE2CA(mWord));
	::SetWindowText(GetDlgItem(IDC_READ), Appstr);
	*/
	::SetWindowText(GetDlgItem(IDC_READ), OLE2CA(mWord));

}

LRESULT CDialogo::OnChangeWrite(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
	char	Buf1[1024];
	ZeroMemory(Buf1,sizeof(Buf1));
	char	Buf2[1024];
	ZeroMemory(Buf2,sizeof(Buf2));
	char	mApp[3];
	ZeroMemory(mApp,sizeof(mApp));


	USES_CONVERSION;
	BSTR mBst1,mBst2;

	if( mConnectBool )
	{
		int chr = ::GetWindowTextLength(GetDlgItem(IDC_WRITE));
		::GetWindowText(GetDlgItem(IDC_WRITE),Buf1,1000);
		
		int siz = sizeof(*(A2W(Buf1)));
		mBst1 = SysAllocString(A2W(Buf1));
		/*
		mApp[0] = ((Buf1[chr-2]==13)?13:Buf1[chr-1]);
		mApp[1] = ((Buf1[chr-2]==13)?10:'\0');
		mBst1 = SysAllocString(A2W(mApp));
		*/
/////////////////////////////////////////////////
		hr = pCall2->SetBoolForWriteOnReturn(1);
		hr = pCall2->ShowWords(mBst1);
		hr = pCall2->SetBoolForWriteOnReturn(0);
/////////////////////////////////////////////////
	}
	else
		{
		int chr = ::GetWindowTextLength(GetDlgItem(IDC_WRITE));
		::GetWindowText(GetDlgItem(IDC_WRITE),Buf2,1000);
		/*
		mApp[0] = ((Buf2[chr-2]==13)?13:Buf2[chr-1]);
		mApp[1] = ((Buf2[chr-2]==13)?10:'\0');
		mBst2 = SysAllocString(A2W(mApp));
		*/
		mBst2 = SysAllocString(A2W(Buf2));

//solo e solo se la mRetWrit � falsa deve essere possibile trasmettere in ritorno dato
//che viene utilizzata la stessa interfaccia sia per Tx che pr Rx2;
		
		if(!mWriteOnReturn)
			hr = mpCall2->ReturnWrite( mBst2 );
			//hr = (CDialogo::g_pRx2)->WriteOnTheReturn(mBst2);
		}


return 0;
}

void CDialogo::RunCombo()
{
	int i = 0;
	fstream f;
    f.open("IpAddress.txt",ios::in);

  while(  !f.eof() )
	{
	  ZeroMemory(ArrAddr[i].utente,sizeof(ArrAddr[i].utente));
	  ZeroMemory(ArrAddr[i].address,sizeof(ArrAddr[i].address));

	  f.getline(ArrAddr[i].utente,50,'\n');
	  f.getline(ArrAddr[i].address,50,'\n');
	  if( ArrAddr[i].utente[0] != 0 )
	  {
	   ::SendMessage(mhCombo, CB_INSERTSTRING, i, (LPARAM) (LPCTSTR)(ArrAddr[i].utente) );
	   i++;
	  }
	  
	}

  f.close();

  //::SendMessage(mhCombo, CB_SETCURSEL, (WPARAM)0, 0);

}

void CDialogo::EnableControls(bool mConn)
{	
	//l'istruzione mhCombo = GetDlgItem(IDC_ADDRESS); deve stare prima 
	//di qualsiasi uso della combo perch� ne inizializza l'handle
		CenterWindow();
		mhCombo = GetDlgItem(IDC_ADDRESS);
		//////////////////////
		RunCombo();
		//////////////////////

		if( mConn )
		{
		::EnableWindow(GetDlgItem(IDC_ADDRESS),true);		
		::EnableWindow(GetDlgItem(IDC_WRITE),false);		
		::EnableWindow(GetDlgItem(IDC_READ),false);		
		::ShowWindow(GetDlgItem(IDC_YESCOM),SW_HIDE);
		::ShowWindow(GetDlgItem(IDC_NOCOM),SW_HIDE);
		::ShowWindow(GetDlgItem(IDC_LABCOM),SW_HIDE);
		::ShowWindow(GetDlgItem(IDC_CALLER),SW_HIDE);
		}
		else
			{
			::EnableWindow(GetDlgItem(IDC_WRITE),false);		
			::EnableWindow(GetDlgItem(IDC_READ),false);	
			::EnableWindow(GetDlgItem(1),false);		
			::EnableWindow(GetDlgItem(2),false);	

			::ShowWindow(GetDlgItem(IDC_ADDRESS),SW_HIDE);
			::ShowWindow(GetDlgItem(IDC_IP),SW_HIDE);
			::ShowWindow(GetDlgItem(IDC_YESCOM),SW_SHOW);
			::ShowWindow(GetDlgItem(IDC_NOCOM),SW_SHOW);
			::ShowWindow(GetDlgItem(IDC_LABCOM),SW_SHOW);
			::ShowWindow(GetDlgItem(IDC_CALLER),SW_SHOW);
							
				int LittleCounter = 0;
				for(int ab=0; ab<4; ++ab)
				{
					for(int aa=0; aa<LittleCounter; ++aa)
					{
					::MessageBeep(MB_ICONEXCLAMATION);
					}
					++LittleCounter;
					::Sleep(600);
				}
				
			}
}


void CDialogo::Agree(int* mrVal)
{
	
	if(*mrVal == 3)
	{
		::EnableWindow(GetDlgItem(IDC_WRITE),true);		
		::EnableWindow(GetDlgItem(IDC_READ),true);		
	}
	else
	if(*mrVal == 23)
		{
		::MessageBox(NULL,"Sorry...The other does not want talk with you..", "The Talk",MB_OK);
		hr = m_pIRx2ConnectionPoint->Unadvise(m_dwCookie);
		if(SUCCEEDED(hr))
			{ m_dwCookie = 0; }
		}

}

LRESULT CDialogo::OnClickedNocom(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
	AnswerforDialog = true;
	int rval = 23;
	::EnableWindow(GetDlgItem(IDC_YESCOM),false);		
	::EnableWindow(GetDlgItem(IDC_NOCOM),false);		
    ::EnableWindow(GetDlgItem(IDC_LABCOM),false);

	hr = mpCall2->ReturnAgree( &rval );

	if(MainBool || !mConnectBool)
		DestroyWindow();
	else
		if(!MainBool)
		EndDialog(wID);

	return 0;
}

LRESULT CDialogo::OnClickedYescom(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
	AnswerforDialog = true;

	int rval = 3;
	::EnableWindow(GetDlgItem(IDC_WRITE),true);		
	::EnableWindow(GetDlgItem(IDC_READ),true);	
	::EnableWindow(GetDlgItem(IDC_YESCOM),false);		
	::EnableWindow(GetDlgItem(IDC_NOCOM),false);		
    ::EnableWindow(GetDlgItem(IDC_LABCOM),false);
    /////////////////////////////////////////////

	hr = mpCall2->ReturnAgree( &rval );
	//hr = CDialogo::g_pRx2->IAgree( &rval );
	return 0;
}

void CDialogo::ShowCaller(BSTR mTheCaller)
{
	USES_CONVERSION;
	::SetWindowText(GetDlgItem(IDC_CALLER), OLE2CA(mTheCaller));
}
void CDialogo::RunConnection()
{
	
	USES_CONVERSION;
	i = res = 0;
	COSERVERINFO info;
	MULTI_QI qi;
	int result = 0;
	info.dwReserved1 = NULL;
	info.dwReserved2 = NULL;
	info.pAuthInfo   = NULL;
	//info.pwszName	 = NULL;
	info.pwszName	 = A2W(SelectedIp);
	//info.pwszName	= L"150.197.55.101";//max

	qi.pIID = &IID_IUnknown;
	qi.hr	= 0;
	qi.pItf = NULL;

	int	mConnCLCTX;

	if (SelectedIp[0] == '�')
	{
		mLocalTalk = true;

		info.pwszName	 = NULL;
		mConnCLCTX = CLSCTX_LOCAL_SERVER;
	}else
		{
		mConnCLCTX = CLSCTX_REMOTE_SERVER;
		}

	hr = CoCreateInstanceEx( CLSID_Call2,
							 NULL,
							 mConnCLCTX,  
							 &info,
							 1,
							 &qi );
	
	//ATLASSERT(hr==NOERROR);
	if (!SUCCEEDED(hr))
	{
		::MessageBox(m_hWnd, _T("Could not create ExeChat object.  Make sure the server is registered."),
			_T("Object Instantiation Error."), MB_OK | MB_ICONINFORMATION);

	//	return 0L;
	}
	_ASSERT(qi.pItf != NULL);
	
	hr = qi.pItf->QueryInterface(IID_ICall2,(void**)&pCall2);
	_ASSERT(pCall2 != NULL);

	hr = pCall2->QueryInterface(IID_IConnectionPointContainer,(void **)&pConnPtContainer);			
	_ASSERT(SUCCEEDED(hr) && pConnPtContainer != NULL);

//BSTR per il chiamante 
//	wchar_t  nome[] = L"ivan";
//BSTR mTempBstr = SysAllocString(nome);

	hr = pCall2->Run(&res);
	_ASSERT(SUCCEEDED(hr));

	
	mpRx2 = new CComObject<CRx2>;
	_ASSERT(mpRx2 != NULL);
	((IRx2*)mpRx2)->AddRef();

	hr = pConnPtContainer->FindConnectionPoint(IID_IRx2, &m_pIRx2ConnectionPoint);
	_ASSERT(SUCCEEDED(hr) && mpRx2 != NULL);
	
	qi.pItf->Release();
	pConnPtContainer->Release();

	//////////////////////	Advise	//////////////////////////////////
	_ASSERT(mpRx2 != NULL);
	hr = m_pIRx2ConnectionPoint->Advise((IUnknown*)mpRx2, &m_dwCookie);
	_ASSERT(SUCCEEDED(hr) && m_dwCookie != 0);
	//////////////////////////////////////////////////////////////////
	
}

