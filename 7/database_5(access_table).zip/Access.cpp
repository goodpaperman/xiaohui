// Access.cpp : Implementation of CAccess
#include "stdafx.h"
#include "AccessAutomation.h"
#include "Access.h"


//#include "Msacc8.h"
#include "AfxWin.h"
#include "afxdao.h"
#include "afxdb.h"
#include <afxdisp.h>

#include "CBstrImpl.h"
#include "winuser.h"

/////////////////////////////////////////////////////////////////////////////
// CAccess

STDMETHODIMP CAccess::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IAccess
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}

STDMETHODIMP CAccess::put_ReportName(BSTR newVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	m_ReportName = newVal;

	return S_OK;
}

STDMETHODIMP CAccess::put_DatabaseName(BSTR newVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	m_DatabaseName = newVal;

	return S_OK;
}

STDMETHODIMP CAccess::put_QueryName(BSTR newVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	m_QueryName = newVal;

	return S_OK;
}

STDMETHODIMP CAccess::put_QueryString(BSTR newVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

	m_QueryString = newVal;

	return S_OK;
}


STDMETHODIMP CAccess::ShowReport( BOOL Preview = FALSE) 
{
	 AFX_MANAGE_STATE(AfxGetStaticModuleState())

     // Fix the Query as required
     m_Preview = Preview;
	 CDaoDatabase m_database;
	 CBstr databaseName( static_cast <_bstr_t> ( m_DatabaseName));
     char a_database[255];
	 lstrcpy (a_database, databaseName);
	 if (!m_database.IsOpen())
			m_database.Open(a_database,FALSE,FALSE,_T("")); 
     CDaoQueryDef qdef (&m_database);
	 CBstr QueryName ( static_cast <_bstr_t> (  m_QueryName));
	 qdef.Open ( QueryName );
	 CBstr sSql (  static_cast <_bstr_t> (  m_QueryString));
	 qdef.SetSQL (sSql);
	 qdef.Close ();
	 m_database.Close ();
	 AfxDaoTerm  ();
     
	 //Start Automation

	 if (!app.CreateDispatch ("Access.Application.8")) {
		TRACE ("Could't start the Access Application");	
		return S_FALSE;
	 }
	 app.OpenCurrentDatabase  ( databaseName  , m_Preview ? true :false);
	 LPDISPATCH lDoCommand = app.GetDoCmd ();
     IDoCmd DoCmd (lDoCommand);
	 COleVariant  Rc ; 
	 COleVariant  Re ;
	 CBstr RptName ( static_cast <_bstr_t> (  m_ReportName) );
	 COleVariant ReportName (RptName);

	 if (m_Preview) {
		 app.SetVisible (TRUE);
		 DoCmd.Restore ();
		 DoCmd.Maximize ();
		 DoCmd.OpenReport (ReportName,2L,Rc,Re);	
		 LPDISPATCH lRpts = app.GetReports ();
		 Reports Rpts (lRpts);
		 LPDISPATCH   lRpt = Rpts.GetItem (ReportName);
		 _Report rpt(lRpt);
		 long hwnd = rpt.GetHwnd ();
		 SetFocus ((HWND) hwnd);
    	 do  {
		      		
		 } while (IsWindow ( (HWND) hwnd ));
		 rpt.DetachDispatch ();
		 Rpts.DetachDispatch ();
	 } else {
		 app.SetVisible (FALSE);
		 DoCmd.OpenReport (ReportName,0L,Rc,Re);
		 app.CloseCurrentDatabase ();	
	 }
	 
	 app.Quit (2L);
     return S_OK;
}



STDMETHODIMP CAccess::CloseAccess()
{

	AFX_MANAGE_STATE(AfxGetStaticModuleState())
	return S_OK;

}

