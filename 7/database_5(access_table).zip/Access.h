// Access.h : Declaration of the CAccess

#ifndef __ACCESS_H_
#define __ACCESS_H_

#include "resource.h"       // main symbols

#include "afxdao.h"
#include "afxdb.h"
#include "ustring.h"

#include "msacc8.h"
class _Application;

/////////////////////////////////////////////////////////////////////////////
// CAccess
class ATL_NO_VTABLE CAccess : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CAccess, &CLSID_Access>,
	public ISupportErrorInfo,
	public IConnectionPointContainerImpl<CAccess>,
	public IDispatchImpl<IAccess, &IID_IAccess, &LIBID_ACCESSAUTOMATIONLib>
{
public:
	CAccess()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_ACCESS)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CAccess)
	COM_INTERFACE_ENTRY(IAccess)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
	COM_INTERFACE_ENTRY(IConnectionPointContainer)
END_COM_MAP()
BEGIN_CONNECTION_POINT_MAP(CAccess)
END_CONNECTION_POINT_MAP()


// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IAccess
public:
//	STDMETHOD(put_Preview)(/*[in]*/ BOOL newVal);
	STDMETHOD(CloseAccess)();
//	STDMETHOD(Initialize)();
	STDMETHOD(ShowReport)( BOOL Preview);
	STDMETHOD(put_QueryString)(/*[in]*/ BSTR newVal);
	STDMETHOD(put_QueryName)(/*[in]*/ BSTR newVal);
	STDMETHOD(put_DatabaseName)(/*[in]*/ BSTR newVal);
	STDMETHOD(put_ReportName)(/*[in]*/ BSTR newVal);
private:
	BOOL m_Preview;

	CComBSTR m_QueryString;
	CComBSTR m_QueryName;
	CComBSTR m_ReportName;
	CComBSTR m_DatabaseName;
	 _Application app;
};

#endif //__ACCESS_H_
