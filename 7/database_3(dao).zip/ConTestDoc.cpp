// ConTestDoc.cpp : implementation of the CConTestDoc class
//

#include "stdafx.h"
#include "ConTest.h"

#include "ConTestSet.h"
#include "ConTestDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CConTestDoc

IMPLEMENT_DYNCREATE(CConTestDoc, CDocument)

BEGIN_MESSAGE_MAP(CConTestDoc, CDocument)
	//{{AFX_MSG_MAP(CConTestDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	ON_COMMAND(ID_FILE_SEND_MAIL, OnFileSendMail)
	ON_UPDATE_COMMAND_UI(ID_FILE_SEND_MAIL, OnUpdateFileSendMail)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CConTestDoc construction/destruction

CConTestDoc::CConTestDoc()
{
	// TODO: add one-time construction code here

}

CConTestDoc::~CConTestDoc()
{
}

BOOL CConTestDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CConTestDoc serialization

void CConTestDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CConTestDoc diagnostics

#ifdef _DEBUG
void CConTestDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CConTestDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CConTestDoc commands
