// ConTestDoc.h : interface of the CConTestDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_CONTESTDOC_H__EFCAA14F_6A30_11D3_8A70_0000E84F3165__INCLUDED_)
#define AFX_CONTESTDOC_H__EFCAA14F_6A30_11D3_8A70_0000E84F3165__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


class CConTestDoc : public CDocument
{
protected: // create from serialization only
	CConTestDoc();
	DECLARE_DYNCREATE(CConTestDoc)

// Attributes
public:
	CConTestSet m_conTestSet;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CConTestDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CConTestDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CConTestDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONTESTDOC_H__EFCAA14F_6A30_11D3_8A70_0000E84F3165__INCLUDED_)
