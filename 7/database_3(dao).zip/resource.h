//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ConTest.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_CONTEST_FORM                101
#define IDP_FAILED_OPEN_DATABASE        103
#define IDP_SOCKETS_INIT_FAILED         104
#define IDR_MAINFRAME                   128
#define IDR_CONTESTYPE                  129
#define IDC_GebDatum                    1000
#define IDC_TELEFON                     1001
#define IDC_BETRAG                      1002
#define IDC_Vorname                     1003
#define IDC_VEKTOR                      1004
#define IDC_COMBO                       1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
