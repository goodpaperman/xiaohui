// ConTestView.cpp : implementation of the CConTestView class
//

#include "stdafx.h"
#include "ConTest.h"

#include "ConTestSet.h"
#include "QuellenSet.h"
#include "ConTestDoc.h"
#include "ConTestView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CConTestView

IMPLEMENT_DYNCREATE(CConTestView, CDaoRecordView)

BEGIN_MESSAGE_MAP(CConTestView, CDaoRecordView)
	//{{AFX_MSG_MAP(CConTestView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CDaoRecordView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CDaoRecordView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CDaoRecordView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CConTestView construction/destruction

CConTestView::CConTestView()
	: CDaoRecordView(CConTestView::IDD)
{
	//{{AFX_DATA_INIT(CConTestView)
	m_pSet = NULL;
	//}}AFX_DATA_INIT
	// TODO: add construction code here

}

CConTestView::~CConTestView()
{
}

void CConTestView::DoDataExchange(CDataExchange* pDX)
{
	CDaoRecordView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CConTestView)
	DDX_Control(pDX, IDC_COMBO, m_Combo);
	DDX_Control(pDX, IDC_VEKTOR, m_Vektor);
	DDX_Control(pDX, IDC_Vorname, m_Vorname);
	DDX_Control(pDX, IDC_GebDatum, m_GebDatum);
	DDX_Control(pDX, IDC_TELEFON, m_Telefon);
	DDX_Control(pDX, IDC_BETRAG, m_Betrag);
	DDX_FieldText(pDX, IDC_BETRAG, m_pSet->m_Kontostand, m_pSet);
	DDX_FieldText(pDX, IDC_GebDatum, m_pSet->m_GebDatum, m_pSet);
	DDX_FieldText(pDX, IDC_TELEFON, m_pSet->m_Telefon, m_pSet);
	DDX_FieldText(pDX, IDC_Vorname, m_pSet->m_Vorname, m_pSet);
	DDX_FieldText(pDX, IDC_VEKTOR, m_pSet->m_Vektor, m_pSet);
	DDV_MinMaxDouble(pDX, m_pSet->m_Vektor, -9999999.99, 9999999.99);
	//}}AFX_DATA_MAP
	DDX_FieldText(pDX, IDC_COMBO, m_pSet->m_QuelleID, m_pSet);
}

BOOL CConTestView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CDaoRecordView::PreCreateWindow(cs);
}

void CConTestView::OnInitialUpdate()
{
	m_Vorname.SetPicture("!");
	m_Combo.Init( new CQuellenSet, "Name", "ID");
	m_GebDatum.SetPicture("D");
	m_Telefon.SetPicture("P");
	m_Betrag.SetPicture("C");
	m_Vektor.SetPicture("N");

	m_pSet = &GetDocument()->m_conTestSet;
	CDaoRecordView::OnInitialUpdate();
}

/////////////////////////////////////////////////////////////////////////////
// CConTestView printing

BOOL CConTestView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CConTestView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CConTestView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CConTestView diagnostics

#ifdef _DEBUG
void CConTestView::AssertValid() const
{
	CDaoRecordView::AssertValid();
}

void CConTestView::Dump(CDumpContext& dc) const
{
	CDaoRecordView::Dump(dc);
}

CConTestDoc* CConTestView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CConTestDoc)));
	return (CConTestDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CConTestView database support
CDaoRecordset* CConTestView::OnGetRecordset()
{
	return m_pSet;
}


/////////////////////////////////////////////////////////////////////////////
// CConTestView message handlers
