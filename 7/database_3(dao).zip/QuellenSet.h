#if !defined(AFX_QUELLENSET_H__F98C48E3_6F9F_11D3_8A78_0000E84F3165__INCLUDED_)
#define AFX_QUELLENSET_H__F98C48E3_6F9F_11D3_8A78_0000E84F3165__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// QuellenSet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CQuellenSet DAO recordset

class CQuellenSet : public CDaoRecordset
{
public:
	CQuellenSet(CDaoDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CQuellenSet)

// Field/Param Data
	//{{AFX_FIELD(CQuellenSet, CDaoRecordset)
	long	m_ID;
	CString	m_Name;
	CString	m_Beschreibung;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CQuellenSet)
	public:
	virtual CString GetDefaultDBName();		// Default database name
	virtual CString GetDefaultSQL();		// Default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_QUELLENSET_H__F98C48E3_6F9F_11D3_8A78_0000E84F3165__INCLUDED_)
