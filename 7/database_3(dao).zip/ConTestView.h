// ConTestView.h : interface of the CConTestView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_CONTESTVIEW_H__EFCAA151_6A30_11D3_8A70_0000E84F3165__INCLUDED_)
#define AFX_CONTESTVIEW_H__EFCAA151_6A30_11D3_8A70_0000E84F3165__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "EditEx.h"
#include "DaoComboBox.h"


class CConTestSet;

class CConTestView : public CDaoRecordView
{
protected: // create from serialization only
	CConTestView();
	DECLARE_DYNCREATE(CConTestView)

public:
	//{{AFX_DATA(CConTestView)
	enum { IDD = IDD_CONTEST_FORM };
	CDaoComboBox	m_Combo;
	CEditEx	m_Vektor;
	CEditEx	m_Vorname;
	CEditEx	m_GebDatum;
	CEditEx	m_Telefon;
	CEditEx	m_Betrag;
	CConTestSet* m_pSet;
	//}}AFX_DATA

// Attributes
public:
	CConTestDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CConTestView)
	public:
	virtual CDaoRecordset* OnGetRecordset();
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CConTestView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CConTestView)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in ConTestView.cpp
inline CConTestDoc* CConTestView::GetDocument()
   { return (CConTestDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONTESTVIEW_H__EFCAA151_6A30_11D3_8A70_0000E84F3165__INCLUDED_)
