// ConTest.h : main header file for the CONTEST application
//

#if !defined(AFX_CONTEST_H__EFCAA147_6A30_11D3_8A70_0000E84F3165__INCLUDED_)
#define AFX_CONTEST_H__EFCAA147_6A30_11D3_8A70_0000E84F3165__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CConTestApp:
// See ConTest.cpp for the implementation of this class
//

class CConTestApp : public CWinApp
{
public:
	CConTestApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CConTestApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CConTestApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONTEST_H__EFCAA147_6A30_11D3_8A70_0000E84F3165__INCLUDED_)
