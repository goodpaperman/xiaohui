// QuellenSet.cpp : implementation file
//

#include "stdafx.h"
#include "ConTest.h"
#include "QuellenSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CQuellenSet

IMPLEMENT_DYNAMIC(CQuellenSet, CDaoRecordset)

CQuellenSet::CQuellenSet(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CQuellenSet)
	m_ID = 0;
	m_Name = _T("");
	m_Beschreibung = _T("");
	m_nFields = 3;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenDynaset;
}


CString CQuellenSet::GetDefaultDBName()
{
	return _T("D:\\Sources\\VisualC5\\ConTest\\db.mdb");
}

CString CQuellenSet::GetDefaultSQL()
{
	return _T("[Quelle]");
}

void CQuellenSet::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CQuellenSet)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_Long(pFX, _T("[ID]"), m_ID);
	DFX_Text(pFX, _T("[Name]"), m_Name);
	DFX_Text(pFX, _T("[Beschreibung]"), m_Beschreibung);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CQuellenSet diagnostics

#ifdef _DEBUG
void CQuellenSet::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void CQuellenSet::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG
