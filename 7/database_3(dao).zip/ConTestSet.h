// ConTestSet.h : interface of the CConTestSet class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_CONTESTSET_H__EFCAA153_6A30_11D3_8A70_0000E84F3165__INCLUDED_)
#define AFX_CONTESTSET_H__EFCAA153_6A30_11D3_8A70_0000E84F3165__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CConTestSet : public CDaoRecordset
{
public:
	CConTestSet(CDaoDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CConTestSet)

// Field/Param Data
	//{{AFX_FIELD(CConTestSet, CDaoRecordset)
	long	m_ID;
	long	m_QuelleID;
	CString	m_Vorname;
	CString	m_Telefon;
	COleDateTime	m_GebDatum;
	COleDateTime	m_Termin;
	COleCurrency	m_Kontostand;
	double	m_Vektor;
	//}}AFX_FIELD

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CConTestSet)
	public:
	virtual CString GetDefaultDBName();		// REVIEW:  Get a comment here
	virtual CString GetDefaultSQL(); 	// default SQL for Recordset
	virtual void DoFieldExchange(CDaoFieldExchange* pFX);	// RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONTESTSET_H__EFCAA153_6A30_11D3_8A70_0000E84F3165__INCLUDED_)
