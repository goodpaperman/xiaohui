// ConTestSet.cpp : implementation of the CConTestSet class
//

#include "stdafx.h"
#include "ConTest.h"
#include "ConTestSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CConTestSet implementation

IMPLEMENT_DYNAMIC(CConTestSet, CDaoRecordset)

CConTestSet::CConTestSet(CDaoDatabase* pdb)
	: CDaoRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CConTestSet)
	m_ID = 0;
	m_QuelleID = 0;
	m_Vorname = _T("");
	m_Telefon = _T("");
	m_Vektor = 0.0;
	m_nFields = 8;
	//}}AFX_FIELD_INIT
	m_nDefaultType = dbOpenDynaset;
}

CString CConTestSet::GetDefaultDBName()
{
	return _T("D:\\Sources\\VisualC5\\ConTest\\db.mdb");
}


CString CConTestSet::GetDefaultSQL()
{
	return _T("[test]");
}

void CConTestSet::DoFieldExchange(CDaoFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CConTestSet)
	pFX->SetFieldType(CDaoFieldExchange::outputColumn);
	DFX_Long(pFX, _T("[ID]"), m_ID);
	DFX_Long(pFX, _T("[QuelleID]"), m_QuelleID);
	DFX_Text(pFX, _T("[Vorname]"), m_Vorname);
	DFX_Text(pFX, _T("[Telefon]"), m_Telefon);
	DFX_DateTime(pFX, _T("[GebDatum]"), m_GebDatum);
	DFX_DateTime(pFX, _T("[Termin]"), m_Termin);
	DFX_Currency(pFX, _T("[Kontostand]"), m_Kontostand);
	DFX_Double(pFX, _T("[Vektor]"), m_Vektor);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CConTestSet diagnostics

#ifdef _DEBUG
void CConTestSet::AssertValid() const
{
	CDaoRecordset::AssertValid();
}

void CConTestSet::Dump(CDumpContext& dc) const
{
	CDaoRecordset::Dump(dc);
}
#endif //_DEBUG
