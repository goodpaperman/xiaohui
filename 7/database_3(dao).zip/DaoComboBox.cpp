// DaoComboBox.cpp : implementation file
//

#include "stdafx.h"
#include "ConTest.h"
#include "DaoComboBox.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDaoComboBox

CDaoComboBox::CDaoComboBox() {
	m_bIsFilled = false;
}

CDaoComboBox::~CDaoComboBox() {
}


BEGIN_MESSAGE_MAP(CDaoComboBox, CComboBox)
	//{{AFX_MSG_MAP(CDaoComboBox)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDaoComboBox message handlers

void CDaoComboBox::SetRecordSet(CDaoRecordset * pSet, bool bIsRecordsetConstant) {
	m_pSet = pSet;
	m_bIsRecordsetConstant = bIsRecordsetConstant;
	if ( ! m_pSet->IsOpen() ) {
		// if source recordset isn't allready open the combobox is assumed to be its "owner"
		m_pSet->Open();
		m_bOwnerOfSet = true;
	}
	else
		// else the calling view or dialog must close the source rset and free its memory
		m_bOwnerOfSet = false;
}

void CDaoComboBox::SetDisplayField(CString strField) {
	m_strDisplayField = strField;
}

void CDaoComboBox::SetReturnField(CString strField) {
	m_strReturnField = strField;
}

void CDaoComboBox::Init(CDaoRecordset * pSet, CString strDispField, CString strReturnField, bool bIsRecordsetConstant) {
	SetRecordSet( pSet, bIsRecordsetConstant );
	SetDisplayField( strDispField );
	SetReturnField( strReturnField );
}

void CDaoComboBox::Fill() {
	COleVariant varDisplay;
	COleVariant varReturn;
	
	// clear old pointers (if exist) and clear combo-box contents (if exist)
	if (m_bIsFilled)
		clear();
	else
		m_bIsFilled = true;

	// if the source-rset may change (E.G. because of an filter expression) it should be requeried first
	if (!m_bIsRecordsetConstant)
		m_pSet->Requery();

	// Get number of records in source-rset, initialize size of combo-box memory (speeds up if large number of records)
	m_pSet->MoveLast();
	int iItems = m_pSet->GetRecordCount();
	CDaoFieldInfo fi;
	m_pSet->GetFieldInfo( m_strDisplayField, fi );
	InitStorage( iItems, iItems*fi.m_lSize );

	// Go to the top of the source recordset
	if ( ! m_pSet->IsBOF() )
		m_pSet->MoveFirst();
	
	// Get the values of the source recordset
	while ( ! m_pSet->IsEOF() ) {
		
		// Get Values from source rset
		m_pSet->GetFieldValue( m_strDisplayField, varDisplay );
		m_pSet->GetFieldValue( m_strReturnField, varReturn );

		// store display values in combobox, 
		int nItem = AddString( var2String( varDisplay ) );
		// store return values in memory, set comboboxes pointers
		SetItemDataPtr( nItem, new CString( var2String( varReturn ) ) );

		m_pSet->MoveNext();
	}
}

CString CDaoComboBox::var2String(COleVariant var) {
	// converts values from rset into strings for display
	CString str;
	switch (var.vt) {
	case VT_UI1:
		str.Format("%d", var.bVal );
		break;
	case VT_I2:
		str.Format("%d", var.iVal );
		break;
	case VT_I4:
		str.Format("%d", var.lVal );
		break;
	case VT_R4:
		str.Format("%f", var.fltVal );
		break;
	case VT_R8:
		str.Format("%f", var.dblVal );
		break;
	case VT_BSTR:
		str = (LPCTSTR)var.bstrVal;
		break;
	case VT_CY:
		{	
			COleCurrency curr( var );
			str = curr.Format();
		}
		break;
	case VT_DATE:
		{
			COleDateTime datetime( var );
			str = datetime.Format();
		}
		break;
	default:
		str = " ERROR !!!";
		// makes no sense to display these values in combobox
	}
	return str;
}

LRESULT CDaoComboBox::WindowProc(UINT message, WPARAM wParam, LPARAM lParam) {
	// catch WM_GETTEXT and WM_SETTEXT to override standard behavior
	switch (message) {
	case WM_GETTEXT:
		return getText( wParam, lParam);
	case WM_SETTEXT:
		return setText( (LPCTSTR)lParam );
	default:
		return CComboBox::WindowProc(message, wParam, lParam);
	}	
}

DWORD CDaoComboBox::getText(WPARAM maxLength, LPARAM textbuffer) {
	// return the associates return-value (as string)
	CString text = * (CString*)GetItemDataPtr(GetCurSel());
	if ( (maxLength-1) < (WPARAM)text.GetLength())
		text = text.Left(maxLength-1);
	strcpy( (char *)textbuffer, text );
	return text.GetLength();
}

BOOL CDaoComboBox::setText(LPCTSTR text) {
	// set focus to the current value
	// remark: the return-field should be unique in the source recordset, otherwise the first match is used
	
	CString strText( text );
	CString str;
	
	// fill/refill the list
	if ( (!m_bIsFilled) || (!m_bIsRecordsetConstant) )
		// If the combobox isn't allready filled
		// or the content of the source recordset may change with each record of the target recordset
		// (for example if a filter is set depending on another value in the target-rset)
		Fill();

	// search for first match of return-value and with current new text value
	for (int i = 0; i < GetCount(); i++) {
		str = * (CString*)GetItemDataPtr(i);
		if (str == strText)
			break;
	}
	if ( i >= GetCount() ) // if value is not found
		i = -1;
	// set selection
	SetCurSel(i);
	return TRUE;
}

void CDaoComboBox::clear() {
	for (int i = 0; i < GetCount(); i++)
		// free the memory used for the associated return-strings
		delete (CString*)GetItemDataPtr(i);
	
	// clear the combo-box
	ResetContent();
}

void CDaoComboBox::OnDestroy() {
	clear();
	CComboBox::OnDestroy();
	
	// close source rset and free memory if the combobox is its "owner"
	if (m_bOwnerOfSet) {
		m_pSet->Close();
		delete m_pSet;
	}
}
