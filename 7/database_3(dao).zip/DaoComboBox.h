#if !defined(AFX_DAOCOMBOBOX_H__5B43D1C5_6F5E_11D3_8A77_0000E84F3165__INCLUDED_)
#define AFX_DAOCOMBOBOX_H__5B43D1C5_6F5E_11D3_8A77_0000E84F3165__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// DaoComboBox.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDaoComboBox window

class CDaoComboBox : public CComboBox
{
// Construction
public:
	CDaoComboBox();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDaoComboBox)
	protected:
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
public:
	void Init( CDaoRecordset* pSet, CString strDispField, CString strReturnField, bool bIsRecordsetConstant = true);
	void SetReturnField( CString strField );
	void SetDisplayField( CString strField );
	void SetRecordSet( CDaoRecordset* pSet, bool bIsRecordsetConstant = true );
	void Fill();
	virtual ~CDaoComboBox();

	// Generated message map functions
protected:
	void clear();
	BOOL setText( LPCTSTR text );
	DWORD getText( WPARAM maxLength, LPARAM textbuffer );
	CString var2String( COleVariant var );
	CString m_strReturnField;
	CString m_strDisplayField;
	CDaoRecordset* m_pSet;
	bool m_bIsRecordsetConstant;
	bool m_bIsFilled;
	bool m_bOwnerOfSet;
	//{{AFX_MSG(CDaoComboBox)
	afx_msg void OnDestroy();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DAOCOMBOBOX_H__5B43D1C5_6F5E_11D3_8A77_0000E84F3165__INCLUDED_)
