#if !defined(AFX_EDITEX_H__EFCAA15B_6A30_11D3_8A70_0000E84F3165__INCLUDED_)
#define AFX_EDITEX_H__EFCAA15B_6A30_11D3_8A70_0000E84F3165__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// EditEx.h : header file
//

#include <locale.h>
#include <process.h>
#include <errno.h>

#define EEX_DATE	1
#define EEX_NUM		2
#define EEX_CURR	3
#define EEX_FIRST	4
#define EEX_PHONE	5


/////////////////////////////////////////////////////////////////////////////
// CEditEx window

class CEditEx : public CEdit
{
// Construction
public:
	CEditEx();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEditEx)
	//}}AFX_VIRTUAL

// Implementation
public:
	LRESULT WindowProc( UINT message, WPARAM wParam, LPARAM lParam );
	void SetPicture(CString pic);
	virtual ~CEditEx();

	// Generated message map functions
protected:
	int m_iSepCounter;
	void parsePicture();
	int		m_Type;
	CString m_Pic;
	int		m_iNumVK;
	int		m_iNumNK;
	CString	m_sNumPostfix;
	int		*m_pInfo;
	char	*m_pChar;
	//{{AFX_MSG(CEditEx)
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnKillfocus();
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
private:
	bool processNumber(UINT nChar, UINT nRepCnt);
	DWORD getTextNum( WPARAM maxLength, LPARAM textbuffer );
	DWORD getTextDate( WPARAM maxLength, LPARAM textbuffer );
	BOOL setTextNum( LPCTSTR text);
	BOOL setTextDate( LPCTSTR text );
	bool processFirstUpper( UINT nChar, UINT nRepCnt);
	bool processPhone(UINT nChar, UINT nRepCnt);
	CString m_sNumDec;
	CString m_sNumSep;
	int		m_iNumSep;
	CString m_sCurSym;
	CString m_sCurDec;
	CString m_sCurSep;
	int		m_iCurSep;
	CString m_sDateSep;
	CString m_sTimeSep;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EDITEX_H__EFCAA15B_6A30_11D3_8A70_0000E84F3165__INCLUDED_)
