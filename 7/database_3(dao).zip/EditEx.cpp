// EditEx.cpp : implementation file
//

#include "stdafx.h"
#include "ConTest.h"
#include "EditEx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEditEx

CEditEx::CEditEx() {
	m_pInfo = NULL;
	m_pChar = NULL;

	char buffer[3];
	::GetLocaleInfo( LOCALE_SYSTEM_DEFAULT, LOCALE_SDECIMAL, buffer, 3);
	m_sNumDec = buffer;
	::GetLocaleInfo( LOCALE_SYSTEM_DEFAULT, LOCALE_STHOUSAND, buffer, 3);
	m_sNumSep = buffer;
	::GetLocaleInfo( LOCALE_SYSTEM_DEFAULT, LOCALE_SGROUPING, buffer, 3);
	m_iNumSep = atoi( buffer );
	::GetLocaleInfo( LOCALE_SYSTEM_DEFAULT, LOCALE_SCURRENCY, buffer, 3);
	m_sCurSym = buffer;
	::GetLocaleInfo( LOCALE_SYSTEM_DEFAULT, LOCALE_SMONDECIMALSEP, buffer, 3);
	m_sCurDec = buffer;
	::GetLocaleInfo( LOCALE_SYSTEM_DEFAULT, LOCALE_SMONTHOUSANDSEP, buffer, 3);
	m_sCurSep = buffer;
	::GetLocaleInfo( LOCALE_SYSTEM_DEFAULT, LOCALE_SMONGROUPING, buffer, 3);
	m_iCurSep = atoi( buffer );
	::GetLocaleInfo( LOCALE_SYSTEM_DEFAULT, LOCALE_SDATE, buffer, 3);
	m_sDateSep = buffer;
	::GetLocaleInfo( LOCALE_SYSTEM_DEFAULT, LOCALE_STIME, buffer, 3);
	m_sTimeSep = buffer;
}

CEditEx::~CEditEx() {
	if (m_pInfo)
		delete[] m_pInfo;
	if (m_pChar) 
		delete[] m_pChar;
}


BEGIN_MESSAGE_MAP(CEditEx, CEdit)
	//{{AFX_MSG_MAP(CEditEx)
	ON_WM_CHAR()
	ON_CONTROL_REFLECT(EN_KILLFOCUS, OnKillfocus)
	ON_WM_KEYDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEditEx message handlers

void CEditEx::SetPicture(CString pic) {
	int i = pic.GetLength();
	
	if (i==0) return;

	if (pic[0] == 'D') {
		m_Type = EEX_DATE;
	
		if (i==1 || pic[1]=='4')
			m_Pic = "dd/mm/yyyy";
		else if (pic[1]=='2')
			m_Pic = "dd/mm/yy";
		else if (pic[1]=='T')
			m_Pic = "dd/mm/yyyy hh:ii";
		else 
			m_Pic = pic.Mid(1);
		parsePicture();
	}
	else if (pic[0] == 'T') {
		m_Type = EEX_DATE;

		if (i==1)
			m_Pic = "hh:ii";
		else if (pic[1]=='S')
			m_Pic = "hh:ii:ss";
		else if (pic[1]=='M')
			m_Pic = "hh:ii:ss.lll";
		parsePicture();
	}
	else if (pic[0] == 'C') {
		m_Type = EEX_CURR;
		
		if (i==1)
			m_Pic = "$07:02";
		else
			m_Pic = pic.Mid(1);
		parsePicture();
	}
	else if (pic[0] == 'N') {
		m_Type = EEX_NUM;
		if (i==1)
			m_Pic = "07:02";
		else
			m_Pic = pic.Mid(1);
		parsePicture();
	}
	else if (pic[0] == '!'){
		m_Type = EEX_FIRST;
	}
	else if (pic[0] == 'P'){
		m_Type = EEX_PHONE;
	}
}

void CEditEx::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags) {
	// TODO: Add your message handler code here and/or call default

	bool bProcessed = false;
	
	switch (m_Type) {
	case EEX_DATE:
		break;
	case EEX_NUM:
	case EEX_CURR:
		bProcessed = processNumber( nChar, nRepCnt );
		break;
	case EEX_FIRST:
		bProcessed = processFirstUpper( nChar, nRepCnt );
		break;
	case EEX_PHONE:
		bProcessed = processPhone( nChar, nRepCnt );
		break;
	}

	if (! bProcessed)
		CEdit::OnChar(nChar, nRepCnt, nFlags);
}

void CEditEx::OnKillfocus() {
	CString str;
	switch (m_Type) {
	case EEX_DATE:
//		todo:
		break;
	case EEX_NUM:
	case EEX_CURR:
		GetWindowText(str);
		SetWindowText(str);
		break;
	case EEX_FIRST:
	case EEX_PHONE:
		// todo: ???
		break;
	}
	
}

bool CEditEx::processNumber(UINT nChar, UINT nRepCnt) {
	CString sDec = (m_Type==EEX_CURR ? m_sCurDec : m_sNumDec );
	CString sSep = (m_Type==EEX_CURR ? m_sCurSep : m_sNumSep );
	const int KEY_DEL = 46;

	if (! IsCharAlphaNumeric(nChar) && nChar != '\b' && nChar != '-' && nChar != '+' && nChar != sDec && nChar != KEY_DEL)
		return true;	// keine weiteren zeichen zulassen 

	int iSelBeg, iSelEnd, i;
	int iOffset;
	GetSel(iSelBeg, iSelEnd);
	
	LPCTSTR textbuffer = new char[100];
	DWORD len = CEdit::WindowProc(WM_GETTEXT, 100, (LPARAM)textbuffer);
	CString strText( textbuffer, len );
	delete (char*)textbuffer;
	CString strWork;

	if ( nChar == '-' ) {
		GetWindowText(strText);
		int i1, i2;
		if ( strText[0] == '-' ) {
			strText = strText.Mid(1);
			i1 = max(0,iSelBeg-1);
			i2 = max(0,iSelEnd-1);
		}
		else {
			strText = '-'+strText;
			i1 = iSelBeg+1;
			i2 = iSelEnd+1;
		}
		SetWindowText(strText);
		SetSel(i1, i2);
		return true;
	}
	else if ( nChar == '+' ) {
		GetWindowText(strText);
		int i1, i2;
		if ( strText[0] == '-' ) {
			strText = strText.Mid(1);
			i1 = max(0,iSelBeg-1);
			i2 = max(0,iSelEnd-1);
			SetWindowText(strText);
			SetSel(i1, i2);
		}
		return true;
	}
	else if ( nChar == sDec ) {
		if ( (i=strText.Find(sDec)) >= 0) {
			SetSel(i+1, i+1);
			return true;
		}
		CEdit::OnChar(nChar, nRepCnt, 0);
		GetWindowText(strText);
		SetWindowText(strText);
		if ( (i=strText.Find(sDec)) >= 0) {
			SetSel(i+1, i+1);
			return true;
		}
		return true;
	}
	else if ( nChar == '\b' ) {
		int iOffset1 = 1;
		if ( iSelBeg > 0 && strText[iSelBeg-1] == sSep ) {
			// zu l�schendes zeichen ist Separator !
			
			// Separator und davor liegendes Zeichen L�schen
			iSelBeg = max(0, iSelBeg-(iSelBeg==iSelEnd ? 2 : 1));
			SetSel( iSelBeg, iSelEnd );
		}
		else if ( iSelBeg > 0 && iSelBeg == iSelEnd && strText[iSelBeg-1] == sDec ) {
			iSelBeg--;
			iSelEnd--;
			SetSel( iSelBeg, iSelEnd );
		}
		strWork = strText.Mid(max(0,iSelBeg-1), max(1,iSelEnd-iSelBeg) );
		CEdit::OnChar(nChar, nRepCnt, 0);
		iOffset = m_iSepCounter;
		GetWindowText(strText);
		SetWindowText(strText);
		iOffset = min(0,m_iSepCounter-iOffset);
		i = iSelBeg-iOffset1+iOffset;
		// Selektion ausgleichen
		if (iSelBeg < iSelEnd) {
			i++;
			// evtl. durch Selektion gel�schte Separatoren ausgleichen
			int j;
			while ( (j=strWork.Find( sSep )) >= 0) {
				i++;
				strWork = strWork.Left(j)+strWork.Mid(j+1);
			}
		}
	}
	else if ( nChar == KEY_DEL) {
		int iOffset1 = 0;
		if ( (iSelBeg < strText.GetLength()) && strText[iSelBeg] == sSep ) {
			// zu l�schendes Zeichen ist Separator
			iSelEnd = min(strText.GetLength(), iSelEnd+(iSelBeg==iSelEnd ? 2 : 1));
			SetSel( iSelBeg, iSelEnd );
			iOffset1 = 1;
		}
		else if ( (iSelBeg < strText.GetLength()) && iSelBeg == iSelEnd && strText[iSelBeg] == sDec ) {
			iSelBeg++;
			iSelEnd++;
			SetSel( iSelBeg, iSelEnd );
		}
		strWork = strText.Mid(max(0,iSelBeg), max(1,iSelEnd-iSelBeg) );
		CEdit::OnKeyDown(nChar, nRepCnt, 0);
		iOffset = m_iSepCounter;
		GetWindowText(strText);
		SetWindowText(strText);
		iOffset = min(0,m_iSepCounter-iOffset);
		i = iSelBeg-iOffset1+iOffset;
		// Selektion ausgleichen
		if (iSelBeg < iSelEnd) {
			// evtl. durch Selektion gel�schte Separatoren ausgleichen
			int j;
			while ( (j=strWork.Find( sSep )) >= 0) {
				i++;
				strWork = strWork.Left(j)+strWork.Mid(j+1);
			}
		}
	}
	else if ( nChar == 'C' || nChar == 'c' ) {
		// eiziges zugelassenes zeichen ... Ruft Calculator auf !!! toller gimmick
		_spawnlp( _P_NOWAIT, "calc.exe", "calc.exe", NULL );
		return true;
	}
	else if ( IsCharAlpha(nChar) )
		return true; // sonst keine zeichen zulassen !
	else {
		int iOffset1 = 1;
		if (iSelBeg == 0 && iSelEnd == 0 && strText[0] == '0' && strText[1] == sDec) {
			// rest ist nur 0,xx
			SetSel(0,1);
			ReplaceSel( CString(nChar) );
		}
		else {
			CEdit::OnChar(nChar, nRepCnt, 0);
		}
		iOffset = m_iSepCounter;
		GetWindowText(strText);
		SetWindowText(strText);
		iOffset = max(0,m_iSepCounter-iOffset);
		i = iSelBeg+iOffset1+iOffset;
		// Selektion ausgleichen
		if (iSelBeg < iSelEnd) {
			// evtl. durch Selektion gel�schte Separatoren ausgleichen
			int j;
			while ( (j=strWork.Find( sSep )) >= 0) {
				i++;
				strWork = strWork.Left(j)+strWork.Mid(j+1);
			}
		}
	}
	
	SetSel(i, i);
	return true;
}

bool CEditEx::processFirstUpper(UINT nChar, UINT nRepCnt) {
	if (! IsCharAlpha(nChar))
		return false;

	int iSelBeg, iSelEnd;
	CString strText;
	GetWindowText(strText);
	GetSel(iSelBeg, iSelEnd);
	if (iSelBeg == 0 || ! IsCharAlpha(strText[iSelBeg-1]) ) {
		nChar = *CharUpper( (char*)(&nChar) );
		strText = strText.Left(iSelBeg) + CString(nChar) + strText.Mid(iSelEnd);
		SetWindowText(strText);
		SetSel(iSelBeg+1, iSelBeg+1);
		return true;
	}

	return false;
}

bool CEditEx::processPhone(UINT nChar, UINT nRepCnt) {
	int iSelBeg, iSelEnd;
	CString strText, strTextWork1, strTextWork2;
	int i, j, k;
	GetWindowText(strText);
	GetSel(iSelBeg, iSelEnd);
	strText = strText.Left(iSelBeg)+strText.Mid(iSelEnd);
	if (nChar == '/' || nChar == '-' || nChar == ')' || nChar == ' ') {
		i = strText.Find( ')' );
		if ( i<0 || i >= iSelBeg ) {
			// Vorwahl ohne Zeihen
			strTextWork1 = strText.Left(iSelBeg);

			while ( (i = strTextWork1.FindOneOf("()/- ")) >= 0 )
				strTextWork1 = strTextWork1.Left(i)+strTextWork1.Mid(i+1);

			strTextWork2 = strText.Mid(iSelBeg);
			
			// Durchwahl ohne f�hrende )
			while ( (j = strTextWork2.Find( ')' )) >= 0 && ( (k = strTextWork2.Find( '(' )) < 0 || k > j ) ) {
				strTextWork2 = strTextWork2.Left(j)+strTextWork2.Mid(j+1);
			}
			strTextWork2.TrimLeft();

			strText = "("+strTextWork1+") ";
			i = strText.GetLength();
			strText += strTextWork2;

			SetWindowText(strText);
			SetSel(i, i);
			return true;
		}
	}
	
	return false;
}

void CEditEx::parsePicture() {
	int i;
	CString str, str2;
	// temp. Ctrl Arrays
	int* pInfo;
	char* pChar;
	int iLen, iOffset = 0;

	// 1 = char, nicht editierbar, geh�rt nicht zur R�ckgabe
	// 2 = char, nicht editierbar, geh�rt zur R�ckgabe ...
	// 3 = Vorzeichen (+/-)
	// 4 = numm. Vorkomman
	// 5 = numm. Nachkomma
	// 6 = datum Tag
	// 7 = datum Monat
	// 8 = datum Jahr
	// 9 = Zeit Stunde
	// 10 = Zeit Minute
	// 11 = Zeit Sekunde
	// 12 = zeit Sekundenbruchteile

	iLen = m_Pic.GetLength();
	bool isString = false;
	bool isCurrSign = false;
	int iVK, iNK;

	switch (m_Type) {
	case EEX_DATE:
		str = m_Pic;
		pInfo = new int[iLen];
		pChar = new char[iLen];
		for (i = 0; i < iLen; i++) {
			if (m_Pic[i] == '\'') {
				iOffset++;
				isString = ! isString;
				continue;
			}
			if (isString) {
				pInfo[i-iOffset] = 1;
				pChar[i-iOffset] = m_Pic[i];
			}
			else if (m_Pic[i] == 'd') pInfo[i-iOffset] = 6;
			else if (m_Pic[i] == 'm') pInfo[i-iOffset] = 7;
			else if (m_Pic[i] == 'y') pInfo[i-iOffset] = 8;
			else if (m_Pic[i] == 'h') pInfo[i-iOffset] = 9;
			else if (m_Pic[i] == 'i') pInfo[i-iOffset] = 10;
			else if (m_Pic[i] == 's') pInfo[i-iOffset] = 11;
			else if (m_Pic[i] == 'f') pInfo[i-iOffset] = 12;
			else if (m_Pic[i] == '/') {
				pInfo[i-iOffset] = 2;
				pChar[i-iOffset] = m_sDateSep[0];
			}
			else if (m_Pic[i] == ':') {
				pInfo[i-iOffset] = 2;
				pChar[i-iOffset] = m_sTimeSep[0];
			}
			else if (m_Pic[i] == '.') {
				pInfo[i-iOffset] = 2;
				pChar[i-iOffset] = m_sNumDec[0];
			}
		}

		if (m_pInfo) delete[] m_pInfo;
		if (m_pChar) delete[] m_pChar;
		m_pInfo = new int[iLen-iOffset];
		m_pChar = new char[iLen-iOffset]
			;
		for (i = 0; i < (iLen-iOffset); i++) {
			m_pInfo[i] = pInfo[i];
			m_pChar[i] = pChar[i];
		}

		delete[] pInfo;
		delete[] pChar;

		break;

	case EEX_CURR:
	case EEX_NUM:
		str = m_Pic;

		if (m_Pic[0] == '$') {
			isCurrSign = true;
			m_Pic = m_Pic.Mid(1);
		}

		iVK = atoi( m_Pic.Mid(0, 2) );
		iNK = atoi( m_Pic.Mid(3, 2) );
		
		m_Pic = m_Pic.Mid(5);
		str = isCurrSign ? (" "+m_sCurSym) : "";
		
		while (m_Pic.GetLength() > 0) {
			if (m_Pic[i] == '\'') {
				isString = ! isString;
				m_Pic = m_Pic.Mid(1);
				continue;
			}
			if (isString)
				str += m_Pic[0];
		}
		m_iNumVK = iVK;
		m_iNumNK = iNK;
		m_sNumPostfix = str;
		break;

	case EEX_FIRST:
	case EEX_PHONE:
		break;
	}
}

LRESULT CEditEx::WindowProc(UINT message, WPARAM wParam, LPARAM lParam) {
	switch (message) {
	case WM_GETTEXT:
		if (m_Type == EEX_DATE)
			return getTextDate(wParam, lParam);
		else if (m_Type == EEX_NUM || m_Type == EEX_CURR)
			return getTextNum(wParam, lParam);
	case WM_SETTEXT:
	// TODO:
//		if (m_Type == EEX_DATE)
//			return setTextDate( (LPCTSTR)lParam );
//		else
		if (m_Type == EEX_NUM || m_Type == EEX_CURR)
			return setTextNum( (LPCTSTR)lParam );
	default:
		return CEdit::WindowProc(message, wParam, lParam);
	}
}

BOOL CEditEx::setTextDate(LPCTSTR text) {
	// TODO:
	return FALSE;
}

BOOL CEditEx::setTextNum(LPCTSTR text) {
	CString strNew, strWork, str_nk;
	strNew = text;
	long vk_value;
	int i;
//	char cRunden;

	// StrWork == Vorkommaanteil inkl. Vorzeichen.
	strWork = strNew.SpanExcluding( m_Type==EEX_NUM ? '.' : m_sCurDec );
	vk_value = atol(strWork);

	// StrWork == Nachkommaanteil bzw. 0
	if ( (i = strWork.GetLength()) < strNew.GetLength() ) {
		str_nk = strNew.Mid(i+1);
		str_nk = str_nk.SpanIncluding("0123456789");
	}
	else
		str_nk = CString('0', m_iNumNK);
	
	if (vk_value < 0) {
		strNew = "-";
		vk_value = 0-vk_value;
		GetDC()->SetBkColor( (COLORREF)0x0000FF );
	}
	else
		strNew = "";

	// Vorkommastellen
	strWork.Format("%d", vk_value);
	
	i = strWork.GetLength();
	
//	ASSERT (i <= m_iNumVK);

	// Vorkommastellen Gruppieren
	int g = m_Type==EEX_NUM ? m_iNumSep : m_iCurSep;
	m_iSepCounter = 0;
	for (int j = i-g; j > 0; j-=g) {
		strWork = strWork.Left(j)+( m_Type==EEX_NUM ? m_sNumSep : m_sCurSep )+strWork.Mid(j);
		m_iSepCounter ++;
	}


	strNew += strWork;
	
	// Nachkommastellen
	strWork = str_nk;

	i = strWork.GetLength();
	if (i < m_iNumNK)
		strWork += CString('0', m_iNumNK-i);
	else if (i > m_iNumNK)
		strWork = strWork.Left(m_iNumNK);
		// TODO: Runden ???

	strNew += ( m_Type==EEX_NUM ? m_sNumDec : m_sCurDec )+strWork+m_sNumPostfix;
		
	// Text Aktualisieren
	CEdit::WindowProc(WM_SETTEXT, 0, (LPARAM)(LPCTSTR)strNew);
	// Einfaches CEdit::SetText() w�rde wieder zur�ckgeroutet auf CEditEx::WindowProc() -> Endlosschleife !
	return TRUE;
}

DWORD CEditEx::getTextDate(WPARAM maxLength, LPARAM textbuffer) {
	// TODO:
	return CEdit::WindowProc(WM_GETTEXT, maxLength, textbuffer);
}

DWORD CEditEx::getTextNum(WPARAM maxLength, LPARAM textbuffer) {
	DWORD length = CEdit::WindowProc(WM_GETTEXT, maxLength, textbuffer);
	
	if (m_Type == EEX_CURR) {
		CString text((LPCTSTR)textbuffer, length);
		int i;

		while ( (i = text.Find(m_sCurSep)) >= 0 )
			text = text.Left(i)+text.Mid(i+1);

		strcpy( (char *)textbuffer, text );
		length = text.GetLength();
	}
	else {
		CString text((LPCTSTR)textbuffer, length);
		int i;

		while ( (i = text.Find(m_sNumSep)) >= 0 )
			text = text.Left(i)+text.Mid(i+1);

		if ( (i = text.Find(m_sNumDec)) >= 0 )
			text = text.Left(i)+"."+text.Mid(i+1);

		strcpy( (char *)textbuffer, text );
		length = text.GetLength();
	}

	return length;
	
}

void CEditEx::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) {
	bool bProcessed = false;
	if (nChar == 46) { // KEY_DEL
		
		switch (m_Type) {
		case EEX_DATE:
			break;
		case EEX_NUM:
		case EEX_CURR:
			bProcessed = processNumber( nChar, nRepCnt );
			break;
		case EEX_FIRST:
//			bProcessed = processFirstUpper( nChar, nRepCnt );
			break;
		case EEX_PHONE:
//			bProcessed = processPhone( nChar, nRepCnt );
			break;
		}
	}
	if (! bProcessed)
		CEdit::OnKeyDown(nChar, nRepCnt, nFlags);
}
