// HLinkFormatPage.cpp : implementation file
//

#include "stdafx.h"
#include "drawcli.h"
#include "HLinkFormatPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const int arrayPossibleHAlignes[]=
{
	DT_LEFT,
	DT_CENTER,
	DT_RIGHT
};

const TCHAR* arrayPossibleHAlignNames[]=
{
	_T("Left"),
	_T("Center"),
	_T("Right")
};

const int arrayPossibleVAlignes[]=
{
	DT_TOP,
	DT_VCENTER,
	DT_BOTTOM
};

const TCHAR* arrayPossibleVAlignNames[]=
{
	_T("Up"),
	_T("Center"),
	_T("Down")
};

/////////////////////////////////////////////////////////////////////////////
// CHLinkFormatPage dialog


CHLinkFormatPage::CHLinkFormatPage()
	: CPropertyPage(CHLinkFormatPage::IDD)
{
	//{{AFX_DATA_INIT(CHLinkFormatPage)
	m_bSingleLine = FALSE;
	//}}AFX_DATA_INIT

	m_iHorAlignment=DT_LEFT;
	m_iVerAlignment=DT_TOP;
	m_rgbTextColour=0;
}


void CHLinkFormatPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CHLinkFormatPage)
	DDX_Control(pDX, IDC_COMBO_HALIGN, m_cbxHorAlignment);
	DDX_Control(pDX, IDC_COMBO_VALIGN, m_cbxVerAlignment);
	DDX_Check(pDX, IDC_CHECK_SINGLE_LINE, m_bSingleLine);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CHLinkFormatPage, CPropertyPage)
	//{{AFX_MSG_MAP(CHLinkFormatPage)
	ON_BN_CLICKED(IDC_SEL_FONT, OnSelFont)
	ON_BN_CLICKED(IDC_CHECK_SINGLE_LINE, OnCheckSingleLine)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHLinkFormatPage message handlers
void CHLinkFormatPage::UpdateFontInformation()
{
	SetDlgItemText(IDC_STATIC_FONT_NAME,m_logfont.lfFaceName);
}

void CHLinkFormatPage::OnSelFont() 
{
	// TODO: Add your control notification handler code here
	// TODO: Add your control notification handler code here
	CFontDialog dlg(&m_logfont);
	dlg.m_cf.rgbColors=m_rgbTextColour;
	if(dlg.DoModal()==IDOK)
	{
		dlg.GetCurrentFont(&m_logfont);
		m_rgbTextColour=dlg.m_cf.rgbColors;
		UpdateFontInformation();
	}
}

BOOL CHLinkFormatPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	// TODO: Add extra initialization here
	UpdateFontInformation();

	for(int i=0; i<3; i++)
	{
		m_cbxHorAlignment.AddString(arrayPossibleHAlignNames[i]);
		m_cbxVerAlignment.AddString(arrayPossibleVAlignNames[i]);
	}

	//Select alignments
	for(i=0; i<3; i++)
	{
		if(arrayPossibleHAlignes[i]==m_iHorAlignment)
			m_cbxHorAlignment.SetCurSel(i);

		if(arrayPossibleVAlignes[i]==m_iVerAlignment)
			m_cbxVerAlignment.SetCurSel(i);
	}

	
	m_cbxVerAlignment.EnableWindow(m_bSingleLine);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CHLinkFormatPage::OnCheckSingleLine() 
{
	// TODO: Add your control notification handler code here
	if(!UpdateData())
		return;

	m_cbxVerAlignment.EnableWindow(m_bSingleLine);	
}


BOOL CHLinkFormatPage::OnKillActive() 
{
	// TODO: Add your specialized code here and/or call the base class
	BOOL bOk=CPropertyPage::OnKillActive();
	if(bOk)
	{
		int iSel=m_cbxHorAlignment.GetCurSel();
		if(iSel!=LB_ERR)
		{
			m_iHorAlignment=arrayPossibleHAlignes[iSel];
		}

		iSel=m_cbxVerAlignment.GetCurSel();
		if(iSel!=LB_ERR)
		{
			m_iVerAlignment=arrayPossibleVAlignes[iSel];
		}

	}

	return bOk;
}