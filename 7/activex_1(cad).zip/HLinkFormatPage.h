#if !defined(AFX_HLINKFORMATPAGE_H__331B26A6_D3FA_11D2_824E_000001177053__INCLUDED_)
#define AFX_HLINKFORMATPAGE_H__331B26A6_D3FA_11D2_824E_000001177053__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// HLinkFormatPage.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CHLinkFormatPage dialog

class CHLinkFormatPage : public CPropertyPage
{
// Construction
public:
	CHLinkFormatPage();   // standard constructor

	void SetLogFont(const LOGFONT& logfont)
	{
		memcpy(&m_logfont,&logfont,sizeof(LOGFONT));
	}

	const LOGFONT& GetLogFont()
	{
		return m_logfont;
	}

// Dialog Data
	//{{AFX_DATA(CHLinkFormatPage)
	enum { IDD = IDD_PROP_HLINK_PARAMS };
	CComboBox	m_cbxHorAlignment;
	CComboBox	m_cbxVerAlignment;
	BOOL	m_bSingleLine;
	//}}AFX_DATA

	int			m_iHorAlignment;
	int			m_iVerAlignment;
	COLORREF	m_rgbTextColour;



// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHLinkFormatPage)
	protected:
	virtual BOOL OnKillActive();
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CHLinkFormatPage)
	afx_msg void OnSelFont();
	virtual BOOL OnInitDialog();
	afx_msg void OnCheckSingleLine();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	void UpdateFontInformation();

	LOGFONT	m_logfont;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HLINKFORMATPAGE_H__331B26A6_D3FA_11D2_824E_000001177053__INCLUDED_)
