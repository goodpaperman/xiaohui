// HLinkPage.cpp : implementation file
//

#include "stdafx.h"
#include "drawcli.h"
#include "HLinkPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHLinkPage property page

IMPLEMENT_DYNCREATE(CHLinkPage, CPropertyPage)

CHLinkPage::CHLinkPage() : CPropertyPage(CHLinkPage::IDD)
{
	//{{AFX_DATA_INIT(CHLinkPage)
	m_strText = _T("");
	m_strURL = _T("");
	m_strLocation = _T("");
	m_strFriendlyName = _T("");
	//}}AFX_DATA_INIT
	m_bLinkChanged=FALSE;
}

CHLinkPage::~CHLinkPage()
{
}

void CHLinkPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CHLinkPage)
	DDX_Text(pDX, IDC_EDIT_TEXT, m_strText);
	DDX_Text(pDX, IDC_EDIT_URL, m_strURL);
	DDX_Text(pDX, IDC_EDIT_LOCATION, m_strLocation);
	DDX_Text(pDX, IDC_EDIT_FRIENDLY_NAME, m_strFriendlyName);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CHLinkPage, CPropertyPage)
	//{{AFX_MSG_MAP(CHLinkPage)
	ON_BN_CLICKED(IDC_BUTTON_BROWSE, OnButtonBrowse)
	ON_EN_CHANGE(IDC_EDIT_FRIENDLY_NAME, OnChangeEditFriendlyName)
	ON_EN_CHANGE(IDC_EDIT_LOCATION, OnChangeEditLocation)
	ON_EN_CHANGE(IDC_EDIT_TEXT, OnChangeEditText)
	ON_EN_CHANGE(IDC_EDIT_URL, OnChangeEditUrl)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHLinkPage message handlers

void CHLinkPage::OnButtonBrowse() 
{
	// TODO: Add your control notification handler code here
	CFileDialog dlg(TRUE, 
					NULL,
					_T("*.*"),
					0,
					_T("All files (*.*)"));

	if(dlg.DoModal()==IDOK)
	{
		m_strURL=dlg.GetPathName();
		SetDlgItemText(IDC_EDIT_URL,m_strURL);
	}

	GetDlgItem(IDC_EDIT_URL)->SetFocus();
}

void CHLinkPage::OnChangeEditFriendlyName() 
{
	m_bLinkChanged=TRUE;	
}

void CHLinkPage::OnChangeEditLocation() 
{
	m_bLinkChanged=TRUE;	
}

void CHLinkPage::OnChangeEditText() 
{
	m_bLinkChanged=TRUE;	
}

void CHLinkPage::OnChangeEditUrl() 
{
	m_bLinkChanged=TRUE;	
}
