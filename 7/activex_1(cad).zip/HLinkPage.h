#if !defined(AFX_HLINKPAGE_H__331B26A5_D3FA_11D2_824E_000001177053__INCLUDED_)
#define AFX_HLINKPAGE_H__331B26A5_D3FA_11D2_824E_000001177053__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// HLinkPage.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CHLinkPage dialog

class CHLinkPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CHLinkPage)

// Construction
public:
	CHLinkPage();
	~CHLinkPage();

// Dialog Data
	//{{AFX_DATA(CHLinkPage)
	enum { IDD = IDD_PROP_HLINK };
	CString	m_strText;
	CString	m_strURL;
	CString	m_strLocation;
	CString	m_strFriendlyName;
	//}}AFX_DATA

	BOOL IsLinkChanged() const
	{
		return m_bLinkChanged;
	}


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CHLinkPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CHLinkPage)
	afx_msg void OnButtonBrowse();
	afx_msg void OnChangeEditFriendlyName();
	afx_msg void OnChangeEditLocation();
	afx_msg void OnChangeEditText();
	afx_msg void OnChangeEditUrl();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	BOOL	m_bLinkChanged;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HLINKPAGE_H__331B26A5_D3FA_11D2_824E_000001177053__INCLUDED_)
