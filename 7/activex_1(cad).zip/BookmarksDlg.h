#if !defined(AFX_BOOKMARKSDLG_H__B1486355_D233_11D2_BE52_4854E8297ADB__INCLUDED_)
#define AFX_BOOKMARKSDLG_H__B1486355_D233_11D2_BE52_4854E8297ADB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// BookmarksDlg.h : header file
//

class CDrawDoc;

/////////////////////////////////////////////////////////////////////////////
// CBookmarksDlg dialog

class CBookmarksDlg : public CDialog
{
// Construction
public:
	CBookmarksDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CBookmarksDlg)
	enum { IDD = IDD_BOOKMARKS };
	CListBox	m_listBookmarks;
	//}}AFX_DATA

	CString		m_strCaption;
	CDrawDoc*	m_pDoc;
	CString		m_strSelectedBookmarkName;


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBookmarksDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CBookmarksDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangeList1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BOOKMARKSDLG_H__B1486355_D233_11D2_BE52_4854E8297ADB__INCLUDED_)
