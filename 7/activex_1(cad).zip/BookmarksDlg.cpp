// BookmarksDlg.cpp : implementation file
//

#include "stdafx.h"
#include "drawcli.h"
#include "drawdoc.h"
#include "BookmarksDlg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBookmarksDlg dialog


CBookmarksDlg::CBookmarksDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CBookmarksDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CBookmarksDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_pDoc=NULL;
}


void CBookmarksDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CBookmarksDlg)
	DDX_Control(pDX, IDC_LIST1, m_listBookmarks);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CBookmarksDlg, CDialog)
	//{{AFX_MSG_MAP(CBookmarksDlg)
	ON_LBN_SELCHANGE(IDC_LIST1, OnSelchangeList1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBookmarksDlg message handlers

BOOL CBookmarksDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	SetWindowText(m_strCaption);

	ASSERT(m_pDoc);
	const CDrawDoc::BookmarkArray& bookmarks=m_pDoc->GetBookmarks();
	for(int i=0; i<bookmarks.GetSize(); i++)
	{
		CDrawDoc::Bookmark& bm=bookmarks[i];
		if(!bm.m_bHidden)
			m_listBookmarks.AddString(bm.m_strName);
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CBookmarksDlg::OnSelchangeList1() 
{
	// TODO: Add your control notification handler code here
	int nIndex=m_listBookmarks.GetCurSel();
	if(nIndex==LB_ERR)
		m_strSelectedBookmarkName.Empty();
	else
		m_listBookmarks.GetText(nIndex,m_strSelectedBookmarkName);
}
