/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Fri Feb 11 16:14:03 2000
 */
/* Compiler settings for E:\Emmanuel\DVP\Tools\SimpleEmailClient\SimpleEmailClient.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __SimpleEmailClient_h__
#define __SimpleEmailClient_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __ISimpleEmailClientX_FWD_DEFINED__
#define __ISimpleEmailClientX_FWD_DEFINED__
typedef interface ISimpleEmailClientX ISimpleEmailClientX;
#endif 	/* __ISimpleEmailClientX_FWD_DEFINED__ */


#ifndef __SimpleEmailClientX_FWD_DEFINED__
#define __SimpleEmailClientX_FWD_DEFINED__

#ifdef __cplusplus
typedef class SimpleEmailClientX SimpleEmailClientX;
#else
typedef struct SimpleEmailClientX SimpleEmailClientX;
#endif /* __cplusplus */

#endif 	/* __SimpleEmailClientX_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __ISimpleEmailClientX_INTERFACE_DEFINED__
#define __ISimpleEmailClientX_INTERFACE_DEFINED__

/* interface ISimpleEmailClientX */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ISimpleEmailClientX;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("B3317880-B203-11D3-BFEF-0010E3B966CE")
    ISimpleEmailClientX : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SendEmail( 
            BSTR BFrom,
            BSTR BTo,
            BSTR BSubject,
            BSTR BBody,
            BSTR BServerName) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_TimeOut( 
            /* [retval][out] */ long __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_TimeOut( 
            /* [in] */ long newVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISimpleEmailClientXVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ISimpleEmailClientX __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ISimpleEmailClientX __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ISimpleEmailClientX __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ISimpleEmailClientX __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ISimpleEmailClientX __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ISimpleEmailClientX __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ISimpleEmailClientX __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SendEmail )( 
            ISimpleEmailClientX __RPC_FAR * This,
            BSTR BFrom,
            BSTR BTo,
            BSTR BSubject,
            BSTR BBody,
            BSTR BServerName);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_TimeOut )( 
            ISimpleEmailClientX __RPC_FAR * This,
            /* [retval][out] */ long __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_TimeOut )( 
            ISimpleEmailClientX __RPC_FAR * This,
            /* [in] */ long newVal);
        
        END_INTERFACE
    } ISimpleEmailClientXVtbl;

    interface ISimpleEmailClientX
    {
        CONST_VTBL struct ISimpleEmailClientXVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISimpleEmailClientX_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISimpleEmailClientX_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISimpleEmailClientX_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISimpleEmailClientX_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISimpleEmailClientX_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISimpleEmailClientX_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISimpleEmailClientX_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISimpleEmailClientX_SendEmail(This,BFrom,BTo,BSubject,BBody,BServerName)	\
    (This)->lpVtbl -> SendEmail(This,BFrom,BTo,BSubject,BBody,BServerName)

#define ISimpleEmailClientX_get_TimeOut(This,pVal)	\
    (This)->lpVtbl -> get_TimeOut(This,pVal)

#define ISimpleEmailClientX_put_TimeOut(This,newVal)	\
    (This)->lpVtbl -> put_TimeOut(This,newVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISimpleEmailClientX_SendEmail_Proxy( 
    ISimpleEmailClientX __RPC_FAR * This,
    BSTR BFrom,
    BSTR BTo,
    BSTR BSubject,
    BSTR BBody,
    BSTR BServerName);


void __RPC_STUB ISimpleEmailClientX_SendEmail_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ISimpleEmailClientX_get_TimeOut_Proxy( 
    ISimpleEmailClientX __RPC_FAR * This,
    /* [retval][out] */ long __RPC_FAR *pVal);


void __RPC_STUB ISimpleEmailClientX_get_TimeOut_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ISimpleEmailClientX_put_TimeOut_Proxy( 
    ISimpleEmailClientX __RPC_FAR * This,
    /* [in] */ long newVal);


void __RPC_STUB ISimpleEmailClientX_put_TimeOut_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISimpleEmailClientX_INTERFACE_DEFINED__ */



#ifndef __SIMPLEEMAILCLIENTLib_LIBRARY_DEFINED__
#define __SIMPLEEMAILCLIENTLib_LIBRARY_DEFINED__

/* library SIMPLEEMAILCLIENTLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_SIMPLEEMAILCLIENTLib;

EXTERN_C const CLSID CLSID_SimpleEmailClientX;

#ifdef __cplusplus

class DECLSPEC_UUID("B3317881-B203-11D3-BFEF-0010E3B966CE")
SimpleEmailClientX;
#endif
#endif /* __SIMPLEEMAILCLIENTLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
