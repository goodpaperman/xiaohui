/*=========================================================================== 
    (c) Copyright 1998-1999, Emmanuel KARTMANN, all rights reserved                 
  =========================================================================== 
    File           : WindowsErrorText.h
    $Header: $
    Author         : Emmanuel KARTMANN
    Creation       : Monday 11/15/99 10:35:27 PM
    Remake         : 
  ------------------------------- Description ------------------------------- 

           Declaration of the WindowsGetErrorText function.

  ------------------------------ Modifications ------------------------------ 
    $Log: $  
  =========================================================================== 
*/

#ifndef _WINDOWS_ERROR_TEXT_
#define _WINDOWS_ERROR_TEXT_


/////////////////////////////////////////////////////////////////////
//
// <U>Purpose:</U> return the text for a given Windows Error Code
//
// <U>Parameters:</U> 
//
//       [in] dwErrorCode
//                WIN32 error code (e.g. returned by "GetLastError")
//       [in] lpszBuf
//                buffer where the error text will be written
//       [in] dwSize
//                size of the buffer (maximum size for the error text)
//
// <U>Return value :</U> LPTSTR = error text (points to lpszBuf)
//
// <U>Description  :</U> This function is a wrapper for many error-handling
//                       functions from WIN32. It searches for error text
//                       in the following locations:
//
//  <UL>
//      <LI>In the Operating System, using function FormatMessage (...FORMAT_MESSAGE_FROM_SYSTEM...)
//      <LI>In specific modules, using function FormatMessage (...FORMAT_MESSAGE_FROM_HMODULE...):
//      <UL>
//          <LI>wininet.dll (Win32 Internet Errors)
//          <LI>mqutil.dll (Microsoft Message Queue Errors)
//      </UL>
//      <LI>In Extended Internet Errors, using function InternetGetLastResponseInfo()
//  </UL>
//
//  If no error text is found, this function still builds an error message
//  with the format "Error Code 0x%X (%d)" (the error code is shown is hexadecimal
//  and in decimal).
//
LPTSTR WindowsGetErrorText(DWORD dwErrorCode, LPTSTR lpszBuf, DWORD dwSize);

#endif // _WINDOWS_ERROR_TEXT_
