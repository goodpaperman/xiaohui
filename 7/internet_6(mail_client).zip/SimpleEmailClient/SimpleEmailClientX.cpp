// SimpleEmailClientX.cpp : Implementation of CSimpleEmailClientX
#include "stdafx.h"
#include <comdef.h>
#include "SimpleEmailClient.h"
#include "SimpleEmailClientX.h"
#include "SimpleSMTPClient.h"

/////////////////////////////////////////////////////////////////////////////
// CSimpleEmailClientX

STDMETHODIMP CSimpleEmailClientX::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_ISimpleEmailClientX
	};
	for (int i=0; i < sizeof(arr) / sizeof(arr[0]); i++)
	{
        if (IsEqualGUID((REFGUID)*arr[i],(REFGUID)riid))
			return S_OK;
	}
	return S_FALSE;
}


STDMETHODIMP CSimpleEmailClientX::SendEmail(BSTR BFrom, BSTR BTo, BSTR BSubject, BSTR BBody, BSTR BServerName)
{
    HRESULT hReturnCode = S_OK;
    _bstr_t szFrom = BFrom;
    _bstr_t szTo = BTo;
    _bstr_t szSubject = BSubject;
    _bstr_t szBody = BBody;
    _bstr_t szServerName = BServerName;
    CSimpleSMTPClient oMailClient(szServerName, 25, m_uTimeOut);
    USES_CONVERSION;

    hReturnCode = oMailClient.SendEmail(szFrom, szTo, szSubject, szBody);
    if (FAILED(hReturnCode)) {
        // Build error info object
        ICreateErrorInfo *pcerrinfo = NULL;
        IErrorInfo *perrinfo = NULL;
        HRESULT hr;

        hr = CreateErrorInfo(&pcerrinfo);

        // Fill error info object
        pcerrinfo->SetDescription(T2OLE(oMailClient.GetLastErrorMessage()));
        pcerrinfo->SetSource(T2OLE("Emmanuel.SimpleEmailClientX"));
        pcerrinfo->SetGUID(IID_ISimpleEmailClientX);

        // Set error info object for current thread
        hr = pcerrinfo->QueryInterface(IID_IErrorInfo, (LPVOID FAR*) &perrinfo);
        if (SUCCEEDED(hr))
        {
            SetErrorInfo(0, perrinfo);
            perrinfo->Release();
        }
        pcerrinfo->Release();
    }

	return(hReturnCode);
}

STDMETHODIMP CSimpleEmailClientX::get_TimeOut(long *pVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

    if (pVal) {
        *pVal = m_uTimeOut;
    }

	return S_OK;
}

STDMETHODIMP CSimpleEmailClientX::put_TimeOut(long newVal)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState())

    m_uTimeOut = (UINT)newVal;

	return S_OK;
}
