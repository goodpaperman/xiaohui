========================================================================
       ATL COM Object : SimpleEmailClientX 1.3
========================================================================

Author: Emmanuel KARTMANN <emmanuel@kartmann.com>
Creation Date: November 28th, 1998
Last Modification Date: February 8th, 2000

OVERVIEW
========

This ATL COM component provides very simple Internet email functionality (SMTP).



FEATURES
========

    * implement the basics of SMTP, as defined in RFC821 and RFC822
    * send plain text email: no attachements, no MIME encoding.
    * support multiple recipients (separate email addresses with commas ',')
    * support multiple email servers (try next server if email cannot be delivered to a server)
NEW * provides automatic detection of SMTP server (resolve MX record in the DNS, using COMponent SimpleDNSResolver)
    * provide extended error information (ISupportErrorInfo and IErrorInfo are implemented)
    * provide very small executable: 44 Ko (MinSize) to 144 Ko (MinDependency)
    * require no Graphical User Interface: the component can be used in non-GUI applications, 
      like a Windows NT Service.
	* run on Windows NT 4.0, Windows 95 and Windows 98
	* compile with VC++ 6.0 SP3



USAGE
=====

To use this component:
    * create an instance of the component,
    * call method SendEmail from interface ISimpleEmailClientX,
    * handle errors (try/catch in C++)



SAMPLE CODE (VC++)
==================

    // Import smart pointer definition
    #import "SimpleEmailClient.dll" no_namespace

    // Create smart pointer object
    ISimpleEmailClientXPtr pSimpleEmailClientX;

    // =======================================================================
	// Initialize COM (This should be called at thread startup)
    // =======================================================================
    HRESULT hResult = CoInitialize(NULL); 
    if (FAILED(hResult)) {
        ErrorDialogBox("Cannot initialize COM: \n", hResult);
        return; // Failed
    }
	
    // =======================================================================
	// Create instance of the component to test
    // =======================================================================
    try 
    {
        HRESULT hResult = S_OK;
        // Create object
        hResult = pSimpleEmailClientX.CreateInstance("Emmanuel.SimpleEmailClientX.1");
        if (FAILED(hResult)) {
            ErrorDialogBox("Cannot create component Emmanuel.SimpleEmailClientX.1: \n", hResult);
        }
    }
    catch (_com_error &e)
    {
        ErrorDialogBox("Cannot create component Emmanuel.SimpleEmailClientX.1: \n", e);
    }

    // =======================================================================
    // Call method of component
    // =======================================================================
    try 
    {
        HRESULT hResult = S_OK;
        hResult = pSimpleEmailClientX->SendEmail(_bstr_t(m_szFrom), _bstr_t(m_szTo), _bstr_t(m_szSubject), _bstr_t(m_szBody), _bstr_t(m_szServerName));
        if (FAILED(hResult)) {
            ErrorDialogBox("Failure while executing method SendMail: \n", hResult);
        }
    }
    catch (_com_error &e)
    {
        ErrorDialogBox("Failure while executing method SendMail: \n", e);
    }

    // =======================================================================
    // UnInitialize COM (This should be called at thread exit)
    // =======================================================================
    CoUninitialize(); 


Please refer to the test project in subdirectory "TestSimpleEmailClient" for a full example.



SAMPLE CODE (VBScript)
======================

	Dim oSMTP

	Set oSMTP = CreateObject("Emmanuel.SimpleEmailClientX.1")

	oSMTP.SendEmail "me@mydomain.com", "you@yourdomain.com", "My Subject", "My Text...", "myserver.domain.com"


Please refer to the test HTML file for a full VBSsript example :
    TestSimpleEmailClient/TestSimpleEmailClient.htm



IMPLEMENTATION
==============

This component relies on two MFC-related C++ class:
    * CSimpleSocket: an extension of MFC class CSocket providing text and timer features
    * CSimpleSMTPClient: a C++ class implementing a SMTP client.

You can integrate these classes in your application if you don't want to use the component.

If the COMponent "Emmanuel.SimpleDNSClient" is installed on your machine, it will be used
to find the name of you SMTP server(s) as registered in the DNS. You will not need to provide
a SMTP name as the 5th parameter of method SendEmail (just put an empty string). Please refer 
to the SimpleDNSClient documentation (www.kartmann.com/emmanuel) for details.


TO DO LIST
==========

    * Support attachments
    * Support binary data (MIME encoding)
	* Support additional SMTP headers (Reply-To, Cc, Bcc, etc...)
	* Support ESMTP
