/*=========================================================================== 
    (c) Copyright 1998-1999, Emmanuel KARTMANN, all rights reserved
  =========================================================================== 
    File           : SimpleSocket.h
    $Header: $
    Author         : Emmanuel KARTMANN
    Creation       : Tuesday 11/17/98
    Remake         : 
  ------------------------------- Description ------------------------------- 

           Declaration of the CSimpleSocket class.

  ------------------------------ Modifications ------------------------------ 
    $Log: $  
  =========================================================================== 
*/

#ifndef __SocketWithTimeOut_H__
#define __SocketWithTimeOut_H__

#include <afxsock.h>

/* -----------------------------------------------------------------
CLASS

    CSimpleSocket 

    Implements a socket class with additional features: timer, text protocol...

DESCRIPTION

    This class provides an API for accessing Windows Socket similar
    to the MFC CSocket class, but with additional features:
    <UL>
        <LI>Timer on all operations (Connect, Send, Receive)
        <LI>Text Protocol Handling: new functions to receive text/lines
            (suitable for text protocols like SMTP).
    </UL>

    <U><B>CAUTION:</B></U> do not share instances of this class between threads. 
    This class is derived from CSocket is suffers the same limitations
    as its base class (as described in MSDN articles Q175668 and Q140527).

USAGE

    To use this class:
    <UL>
        <LI>Create an instance of the class
        <LI>Call method Create() [inherited]
        <LI>Call method Connect() [inherited]
        <LI>Call either method Send(), ReceiveString(), or ReceiveLine()
    </UL>

EXAMPLE

<PRE>
    // Create an instance
    CSimpleSocket oSocket;

    // Create the socket
    if (oSocket.Create())
    {
        // Connect to the server
        if (oSocket.Connect(m_szServerName, m_uPortNumber)!=0)
        {
            // Set timeout value to 30 seconds
            oSocket.SetTimeOut(30000);

            CString strResponse;
            // Read response from the server
            if (oSocket.ReceiveLine(strResponse) != SOCKET_ERROR) {

                // Send data to server
                oSocket.Send("QUIT\r\n");
                
            }
        }
    }

    // socket is closed automatically when the object oSocket is deleted.

</PRE>


ADMINISTRATIVE

  Author     Emmanuel KARTMANN

  Date       Tuesday 11/17/98

SEE ALSO

    CSocket CAsyncSocket<BR>
    MSDN articles Q175668 and Q140527

----------------------------------------------------------------- */

class CSimpleSocket : public CSocket
{
	DECLARE_DYNAMIC(CSimpleSocket);

public:

/////////////////////////////////////////////////////////////////////
//
// <U>Purpose:</U> establish a connection to an unconnected stream 
//                 or datagram socket.
//
// <U>Parameters:</U> 
//
//       [in] lpszHostAddress
//                network address of the socket to which this object 
//                is connected: a machine name such as 
//                "ftp.microsoft.com", or a dotted number such as 
//                "128.56.22.8".
//       [in] nHostPort
//                The port identifying the socket application
//       [in] uTimeOut 
//                timeout value (in milliseconds)
//
// <U>Return value :</U> BOOL = TRUE for success, FALSE otherwise.
//
// <U>Description  :</U> overrides CAsyncSocket::Connect
//                       (implements timer with multithreading) 
//
    BOOL Connect( LPCTSTR lpszHostAddress, UINT nHostPort, UINT uTimeOut = INFINITE);

/////////////////////////////////////////////////////////////////////
//
// <U>Purpose:</U> create an instance of the class
//
// <U>Parameters:</U> 
//
//       [in] uTimeOut
//                default timeout value (in milliseconds)
//
// <U>Return value :</U> none (C++ constructor)
//
// <U>Description  :</U> 
//
    CSimpleSocket(UINT uTimeOut = 0);

/////////////////////////////////////////////////////////////////////
//
// <U>Purpose:</U> delete an instance of the class
//
// <U>Parameters:</U> none (C++ destructor)
//
// <U>Return value :</U> none (C++ destructor)
//
// <U>Description  :</U> 
//
    ~CSimpleSocket();

/////////////////////////////////////////////////////////////////////
//
// <U>Purpose:</U> receives data (string only) from the socket.
//
// <U>Parameters:</U> 
//
//       [in] nFlags 
//                option flag (same as for CSocket::Receive())
//       [out] str
//                the string received from socket
//
// <U>Return value :</U> int = number of bytes received in case of success,
//                             SOCKET_ERROR otherwise.
//
// <U>Description  :</U> This function times out after (m_uTimeOut) milliseconds
//
    int ReceiveString(CString& str, int nFlags = 0);

/////////////////////////////////////////////////////////////////////
//
// <U>Purpose:</U> receives next line (string data only) from the socket.
//
// <U>Parameters:</U> 
//
//       [in] nFlags 
//                option flag (same as for CSocket::Receive())
//       [out] szLine
//                the line received from socket
//
// <U>Return value :</U> int = number of bytes received in case of success,
//                             SOCKET_ERROR otherwise.
//
// <U>Description  :</U> Reads data up to the next CRLF character.
//                       This function times out after (m_uTimeOut) milliseconds
//
    int ReceiveLine(CString& szLine, int nFlags = 0);


/////////////////////////////////////////////////////////////////////
//
// <U>Purpose:</U> receive data from a socket (with timeout)
//
// <U>Parameters:</U> 
//
//       [out] lpBuf
//                A buffer for the incoming data
//       [in] nBufLen
//                The length of lpBuf in bytes
//       [in] nFlags 
//                Specifies the way in which the call is made
//                (see CAsyncSocket::Receive() for details)
//
// <U>Return value :</U> int = If no error occurs, Receive returns 
//                             the number of bytes received.
//                             If the connection has been closed, 
//                             it returns 0. 
//                             Otherwise, a value of SOCKET_ERROR 
//                             is returned
//
// <U>Description  :</U> overrides method CAsyncSocket::Receive()
//
    virtual int Receive(void* lpBuf, int nBufLen, int nFlags = 0);

/////////////////////////////////////////////////////////////////////
//
// <U>Purpose:</U> send data to the socket (with timeout)
//
// <U>Parameters:</U> 
//
//       [in] lpBuf
//                A buffer containing the data to be transmitted
//       [in] nBufLen
//                The length of the data in lpBuf in bytes
//       [in] nFlags 
//                Specifies the way in which the call is made
//                (see CAsyncSocket::Send() for details)
//
// <U>Return value :</U> int = If no error occurs, Send returns 
//                             the total number of characters sent.
//                             Otherwise, a value of SOCKET_ERROR is 
//                             returned.
//
// <U>Description  :</U> overrides method CAsyncSocket::Send()
//
    virtual int Send(const void* lpBuf, int nBufLen, int nFlags = 0);

/////////////////////////////////////////////////////////////////////
//
// <U>Purpose:</U> send string to the socket (with timeout)
//
// <U>Parameters:</U> 
//
//       [in] szString
//                A string to be transmitted
//       [in] nFlags 
//                Specifies the way in which the call is made
//                (see CAsyncSocket::Send() for details)
//
// <U>Return value :</U> int = If no error occurs, Send returns 
//                             the total number of characters sent.
//                             Otherwise, a value of SOCKET_ERROR is 
//                             returned.
//
// <U>Description  :</U> overrides method CAsyncSocket::Send()
//
    virtual int Send(CString &szString, int nFlags = 0);

/////////////////////////////////////////////////////////////////////
//
// <U>Purpose:</U> send string to the socket (with timeout)
//
// <U>Parameters:</U> 
//
//       [in] lpszString
//                A pointer to a string to be transmitted
//       [in] nFlags 
//                Specifies the way in which the call is made
//                (see CAsyncSocket::Send() for details)
//
// <U>Return value :</U> int = If no error occurs, Send returns 
//                             the total number of characters sent.
//                             Otherwise, a value of SOCKET_ERROR is 
//                             returned.
//
// <U>Description  :</U> overrides method CAsyncSocket::Send()
//
    virtual int Send(LPCTSTR lpszString, int nFlags = 0);

/////////////////////////////////////////////////////////////////////
//
// <U>Purpose:</U> set the timeout value for all socket operations
//
// <U>Parameters:</U> 
//
//       [in] uTimeOut 
//                timeout value, in milliseconds (0 for infinite wait)
//
// <U>Return value :</U> none
//
// <U>Description  :</U> Send/Receive methods use the timeout value
//                       in their implementation.
//
    void SetTimeOut(UINT uTimeOut = 0);

/////////////////////////////////////////////////////////////////////
//
// <U>Purpose:</U> returns the timeout value for all socket operations
//
// <U>Parameters:</U> none
//
// <U>Return value :</U> UINT = timeout value, in milliseconds  (0 for infinite wait)
//
// <U>Description  :</U> 
//
    UINT GetTimeOut() const;

protected: 
	HANDLE CreateConnectingThread(void *pvIOParams);
    static void ThreadConnectSocket(void *pvIOParams);
    int WaitForData(SOCKET *pSocketForReceiving, SOCKET *pSocketForSending,SOCKET *pSocketForExceptions = NULL);

    UINT m_uTimeOut;
    CString m_szFullString;
};
#endif // __SocketWithTimeOut_H__
