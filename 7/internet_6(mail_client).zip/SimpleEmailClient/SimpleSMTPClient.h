/*=========================================================================== 
    (c) Copyright 1998-1999, Emmanuel KARTMANN, all rights reserved
  =========================================================================== 
    File           : SimpleSMTPClient.h
    $Header: $
    Author         : Emmanuel KARTMANN
    Creation       : Tuesday 11/17/98
    Remake         : 
  ------------------------------- Description ------------------------------- 

           Declaration of the CSimpleSMTPClient class.

  ------------------------------ Modifications ------------------------------ 
    $Log: $  
  =========================================================================== 
*/

#if !defined(AFX_SIMPLESMTPCLIENT_H__B3317884_B203_11D3_BFEF_0010E3B966CE__INCLUDED_)
#define AFX_SIMPLESMTPCLIENT_H__B3317884_B203_11D3_BFEF_0010E3B966CE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/* -----------------------------------------------------------------
CLASS

    CSimpleSMTPClient

    Simple API for sending Internet Emails (via SMTP).

DESCRIPTION

    This class provides a simple API to send Internet Emails via the
    Simple Mail Transfer Protocol (SMTP).

    This class succeeded in sending email messages to the following SMTP servers:
    <UL>
        <LI>Lotus SMTP MTA Service
        <LI>ESMTP Sendmail 8.8.8
        <LI>ESMTP Sendmail 8.9.3
        <LI>ESMTP Postfix
    </UL>

USAGE

    To use this class:
    <UL>
        <LI>Create an instance of the class, passing the SMTP Server Name (or address)
        <LI>Call method SendEmail()
    </UL>

EXAMPLE

<PRE>
    // Create instance
    CSimpleSMTPClient oSMTPClient("smtp.mydomain.com");

    HRESULT hResult = oSMTPClient.SendEmail("me@mydomain.com",
                                            "you@yourdomain.com",
                                            "This is my subject...",
                                            "This is the body text...");
    if (FAILED(hResult)) {

        // Log error

        [...]

    } else {

        // Email sent successfully

        [...]

    }
</PRE>

ADMINISTRATIVE

  Author     Emmanuel KARTMANN

  Date       Tuesday 11/17/98

SEE ALSO

    CSimpleSocket CSocket <A HREF="http://www.ietf.org/rfc/rfc0822.txt">RFC822</A>
    <A HREF="http://www.ietf.org/rfc/rfc0821.txt">RFC821</A>

----------------------------------------------------------------- */
class CSimpleSMTPClient
{
public:

/////////////////////////////////////////////////////////////////////
//
// <U>Purpose:</U> create an instance of the class
//
// <U>Parameters:</U> 
//
//       [in] lpszSMTPServerNames
//                List of IP name or IP address of the SMTP Servers
//                (string with names separated by commas).
//       [in] uPortNumber 
//                SMTP port number (defaults to 25)
//       [in] uTimeOut 
//                timeout (in milliseconds) for connection/send/receive
//                (defaults to 30 seconds)
//
// <U>Return value :</U> none (C++ constructor)
//
// <U>Description  :</U> 
//
    CSimpleSMTPClient(LPCTSTR lpszSMTPServerNames, UINT uPortNumber = 25, UINT uTimeOut = 30000);

/////////////////////////////////////////////////////////////////////
//
// <U>Purpose:</U> delete an instance of the class
//
// <U>Parameters:</U> none (C++ destructor)
//
// <U>Return value :</U> none (C++ destructor)
//
// <U>Description  :</U> 
//
    virtual ~CSimpleSMTPClient();

/////////////////////////////////////////////////////////////////////
//
// <U>Purpose:</U> send an email message (via SMTP)
//
// <U>Parameters:</U> 
//
//       [in] lpszFrom
//                message originator (one RFC822 address). You can use
//                full addresses (e.g. "Emmanuel KARTMANN <emmanuel@kartmann.com>")
//                or raw addresses (e.g. "emmanuel@kartmann.com").
//       [in] lpszTo
//                message recipients (list of RFC822 addresses, 
//                separated by commas or semicolons). You can use
//                full addresses (e.g. "Emmanuel KARTMANN <emmanuel@kartmann.com>")
//                or raw addresses (e.g. "emmanuel@kartmann.com").
//       [in] lpszSubject
//                message subject
//       [in] lpszBody
//                message body
//
// <U>Return value :</U> HRESULT = S_OK (0) for success
//
// <U>Description  :</U> This function tries to send the email message
//                       using all known SMTP servers (see constructor).
//                       It calls function SendEmailToServer() until
//                       one server accepts to deliver the email message.
//
    HRESULT SendEmail(LPCTSTR lpszFrom, LPCTSTR lpszTo, LPCTSTR lpszSubject, LPCTSTR lpszBody);

/////////////////////////////////////////////////////////////////////
//
// <U>Purpose:</U> returns the last error message
//
// <U>Parameters:</U> none
//
// <U>Return value :</U> CString = last error message
//
// <U>Description  :</U> CAUTION: the current implementation is
//                       not thread-safe (there's only one message
//                       per class instance; you should not share
//                       the class instance between threads).
//
    CString GetLastErrorMessage(void);

protected:
/////////////////////////////////////////////////////////////////////
//
// <U>Purpose:</U> Builds a CStringList object with a string
//                 containing separators (e.g. list of SMTP addresses
//                 separated by commas ',')
//
// <U>Parameters:</U> 
//
//       [in] lpszStringWithSeparators
//                the string that will be parsed to build the list
//       [out] oList
//                the built list
//
// <U>Return value :</U> BOOL = TRUE for success, FALSE otherwise
//
// <U>Description  :</U> The separator is either a comma (',') or 
//                       a semicolon (';').
//
    BOOL BuildListFromString(LPCTSTR lpszStringWithSeparators, CStringList &oList);

/////////////////////////////////////////////////////////////////////
//
// <U>Purpose:</U> Builds a string containing separators with a 
//                 CStringList object with a string (e.g. list of 
//                 SMTP addresses separated by commas ',')
//
// <U>Parameters:</U> 
//
//       [in] oList
//                the list of strings
//       [in] lpszSeparator
//                the separator used
//
// <U>Return value :</U> CString = the built string
//
// <U>Description  :</U> 
//
    CString BuildStringFromList(CStringList &oList, LPCTSTR lpszSeparator);

/////////////////////////////////////////////////////////////////////
//
// <U>Purpose:</U> builds a RFC822 address from a plain string
//
// <U>Parameters:</U> 
//
//       [in] lpszAddress
//                a plain string (e.g. "emmanuel@kartmann.com")
//
// <U>Return value :</U> CString = RFC822 address, e.g. "<emmanuel@kartmann.com>"
//
// <U>Description  :</U> If the parameter is already an RFC822 address,
//                       (e.g. "Emmanuel KARTMANN <emmanuel@kartmann.com>")
//                       this function does nothing.
//
    CString BuildRFC822Address(LPCTSTR lpszAddress);

/////////////////////////////////////////////////////////////////////
//
// <U>Purpose:</U> extract an SMTP address from a full RFC822 address
//
// <U>Parameters:</U> 
//
//       [in] lpszAddress
//                full address (e.g. "Emmanuel KARTMANN <emmanuel@kartmann.com>")
//
// <U>Return value :</U> CString = SMTP address (e.g. "emmanuel@kartmann.com")
//
// <U>Description  :</U> This function extracts everything between
//                       '<' and '>' in the input string. It's used
//                       because some SMTP servers reject full addresses.
//
    CString ExtractSMTPAddress(LPCTSTR lpszAddress);

/////////////////////////////////////////////////////////////////////
//
// <U>Purpose:</U> return the fully qualified IP name of the local
//                 machine.
//
// <U>Parameters:</U> 
//
//       [out] szFullyQualifiedHostName
//                fully qualified (i.e. including domain name) IP name
//
// <U>Return value :</U> BOOL = TRUE for success, FALSE otherwise
//
// <U>Description  :</U> The IP name is used as part of the SMTP
//                       protocol (in the "HELO" line).
//
    BOOL GetHostName(CString &szFullyQualifiedHostName);

/////////////////////////////////////////////////////////////////////
//
// <U>Purpose:</U> send an email message (via SMTP)
//
// <U>Parameters:</U> 
//
//       [in] lpszServerName
//                IP Name (or address) of the SMTP server to connect to
//       [in] lpszFrom
//                message originator (one RFC822 address). You can use
//                full addresses (e.g. "Emmanuel KARTMANN <emmanuel@kartmann.com>")
//                or raw addresses (e.g. "emmanuel@kartmann.com").
//       [in] lpszTo
//                message recipients (list of RFC822 addresses, 
//                separated by commas or semicolons). You can use
//                full addresses (e.g. "Emmanuel KARTMANN <emmanuel@kartmann.com>")
//                or raw addresses (e.g. "emmanuel@kartmann.com").
//       [in] lpszSubject
//                message subject
//       [in] lpszBody
//                message body
//
// <U>Return value :</U> HRESULT = S_OK (0) for success
//
// <U>Description  :</U> -
//
    HRESULT SendEmailToServer(LPCTSTR lpszServerName, LPCTSTR lpszFrom, LPCTSTR lpszTo, LPCTSTR lpszSubject, LPCTSTR lpszBody);

	CString m_szLastErrorMessage;
	BOOL SetLastError(LPCTSTR lpszErrorMessage, DWORD dwLastError = 0, LPCTSTR lpszSMTPResponse = NULL);
	CStringList m_oServerNames;
    UINT m_uPortNumber;
    UINT m_uTimeOut;
};

#endif // !defined(AFX_SIMPLESMTPCLIENT_H__B3317884_B203_11D3_BFEF_0010E3B966CE__INCLUDED_)
