// TestSimpleEmailClientDlg.h : header file
//

#if !defined(AFX_TESTSIMPLEEMAILCLIENTDLG_H__B331788E_B203_11D3_BFEF_0010E3B966CE__INCLUDED_)
#define AFX_TESTSIMPLEEMAILCLIENTDLG_H__B331788E_B203_11D3_BFEF_0010E3B966CE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#import "SimpleEmailClient.dll" no_namespace

/////////////////////////////////////////////////////////////////////////////
// CTestSimpleEmailClientDlg dialog

class CTestSimpleEmailClientDlg : public CDialog
{
// Construction
public:
    BOOL ErrorDialogBox(LPCTSTR lpszContextErrorMessage, LPCTSTR lpszErrorMessage);
	BOOL ErrorDialogBox(LPCTSTR lpszContextErrorMessage, HRESULT hResult);
    BOOL ErrorDialogBox(LPCTSTR lpszContextErrorMessage, _com_error &e);

	CTestSimpleEmailClientDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CTestSimpleEmailClientDlg)
	enum { IDD = IDD_TESTSIMPLEEMAILCLIENT_DIALOG };
	CString	m_szBody;
	CString	m_szFrom;
	CString	m_szSubject;
	CString	m_szTo;
	CString	m_szServerName;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestSimpleEmailClientDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
    ISimpleEmailClientXPtr m_pSimpleEmailClientX;

	// Generated message map functions
	//{{AFX_MSG(CTestSimpleEmailClientDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTSIMPLEEMAILCLIENTDLG_H__B331788E_B203_11D3_BFEF_0010E3B966CE__INCLUDED_)
