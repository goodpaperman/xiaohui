// TestSimpleEmailClientDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TestSimpleEmailClient.h"
#include "TestSimpleEmailClientDlg.h"
#include "WindowsErrorText.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestSimpleEmailClientDlg dialog

CTestSimpleEmailClientDlg::CTestSimpleEmailClientDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTestSimpleEmailClientDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTestSimpleEmailClientDlg)
	m_szBody = _T("");
	m_szFrom = _T("");
	m_szSubject = _T("");
	m_szTo = _T("");
	m_szServerName = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTestSimpleEmailClientDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestSimpleEmailClientDlg)
	DDX_Text(pDX, IDC_EDIT_BODY, m_szBody);
	DDX_Text(pDX, IDC_EDIT_FROM, m_szFrom);
	DDX_Text(pDX, IDC_EDIT_SUBJECT, m_szSubject);
	DDX_Text(pDX, IDC_EDIT_TO, m_szTo);
	DDX_Text(pDX, IDC_EDIT_SERVER_NAME, m_szServerName);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTestSimpleEmailClientDlg, CDialog)
	//{{AFX_MSG_MAP(CTestSimpleEmailClientDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestSimpleEmailClientDlg message handlers

BOOL CTestSimpleEmailClientDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CTestSimpleEmailClientDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTestSimpleEmailClientDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTestSimpleEmailClientDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CTestSimpleEmailClientDlg::OnOK() 
{
	CDialog::OnOK();

    // =======================================================================
	// Initialize COM (This should be called at thread startup)
    // =======================================================================
    HRESULT hResult = CoInitialize(NULL); 
    if (FAILED(hResult)) {
        ErrorDialogBox("Cannot initialize COM: \n", hResult);
        return; // Failed
    }
	
    // =======================================================================
	// Create instance of the component to test
    // =======================================================================
    try 
    {
        HRESULT hResult = S_OK;
        // Create object
        hResult = m_pSimpleEmailClientX.CreateInstance("Emmanuel.SimpleEmailClientX.1");
        if (FAILED(hResult)) {
            ErrorDialogBox("Cannot create component Emmanuel.SimpleEmailClientX.1: \n", hResult);
        }
    }
    catch (_com_error &e)
    {
        ErrorDialogBox("Cannot create component Emmanuel.SimpleEmailClientX.1: \n", e);
    }

    // =======================================================================
    // Call method of component
    // =======================================================================
    try 
    {
        HRESULT hResult = S_OK;
        hResult = m_pSimpleEmailClientX->SendEmail(_bstr_t(m_szFrom), _bstr_t(m_szTo), _bstr_t(m_szSubject), _bstr_t(m_szBody), _bstr_t(m_szServerName));
        if (FAILED(hResult)) {
            ErrorDialogBox("Failure while executing method SendMail: \n", hResult);
        }
    }
    catch (_com_error &e)
    {
        ErrorDialogBox("Failure while executing method SendMail: \n", e);
    }

    // =======================================================================
    // UnInitialize COM (This should be called at thread exit)
    // =======================================================================
    //CoUninitialize(); 
	
}

BOOL CTestSimpleEmailClientDlg::ErrorDialogBox(LPCTSTR lpszContextErrorMessage, LPCTSTR lpszErrorMessage)
{
    // Concatenate both message strings
    CString szErrorMessage = lpszContextErrorMessage;
    szErrorMessage+=lpszErrorMessage;
    AfxMessageBox(szErrorMessage, MB_OK|MB_ICONERROR);
    return(TRUE);
}

BOOL CTestSimpleEmailClientDlg::ErrorDialogBox(LPCTSTR lpszContextErrorMessage, HRESULT hResult)
{
    // Map hResult to message text and call above function
    TCHAR lpszSystemErrorText[1024];
    ErrorDialogBox(lpszContextErrorMessage, WindowsGetErrorText(hResult, lpszSystemErrorText, sizeof(lpszSystemErrorText)));
    return(TRUE);
}

BOOL CTestSimpleEmailClientDlg::ErrorDialogBox(LPCTSTR lpszContextErrorMessage, _com_error &e)
{
    TCHAR lpszBuffer[1024];
    DWORD dwLastError = e.Error();
    _bstr_t bstrSource(e.Source());
    _bstr_t bstrDescription(e.Description());
    CString szDescription = (TCHAR *)bstrDescription;
    if (szDescription == "" && FAILED(dwLastError)) {
        WindowsGetErrorText(HRESULT_CODE(dwLastError), lpszBuffer, sizeof(lpszBuffer));
    } else {
        sprintf(lpszBuffer, "[%X] %s", e.Error(), szDescription);
    }
    ErrorDialogBox(lpszContextErrorMessage, lpszBuffer);
    return(TRUE);
}
