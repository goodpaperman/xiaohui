/*=========================================================================== 
    (c) Copyright 1998-2000, Emmanuel KARTMANN, all rights reserved                 
  =========================================================================== 
    File           : WindowsErrorText.cpp
    $Header: $
    Author         : Emmanuel KARTMANN
    Creation       : Monday 11/15/99 11:44:48 PM
    Remake         : 
  ------------------------------- Description ------------------------------- 

           Implementation of the WindowsGetErrorText function.

  ------------------------------ Modifications ------------------------------ 
    $Log: $  
  =========================================================================== 
*/


#include "stdafx.h"

// We need this for function InternetGetLastResponseInfo (maps extended Inet error code to a text)
#include <wininet.h>
#pragma comment(lib, "wininet.lib")

LPTSTR WindowsGetErrorText(DWORD dwErrorCode, LPTSTR lpszBuf, DWORD dwSize) 
{
    LPTSTR lpszTemp = 0;

    DWORD dwRet =	::FormatMessage(
						FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM |FORMAT_MESSAGE_ARGUMENT_ARRAY,
						0,
						dwErrorCode,
						LANG_NEUTRAL,
						(LPTSTR)&lpszTemp,
						0,
						0
					);

    if( !dwRet || (dwSize < dwRet+14) ) {
        if(lpszTemp) {
            LocalFree(HLOCAL(lpszTemp));
            lpszTemp = NULL;
        }
        lpszBuf[0] = TEXT('\0');
        // Empty string: couldn't map message code to a text!
        // Try in other modules (resources are in other DLLs...)
        TCHAR *lpszOtherModuleNames[] = {
            "wininet.dll",
            "Wsock32.dll",
            "mqutil.dll",
            NULL
        };
        int nCurrentModule = 0;
        while (lpszOtherModuleNames[nCurrentModule]) {
            HMODULE hModule = GetModuleHandle(lpszOtherModuleNames[nCurrentModule]);
            dwRet=0;

            if (hModule) {
                dwRet = FormatMessage(FORMAT_MESSAGE_FROM_HMODULE | FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_ARGUMENT_ARRAY,
                                      hModule,
                                      dwErrorCode,
                                      LANG_NEUTRAL,
                                      (LPTSTR)&lpszTemp,
                                      0,
                                      NULL);
                if (dwRet) {
                    // Found message stop loop
                    break;
                }
            }
            nCurrentModule++;
        }

        if (!dwRet) {

            // Nothing either: Show the code anyway
            sprintf(lpszBuf, "Error Code 0x%X (%d)", dwErrorCode, dwErrorCode);

        } else {
            _tcscpy(lpszBuf, lpszTemp);
        }

        // Still Try in EXTENDED INET ERROR
        if (HRESULT_CODE(dwErrorCode) == ERROR_INTERNET_EXTENDED_ERROR) {
            DWORD  dwIntError , dwLength = 0;
            // Try to fetch the error text length BEFORE allocating the buffer
            if (InternetGetLastResponseInfo(&dwIntError, NULL, &dwLength)) {
                if (dwLength) {
                    if ((lpszTemp = (TCHAR *) LocalAlloc( LPTR,  dwLength) ) ) {
                        if (!InternetGetLastResponseInfo(&dwIntError, (LPTSTR) lpszTemp, &dwLength)) {
                            // Can't map: keep the raw code
                            LocalFree(lpszTemp);
                            lpszTemp=NULL;
                        } else {
                            // Found extended error: copy it or add it to current error
                            _tcscat(lpszBuf, lpszTemp);
                        }
                    
                    }
                }
            } else {
                // Can't get extended error: try again with fixed-length buffer
                if (GetLastError() == ERROR_INSUFFICIENT_BUFFER) {
                    // Try to guess the buffer length
                    DWORD dwLength = 4096;
                    if ((lpszTemp = (TCHAR *) LocalAlloc( LPTR,  dwLength) ) ) {
                        if (!InternetGetLastResponseInfo(&dwIntError, (LPTSTR) lpszTemp, &dwLength)) {
                            // Can't map: keep the raw code
                            LocalFree(lpszTemp);
                            lpszTemp=NULL;
                        } else {
                            // Found extended error: copy it or add it to current error
                            _tcscat(lpszBuf, lpszTemp);
                        }
                    }
                }
            }
            
        }

    } else {
        lpszTemp[_tcsclen(lpszTemp)-2] = TEXT('\0');  //remove cr/nl characters
        _tcscpy(lpszBuf, lpszTemp);
    }

    if( lpszTemp )
        LocalFree(HLOCAL(lpszTemp));

    TRACE1("\n\nERROR: %s\n\n", lpszBuf);
    return lpszBuf;
}



