========================================================================
       MICROSOFT FOUNDATION CLASS APPLICATION : TestSimpleEmailClient
========================================================================

Author: Emmanuel KARTMANN
Date: November 28th, 1998

OVERVIEW
========

This dialog-based application is a unit test for the SimpleEmailClientX component
(SimpleEmailClient.dll). You can use it to test the component and to 

USAGE
=====

This program provides a Graphical User Interface to edit an email message:
 * From: type the originator of the message
 * To: type the recipient(s) of the message (list of email addresses separated
       by commas)
 * Subject: type the message subject
 * Body: type the message body
 * SMTP Server Name(s): type the list of SMTP server names to contact 
                        (list of IP names separated by commas)

Click on the OK button when done.

COMPILATION
===========

Extract the kit (TestSimpleEmailClient.zip) in a directory beneath the SimpleEmailClient directory, i.e.:
 SimpleEmailClient\                 (this is where the ActiveX project is located)
 	TestSimpleEmailClient\      (this is where the test project must be located)


IMPLEMENTATION
==============

When the user clicks on the OK button, this program:
 * creates an instance of the component,
 * calls method SendEmail from interface ISimpleEmailClientX,
 * in case of error, it displays an dialog box with full error text.

