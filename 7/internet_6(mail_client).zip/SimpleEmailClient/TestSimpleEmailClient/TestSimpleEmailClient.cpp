// TestSimpleEmailClient.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "TestSimpleEmailClient.h"
#include "TestSimpleEmailClientDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestSimpleEmailClientApp

BEGIN_MESSAGE_MAP(CTestSimpleEmailClientApp, CWinApp)
	//{{AFX_MSG_MAP(CTestSimpleEmailClientApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestSimpleEmailClientApp construction

CTestSimpleEmailClientApp::CTestSimpleEmailClientApp()
{
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CTestSimpleEmailClientApp object

CTestSimpleEmailClientApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CTestSimpleEmailClientApp initialization

BOOL CTestSimpleEmailClientApp::InitInstance()
{
	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	CTestSimpleEmailClientDlg dlg;
	m_pMainWnd = &dlg;

    // Initialize defaults with values saved in registry
    SetRegistryKey("Emmanuel"); // Should be a Company name, but...
	dlg.m_szBody = GetProfileString("Email Defaults", "Body");
	dlg.m_szFrom = GetProfileString("Email Defaults", "From");
	dlg.m_szSubject = GetProfileString("Email Defaults", "Subject");
	dlg.m_szTo = GetProfileString("Email Defaults", "To");
	dlg.m_szServerName = GetProfileString("Email Defaults", "Server Name");

	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		//  dismissed with OK
	    WriteProfileString("Email Defaults", "Body", dlg.m_szBody);
	    WriteProfileString("Email Defaults", "From", dlg.m_szFrom);
	    WriteProfileString("Email Defaults", "Subject", dlg.m_szSubject);
	    WriteProfileString("Email Defaults", "To", dlg.m_szTo);
	    WriteProfileString("Email Defaults", "Server Name", dlg.m_szServerName);
	}
	else if (nResponse == IDCANCEL)
	{
		//  dismissed with Cancel
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
