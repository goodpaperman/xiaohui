// SimpleEmailClientX.h : Declaration of the CSimpleEmailClientX

#ifndef __SIMPLEEMAILCLIENTX_H_
#define __SIMPLEEMAILCLIENTX_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CSimpleEmailClientX
class ATL_NO_VTABLE CSimpleEmailClientX : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CSimpleEmailClientX, &CLSID_SimpleEmailClientX>,
	public ISupportErrorInfo,
	public IDispatchImpl<ISimpleEmailClientX, &IID_ISimpleEmailClientX, &LIBID_SIMPLEEMAILCLIENTLib>
{
public:
	CSimpleEmailClientX()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_SIMPLEEMAILCLIENTX)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CSimpleEmailClientX)
	COM_INTERFACE_ENTRY(ISimpleEmailClientX)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()

// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// ISimpleEmailClientX
public:
	STDMETHOD(get_TimeOut)(/*[out, retval]*/ long *pVal);
	STDMETHOD(put_TimeOut)(/*[in]*/ long newVal);
	STDMETHOD(SendEmail)(BSTR BFrom, BSTR BTo, BSTR BSubject, BSTR BBody, BSTR BServerName);
protected:
	UINT m_uTimeOut;
};

#endif //__SIMPLEEMAILCLIENTX_H_
