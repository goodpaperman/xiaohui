// SimpleDNSClient.cpp: implementation of the CSimpleDNSClient class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SimpleDNSClient.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSimpleDNSClient::CSimpleDNSClient()
{
}

CSimpleDNSClient::~CSimpleDNSClient()
{

}

BOOL CSimpleDNSClient::IsInstalled()
{
    HRESULT hResult = S_OK;

    // Get the CLSID of the "Emmanuel.SimpleDNSClient" object
    LPCOLESTR lpszProgID = L"Emmanuel.SimpleDNSClient.1";
    CLSID clsid;
    hResult = CLSIDFromProgID(lpszProgID, &clsid);
    if (FAILED(hResult)) {
        return(FALSE); // Failed
    }
    return(TRUE);
}


BOOL CSimpleDNSClient::GetMailServers(CString &szMailServerNames)
{
    ISimpleDNSClientPtr pSimpleDNSClient = NULL;
    HRESULT hResult = S_OK;
    LPCOLESTR lpszProgID = L"Emmanuel.SimpleDNSClient.1";
    CLSID clsid;
    _bstr_t BSearchedName;
    _variant_t vFoundNames;
    _variant_t vDNSDomainName;

    szMailServerNames = "";

    // Get the CLSID of the "Emmanuel.SimpleDNSClient" object
    hResult = CLSIDFromProgID(lpszProgID, &clsid);
    if (FAILED(hResult)) {
        ::SetLastError(hResult);
        return(FALSE); // Failed
    }
    // Create instance of SimpleDNSClient
    hResult = CoCreateInstance(clsid, NULL, CLSCTX_INPROC_SERVER, __uuidof(ISimpleDNSClient), (void**)&pSimpleDNSClient);
    if (FAILED(hResult)) {
        ::SetLastError(hResult);
        return(FALSE); // Failed
    }

    // Get the DNS domain name (i.e. my location within DNS)
    hResult = pSimpleDNSClient->GetDNSDomain(&vDNSDomainName);
    if (FAILED(hResult)) {
        ::SetLastError(hResult);
        return(FALSE);
    }
    BSearchedName = vDNSDomainName;

    // Resolve a MX record with the TCP/IP domain name
    hResult = pSimpleDNSClient->GetEmailServers(BSearchedName, &vFoundNames);
    if (FAILED(hResult)) {
        ::SetLastError(hResult);
        return(FALSE);
    }

    // Set output variable
    szMailServerNames = (LPCTSTR)_bstr_t(vFoundNames);

    return(TRUE);
}
