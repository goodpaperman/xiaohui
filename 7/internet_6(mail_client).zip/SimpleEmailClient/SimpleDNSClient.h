// SimpleDNSClient.h: interface for the CSimpleDNSClient class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SIMPLEDNSCLIENT_H__E4696753_D4D4_11D3_8021_0010E3B966CE__INCLUDED_)
#define AFX_SIMPLEDNSCLIENT_H__E4696753_D4D4_11D3_8021_0010E3B966CE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//////////////////////////////////////////////////////////////////////
// DNS Resolver component (used to find the name of SMTP servers)
//////////////////////////////////////////////////////////////////////
#import "SimpleDNSResolver.dll" no_namespace


class CSimpleDNSClient  
{
public:
	CSimpleDNSClient();
	virtual ~CSimpleDNSClient();
	BOOL GetMailServers(CString &szMailServerNames);
	BOOL IsInstalled(void);
};

#endif // !defined(AFX_SIMPLEDNSCLIENT_H__E4696753_D4D4_11D3_8021_0010E3B966CE__INCLUDED_)
