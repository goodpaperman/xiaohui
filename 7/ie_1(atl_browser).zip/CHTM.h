// CHTM.h : Declaration of the CCHTM

#ifndef __CHTM_H_
#define __CHTM_H_
#define MIN_SIZE_X 100
#define MIN_SIZE_Y 100

#include "resource.h"       // main symbols
#include <atlctl.h>
#include <shlguid.h>
#include <shlobj.h>



/////////////////////////////////////////////////////////////////////////////
// CCHTM
class ATL_NO_VTABLE CCHTM : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public IDispatchImpl<ICHTM, &IID_ICHTM, &LIBID_BANDLib>,
	public IDispatchImpl<ICHTMUI, &IID_ICHTMUI, &LIBID_BANDLib>,
	public CWindowImpl<CCHTM>,
	public IPersistStreamInitImpl<CCHTM>,
	public IObjectWithSiteImpl<CCHTM>,
	public IDeskBand,
	public CComCoClass<CCHTM, &CLSID_CHTM>
{
public:
	CCHTM()
	{
	_hwndParent = NULL;
	m_dwBandID = NULL; 
	m_dwViewMode = NULL;
	m_bRequiresSave = FALSE;
	s_pFrameWB = NULL;
	_pSite = NULL;
	}

DECLARE_REGISTRY_RESOURCEID(IDR_CHTM)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CCHTM)
	COM_INTERFACE_ENTRY(ICHTM)
	COM_INTERFACE_ENTRY(ICHTMUI)
	COM_INTERFACE_ENTRY2(IDispatch, ICHTM)
	COM_INTERFACE_ENTRY(IObjectWithSite)
	COM_INTERFACE_ENTRY_IID(IID_IDeskBand,IDeskBand)
	COM_INTERFACE_ENTRY(IPersistStreamInit)
	COM_INTERFACE_ENTRY2(IPersist, IPersistStreamInit)
END_COM_MAP()

BEGIN_PROP_MAP(CCHTM)

END_PROP_MAP()

BEGIN_MSG_MAP(CCHTM)
	MESSAGE_HANDLER(WM_CREATE, OnCreate)

END_MSG_MAP()
// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);



// IViewObjectEx


// ICHTM
public:

// ICHTMUI
public:
	STDMETHOD(OnNav)(IDispatch*  pDisp, VARIANT varLnk);
	// Example method called by the HTML to change the <BODY> background color
	STDMETHOD(OnClick)(IDispatch* pdispBody, VARIANT varColor)
	{
		CComQIPtr<IHTMLBodyElement> spBody(pdispBody);
		if (spBody != NULL)
			spBody->put_bgColor(varColor);
		return S_OK;
	}
	STDMETHOD(OnNag)(IDispatch* pdisp, BSTR varLnk)
	{
		CComQIPtr<IHTMLAnchorElement> spBody(pdisp);
		
		if (spBody != NULL)
			{	
				CComVariant vtEmpty;
				s_pFrameWB->Navigate(varLnk,&vtEmpty,&vtEmpty,&vtEmpty,&vtEmpty);
			}

		return S_OK;
	}


	LRESULT OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{
		CAxWindow wnd(m_hWnd);
		HRESULT hr = wnd.CreateControl(IDH_CHTM);
		if (SUCCEEDED(hr))
			hr = wnd.SetExternalDispatch(static_cast<ICHTMUI*>(this));
		if (SUCCEEDED(hr))
			hr = wnd.QueryControl(IID_IWebBrowser2, (void**)&m_spBrowser);
		return SUCCEEDED(hr) ? 0 : -1;
	}
	

	STDMETHODIMP SetSite(IUnknown* pUnkSite);
	STDMETHODIMP GetSite(REFIID riid, void **ppvSite);
	CComPtr<IWebBrowser2> m_spBrowser;
	STDMETHODIMP GetWindow(HWND* phwnd)
	{
		*phwnd = m_hWnd;
		return S_OK;
	}
	STDMETHODIMP ContextSensitiveHelp(BOOL)
	{
		return E_NOTIMPL;
	}
	STDMETHODIMP ShowDW(BOOL fShow)
	{
		if(m_hWnd)
		{
			if(fShow)
			{
				::ShowWindow(m_hWnd,SW_SHOW);
			}
			else
			{
				::ShowWindow(m_hWnd,SW_HIDE);
			}
		}
		return S_OK;
	}
	STDMETHODIMP CloseDW(unsigned long dwReserved)
	{
		ShowDW(FALSE);
		if(::IsWindow(m_hWnd))
			::DestroyWindow(m_hWnd);
		m_hWnd = NULL;
		return S_OK;
	}
	STDMETHODIMP ResizeBorderDW(const RECT*  prcBorder,
                                     IUnknown* punkToolbarSite,
                                     BOOL      fReserved)
	{
		return E_NOTIMPL;
	}
	STDMETHODIMP GetBandInfo(DWORD dwBandID, DWORD dwViewMode,DESKBANDINFO* pdbi);
	BOOL m_bRequiresSave;
private:
	IWebBrowser2 *s_pFrameWB;
	HWND _hwndParent;
	IInputObjectSite*  _pSite;
	DWORD m_dwBandID; 
	DWORD m_dwViewMode;

};

#endif //__CHTM_H_
