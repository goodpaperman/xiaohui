/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Fri Feb 05 19:31:17 1999
 */
/* Compiler settings for C:\WINNT\Profiles\Administrator\Desktop\Band\band.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_ICHTM = {0x159C2E50,0x9823,0x11D2,{0x8D,0xDC,0xD8,0x4A,0x1B,0x4A,0xCD,0x4D}};


const IID IID_ICHTMUI = {0x159C2E52,0x9823,0x11D2,{0x8D,0xDC,0xD8,0x4A,0x1B,0x4A,0xCD,0x4D}};


const IID LIBID_BANDLib = {0x159C2E41,0x9823,0x11D2,{0x8D,0xDC,0xD8,0x4A,0x1B,0x4A,0xCD,0x4D}};


const CLSID CLSID_CHTM = {0x159C2E51,0x9823,0x11D2,{0x8D,0xDC,0xD8,0x4A,0x1B,0x4A,0xCD,0x4D}};


#ifdef __cplusplus
}
#endif

