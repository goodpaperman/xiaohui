// CHTM.cpp : Implementation of CCHTM

#include "stdafx.h"
#include "Band.h"
#include "CHTM.h"

/////////////////////////////////////////////////////////////////////////////
// CCHTM

STDMETHODIMP CCHTM::SetSite(IUnknown* pUnkSite)
{
// If punkSite is not NULL, a new site is being set.
   if (pUnkSite)
   {
      //
      // If a site is being held, release it and
      // release the in-place object and frame interfaces.
      //
      if (_pSite)
      {
         _pSite->Release();
         _pSite = NULL;
      }

      // Get the parent window.
      IOleWindow* pOleWindow;
   
      if (SUCCEEDED(pUnkSite->QueryInterface(IID_IOleWindow, (LPVOID*)&pOleWindow)))
      {
         pOleWindow->GetWindow(&_hwndParent);
         pOleWindow->Release();
      }

      _ASSERT(_hwndParent);
      if (!_hwndParent)
         return E_FAIL;

      RECT rc;
	  ::GetClientRect(_hwndParent, &rc);
	Create(_hwndParent, rc);

      // Get and keep the IInputObjectSite pointer.
      HRESULT hr = pUnkSite->QueryInterface(IID_IInputObjectSite, (LPVOID*)&_pSite);
      _ASSERT(SUCCEEDED(hr));

      //
      // Get the IWebBrowser2 interface of Internet Explorer
      // This is so we can do such things as navigate in the main
      // window and write to the status bar.
      //
      IOleCommandTarget* pCmdTarget;
      hr = pUnkSite->QueryInterface(IID_IOleCommandTarget, (LPVOID*)&pCmdTarget);
      if (SUCCEEDED(hr))
      {
         IServiceProvider* pSP;
         hr = pCmdTarget->QueryInterface(IID_IServiceProvider, (LPVOID*)&pSP);

         pCmdTarget->Release();

         if (SUCCEEDED(hr))
         {
            if (s_pFrameWB)
            {
               s_pFrameWB->Release();
               s_pFrameWB = NULL;
            }

            hr = pSP->QueryService(SID_SWebBrowserApp, IID_IWebBrowser2, (LPVOID*)&s_pFrameWB);
            _ASSERT(s_pFrameWB);

            pSP->Release();
         }
      }

}
      return S_OK;
}




STDMETHODIMP CCHTM::GetSite(REFIID riid, void **ppvSite)
{
	*ppvSite = NULL;
		if(_pSite)
		 return _pSite->QueryInterface(riid,ppvSite);

	 return E_FAIL;

}

STDMETHODIMP CCHTM::GetBandInfo(DWORD dwBandID, DWORD dwViewMode,DESKBANDINFO* pdbi)
{
	if(pdbi)
	{
		m_dwBandID = dwBandID;
		m_dwViewMode = dwViewMode;

		if(pdbi->dwMask & DBIM_MINSIZE)
		{
			pdbi->ptMinSize.x = MIN_SIZE_X;
			pdbi->ptMinSize.y = MIN_SIZE_Y;
		}

		if(pdbi->dwMask & DBIM_MAXSIZE)
		{
			pdbi->ptMaxSize.x = -1;
			pdbi->ptMaxSize.y = -1;
		}

		if(pdbi->dwMask & DBIM_INTEGRAL)
		{
			pdbi->ptIntegral.x = 1;
			pdbi->ptIntegral.y = 1;
		}

		if(pdbi->dwMask & DBIM_ACTUAL)
		{
			pdbi->ptActual.x = 0;
			pdbi->ptActual.y = 0;
		}

		if(pdbi->dwMask & DBIM_TITLE)
		{
			lstrcpyW(pdbi->wszTitle,L"Morning Band");
		}

		if(pdbi->dwMask & DBIM_MODEFLAGS)
		{
			pdbi->dwModeFlags = DBIMF_VARIABLEHEIGHT;
			
		}

		if(pdbi->dwMask & DBIM_BKCOLOR)
		{
			pdbi->dwMask &= ~DBIM_BKCOLOR;
			
		}
		return S_OK;

	}
	return E_INVALIDARG;
}


STDMETHODIMP CCHTM::OnNav(IDispatch *pDisp, VARIANT varLnk)
{
	// TODO: Add your implementation code here

	return S_OK;
}
