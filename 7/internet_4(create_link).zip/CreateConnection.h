// CreateConnection.h : main header file for the CREATECONNECTION application
//

#if !defined(AFX_CREATECONNECTION_H__A975FC23_83D9_11D3_98E5_0080C82091EC__INCLUDED_)
#define AFX_CREATECONNECTION_H__A975FC23_83D9_11D3_98E5_0080C82091EC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CCreateConnectionApp:
// See CreateConnection.cpp for the implementation of this class
//

class CCreateConnectionApp : public CWinApp
{
public:
	CCreateConnectionApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCreateConnectionApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CCreateConnectionApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CREATECONNECTION_H__A975FC23_83D9_11D3_98E5_0080C82091EC__INCLUDED_)
