//
// RAS Abstraction Layer
//
// This class contains all the phone entry managment and dialup functions
//
//
//

#include "stdafx.h"
#include "rasabslay.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//
//	Inits an RASIPADDR struc
//
inline void InitRASIP (RASIPADDR& rasIP)
{
		rasIP.a	=0;
		rasIP.b =0;
		rasIP.c =0;
		rasIP.d =0;
}


/////////////////////////////////////////////////////////////////////////////
// CRasAbsLay

CRasAbsLay::CRasAbsLay()
{
}

CRasAbsLay::~CRasAbsLay()
{
}


//
//	Creates a PhoneBook Entry in the diaulp network
//
BOOL CRasAbsLay::CreatePhoneBookEntry(CString& strName,		
								CString&	strPhoneNumber,	
								CString&	strUserName,	
								CString&	strUserPassword,
								CString&	strDNS1,
								CString&	strDNS2,
								CString&	strDevType,
								CString&	strDevName)									
{

	
	RASENTRY	rasEntry;
	CRas		rasObj;
		
	if (rasObj.RasValidateEntryName(NULL, strName)!=ERROR_SUCCESS)
	{
		TRACE ("RasValidateEntryName cannot validate name %s\n", strName);	
		
	}
	
	// Num values
	rasEntry.dwSize				= sizeof (RASENTRY);
	rasEntry.dwfOptions			= RASEO_RemoteDefaultGateway | RASEO_SpecificNameServers;
	rasEntry.dwAlternateOffset	= 0;
	rasEntry.dwCountryID		= 34;
	rasEntry.dwCountryCode		= 34;
	rasEntry.dwFrameSize		= 0;
	rasEntry.dwFrameSize		= 0;
	rasEntry.dwfNetProtocols	= RASNP_Ip;		// TCP/IP
	rasEntry.dwFramingProtocol	= RASFP_Ppp;	//PPP
	rasEntry.dwChannels			= 0;
	rasEntry.dwReserved1		= 0;
	rasEntry.dwReserved2		= 0;

	// Strings
	strcpy (rasEntry.szAreaCode, " ");
	strcpy (rasEntry.szLocalPhoneNumber, strPhoneNumber.GetBuffer(0));
	strcpy (rasEntry.szScript, "");
	strcpy (rasEntry.szAutodialDll, "");
	strcpy (rasEntry.szAutodialFunc, "");
	strcpy (rasEntry.szDeviceType, "");
	strcpy (rasEntry.szDeviceName, "");
	strcpy (rasEntry.szX25PadType, "");
	strcpy (rasEntry.szX25Address, "");
	strcpy (rasEntry.szX25Facilities, "");
	strcpy (rasEntry.szX25UserData, "");
	strcpy (rasEntry.szDeviceType, strDevType.GetBuffer(0));
	strcpy (rasEntry.szDeviceName, strDevName.GetBuffer(0));	
	
	// IP addresses
	InitRASIP (rasEntry.ipaddr);
	InitRASIP (rasEntry.ipaddrDns);
	InitRASIP (rasEntry.ipaddrDnsAlt);
	InitRASIP (rasEntry.ipaddrWins);
	InitRASIP (rasEntry.ipaddrWinsAlt);

	FromStringToIpAddr(strDNS1, rasEntry.ipaddrDns);
	FromStringToIpAddr(strDNS2, rasEntry.ipaddrDnsAlt);

	// Call RAS
	if (rasObj.RasSetEntryProperties (NULL, strName, &rasEntry, sizeof (RASENTRY), NULL, NULL))
	{
		TRACE ("RasSetEntryProperties failed %s\n", 	strName);
		return FALSE;
	}	
	
	
	RASDIALPARAMS	dialParm;
	DWORD			dwError;

	dialParm.dwSize = sizeof (RASDIALPARAMS);

	strcpy (dialParm.szEntryName,  strName.GetBuffer(0));
	strcpy (dialParm.szPhoneNumber, "");
	strcpy (dialParm.szCallbackNumber,"");
	strcpy (dialParm.szUserName, strUserName);
	strcpy (dialParm.szPassword, strUserPassword);
	strcpy (dialParm.szDomain, "");
	

	dwError = rasObj.RasSetEntryDialParams(NULL, &dialParm, FALSE);

	if (dwError)
	{
		TRACE ("RasSetEntryDialParams failed. You need DUN 1.2 or better.\n");
		
	}


	return TRUE;
	
}

//
// Enums all the RAS devices
//
BOOL CRasAbsLay::EnumDevices(CArray <RASDEVINFO, RASDEVINFO> &ArRasDevInfo)
{

	ArRasDevInfo.RemoveAll();

	
	DWORD			lpcb	=	0;
	DWORD			lpcDevices;	
	RASDEVINFO*		lpRasDevInfo;
	DWORD			nRet;                          
	CRas			rasObj;

	rasObj.RasEnumDevices(NULL, &lpcb, &lpcDevices);
	
	lpRasDevInfo = (LPRASDEVINFO) GlobalAlloc(GPTR, lpcb);
	lpRasDevInfo->dwSize = sizeof(RASDEVINFO);

	nRet = rasObj.RasEnumDevices(lpRasDevInfo, &lpcb, &lpcDevices);
	if (nRet != 0)
	{
		TRACE ("No Dial-up devices\n");		
		return FALSE;	
	}
	else
	{	
		for (DWORD i=0; i < lpcDevices; i++)
		{
			RASDEVINFO	rasdevinfo;

			strcpy (rasdevinfo.szDeviceName, lpRasDevInfo->szDeviceName);
			strcpy (rasdevinfo.szDeviceType, lpRasDevInfo->szDeviceType);

			ArRasDevInfo.Add(rasdevinfo);
			lpRasDevInfo++;
		}
	}

	return TRUE;

}

//
//
//
BOOL CRasAbsLay::FromStringToIpAddr(CString str, RASIPADDR &rasIP)
{
	CString		s;
	int			nPos;
	int			n;
	int			nWhich = 1;

	while (1)
	{
		nPos = str.Find(".");

		if (nPos==-1)
			s = str;
		else
			s = str.Left(nPos);

		n = atoi(s);
		str = str.Right(str.GetLength()-(nPos+1));

		switch (nWhich)
		{
		case 1:
			rasIP.a = (BYTE)n;
			break;
		case 2:
			rasIP.b = (BYTE)n;
			break;
		case 3:
			rasIP.c = (BYTE)n;
			break;
		case 4:
			rasIP.d = (BYTE)n;
			break;
		default:
			ASSERT (FALSE);
			break;
		}

		nWhich++;

		if (nPos==-1)
			break;
	} 

	return 0;
}




//
// RAS object
//


typedef DWORD (CALLBACK* RASSETENTRYDIALPARAMSPROC)(LPCTSTR lpszPhonebook,  LPRASDIALPARAMS lprasdialparams,                         
			BOOL fRemovePassword);

typedef DWORD (CALLBACK* RASSETENTRYPROPERTIESPROC)(LPCTSTR lpszPhonebook,   LPCTSTR lpszEntry,   LPRASENTRY lpRasEntry,
	DWORD dwEntryInfoSize, LPBYTE lpbDeviceInfo,   DWORD dwDeviceInfoSize);

typedef DWORD (CALLBACK* RASVALIDATEENTRYNAMEPROC)(LPCTSTR lpszPhonebook, LPCTSTR lpszEntry);

typedef DWORD (CALLBACK* RASENUMDEVICESPROC)(LPRASDEVINFO lpRasDevInfo,  LPDWORD lpcb, LPDWORD lpcDevices);

//
//
//
DWORD CRas::RasSetEntryDialParams(LPCTSTR lpszPhonebook,  LPRASDIALPARAMS lprasdialparams,                         
			BOOL fRemovePassword)
{
	RASSETENTRYDIALPARAMSPROC	proc;

	proc = (RASSETENTRYDIALPARAMSPROC)GetProcAddress(m_hRasLib, TEXT("RasSetEntryDialParamsA"));

	if (!proc)
		return 0;
	
	return (*proc)(lpszPhonebook, lprasdialparams, fRemovePassword);

}

DWORD CRas::RasSetEntryProperties(LPCTSTR lpszPhonebook,   LPCTSTR lpszEntry,   LPRASENTRY lpRasEntry,
	DWORD dwEntryInfoSize, LPBYTE lpbDeviceInfo,   DWORD dwDeviceInfoSize)
{

	RASSETENTRYPROPERTIESPROC	proc;

	proc = (RASSETENTRYPROPERTIESPROC)GetProcAddress(m_hRasLib, TEXT("RasSetEntryPropertiesA"));

	if (!proc)
		return 1;
	
	return (*proc)(lpszPhonebook, lpszEntry, lpRasEntry, dwEntryInfoSize, 
		lpbDeviceInfo,  dwDeviceInfoSize);
}

DWORD CRas::RasValidateEntryName(LPCTSTR lpszPhonebook, LPCTSTR lpszEntry)
{		
	RASVALIDATEENTRYNAMEPROC	proc;

	proc = (RASVALIDATEENTRYNAMEPROC )GetProcAddress(m_hRasLib, TEXT("RasValidateEntryNameA"));

	if (!proc)	
		return 1;
	
	
	return (*proc)(lpszPhonebook, lpszEntry);
}


DWORD CRas::RasEnumDevices(LPRASDEVINFO lpRasDevInfo,  LPDWORD lpcb, LPDWORD lpcDevices)
{
	RASENUMDEVICESPROC	proc;

	if (!m_hRasLib)
		return 1;
			  
	proc = (RASENUMDEVICESPROC)GetProcAddress(m_hRasLib, TEXT("RasEnumDevicesA"));	

	if (!proc)
		return 1;

	return (*proc)(lpRasDevInfo,  lpcb, lpcDevices);

}

CRas::CRas()
{
	LoadLibrary();
}

CRas::~CRas()
{
	ReleaseLibrary();
}


BOOL	CRas::LoadLibrary()
{
	m_hRasLib = ::LoadLibrary(TEXT("rasapi32.dll"));

	return TRUE;

}

BOOL	CRas::ReleaseLibrary()
{

	if (m_hRasLib)
		FreeLibrary(m_hRasLib);

	return TRUE;
}


