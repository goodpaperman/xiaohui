// CreateConnectionDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CreateConnection.h"
#include "CreateConnectionDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCreateConnectionDlg dialog

CCreateConnectionDlg::CCreateConnectionDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCreateConnectionDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCreateConnectionDlg)
	m_strDNS1 = _T("212.78.128.11");
	m_strDNS2 = _T("212.78.128.12");
	m_strID = _T("");
	m_strPass = _T("");
	m_strPassCheck = _T("");
	m_strPhone = _T("");
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CCreateConnectionDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCreateConnectionDlg)
	DDX_Control(pDX, IDC_ADAPTERSLIST, m_AdapterCtrl);
	DDX_Text(pDX, IDC_DNS1, m_strDNS1);
	DDX_Text(pDX, IDC_DNS2, m_strDNS2);
	DDX_Text(pDX, IDC_ID, m_strID);
	DDX_Text(pDX, IDC_PASSWORD, m_strPass);
	DDX_Text(pDX, IDC_PASSWORDCOMP, m_strPassCheck);
	DDX_Text(pDX, IDC_PHONE, m_strPhone);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CCreateConnectionDlg, CDialog)
	//{{AFX_MSG_MAP(CCreateConnectionDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_CREATE, OnCreateConnection)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCreateConnectionDlg message handlers

BOOL CCreateConnectionDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	CRas	ras;

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	m_ras.EnumDevices(m_ArRasDevInfo);

	int nItem;
	for (int n=0; n<m_ArRasDevInfo.GetSize(); n++)
	{	
		nItem = m_AdapterCtrl.AddString (m_ArRasDevInfo[n].szDeviceName);
		m_AdapterCtrl.SetItemData (nItem, n);
	}		

	m_AdapterCtrl.SetCurSel(0);

	if (!ras.m_hRasLib) // No ras installed
		GetDlgItem(IDC_CREATE)->EnableWindow(FALSE);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CCreateConnectionDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CCreateConnectionDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

//
// Create the Dialup entry
//
void CCreateConnectionDlg::OnCreateConnection() 
{

	CString	strConnection;
	CString	strDevType;
	CString	strDevName;
	int		nCur;
	int		nData;

	UpdateData(TRUE);

	if (m_strPass!=m_strPassCheck)
	{
		AfxMessageBox ("The password does not match with the verification password");
		return;
	}

	strConnection = "OurConnection";

	nCur	= m_AdapterCtrl.GetCurSel();
	nData	= m_AdapterCtrl.GetItemData(nCur);

	if ((nCur!=CB_ERR) && (nData!=-1))
	{
		strDevType	= m_ArRasDevInfo[nData].szDeviceType;
		strDevName	= m_ArRasDevInfo[nData].szDeviceName;		
	}
	else
	{
		return;
	}

	
	//
	//	Creates the connectiond
	//
	if (!m_ras.CreatePhoneBookEntry(strConnection,	
								m_strPhone,
								m_strID,
								m_strPass,
								m_strDNS1,
								m_strDNS2,
								strDevType,
								strDevName))
	{
		AfxMessageBox("Unable to create connection");		
	}
	else
	{
		AfxMessageBox("Connection created");		
	}

	SendMessage(WM_CLOSE, NULL,NULL);

}
