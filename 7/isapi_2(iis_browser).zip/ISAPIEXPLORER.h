#if !defined(AFX_ISAPIEXPLORER_H__AAFEC15B_FB13_11D3_967E_0080C894582C__INCLUDED_)
#define AFX_ISAPIEXPLORER_H__AAFEC15B_FB13_11D3_967E_0080C894582C__INCLUDED_

// ISAPIEXPLORER.H - Header file for your Internet Server
//    IsapiExplorer Extension

#include "resource.h"
#include <io.h>
class CIsapiExplorerExtension : public CHttpServer
{	
CString m_sFiles;
public:
	CString GetDriveIcon(int iType);
	CString GetDriveTypeString(int iType);
	void WriteDrives(CHttpServerContext *pCtxt);
	CString m_sPath;
	void WriteFileLine(CHttpServerContext *pCtxt, _finddata_t &fd);
	void WriteTable(CHttpServerContext *pCtxt);
	void WritePath(CHttpServerContext *pCtxt, CString sPath, int iDepth=0);
	CIsapiExplorerExtension();
	~CIsapiExplorerExtension();

// Overrides
	// ClassWizard generated virtual function overrides
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//{{AFX_VIRTUAL(CIsapiExplorerExtension)
	public:
	virtual BOOL GetExtensionVersion(HSE_VERSION_INFO* pVer);
	virtual void WriteTitle(CHttpServerContext* pCtxt) const;
	virtual void EndContent(CHttpServerContext* pCtxt) const;
	//}}AFX_VIRTUAL
	virtual BOOL TerminateExtension(DWORD dwFlags);

	// TODO: Add handlers for your commands here.
	// For example:

	void Default(CHttpServerContext* pCtxt);
	void View(CHttpServerContext* pCtxt, LPTSTR sPath);

	DECLARE_PARSE_MAP()

	//{{AFX_MSG(CIsapiExplorerExtension)
	//}}AFX_MSG
};


//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ISAPIEXPLORER_H__AAFEC15B_FB13_11D3_967E_0080C894582C__INCLUDED)
