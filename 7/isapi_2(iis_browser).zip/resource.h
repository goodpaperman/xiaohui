//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by IsapiExplorer.rc
//
#define IDS_SERVER                      102
#define IDS_HEADERCOLOR                 105
#define IDS_IMAGE_DIR                   106
#define IDS_IMAGE_ANY                   107
#define IDS_IMAGE_BMP                   108
#define IDS_IMAGE_BAT                   109
#define IDS_IMAGE_EXE                   110
#define IDS_IMAGE_INI                   111
#define IDS_IMAGE_SYS                   112
#define IDS_IMAGE_TXT                   113
#define IDS_IMAGE_AVI                   114
#define IDS_IMAGE_TMP                   115
#define IDS_IMAGE_WRI                   116
#define IDS_IMAGE_PIF                   117
#define IDS_IMAGE_MID                   118
#define IDS_IMAGE_WAV                   119
#define IDS_IMAGE_FRM                   120
#define IDS_IMAGE_VBP                   121
#define IDS_IMAGE_HLP                   122
#define IDS_IMAGE_ZIP                   123
#define IDS_IMAGE_LOG                   124
#define IDS_IMAGE_DOC                   125
#define IDS_IMAGE_HTM                   126
#define IDS_IMAGE_XLS                   127
#define IDS_IMAGE_TLB                   128
#define IDS_IMAGE_INS                   129
#define IDS_IMAGE_CNF                   130
#define IDS_IMAGE_PDF                   131
#define IDS_IMAGE_FDF                   132
#define IDS_IMAGE_CAT                   133
#define IDS_IMAGE_H                     134
#define IDS_IMAGE_C                     135
#define IDS_IMAGE_CPP                   136
#define IDS_IMAGE_MSC                   137
#define IDS_IMAGE_URL                   138
#define IDS_IMAGE_AKTENKOFFER           139
#define IDS_IMAGE_SCR                   140
#define IDS_IMAGE_CDR                   141
#define IDS_IMAGE_MDB                   142
#define IDS_IMAGE_PPT                   143
#define IDS_IMAGE_RAM                   144
#define IDS_IMAGE_LNK                   145
#define IDS_IMAGE_BAS                   146
#define IDS_IMAGE_WAB                   147
#define IDS_LINKCOLOR                   148
#define IDS_TEXTCOLOR                   149
#define IDS_VISITEDCOLOR                150
#define IDS_ACTIVECOLOR                 151
#define IDS_TABBGCOLOR                  152
#define IDS_HIDDENCOLOR                 153
#define IDS_DRIVE_FIXED                 154
#define IDS_DRIVE_NV                    155
#define IDS_DRIVE_NOROOT                156
#define IDS_DRIVE_REMOVABLE             157
#define IDS_DRIVE_REMOTE                158
#define IDS_DRIVE_CDROM                 159
#define IDS_DRIVE_RAMDISK               160
#define IDS_DRIVE_UNKNOWN               161

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         103
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
