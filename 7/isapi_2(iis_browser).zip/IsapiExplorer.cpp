// ISAPIEXPLORER.CPP - Implementation file for your Internet Server
//    IsapiExplorer Extension

#include "stdafx.h"
#include "IsapiExplorer.h"
#include <wchar.h>
#include <direct.h>

///////////////////////////////////////////////////////////////////////
// The one and only CWinApp object
// NOTE: You may remove this object if you alter your project to no
// longer use MFC in a DLL.

CWinApp theApp;

///////////////////////////////////////////////////////////////////////
// command-parsing map

BEGIN_PARSE_MAP(CIsapiExplorerExtension, CHttpServer)
	// TODO: insert your ON_PARSE_COMMAND() and 
	// ON_PARSE_COMMAND_PARAMS() here to hook up your commands.
	// For example:

	ON_PARSE_COMMAND(Default, CIsapiExplorerExtension, ITS_EMPTY)
	DEFAULT_PARSE_COMMAND(Default, CIsapiExplorerExtension)
	ON_PARSE_COMMAND(View, CIsapiExplorerExtension, ITS_PSTR)
	ON_PARSE_COMMAND_PARAMS("path=''")
	
	
END_PARSE_MAP(CIsapiExplorerExtension)


///////////////////////////////////////////////////////////////////////
// The one and only CIsapiExplorerExtension object

CIsapiExplorerExtension theExtension;


///////////////////////////////////////////////////////////////////////
// CIsapiExplorerExtension implementation

CIsapiExplorerExtension::CIsapiExplorerExtension()
{
}

CIsapiExplorerExtension::~CIsapiExplorerExtension()
{
}

BOOL CIsapiExplorerExtension::GetExtensionVersion(HSE_VERSION_INFO* pVer)
{
	// Call default implementation for initialization
	CHttpServer::GetExtensionVersion(pVer);

	// Load description string
	TCHAR sz[HSE_MAX_EXT_DLL_NAME_LEN+1];
	ISAPIVERIFY(::LoadString(AfxGetResourceHandle(),
			IDS_SERVER, sz, HSE_MAX_EXT_DLL_NAME_LEN));
	_tcscpy(pVer->lpszExtensionDesc, sz);
	return TRUE;
}

BOOL CIsapiExplorerExtension::TerminateExtension(DWORD dwFlags)
{
	// extension is being terminated
	//TODO: Clean up any per-instance resources
	return TRUE;
}

///////////////////////////////////////////////////////////////////////
// CIsapiExplorerExtension command handlers
void CIsapiExplorerExtension::View(CHttpServerContext* pCtxt, LPTSTR sPath)
{
	StartContent(pCtxt);
	WriteTitle(pCtxt);
	m_sPath = sPath;

	// Pfad anzeigen oder Arbeitsplatz?
	if(m_sPath.IsEmpty())
	{	m_sPath = "Arbeitsplatz";
		// Header
		*pCtxt << "Verzeichnisinhalt von ";
		*pCtxt << m_sPath;
		*pCtxt << "<br><br>";
		// Ausgeben
		WriteDrives(pCtxt);
	}
	else
	{
		// "\\" hinzuf�gen, falls nicht vorhanden
		if(m_sPath.ReverseFind('\\') != m_sPath.GetLength()-1)
		m_sPath += "\\";
		// Header
		*pCtxt << "Verzeichnisinhalt von ";
		*pCtxt << m_sPath;
		*pCtxt << "<br><br>";
		// Ausgeben
		WriteTable(pCtxt);
		WritePath(pCtxt, sPath);
	}

	EndContent(pCtxt);
}
void CIsapiExplorerExtension::Default(CHttpServerContext* pCtxt)
{
	View(pCtxt, "");
}

// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CIsapiExplorerExtension, CHttpServer)
	//{{AFX_MSG_MAP(CIsapiExplorerExtension)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0



///////////////////////////////////////////////////////////////////////
// If your extension will not use MFC, you'll need this code to make
// sure the extension objects can find the resource handle for the
// module.  If you convert your extension to not be dependent on MFC,
// remove the comments arounn the following AfxGetResourceHandle()
// and DllMain() functions, as well as the g_hInstance global.

/****

static HINSTANCE g_hInstance;

HINSTANCE AFXISAPI AfxGetResourceHandle()
{
	return g_hInstance;
}

BOOL WINAPI DllMain(HINSTANCE hInst, ULONG ulReason,
					LPVOID lpReserved)
{
	if (ulReason == DLL_PROCESS_ATTACH)
	{
		g_hInstance = hInst;
	}

	return TRUE;
}

****/

void CIsapiExplorerExtension::WritePath(CHttpServerContext *pCtxt, CString sPath, int iDepth)
{
	_finddata_t fd;
	CString sFind = sPath + "\\*.*";
	long Handle=_findfirst(sFind, &fd);
	
	// Pfad durchsuchen
	CString sTarget;
	do
	{	WriteFileLine(pCtxt, fd);
	}while(_findnext(Handle, &fd) == 0);
	// Dateien ausgeben
	*pCtxt << m_sFiles;
}

void CIsapiExplorerExtension::WriteTitle(CHttpServerContext* pCtxt) const
{

	CString sLink, sText, sActive, sVisited, sBody;
	// Laden
	sLink.LoadString(IDS_LINKCOLOR);
	sText.LoadString(IDS_TEXTCOLOR);
	sActive.LoadString(IDS_ACTIVECOLOR);
	sVisited.LoadString(IDS_VISITEDCOLOR);
	// Formatieren
	sBody.Format("<body bgcolor=white text=%s link=%s vlink=%s alink=%s>\n", sText, sLink, sVisited, sActive);
	// Ausgeben
	*pCtxt << "<html><head><title>Isapi Explorer</title>\n";
	*pCtxt << "<style type=\"text/css\">\n";
	*pCtxt << "<!--\n";
	*pCtxt << "A:link {text-decoration: none;} A:visited {text-decoration: none} A:active {text-decoration: none}\n";
	*pCtxt << "-->\n";
	*pCtxt << "</style></head>\n";
	*pCtxt << sBody;
	
	//CHttpServer::WriteTitle(pCtxt);
}

void CIsapiExplorerExtension::EndContent(CHttpServerContext* pCtxt) const
{
	*pCtxt << "</table></html>\n";
}

void CIsapiExplorerExtension::WriteTable(CHttpServerContext *pCtxt)
{
	CString sRgb;
	CString s;
	sRgb.LoadString(IDS_HEADERCOLOR);
	*pCtxt << "<font face=\"Arial\" size=2><br>\n";
	*pCtxt << "<table width=600 border=0 cellpadding=0 cellspacing=1>\n";
	s.Format("<tr><td width=300 bgcolor=%s border=0><font face=\"Arial\" size=2>Name</td><td bgcolor=%s width=100 border=1 align=right><font face=\"Arial\" size=2>Gr��e</td><td bgcolor=%s width=100 border=1><font face=\"Arial\" size=2>Ge�ndert am</td><td bgcolor=%s border=1 align=center colspan=5><font face=\"Arial\" width=100 size=2>Attribute</td></tr>\n", sRgb, sRgb, sRgb, sRgb, sRgb, sRgb, sRgb);
	*pCtxt << s;
}

void CIsapiExplorerExtension::WriteFileLine(CHttpServerContext *pCtxt, _finddata_t &fd)
{
	CString s, sImage, sExt="*", sName, sLink, sRgb, sColor, sHidden, sChange;
	
	// Farbe laden
	sRgb.LoadString(IDS_TABBGCOLOR);
	sName = fd.name;
	// Farbe bestimmen
	if(fd.attrib&_A_HIDDEN)
	{	sHidden.LoadString(IDS_HIDDENCOLOR);
		sColor.Format(" color=%s", sHidden);
	}
	// Icon bestimmen
	if(fd.attrib&_A_SUBDIR)
	{	sImage.LoadString(IDS_IMAGE_DIR);
		// Link erstellen
		if(sName == ".")
			sLink = sName;
		else if(sName == "..")
		{	// Letzten Pfad wegschneiden
			CString sDir = m_sPath.Left(m_sPath.ReverseFind('\\'));
			sDir = sDir.Left(sDir.ReverseFind('\\'));
			sLink.Format("<a href=\"IsapiExplorer.dll?View&path=%s\">%s</a><br>\n", sDir, fd.name);
		}
		else
		{	sLink.Format("<a href=\"IsapiExplorer.dll?View&path=%s%s\">%s</a><br>\n", m_sPath, fd.name, fd.name);
			if(sName=="Aktenkoffer")
				sImage.LoadString(IDS_IMAGE_AKTENKOFFER);
		}
	}
	else
	{	sLink = sName;
		// Erweiterung eruieren
		if(sName.Find(".") != -1)
			sExt = sName.Right(sName.GetLength()-sName.ReverseFind('.') - 1);
		// Zuweisen
		sExt.MakeLower();
		if(sExt=="bmp"||sExt=="jpg"||sExt=="gif"||sExt=="tif"||sExt=="pcx")
			sImage.LoadString(IDS_IMAGE_BMP);
		else if(sExt=="z"||sExt=="zip"||sExt=="arj"||sExt=="cab"||sExt=="rar"||sExt=="lha")
			sImage.LoadString(IDS_IMAGE_ZIP);
		else if(sExt=="bat"||sExt=="cmd")
			sImage.LoadString(IDS_IMAGE_BAT);
		else if(sExt=="exe"||sExt=="com")
			sImage.LoadString(IDS_IMAGE_EXE);
		else if(sExt=="ini"||sExt=="inf")
			sImage.LoadString(IDS_IMAGE_INI);
		else if(sExt=="sys"||sExt=="dll"||sExt=="cpl"||sExt=="drv"||sExt=="pnf")
			sImage.LoadString(IDS_IMAGE_SYS);
		else if(sExt=="pif")
			sImage.LoadString(IDS_IMAGE_PIF);
		else if(sExt=="wab")
			sImage.LoadString(IDS_IMAGE_WAB);
		else if(sExt=="lnk")
			sImage.LoadString(IDS_IMAGE_LNK);
		else if(sExt=="scr")
			sImage.LoadString(IDS_IMAGE_SCR);
		else if(sExt=="bas")
			sImage.LoadString(IDS_IMAGE_BAS);
		else if(sExt=="cnf")
			sImage.LoadString(IDS_IMAGE_CNF);
		else if(sExt=="mdb")
			sImage.LoadString(IDS_IMAGE_MDB);
		else if(sExt=="avi")
			sImage.LoadString(IDS_IMAGE_AVI);
		else if(sExt=="frm")
			sImage.LoadString(IDS_IMAGE_FRM);
		else if(sExt=="cdr"||sExt=="wpg")
			sImage.LoadString(IDS_IMAGE_CDR);
		else if(sExt=="pdf")
			sImage.LoadString(IDS_IMAGE_PDF);
		else if(sExt=="fdf")
			sImage.LoadString(IDS_IMAGE_FDF);
		else if(sExt=="vbp")
			sImage.LoadString(IDS_IMAGE_VBP);
		else if(sExt=="htm")
			sImage.LoadString(IDS_IMAGE_HTM);
		else if(sExt=="xls")
			sImage.LoadString(IDS_IMAGE_XLS);
		else if(sExt=="ppt")
			sImage.LoadString(IDS_IMAGE_PPT);
		else if(sExt=="ins")
			sImage.LoadString(IDS_IMAGE_INS);
		else if(sExt=="tlb")
			sImage.LoadString(IDS_IMAGE_TLB);
		else if(sExt=="hlp")
			sImage.LoadString(IDS_IMAGE_HLP);
		else if(sExt=="h")
			sImage.LoadString(IDS_IMAGE_H);
		else if(sExt=="c")
			sImage.LoadString(IDS_IMAGE_C);
		else if(sExt=="cpp")
			sImage.LoadString(IDS_IMAGE_CPP);
		else if(sExt=="msc")
			sImage.LoadString(IDS_IMAGE_MSC);
		else if(sExt=="ram")
			sImage.LoadString(IDS_IMAGE_RAM);
		else if(sExt=="mid"||sExt=="rmi")
			sImage.LoadString(IDS_IMAGE_MID);
		else if(sExt=="wav"||sExt=="aud")
			sImage.LoadString(IDS_IMAGE_WAV);
		else if(sExt=="tmp"||sExt=="dat"||sExt=="msg")
			sImage.LoadString(IDS_IMAGE_TMP);
		else if(sExt=="wri")
			sImage.LoadString(IDS_IMAGE_WRI);
		else if(sExt=="txt")
			sImage.LoadString(IDS_IMAGE_TXT);
		else if(sExt=="url")
			sImage.LoadString(IDS_IMAGE_URL);
		else if(sExt=="doc")
			sImage.LoadString(IDS_IMAGE_DOC);
		else if(sExt=="log"||sExt=="nfo"||sExt=="1st"||sExt=="sql")
			sImage.LoadString(IDS_IMAGE_LOG);
		else
			sImage.LoadString(IDS_IMAGE_ANY);
	}
	// ZEILE ERSTELLEN
	CTime tTime(fd.time_write);
	sChange.Format("%02d.%02d.%02d %02d:%02d", tTime.GetDay(), tTime.GetMonth(), (tTime.GetYear()) % 100, tTime.GetHour(), tTime.GetMinute());
	s.Format("<tr><td valign=center bgcolor=%s> %s <font%s size=2>%s</td><td bgcolor=%s align=right><font size=2>%d</td><td bgcolor=%s align=center><font size=2>%s</td><td align=center bgcolor=%s><font size=2>%s</td><td align=center bgcolor=%s><font size=2>%s</td><td align=center bgcolor=%s><font size=2>%s</td><td align=center bgcolor=%s><font size=2>%s</td><td align=center bgcolor=%s><font size=2>%s</td></tr>\n", sRgb, sImage, sColor, sLink, sRgb, fd.size, sRgb, sChange, sRgb, (fd.attrib&_A_ARCH)?"A":"&nbsp;", sRgb, (fd.attrib&_A_HIDDEN)?"H":"&nbsp;", sRgb, (fd.attrib&_A_RDONLY)?"R":"&nbsp;", sRgb, (fd.attrib&_A_SYSTEM)?"S":"&nbsp;", sRgb, (fd.attrib&_A_SUBDIR)?"D":"&nbsp;");
	// Verzeichnisse von Dateien trennen
	if(fd.attrib&_A_SUBDIR)
		*pCtxt << s;
	else
		m_sFiles += s;
}

void CIsapiExplorerExtension::WriteDrives(CHttpServerContext *pCtxt)
{
	DWORD dDrives=GetLogicalDrives();
	CString s, sRgb, sLink;
	// Header ausgeben
	sRgb.LoadString(IDS_HEADERCOLOR);
	*pCtxt << "<font face=\"Arial\" size=2><br>\n";
	*pCtxt << "<table width=600 border=0 cellpadding=0 cellspacing=1>\n";
	s.Format("<tr><td width=150 bgcolor=%s border=0><font face=\"Arial\" size=2>Name</td><td bgcolor=%s width=300 border=1><font face=\"Arial\" size=2>Typ</td><td width=150 bgcolor=%s border=0><font face=\"Arial\" size=2>Dateisystem</td></tr>\n", sRgb, sRgb, sRgb);
	*pCtxt << s;
	// Farbe laden
	sRgb.LoadString(IDS_TABBGCOLOR);

	// Laufwerke ausgeben
	for(int i=0, iBit=1; i < 24; i++, iBit*=2)
	{	// Vorhanden?
		if(dDrives&iBit)
		{	CString sRoot, sDriveTitle, sFileSystem;
			DWORD dSerial, dMaxPath, dFlags;
			sRoot.Format("%c:\\", 'a'+i);
			// Informationen lesen
			int iType=GetDriveType(sRoot);
			// Auswerten
			CString sType=GetDriveTypeString(iType);
			// Icon eruieren
			CString sImage=GetDriveIcon(iType);
			// Titel eruieren
			GetVolumeInformation(sRoot, sDriveTitle.GetBuffer(256), 256, &dSerial, &dMaxPath, &dFlags, sFileSystem.GetBuffer(256), 256);
			sDriveTitle.ReleaseBuffer();
			sFileSystem.ReleaseBuffer();
			if(sFileSystem.IsEmpty())
				sFileSystem = "(kein Medium eingelegt)";
			// Link erstellen
			sLink.Format("<a href=\"IsapiExplorer.dll?View&path=%c:\\\">%s (%c:)</a><br>\n", 'a'+i, sDriveTitle, 'A'+i);
			// ZEILE ERZEUGEN
			s.Format("<tr><td valign=center bgcolor=%s> %s <font size=2>%s</td><td bgcolor=%s><font size=2>%s</td><td bgcolor=%s><font size=2>%s</td></tr>\n", sRgb, sImage, sLink, sRgb, sType, sRgb, sFileSystem);
			*pCtxt << s;
		}
	}
}

CString CIsapiExplorerExtension::GetDriveTypeString(int iType)
{
	if(iType == DRIVE_UNKNOWN)
		return "unbekannt";
	if(iType == DRIVE_NO_ROOT_DIR)
		return "nicht vorhanden";
	if(iType == DRIVE_REMOVABLE)
		return "auswechselbarer Datentr�ger";
	if(iType == DRIVE_FIXED)
		return "Lokales Laufwerk";
	if(iType == DRIVE_REMOTE)
		return "Netzwerkverbindung";
	if(iType == DRIVE_CDROM)
		return "CD-ROM-Laufwerk";
	if(iType == DRIVE_RAMDISK)
		return "RamDisk";
	return "n/v";
}

CString CIsapiExplorerExtension::GetDriveIcon(int iType)
{	CString sIcon;
	sIcon.LoadString(IDS_DRIVE_UNKNOWN);
	if(iType == DRIVE_UNKNOWN)
		sIcon.LoadString(IDS_DRIVE_UNKNOWN);
	if(iType == DRIVE_NO_ROOT_DIR)
		sIcon.LoadString(IDS_DRIVE_NOROOT);
	if(iType == DRIVE_REMOVABLE)
		sIcon.LoadString(IDS_DRIVE_REMOVABLE);
	if(iType == DRIVE_FIXED)
		sIcon.LoadString(IDS_DRIVE_FIXED);
	if(iType == DRIVE_REMOTE)
		sIcon.LoadString(IDS_DRIVE_REMOTE);
	if(iType == DRIVE_CDROM)
		sIcon.LoadString(IDS_DRIVE_CDROM);
	if(iType == DRIVE_RAMDISK)
		sIcon.LoadString(IDS_DRIVE_RAMDISK);
	return sIcon;
}
