#if !defined(AFX_PAGEYOU_H__5ABF0C07_7631_11D1_82BF_444553540000__INCLUDED_)
#define AFX_PAGEYOU_H__5ABF0C07_7631_11D1_82BF_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// PageYou.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPageYou dialog

class CPageYou : public CPropertyPage
{
	DECLARE_DYNCREATE(CPageYou)

// Construction
public:
	CPageYou();
	~CPageYou();

// Dialog Data
	//{{AFX_DATA(CPageYou)
	enum { IDD = IDD_PAGE_YOU };
	CEdit	m_IPName;
	CEdit	m_IP;
	CButton	m_WithAddress;
	CButton	m_WithDate;
	CEdit	m_Date;
	CEdit	m_SourceFile2;
	CEdit	m_SourceFile1;
	CButton	m_OfflineOnEnd;
	CButton	m_OnlineOnStart;
	CString	m_sServerName;
	CString	m_sDestination;
	CString	m_sDestinationDir;
	CString	m_sPassword;
	CString	m_sUserName;
	CString	m_sSourceFile1;
	CString	m_sSourceFile2;
	CString	m_sIP;
	CString	m_sIPName;
	CString	m_sDate;
	CString	m_sTagDate;
	CString	m_sTagMachine;
	//}}AFX_DATA

  void SaveSettings();

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPageYou)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
public:
	// Generated message map functions
	//{{AFX_MSG(CPageYou)
	virtual BOOL OnInitDialog();
	afx_msg void OnOnline();
	afx_msg void OnOffline();
	afx_msg void OnBrowseOff();
	afx_msg void OnBrowseOn();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PAGEYOU_H__5ABF0C07_7631_11D1_82BF_444553540000__INCLUDED_)
