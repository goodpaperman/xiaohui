// NetManagerDlg.h : header file
//

#if !defined(AFX_NETMANAGERDLG_H__7EBE5928_69C6_11D1_82BF_444553540000__INCLUDED_)
#define AFX_NETMANAGERDLG_H__7EBE5928_69C6_11D1_82BF_444553540000__INCLUDED_

#include "PageGeneral.h"
#include "PageFiles.h"
#include "PageYou.h"
#include "PageNet.h"
#include "PagePeople.h"
#include "PageMail.h"
#include "OutputWnd.h"
#include "InfoWnd.h"
#include "StatusBar.h"
#include "TabCtrlEx.h"

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////

#define   DLG_MIN_WIDTH          350
#define   DLG_MAX_WIDTH          1000

/////////////////////////////////////////////////////////////////////////////
// CNetManagerDlg dialog

class CNetManagerDlg : public CDialog
{
// Construction
public:
	CNetManagerDlg(CWnd* pParent = NULL);	// standard constructor

	const UINT FAR*	m_lpaIDStatusBar;
	int				m_cIDStatusBar;
	CDlgStatusBar  	m_StatusBar;  
  CToolTipCtrl m_ToolTip;

  COutputWnd m_Output;
  COutputWnd m_History;
  CInfoWnd   m_InfoWindow;

  CTabCtrlEx m_OutputTabCtrl;

  int m_nDlgHeight;
  int m_nDlgClientHeight;
  int m_nDlgDefaultWidth;
  void ResizeWindows();

  bool  m_bDlgCreated;
  bool  m_bStarted;
  CEdit*    m_pOutput;

  CFont*    m_pHistoryFont;
  CFont*    m_pOutputFont;
  int       m_nHistoryFontSize;
  int       m_nOutputFontSize;
  CString   m_sHistoryFontFace;
  CString   m_sOutputFontFace;

  HICON m_BlinkIcon;
  bool  m_BlinkState;

  CPropertySheet*   m_dlgPropSheet;
  CPageGeneral*     m_pPageGeneral;
  CPageFiles*       m_pPageFiles;
  CPageYou*         m_pPageYou;
  CPageNet*         m_pPageNet;
  CPagePeople*      m_pPagePeople;
  CPageMail*        m_pPageMail;

  CString m_sIniFilePath;
  void SaveSettings();
  void GoToHelp();
  void ShowOutput();
  void HideOutput();
  void IniToStringArray(LPCTSTR, LPCTSTR, CStringArray*);
  void SaveArrayToIni(LPCTSTR, CStringArray*);

  void DrawLogoText();
  void SetPaneText(UINT nID = 0);

// Dialog Data
	//{{AFX_DATA(CNetManagerDlg)
	enum { IDD = IDD_NETMANAGER_DIALOG };
	CTreeCtrl	m_InfoTree;
	CAnimateCtrl	m_AnimateWait;
	CAnimateCtrl	m_AnimateNet;
	CAnimateCtrl	m_AnimatePeople;
	CButton	m_ClearOutput;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNetManagerDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

//protected:
public:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CNetManagerDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnCancel();
	afx_msg void OnShowOutput();
	afx_msg void OnClearOutput();
	afx_msg void OnStart();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnEnd();
	afx_msg BOOL OnHelpInfo(HELPINFO* pHelpInfo);
	afx_msg void OnChangeOutput();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI);
	afx_msg void OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized);
	afx_msg void OnSelchangeTabctrlOutput(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnChangeHistory();
	afx_msg void OnSelchangedInfotree(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnSettingChange(UINT uFlags, LPCTSTR lpszSection);
	afx_msg void OnMenuSelect(UINT nItemID, UINT nFlags, HMENU hSysMenu);
	//}}AFX_MSG


	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NETMANAGERDLG_H__7EBE5928_69C6_11D1_82BF_444553540000__INCLUDED_)
