// PagePeopleList.cpp : implementation file
//

#include "stdafx.h"
#include "netmanager.h"
#include "PagePeople.h"
#include "PagePeopleList.h"
#include "GlobalsExtern.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPagePeopleList

CPagePeopleList::CPagePeopleList()
{
}

CPagePeopleList::~CPagePeopleList()
{
}


BEGIN_MESSAGE_MAP(CPagePeopleList, CTreeCtrl)
	//{{AFX_MSG_MAP(CPagePeopleList)
	ON_NOTIFY_REFLECT(TVN_BEGINLABELEDIT, OnBeginlabeledit)
	ON_NOTIFY_REFLECT(TVN_ENDLABELEDIT, OnEndlabeledit)
	ON_NOTIFY_REFLECT(TVN_SELCHANGED, OnSelchanged)
	ON_NOTIFY_REFLECT(TVN_KEYDOWN, OnKeydown)
	ON_COMMAND(IDM_PEOPLE_FINGER, OnPeopleFinger)
	ON_COMMAND(IDM_PEOPLE_REMOVE, OnPeopleRemove)
	ON_WM_CONTEXTMENU()
	ON_COMMAND(IDM_PEOPLE_RENAME, OnPeopleRename)
	ON_NOTIFY_REFLECT(NM_RCLICK, OnRclick)
	ON_COMMAND(IDM_PEOPLE_CHECKALL, OnPeopleCheckall)
	ON_COMMAND(IDM_PEOPLE_ACTIVE, OnPeopleActive)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPagePeopleList message handlers


void CPagePeopleList::OnBeginlabeledit(NMHDR* pNMHDR, LRESULT* pResult) 
{
	TV_DISPINFO* pTVDispInfo = (TV_DISPINFO*)pNMHDR;
  GetEditControl()->LimitText(40);

	*pResult = 0;
}

/////////////////////////////////////////////////////////////////////////////

void CPagePeopleList::OnEndlabeledit(NMHDR* pNMHDR, LRESULT* pResult) 
{
	TV_DISPINFO* pTVDispInfo = (TV_DISPINFO*)pNMHDR;

  HTREEITEM hItemCurrent = GetSelectedItem();
  CEdit* pCurrent = GetEditControl();
  CString sCurrent;
  pCurrent->GetWindowText(sCurrent);
  SetItemText(hItemCurrent, sCurrent);
	
	*pResult = 0;
}

/////////////////////////////////////////////////////////////////////////////

BOOL CPagePeopleList::PreTranslateMessage(MSG* pMsg) 
{
  if(pMsg->message == WM_KEYDOWN)
  {
    // When an item is being edited make sure the edit control
    // receives certain important key strokes
    if(GetEditControl() && (pMsg->wParam == VK_RETURN 
                            || pMsg->wParam == VK_DELETE 
                            || pMsg->wParam == VK_ESCAPE
                            || GetKeyState(VK_CONTROL) 
                           )
      )
    {
      ::TranslateMessage(pMsg);
      ::DispatchMessage(pMsg);
      return TRUE;                            // DO NOT process further
    }
  }

	return CTreeCtrl::PreTranslateMessage(pMsg);
}

/////////////////////////////////////////////////////////////////////////////

void CPagePeopleList::OnSelchanged(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;

  HTREEITEM hCurrItem = GetSelectedItem();

  if(GetItemState(hCurrItem, TVIF_STATE) & TVIS_BOLD)
    ((CPagePeople*)GetParent())->m_Active.SetCheck(1);
  else
    ((CPagePeople*)GetParent())->m_Active.SetCheck(0);

  if((GetItemState(hCurrItem, TVIS_STATEIMAGEMASK) & TVIS_STATEIMAGEMASK) == INDEXTOSTATEIMAGEMASK(ICON_MANUAL))   //je manual?
    ((CPagePeople*)GetParent())->m_IsManual.SetCheck(1);
  else
    ((CPagePeople*)GetParent())->m_IsManual.SetCheck(0);

  if((GetItemState(hCurrItem, TVIS_STATEIMAGEMASK) & TVIS_STATEIMAGEMASK) == INDEXTOSTATEIMAGEMASK(ICON_MAIL))  //kontroluje mail?
    ((CPagePeople*)GetParent())->m_ActiveMail.SetCheck(1);
  else
    ((CPagePeople*)GetParent())->m_ActiveMail.SetCheck(0);

  if(!GetParentItem(hCurrItem))
  {
    // server
    ((CPagePeople*)GetParent())->m_IsManual.EnableWindow(TRUE);
    ((CPagePeople*)GetParent())->m_ActiveMail.EnableWindow(FALSE);
  }
  else
  {
    // user
    ((CPagePeople*)GetParent())->m_IsManual.EnableWindow(FALSE);

    if((GetItemState(GetParentItem(hCurrItem), TVIS_STATEIMAGEMASK) & TVIS_STATEIMAGEMASK) == INDEXTOSTATEIMAGEMASK(ICON_MANUAL))   //je manual?
      ((CPagePeople*)GetParent())->m_ActiveMail.EnableWindow(FALSE);
    else
      ((CPagePeople*)GetParent())->m_ActiveMail.EnableWindow(TRUE);
  }

	*pResult = 0;
}

/////////////////////////////////////////////////////////////////////////////

void CPagePeopleList::OnKeydown(NMHDR* pNMHDR, LRESULT* pResult) 
{
	TV_KEYDOWN* pTVKeyDown = (TV_KEYDOWN*)pNMHDR;

  HTREEITEM hCurrItem = GetSelectedItem();
  if(hCurrItem != NULL)
  {
    switch(pTVKeyDown->wVKey)
    {
      case VK_F3:
        ((CPagePeople*)GetParent())->OnFingerCurrent();
        break;

      case VK_F2:
        EditLabel(hCurrItem);
        break;
      
      case VK_DELETE:
        if(MessageBox("Remove this item???", NULL, MB_ICONQUESTION | MB_YESNO) == IDYES)
        {
          g_WriteToHistory(TRUE, "[People] Removed " + GetItemText(hCurrItem));
          DeleteItem(hCurrItem);
        }
        break;
      
      case VK_SPACE:
        SwitchPeopleActive();
        break;
    }
  }

	*pResult = 0;
}

/////////////////////////////////////////////////////////////////////////////

void CPagePeopleList::OnContextMenu(CWnd* pWnd, CPoint point) 
{
  CMenu popMenu; 
  CPoint posMouse; 
  GetCursorPos(&posMouse); 
  popMenu.LoadMenu(IDR_PEOPLEMENU); 

  HTREEITEM hCurrItem = GetSelectedItem();
  if(hCurrItem && GetItemState(hCurrItem, TVIF_STATE) & TVIS_BOLD)
    popMenu.GetSubMenu(0)->CheckMenuItem(IDM_PEOPLE_ACTIVE, MF_CHECKED | MF_BYCOMMAND);
  else
    popMenu.GetSubMenu(0)->CheckMenuItem(IDM_PEOPLE_ACTIVE, MF_UNCHECKED | MF_BYCOMMAND);

  popMenu.GetSubMenu(0)->TrackPopupMenu(0, posMouse.x, posMouse.y, this);
}

/////////////////////////////////////////////////////////////////////////////

void CPagePeopleList::OnPeopleFinger() 
{
  ((CPagePeople*)GetParent())->OnFingerCurrent();
}

/////////////////////////////////////////////////////////////////////////////

void CPagePeopleList::OnPeopleRename() 
{
  EditLabel(GetSelectedItem());
}

/////////////////////////////////////////////////////////////////////////////

void CPagePeopleList::OnPeopleRemove() 
{
  if(MessageBox("Remove this item???", NULL, MB_ICONQUESTION | MB_YESNO) == IDYES)
  {
    g_WriteToHistory(TRUE, "[People] Removed " + GetItemText(GetSelectedItem()));
    DeleteItem(GetSelectedItem());
  }
}

/////////////////////////////////////////////////////////////////////////////

void CPagePeopleList::OnRclick(NMHDR* pNMHDR, LRESULT* pResult) 
{
  if(GetSelectedItem())
  {
    CPoint point;
    GetCursorPos(&point);
    OnContextMenu(this, point);
	  *pResult = 0;
  }
}

/////////////////////////////////////////////////////////////////////////////

void CPagePeopleList::OnPeopleCheckall() 
{
  ((CPagePeople*)GetParent())->OnCheckAll();
}

/////////////////////////////////////////////////////////////////////////////

void CPagePeopleList::OnPeopleActive() 
{
  SwitchPeopleActive();
}

/////////////////////////////////////////////////////////////////////////////

void CPagePeopleList::SwitchPeopleActive() 
{
  HTREEITEM hCurrItem = GetSelectedItem();
  SetItemData(hCurrItem, 0);
  if(GetItemState(hCurrItem, TVIF_STATE) & TVIS_BOLD)
  {
    SetItemState(hCurrItem, NULL, TVIS_BOLD);
    ((CPagePeople*)GetParent())->m_Active.SetCheck(0);
  }
  else
  {
    SetItemState(hCurrItem, TVIS_BOLD, TVIS_BOLD);
    ((CPagePeople*)GetParent())->m_Active.SetCheck(1);
  }
  ((CPagePeople*)GetParent())->IfCanCheckAll();
}

/////////////////////////////////////////////////////////////////////////////
