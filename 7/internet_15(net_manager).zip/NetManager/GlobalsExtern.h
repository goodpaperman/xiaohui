// global macros, variables and functions

  #define   TIMER_DELAY               60 * 1000             // 1 min.
  #define   TIMER_NETMANAGER_ID		    150
  #define   TIMER_NET_ID		          160
  #define   TIMER_PEOPLE_ID		        170
  #define   TIMER_ICON_BLINKING_ID		180

  extern  CEdit* g_Output;
  extern  CEdit* g_History;
  extern  CAnimateCtrl* g_AnimateWait;
  extern  CAnimateCtrl* g_AnimatePeople;
  extern  CAnimateCtrl* g_AnimateNet;
  extern  CWinApp* g_pThisApp;
  extern  CWnd* g_pMainWnd;

  extern  bool g_bStarting;
  extern  bool g_bEnding;
  extern  bool g_bNetMonitoring;
  extern  bool g_bPeopleMonitoring;
  extern  bool g_bAutoSaveSettings;
  extern  bool g_bWinNotification;
  extern  bool g_bExeImages;
  extern  bool g_bPeopleImages;
  extern  void g_WriteToOutput(BOOL, LPCTSTR);
  extern  void g_WriteToHistory(BOOL, LPCTSTR);
  extern  CString g_MakeWindowsTextLines(CString);
