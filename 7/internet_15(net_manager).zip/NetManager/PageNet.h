#if !defined(AFX_PAGENET_H__E60D4646_763C_11D1_82BF_444553540000__INCLUDED_)
#define AFX_PAGENET_H__E60D4646_763C_11D1_82BF_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// PageNet.h : header file
//

#include "PageNetList.h"

/////////////////////////////////////////////////////////////////////////////
// CPageNet dialog

class CPageNet : public CPropertyPage
{
	DECLARE_DYNCREATE(CPageNet)

// Construction
public:
	CPageNet();
	~CPageNet();

// Dialog Data
	//{{AFX_DATA(CPageNet)
	enum { IDD = IDD_PAGE_NET };
	CSpinButtonCtrl	m_NetSpin;
	CButton	m_OnStart;
	CButton	m_OnEnd;
	CButton	m_Every;
	CStatic	m_StatusLine;
	CEdit	m_URL;
	CEdit	m_Name;
	CString	m_sURL;
	CString	m_sName;
	int		m_nNetMinutes;
	//}}AFX_DATA

  CPageNetList m_List;
  CStringArray* m_psArrayNet;
  CStringArray* m_psArrayNetLastModified;
  void Add();
  bool Check(int, CString&);
  bool CheckAll(CString&);

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPageNet)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

//protected:
public:
	// Generated message map functions
	//{{AFX_MSG(CPageNet)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelChangeList();
	afx_msg void OnDblclkList();
	afx_msg void OnCheckAll();
	afx_msg void OnRemove();
	afx_msg void OnKillfocusMinutes2();
	afx_msg void OnEvery2();
	afx_msg void OnEdit();
	afx_msg void OnSetfocusUrl();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PAGENET_H__E60D4646_763C_11D1_82BF_444553540000__INCLUDED_)
