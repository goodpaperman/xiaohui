// PageYou.cpp : implementation file
//

#include "stdafx.h"
#include "NetManager.h"
#include "PageYou.h"
#include "GlobalsExtern.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

UINT g_FileUpload(LPVOID);

/////////////////////////////////////////////////////////////////////////////
// CPageYou property page

IMPLEMENT_DYNCREATE(CPageYou, CPropertyPage)

CPageYou::CPageYou() : CPropertyPage(CPageYou::IDD)
{
	//{{AFX_DATA_INIT(CPageYou)
	m_sServerName = _T("");
	m_sDestination = _T("");
	m_sDestinationDir = _T("");
	m_sPassword = _T("");
	m_sUserName = _T("");
	m_sSourceFile1 = _T("");
	m_sSourceFile2 = _T("");
	m_sIP = _T("");
	m_sIPName = _T("");
	m_sDate = _T("");
	m_sTagDate = _T("");
	m_sTagMachine = _T("");
	//}}AFX_DATA_INIT
}

CPageYou::~CPageYou()
{

}

void CPageYou::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPageYou)
	DDX_Control(pDX, IDC_IPNAME, m_IPName);
	DDX_Control(pDX, IDC_IP, m_IP);
	DDX_Control(pDX, IDC_WITH_ADDRESS, m_WithAddress);
	DDX_Control(pDX, IDC_WITH_DATE, m_WithDate);
	DDX_Control(pDX, IDC_DATE, m_Date);
	DDX_Control(pDX, IDC_SOURCEFILE2, m_SourceFile2);
	DDX_Control(pDX, IDC_SOURCEFILE1, m_SourceFile1);
	DDX_Control(pDX, IDC_OFFLINE_ONEND, m_OfflineOnEnd);
	DDX_Control(pDX, IDC_ONLINE_ONSTART, m_OnlineOnStart);
	DDX_Text(pDX, IDC_FTPSERVER, m_sServerName);
	DDX_Text(pDX, IDC_DESTINATION, m_sDestination);
	DDX_Text(pDX, IDC_DESTINATIONDIR, m_sDestinationDir);
	DDX_Text(pDX, IDC_FTPPASSWORD, m_sPassword);
	DDX_Text(pDX, IDC_FTPUSERNAME, m_sUserName);
	DDX_Text(pDX, IDC_SOURCEFILE1, m_sSourceFile1);
	DDX_Text(pDX, IDC_SOURCEFILE2, m_sSourceFile2);
	DDX_Text(pDX, IDC_IP, m_sIP);
	DDX_Text(pDX, IDC_IPNAME, m_sIPName);
	DDX_Text(pDX, IDC_DATE, m_sDate);
	DDX_Text(pDX, IDC_TAG_DATE, m_sTagDate);
	DDX_Text(pDX, IDC_TAG_MACHINE, m_sTagMachine);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPageYou, CPropertyPage)
	//{{AFX_MSG_MAP(CPageYou)
	ON_BN_CLICKED(IDB_ONLINE, OnOnline)
	ON_BN_CLICKED(IDB_OFFLINE, OnOffline)
	ON_BN_CLICKED(IDB_BROWSE_OFF, OnBrowseOff)
	ON_BN_CLICKED(IDB_BROWSE_ON, OnBrowseOn)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPageYou message handlers

void CPageYou::SaveSettings()
{
  g_pThisApp->WriteProfileString("You", "Server", m_sServerName);
  g_pThisApp->WriteProfileString("You", "User", m_sUserName);
  g_pThisApp->WriteProfileString("You", "Password", m_sPassword);
  g_pThisApp->WriteProfileString("You", "SourceFileOn", m_sSourceFile1);
  g_pThisApp->WriteProfileString("You", "SourceFileOff", m_sSourceFile2);
  g_pThisApp->WriteProfileString("You", "DestinationDir", m_sDestinationDir);
  g_pThisApp->WriteProfileString("You", "DestinationName", m_sDestination);
  g_pThisApp->WriteProfileString("You", "TagMachine", m_sTagMachine);
  g_pThisApp->WriteProfileString("You", "TagDate", m_sTagDate);
  g_pThisApp->WriteProfileInt("You", "OnStart", m_OnlineOnStart.GetCheck());
  g_pThisApp->WriteProfileInt("You", "OnEnd", m_OfflineOnEnd.GetCheck());
  g_pThisApp->WriteProfileInt("You", "WithAddress", m_WithAddress.GetCheck());
  g_pThisApp->WriteProfileInt("You", "WithDate", m_WithDate.GetCheck());
}

/////////////////////////////////////////////////////////////////////////////

BOOL CPageYou::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
  m_OnlineOnStart.SetCheck(g_pThisApp->GetProfileInt("YOU", "OnStart", 0));
  m_OfflineOnEnd.SetCheck(g_pThisApp->GetProfileInt("YOU", "OnEnd", 0));
  m_WithAddress.SetCheck(g_pThisApp->GetProfileInt("YOU", "WithAddress", 0));
  m_WithDate.SetCheck(g_pThisApp->GetProfileInt("YOU", "WithDate", 0));

  CTime LoginTime = CTime::GetCurrentTime();
  CString sLoginTime = LoginTime.Format("%A, %B %d, %Y, %H:%M:%S");
  m_Date.SetWindowText(sLoginTime);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

/////////////////////////////////////////////////////////////////////////////

void CPageYou::OnBrowseOn() 
{
  UpdateData();
  CFileDialog BrowseDialog(TRUE);
  if(BrowseDialog.DoModal() == IDOK)
  {
    m_sSourceFile1 = BrowseDialog.GetPathName();
    m_SourceFile1.SetWindowText(m_sSourceFile1);
  }
}

/////////////////////////////////////////////////////////////////////////////

void CPageYou::OnBrowseOff() 
{
  UpdateData();
  CFileDialog BrowseDialog(TRUE);
  if(BrowseDialog.DoModal() == IDOK)
  {
    m_sSourceFile2 = BrowseDialog.GetPathName();
    m_SourceFile2.SetWindowText(m_sSourceFile2);
  }
}

/////////////////////////////////////////////////////////////////////////////

void CPageYou::OnOnline() 
{
  UpdateData();

  CStringArray* pasUpload = new CStringArray;
  CString sWithDate = "";
  CString sWithAddress = "";
  if(m_WithDate.GetCheck())
    sWithDate = "YES";
  if(m_WithAddress.GetCheck())
    sWithAddress = "YES";

  pasUpload->Add(m_sSourceFile1);
  pasUpload->Add("[You]: Now you are On-line");
  pasUpload->Add(m_sServerName);
  pasUpload->Add(m_sUserName);
  pasUpload->Add(m_sPassword);
  pasUpload->Add(m_sDestinationDir);
  pasUpload->Add(m_sDestination);
  pasUpload->Add(m_sIPName);
  pasUpload->Add(m_sIP);
  pasUpload->Add(m_sTagDate);
  pasUpload->Add(m_sTagMachine);
  pasUpload->Add(sWithDate);
  pasUpload->Add(sWithAddress);

  AfxBeginThread(g_FileUpload, pasUpload);
}

/////////////////////////////////////////////////////////////////////////////

void CPageYou::OnOffline()
{
  UpdateData();
  CStringArray* pasUpload = new CStringArray;
  CString sWithDate = "";
  CString sWithAddress = "";
  if(m_WithDate.GetCheck())
    sWithDate = "YES";
  if(m_WithAddress.GetCheck())
    sWithAddress = "YES";

  pasUpload->Add(m_sSourceFile2);
  pasUpload->Add("[You]: Now you are Off-line");
  pasUpload->Add(m_sServerName);
  pasUpload->Add(m_sUserName);
  pasUpload->Add(m_sPassword);
  pasUpload->Add(m_sDestinationDir);
  pasUpload->Add(m_sDestination);
  pasUpload->Add(m_sIPName);
  pasUpload->Add(m_sIP);
  pasUpload->Add(m_sTagDate);
  pasUpload->Add(m_sTagMachine);
  pasUpload->Add(sWithDate);
  pasUpload->Add(sWithAddress);

  AfxBeginThread(g_FileUpload, pasUpload);
}

/////////////////////////////////////////////////////////////////////////////

UINT g_FileUpload(LPVOID pParam)
{
  CStringArray* pasUpload = ((CStringArray*)pParam);
  CString sFilePath = pasUpload->GetAt(0);
  CString sOutputText = pasUpload->GetAt(1);
  CString sServerName = pasUpload->GetAt(2);
  CString sUserName = pasUpload->GetAt(3);
  CString sPassword = pasUpload->GetAt(4);
  CString sDestinationDir = pasUpload->GetAt(5);
  CString sDestination = pasUpload->GetAt(6);
  CString sIPName = pasUpload->GetAt(7);
  CString sIP = pasUpload->GetAt(8);
  CString sTagDate = pasUpload->GetAt(9);
  CString sTagMachine = pasUpload->GetAt(10);
  CString sWithDate = pasUpload->GetAt(11);
  CString sWithAddress = pasUpload->GetAt(12);
  pasUpload->RemoveAll();
  delete pasUpload;

  g_AnimateWait->Play(0, -1, -1);

  CInternetSession INetSect(AfxGetAppName(), 0, INTERNET_OPEN_TYPE_DIRECT);
  CFtpConnection* pFtpConn;

  try
  {
    if(pFtpConn = INetSect.GetFtpConnection(sServerName, sUserName, sPassword))
    {
      if(sDestinationDir != "")
      {  
        if(!pFtpConn->SetCurrentDirectory(sDestinationDir))
          g_WriteToHistory(TRUE, "[You]: Error - Change FTP Directory");
      }
      CInternetFile* pFtpFile;
      pFtpFile = pFtpConn->OpenFile(sDestination, GENERIC_WRITE);
      if(pFtpFile)
      {
        CTime LoginTime = CTime::GetCurrentTime();
        CString sLoginTime = "";
        if(sWithDate == "YES")
          sLoginTime = LoginTime.Format("%A, %B %d, %Y, %H:%M:%S");

        CString sMachine = "";
        if(sWithAddress == "YES")
          sMachine = sIPName + " - " + sIP;

        CString sBuffer;
        CStdioFile CInputFile;
        CInputFile.Open(sFilePath, CFile::modeRead);

        int nTimePos;
        bool bTagDateFound = FALSE;
        bool bTagMachineFound = FALSE;
        while(CInputFile.ReadString(sBuffer))
        {
          if((nTimePos = sBuffer.Find(sTagDate)) != -1)
          {
            sBuffer = sBuffer.Left(nTimePos) + sLoginTime + sBuffer.Right(sBuffer.GetLength() - nTimePos - 6);
            bTagDateFound = TRUE;
          }
          if((nTimePos = sBuffer.Find(sTagMachine)) != -1)
          {
            sBuffer = sBuffer.Left(nTimePos) + sMachine + sBuffer.Right(sBuffer.GetLength() - nTimePos - 9);
            bTagMachineFound = TRUE;
          }
          sBuffer += (char)0xa;
          pFtpFile->WriteString(sBuffer);
        }
        pFtpFile->Close();
        if(!bTagDateFound)
          AfxMessageBox("[You]: The tag " + sTagDate + " not found in " + sFilePath);
        if(!bTagMachineFound)
          AfxMessageBox("[You]: The tag " + sTagMachine + " not found in " + sFilePath);

        g_WriteToHistory(TRUE, sOutputText);
      }
      else
        g_WriteToHistory(TRUE, "[You]: Error - Upload File");
    }
    else
      g_WriteToHistory(TRUE, "[You]: Error - Opening FTP");
  }
  catch(CInternetException* pe)
  {
    TCHAR szCause[255];
    pe->GetErrorMessage(szCause, 255);
    CString sError = "[You]: Error - ";
    sError += szCause;
    g_WriteToOutput(FALSE, sError);
    pe->Delete();
  }
  INetSect.Close();

  return 0;
}

/////////////////////////////////////////////////////////////////////////////

BOOL CPageYou::PreTranslateMessage(MSG* pMsg) 
{
  if(pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_RETURN)
    NextDlgCtrl();

	return CPropertyPage::PreTranslateMessage(pMsg);
}

/////////////////////////////////////////////////////////////////////////////
