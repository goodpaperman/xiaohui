// PageMailConfig.cpp : implementation file
//

#include "stdafx.h"
#include "NetManager.h"
#include "PageMail.h"
#include "PageMailConfig.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPageMailConfig dialog


CPageMailConfig::CPageMailConfig(CWnd* pParent /*=NULL*/)
	: CDialog(CPageMailConfig::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPageMailConfig)
	m_sSignature = _T("");
	//}}AFX_DATA_INIT
}


void CPageMailConfig::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPageMailConfig)
	DDX_Control(pDX, IDC_TEXT_SIGNATURE, m_Signature);
	DDX_Text(pDX, IDC_TEXT_SIGNATURE, m_sSignature);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPageMailConfig, CDialog)
	//{{AFX_MSG_MAP(CPageMailConfig)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPageMailConfig message handlers

void CPageMailConfig::OnOK() 
{
  m_psArrayMailSignature->RemoveAll();

  char sBuffer[80];
  int i = 0;
  int j = m_Signature.GetLineCount()-1;
  int k;
  while(i != j)
  {
    k = m_Signature.GetLine(i, sBuffer, 80);
    sBuffer[k] = '\0';
    m_psArrayMailSignature->Add(sBuffer);
    i++;
  }

	CDialog::OnOK();
}
