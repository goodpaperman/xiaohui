// OutputWnd.cpp : implementation file
//

#include "stdafx.h"
#include "netmanager.h"
#include "OutputWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COutputWnd

COutputWnd::COutputWnd()
{
}

COutputWnd::~COutputWnd()
{
}


BEGIN_MESSAGE_MAP(COutputWnd, CEdit)
	//{{AFX_MSG_MAP(COutputWnd)
	ON_WM_LBUTTONDBLCLK()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COutputWnd message handlers

void COutputWnd::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
  SetReadOnly(FALSE);
  SetSel(0, -1);	
  Clear();	
  SetReadOnly();
	
	CEdit::OnLButtonDblClk(nFlags, point);
}

/////////////////////////////////////////////////////////////////////////////
