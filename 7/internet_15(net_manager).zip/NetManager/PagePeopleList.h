#if !defined(AFX_PAGEPEOPLELIST_H__9C0C2843_804B_11D1_82C0_444553540000__INCLUDED_)
#define AFX_PAGEPEOPLELIST_H__9C0C2843_804B_11D1_82C0_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// PagePeopleList.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPagePeopleList window

class CPagePeopleList : public CTreeCtrl
{
// Construction
public:
	CPagePeopleList();

// Attributes
public:

// Operations
public:

  void SwitchPeopleActive();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPagePeopleList)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CPagePeopleList();

	// Generated message map functions
protected:
	//{{AFX_MSG(CPagePeopleList)
	afx_msg void OnBeginlabeledit(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnEndlabeledit(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSelchanged(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnKeydown(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnPeopleFinger();
	afx_msg void OnPeopleRemove();
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg void OnPeopleRename();
	afx_msg void OnRclick(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnPeopleCheckall();
	afx_msg void OnPeopleActive();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PAGEPEOPLELIST_H__9C0C2843_804B_11D1_82C0_444553540000__INCLUDED_)
