// PageFilesExeList.cpp : implementation file
//

#include "stdafx.h"
#include "netmanager.h"
#include "PageFilesExeList.h"
#include "GlobalsExtern.h"
#include "PageFiles.h"

#include <sys/types.h>
#include <sys/stat.h>
#include <shlobj.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPageFilesExeList

CPageFilesExeList::CPageFilesExeList()
{
}

CPageFilesExeList::~CPageFilesExeList()
{
}


BEGIN_MESSAGE_MAP(CPageFilesExeList, CListCtrl)
	//{{AFX_MSG_MAP(CPageFilesExeList)
	ON_NOTIFY_REFLECT(NM_DBLCLK, OnDblclk)
	ON_NOTIFY_REFLECT(LVN_BEGINLABELEDIT, OnBeginlabeledit)
	ON_NOTIFY_REFLECT(LVN_ENDLABELEDIT, OnEndlabeledit)
	ON_WM_KEYDOWN()
	ON_NOTIFY_REFLECT(NM_CLICK, OnClick)
	ON_WM_KEYUP()
	ON_WM_DROPFILES()
	ON_WM_CONTEXTMENU()
	ON_COMMAND(IDM_EXEFILES_RENAME, OnExefilesRename)
	ON_COMMAND(IDM_EXEFILES_REMOVE, OnExefilesRemove)
	ON_COMMAND(IDM_EXEFILES_EXECUTE, OnExefilesExecute)
	ON_COMMAND(IDM_EXEFILES_ADD, OnExefilesAdd)
	ON_COMMAND(IDM_EXEFILES_AUTOSTART, OnExefilesAutostart)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPageFilesExeList message handlers
/////////////////////////////////////////////////////////////////////////////

int CPageFilesExeList::GetCurrentSelection()
{
  int nWhichItem = 0;
  if(GetSelectedCount() == 1)
  {
    while(GetItemState(nWhichItem, LVIS_SELECTED) != LVIS_SELECTED)
      nWhichItem++;
  }
  return nWhichItem;
}

/////////////////////////////////////////////////////////////////////////////

void CPageFilesExeList::OnDblclk(NMHDR* pNMHDR, LRESULT* pResult) 
{
  if(GetSelectedCount() != 0)
  {
    int nWhichItem = GetCurrentSelection();
    ((CPageFiles*)GetParent())->FilesExecute(nWhichItem);
  }
	
	*pResult = 0;
}

/////////////////////////////////////////////////////////////////////////////

void CPageFilesExeList::OnBeginlabeledit(NMHDR* pNMHDR, LRESULT* pResult) 
{
	LV_DISPINFO* pDispInfo = (LV_DISPINFO*)pNMHDR;

  GetEditControl()->LimitText(32);
	
	*pResult = 0;
}

/////////////////////////////////////////////////////////////////////////////

void CPageFilesExeList::OnEndlabeledit(NMHDR* pNMHDR, LRESULT* pResult) 
{
	LV_DISPINFO* pDispInfo = (LV_DISPINFO*)pNMHDR;

  if(GetSelectedCount() != 0)
  {
    int nWhichItem = GetCurrentSelection();

    CEdit* pCurrent = GetEditControl();
    CString sCurrent;
    pCurrent->GetWindowText(sCurrent);

    sCurrent.MakeLower();
    CString sText;
    int j = GetItemCount();
    bool bOK = true;
    for(int i = 0; i < j; i++)
    {
      sText = GetItemText(i, 0);
      sText.MakeLower();
      if(sText == sCurrent && i != nWhichItem)
      {
        bOK = false;
        AfxMessageBox("This name already exists, use another one\n(Because of writing to ini file)");
      }
    }
    if(bOK)
      SetItemText(nWhichItem, 0, sCurrent);
  }
  else
    AfxMessageBox("Nothing selected");

	*pResult = 0;
}

/////////////////////////////////////////////////////////////////////////////

void CPageFilesExeList::RemoveItem(int nWhichItem) 
{
  if(MessageBox("Remove this item???", NULL, MB_ICONQUESTION | MB_YESNO) == IDYES)
  {
    int nWhichItem = GetCurrentSelection();
    g_WriteToHistory(TRUE, "[Files] Removed " + GetItemText(nWhichItem, 0));
    DeleteItem(nWhichItem);
    ((CPageFiles*)GetParent())->m_psArrayExePaths->RemoveAt(nWhichItem);
    ((CPageFiles*)GetParent())->m_pArrayAutoStart->RemoveAt(nWhichItem);
    ((CPageFiles*)GetParent())->m_FilePath.SetWindowText("");
    ((CPageFiles*)GetParent())->m_pImagesSmall->Remove(nWhichItem);
    ((CPageFiles*)GetParent())->m_pImagesLarge->Remove(nWhichItem);
    int j = ((CPageFiles*)GetParent())->m_ExeFiles.GetItemCount();
    for(int i = 0; i < j; i++)
    {
      SetItem(i, NULL, LVIF_IMAGE, NULL, i, NULL, NULL, NULL);
      SetItemState(i, INDEXTOSTATEIMAGEMASK(((CPageFiles*)GetParent())->m_pArrayAutoStart->GetAt(i) + 1), LVIS_STATEIMAGEMASK);
    }
  }
}

/////////////////////////////////////////////////////////////////////////////

void CPageFilesExeList::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	
  if(GetSelectedCount() != 0)
  {
    int nWhichItem = GetCurrentSelection();

    switch(nChar)
    {
      case VK_F3:
        ((CPageFiles*)GetParent())->OnExecuteExe();
        break;

      case VK_F2:
        EditLabel(nWhichItem);
        break;

      case VK_INSERT:
        ((CPageFiles*)GetParent())->OnAddExe();
        break;

      case VK_DELETE:
        RemoveItem(nWhichItem);
        break;

      case VK_SPACE:
        SwitchExeAuto();
        break;
    }
  }

	CListCtrl::OnKeyDown(nChar, nRepCnt, nFlags);
}

/////////////////////////////////////////////////////////////////////////////

void CPageFilesExeList::OnClick(NMHDR* pNMHDR, LRESULT* pResult) 
{
  if(GetSelectedCount() != 0)
  {
    int nWhichItem = GetCurrentSelection();

    CString sFileToExe;
    sFileToExe = ((CPageFiles*)GetParent())->m_psArrayExePaths->GetAt(nWhichItem);
    ((CPageFiles*)GetParent())->m_FilePath.SetWindowText(sFileToExe);

    ((CPageFiles*)GetParent())->m_AutoStart.SetCheck(((CPageFiles*)GetParent())->m_pArrayAutoStart->GetAt(nWhichItem));
  }

	*pResult = 0;
}

/////////////////////////////////////////////////////////////////////////////

void CPageFilesExeList::OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
  if(GetSelectedCount() != 0)
  {
    int nWhichItem = GetCurrentSelection();

    CString sFileToExe;
    sFileToExe = ((CPageFiles*)GetParent())->m_psArrayExePaths->GetAt(nWhichItem);
    ((CPageFiles*)GetParent())->m_FilePath.SetWindowText(sFileToExe);

    ((CPageFiles*)GetParent())->m_AutoStart.SetCheck(((CPageFiles*)GetParent())->m_pArrayAutoStart->GetAt(nWhichItem));
  }

  CListCtrl::OnKeyUp(nChar, nRepCnt, nFlags);
}

/////////////////////////////////////////////////////////////////////////////

void CPageFilesExeList::OnDropFiles(HDROP hDropInfo) 
{
  WORD wNumFilesDropped = DragQueryFile(hDropInfo, -1, NULL, 0);	  // Get the number of pathnames that have been dropped

  CStringArray asFiles;
  for (WORD x = 0 ; x < wNumFilesDropped; x++)                      // get all file names. but we'll only need the first one.
  {
    WORD wPathnameSize = DragQueryFile(hDropInfo, x, NULL, 0);      // Get the number of bytes required by the file's full pathname
    char* npszFile = (char*) LocalAlloc(LPTR, wPathnameSize += 1);  // Allocate memory to contain full pathname & zero byte
    if(npszFile == NULL)
      continue;                                                     // If not enough memory, skip this one
    DragQueryFile(hDropInfo, x, npszFile, wPathnameSize);           // Copy the pathname into the buffer
    asFiles.Add(npszFile);
    LocalFree(npszFile);                                            // clean up
  }
  DragFinish(hDropInfo);                                            // Free the memory block containing the dropped-file information

  CString sFile;
  CString sExpandedFile;
  struct _stat buf;
  int j = asFiles.GetSize();
  for(int i = 0; i < j; i++)
  {
    sFile = asFiles.GetAt(i);
    sExpandedFile = ExpandShortcut(sFile);                          // if this was a shortcut, we need to expand it to the target path
    if(sExpandedFile != "")                                         // if that worked, we should have a real file name
      sFile = sExpandedFile;

    if(_stat(sFile, &buf) == 0)
      ((CPageFiles*)GetParent())->AddExe(sFile);
  }

  CListCtrl::OnDropFiles(hDropInfo);
}

/////////////////////////////////////////////////////////////////////////////
//	use IShellLink to expand the shortcut
//	returns the expanded file, or "" on error
//
//	original code was part of CShortcut 
//	1996 by Rob Warner
//	rhwarner@southeast.net
//	http://users.southeast.net/~rhwarner

CString CPageFilesExeList::ExpandShortcut(CString &inFile)
{
  CString outFile = "";

  // Make sure we have a path
  ASSERT(inFile != _T(""));

  IShellLink* psl;
  HRESULT hres;
  LPTSTR lpsz = inFile.GetBuffer(MAX_PATH);

  // Create instance for shell link
  hres = ::CoCreateInstance(CLSID_ShellLink, NULL, CLSCTX_INPROC_SERVER, IID_IShellLink, (LPVOID*) &psl);
  if(SUCCEEDED(hres))
  {
    // Get a pointer to the persist file interface
    IPersistFile* ppf;
    hres = psl->QueryInterface(IID_IPersistFile, (LPVOID*) &ppf);
    if(SUCCEEDED(hres))
    {
      // Make sure it's ANSI
      WORD wsz[MAX_PATH];
      ::MultiByteToWideChar(CP_ACP, 0, lpsz, -1, wsz, MAX_PATH);

      // Load shortcut
      hres = ppf->Load(wsz, STGM_READ);
      if(SUCCEEDED(hres))
      {
        WIN32_FIND_DATA wfd;
        // find the path from that
        HRESULT hres = psl->GetPath(outFile.GetBuffer(MAX_PATH), 
                MAX_PATH,
                &wfd, 
                SLGP_UNCPRIORITY);

        outFile.ReleaseBuffer();
      }
      ppf->Release();
    }
    psl->Release();
  }

  inFile.ReleaseBuffer();

  // if this fails, outFile == ""
  return outFile;
}

/////////////////////////////////////////////////////////////////////////////

void CPageFilesExeList::OnContextMenu(CWnd* pWnd, CPoint point) 
{
  if(GetSelectedCount() != 0)
  {
    CPoint posMouse; 
    GetCursorPos(&posMouse); 
    int nWhichItem = GetCurrentSelection();
    CMenu PopMenu;
    PopMenu.LoadMenu(IDR_EXEFILESMENU); 
    if(((CPageFiles*)GetParent())->m_pArrayAutoStart->GetAt(nWhichItem) == 0)
      PopMenu.GetSubMenu(0)->CheckMenuItem(IDM_EXEFILES_AUTOSTART, MF_UNCHECKED | MF_BYCOMMAND);
    else
      PopMenu.GetSubMenu(0)->CheckMenuItem(IDM_EXEFILES_AUTOSTART, MF_CHECKED | MF_BYCOMMAND);

    PopMenu.GetSubMenu(0)->TrackPopupMenu(0, posMouse.x, posMouse.y, this);
  }
}

/////////////////////////////////////////////////////////////////////////////

void CPageFilesExeList::OnExefilesExecute() 
{
  ((CPageFiles*)GetParent())->OnExecuteExe();
}

/////////////////////////////////////////////////////////////////////////////

void CPageFilesExeList::OnExefilesRename() 
{
  EditLabel(GetCurrentSelection());
}

/////////////////////////////////////////////////////////////////////////////

void CPageFilesExeList::OnExefilesRemove() 
{
  RemoveItem(GetCurrentSelection());
}

/////////////////////////////////////////////////////////////////////////////

void CPageFilesExeList::OnExefilesAdd() 
{
  ((CPageFiles*)GetParent())->OnAddExe();
}

/////////////////////////////////////////////////////////////////////////////

void CPageFilesExeList::OnExefilesAutostart() 
{
  SwitchExeAuto();
}

/////////////////////////////////////////////////////////////////////////////

void CPageFilesExeList::SwitchExeAuto() 
{
  int nWhichItem = GetCurrentSelection();
  if(((CPageFiles*)GetParent())->m_pArrayAutoStart->GetAt(nWhichItem) == 0)
  {
    SetItemState(nWhichItem, INDEXTOSTATEIMAGEMASK(2), LVIS_STATEIMAGEMASK);
    ((CPageFiles*)GetParent())->m_pArrayAutoStart->SetAt(nWhichItem, 1);
    ((CPageFiles*)GetParent())->m_AutoStart.SetCheck(1);
  }
  else
  {
    SetItemState(nWhichItem, INDEXTOSTATEIMAGEMASK(1), LVIS_STATEIMAGEMASK);
    ((CPageFiles*)GetParent())->m_pArrayAutoStart->SetAt(nWhichItem, 0);
    ((CPageFiles*)GetParent())->m_AutoStart.SetCheck(0);
  }
}

/////////////////////////////////////////////////////////////////////////////
