// PageMail.cpp : implementation file
//

#include "stdafx.h"
#include "NetManager.h"
#include "PageMail.h"
#include "PageMailConfig.h"
#include "GlobalsExtern.h"
#include "SMTP.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPageMail property page

IMPLEMENT_DYNCREATE(CPageMail, CPropertyPage)

CPageMail::CPageMail() : CPropertyPage(CPageMail::IDD)
{
	//{{AFX_DATA_INIT(CPageMail)
	m_sFrom = _T("");
	m_sServer = _T("");
	m_sSubject = _T("");
	m_sText = _T("");
	m_sTo = _T("");
	m_sXMailer = _T("");
	//}}AFX_DATA_INIT
}

CPageMail::~CPageMail()
{
}

void CPageMail::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPageMail)
	DDX_Control(pDX, IDC_ATTACHMENTS, m_Attachments);
	DDX_Control(pDX, IDC_WITHDATE, m_WithDate);
	DDX_Control(pDX, IDC_WITHMAILER, m_WithMailer);
	DDX_Control(pDX, IDC_NUMBER_OF_CHARS, m_NumberOfChars);
	DDX_Control(pDX, IDC_WITHSIGNATURE, m_WithSignature);
	DDX_Control(pDX, IDC_CLEAR, m_Clear);
	DDX_Control(pDX, IDC_TEXT, m_Text);
	DDX_CBString(pDX, IDC_FROM, m_sFrom);
	DDV_MaxChars(pDX, m_sFrom, 256);
	DDX_CBString(pDX, IDC_SERVER, m_sServer);
	DDV_MaxChars(pDX, m_sServer, 256);
	DDX_CBString(pDX, IDC_SUBJECT, m_sSubject);
	DDV_MaxChars(pDX, m_sSubject, 256);
	DDX_Text(pDX, IDC_TEXT, m_sText);
	DDV_MaxChars(pDX, m_sText, 64000);
	DDX_CBString(pDX, IDC_TO, m_sTo);
	DDV_MaxChars(pDX, m_sTo, 256);
	DDX_CBString(pDX, IDC_XMAILER, m_sXMailer);
	DDV_MaxChars(pDX, m_sXMailer, 256);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPageMail, CPropertyPage)
	//{{AFX_MSG_MAP(CPageMail)
	ON_BN_CLICKED(IDB_SEND, OnSend)
	ON_BN_CLICKED(IDB_SETTINGS, OnSettings)
	ON_EN_CHANGE(IDC_TEXT, OnChangeText)
	ON_BN_CLICKED(IDC_WITHSIGNATURE, OnWithSignature)
	ON_BN_CLICKED(IDB_ATTACHMENTS, OnAttachments)
	ON_CBN_SETFOCUS(IDC_ATTACHMENTS, OnSetfocusAttachments)
	ON_BN_CLICKED(IDC_WITHMAILER, OnWithmailer)
	ON_CBN_EDITUPDATE(IDC_ATTACHMENTS, OnEditupdateAttachments)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPageMail message handlers

BOOL CPageMail::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();

  m_Subject.SubclassDlgItem(IDC_SUBJECT, this);
  m_Program.SubclassDlgItem(IDC_XMAILER, this);
  m_Server.SubclassDlgItem(IDC_SERVER, this);
  m_From.SubclassDlgItem(IDC_FROM, this);
  m_To.SubclassDlgItem(IDC_TO, this);
  m_DelCurrent.SubclassDlgItem(IDB_DELCURRENT, this);

  m_Clear.SetCheck(g_pThisApp->GetProfileInt("Mail", "Clear", 1));
  m_WithDate.SetCheck(g_pThisApp->GetProfileInt("Mail", "WithDate", 0));
  m_WithSignature.SetCheck(g_pThisApp->GetProfileInt("Mail", "WithSignature", 0));
  m_WithMailer.SetCheck(g_pThisApp->GetProfileInt("Mail", "WithMailer", 0));

  int i;
  i = m_psArrayMailServer->GetSize();
  while(i != 0)
    m_Server.InsertString(0, m_psArrayMailServer->GetAt(--i));

  i = m_psArrayMailProgram->GetSize();
  while(i != 0)
    m_Program.InsertString(0, m_psArrayMailProgram->GetAt(--i));

  i = m_psArrayMailFrom->GetSize();
  while(i != 0)
    m_From.InsertString(0, m_psArrayMailFrom->GetAt(--i));

  i = m_psArrayMailTo->GetSize();
  while(i != 0)
    m_To.InsertString(0, m_psArrayMailTo->GetAt(--i));

  i = m_psArrayMailSubject->GetSize();
  while(i != 0)
    m_Subject.InsertString(0, m_psArrayMailSubject->GetAt(--i));

  i = 0;
  int j = m_psArrayMailSignature->GetSize();
  while(i != j)
  {
    m_sSignature += m_psArrayMailSignature->GetAt(i);
    m_sSignature += "\r\n";
    i++;
  }

  OnChangeText();
  OnWithmailer();

  CString sInit;
  m_Server.GetLBText(0, sInit); 
  m_Server.SetWindowText(sInit);
  m_Program.GetLBText(0, sInit); 
  m_Program.SetWindowText(sInit);
  m_From.GetLBText(0, sInit); 
  m_From.SetWindowText(sInit);

	return TRUE;  // return TRUE unless you set the focus to a control
                // EXCEPTION: OCX Property Pages should return FALSE
}

/////////////////////////////////////////////////////////////////////////////

void CPageMail::UpdateArrays(CStringArray* pArray, CComboBox* pCombo)
{
  CString sWork;
  pArray->RemoveAll();
  int j = pCombo->GetCount();
  for(int i = 0; i < j; i++)
  {
    pCombo->GetLBText(i, sWork);
    pArray->Add(sWork);
  }
}

/////////////////////////////////////////////////////////////////////////////

void CPageMail::OnSend() 
{
  UpdateData();

  g_AnimateWait->Play(0, -1, -1);

  CString sFromName;
  CString sFromEmail;
  CString sToName;
  CString sToEmail;
  int nFrom = m_sFrom.Find(_T('<'));
  if(nFrom != -1)
  {
    sFromName = m_sFrom.Left(nFrom);
    sFromEmail = m_sFrom.Right(m_sFrom.GetLength() - nFrom);
    sFromEmail = sFromEmail.Mid(1, sFromEmail.GetLength() - 2);
  }
  else
  {
    sFromEmail = m_sFrom;
  }

  int nTo = m_sTo.Find(_T('<'));
  if(nTo != -1)
  {
    sToName = m_sTo.Left(nTo);
    sToEmail = m_sTo.Right(m_sTo.GetLength() - nTo);
    sToEmail = sToEmail.Mid(1, sToEmail.GetLength() - 2);
  }
  else
  {
    sToEmail = m_sTo;
  }

  CSMTPConnection Smtp;
  if(!Smtp.Connect(m_sServer))
  {
    DWORD dwError = ::GetLastError();
    CString sResponse = Smtp.GetLastCommandResponse();
    g_WriteToOutput(TRUE, "[Mail] Failed to connect to SMTP server" + sResponse);
    return;
  }

  CSMTPMessage Message(m_sXMailer, m_WithDate.GetCheck(), m_WithMailer.GetCheck());
  CSMTPAddress From(sFromName, sFromEmail);
  Message.m_From = From;
  CSMTPAddress To(sToName, sToEmail);
  Message.AddRecipient(To);
  Message.m_sSubject = m_sSubject;
  Message.AddBody(m_sText);
//  Message.m_ReplyTo = CSMTPAddress(_T("Another PJ"), _T("pj.naughter@softech-telecom.com"));

  CArray<CSMTPAttachment*, CSMTPAttachment*&> apAttachments;

  CString sAttachment;
  CSMTPAttachment* pAttachment;
  int nAttachments = m_Attachments.GetCount();
  if(nAttachments != CB_ERR && nAttachments != 0)
  {
    for(int i = 0; i < nAttachments; i++)
    {
      pAttachment = new CSMTPAttachment;
      apAttachments.Add(pAttachment);

      m_Attachments.GetLBText(i, sAttachment);
      pAttachment->Attach(sAttachment);
      Message.AddAttachment(pAttachment);
    }
  }

  if(!Smtp.SendMessage(Message))
  {
    DWORD dwError = ::GetLastError();
    CString sResponse = Smtp.GetLastCommandResponse();
    g_WriteToOutput(TRUE, "[Mail] Failed to send the SMTP message" + sResponse);
    return;
  }
  else
  {
    g_WriteToHistory(TRUE, "[Mail] Sent mail to " + m_sTo);

    if(m_Clear.GetCheck())
    {
      m_Text.SetSel(0, -1);
      m_Text.Clear();
      m_To.SetEditSel(0, -1);
      m_To.Clear();
      m_Subject.SetEditSel(0, -1);
      m_Subject.Clear();
      m_Attachments.ResetContent();
    }
  }

  Smtp.Disconnect();

  nAttachments = apAttachments.GetSize();
  for(int i = 0; i < nAttachments; i++)
    delete apAttachments.GetAt(i);
  apAttachments.RemoveAll();
}

/////////////////////////////////////////////////////////////////////////////

void CPageMail::OnAttachments() 
{
  CFileDialog BrowseDialog(TRUE);
  if(BrowseDialog.DoModal() == IDOK)
  {
    CString sPath = BrowseDialog.GetPathName();
    if(!sPath.IsEmpty())
    {
      m_Attachments.EnableWindow(TRUE);
      m_Attachments.SetWindowText(sPath);
      m_Attachments.AddString(sPath);
    }
  }
}

/////////////////////////////////////////////////////////////////////////////

void CPageMail::OnSettings()
{
  CPageMailConfig MailConfig;
  MailConfig.m_psArrayMailSignature = m_psArrayMailSignature;
  MailConfig.m_sSignature = m_sSignature;
  if(MailConfig.DoModal() == IDOK)
  {
    m_sSignature = MailConfig.m_sSignature;
    m_psArrayMailSignature = MailConfig.m_psArrayMailSignature;
    OnChangeText();
  }
}

/////////////////////////////////////////////////////////////////////////////

void CPageMail::OnChangeText() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CPropertyPage::OnInitDialog()
	// function to send the EM_SETEVENTMASK message to the control
	// with the ENM_CHANGE flag ORed into the lParam mask.
	
	// TODO: Add your control notification handler code here

  UpdateData();
  int nLength = m_sText.GetLength();

  if(m_WithSignature.GetCheck())
    nLength += m_sSignature.GetLength();

  CString sLength;
  sLength.Format("%d", nLength);
  m_NumberOfChars.SetWindowText(sLength);
}

/////////////////////////////////////////////////////////////////////////////

void CPageMail::OnWithSignature() 
{
  OnChangeText();	
}

/////////////////////////////////////////////////////////////////////////////

BOOL CPageMail::PreTranslateMessage(MSG* pMsg) 
{
  if(pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_RETURN)
  {
    CWnd* pCurrent = GetFocus()->GetOwner();
    int nCurrent = pCurrent->GetDlgCtrlID();
    if(nCurrent == IDC_FROM
      || nCurrent == IDC_TO
      || nCurrent == IDC_SERVER
      || nCurrent == IDC_SUBJECT
      || nCurrent == IDC_XMAILER
      )
    {
      CString sCurrent;
      pCurrent->GetWindowText(sCurrent);
      if(sCurrent != "")
      {
        ((CComboBox*)pCurrent)->InsertString(-1, sCurrent);
        g_WriteToHistory(TRUE, "[Mail] Added " + sCurrent);
        ((CEdit*)GetFocus())->SetSel(0, -1);
      }
    }
    if(GetKeyState(VK_CONTROL) & 0x8000)
    {
      pMsg->message ^= WM_KEYDOWN;
      int nResult = MessageBox("Send mail?", NULL, MB_ICONQUESTION | MB_YESNO);
      if(nResult != IDNO)
        OnSend();
    }
  }

	return CPropertyPage::PreTranslateMessage(pMsg);
}

/////////////////////////////////////////////////////////////////////////////

void CPageMail::OnSetfocusAttachments() 
{
  CString sText;
  m_Attachments.GetWindowText(sText);
  if(sText.IsEmpty() && m_Attachments.GetCount() == 0)
    m_Attachments.EnableWindow(FALSE);
}

/////////////////////////////////////////////////////////////////////////////

void CPageMail::OnEditupdateAttachments() 
{
  OnSetfocusAttachments();	
}

/////////////////////////////////////////////////////////////////////////////

void CPageMail::OnWithmailer() 
{
  if(m_WithMailer.GetCheck())
    GetDlgItem(IDC_XMAILER)->EnableWindow(TRUE);
  else
    GetDlgItem(IDC_XMAILER)->EnableWindow(FALSE);
}

/////////////////////////////////////////////////////////////////////////////
