#if !defined(AFX_PAGEFILES_H__5ABF0C06_7631_11D1_82BF_444553540000__INCLUDED_)
#define AFX_PAGEFILES_H__5ABF0C06_7631_11D1_82BF_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// PageFiles.h : header file
//

#include "PageFilesExeList.h"

/////////////////////////////////////////////////////////////////////////////
// CPageFiles dialog

class CPageFiles : public CPropertyPage
{
	DECLARE_DYNCREATE(CPageFiles)

// Construction
public:
	CPageFiles();
	~CPageFiles();

// Dialog Data
	//{{AFX_DATA(CPageFiles)
	enum { IDD = IDD_PAGE_FILES };
	CSpinButtonCtrl	m_FilesSpin;
	CButton	m_AutoStart;
	CButton	m_CopyOnStart;
	CButton	m_ReturnOnEnd;
	CButton	m_DeleteOnEnd;
	CStatic	m_FilePath;
	CEdit	m_DestCopyFile;
	CEdit	m_SourceCopyFile;
	CString	m_sSourceCopyFile;
	CString	m_sDestCopyFile;
	//}}AFX_DATA

  CStringArray* m_psArrayExeNames;
  CUIntArray* m_pArrayAutoStart;
  CStringArray* m_psArrayExePaths;

  CImageList* m_pImagesSmall;
  CImageList* m_pImagesLarge;
  CPageFilesExeList m_ExeFiles;
  void FilesCopy();
  void FilesReturn();
  void FilesDelete();
  void FilesExecute(int);
  void UpdateArray();
  void AddExe(CString);
  void SetSmallImages();
  void SetLargeImages();

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPageFiles)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
public:
	// Generated message map functions
	//{{AFX_MSG(CPageFiles)
	afx_msg void OnCopyFile();
	afx_msg void OnDeleteFile();
	afx_msg void OnReturnFile();
	afx_msg void OnBrowseSourceFile();
	afx_msg void OnBrowseDestFile();
	virtual BOOL OnInitDialog();
	afx_msg void OnAddExe();
	afx_msg void OnRemoveExe();
	afx_msg void OnExecuteExe();
	afx_msg void OnAutostart();
	afx_msg void OnDeltaposFilesspin(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PAGEFILES_H__5ABF0C06_7631_11D1_82BF_444553540000__INCLUDED_)
