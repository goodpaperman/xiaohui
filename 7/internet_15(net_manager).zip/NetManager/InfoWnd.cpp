// InfoWnd.cpp : implementation file
//

#include "stdafx.h"
#include "netmanager.h"
#include "InfoWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CInfoWnd

CInfoWnd::CInfoWnd()
{
}

CInfoWnd::~CInfoWnd()
{
}


BEGIN_MESSAGE_MAP(CInfoWnd, CEdit)
	//{{AFX_MSG_MAP(CInfoWnd)
	ON_WM_SETFOCUS()
	ON_WM_RBUTTONDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CInfoWnd message handlers

void CInfoWnd::OnSetFocus(CWnd* pOldWnd) 
{
  pOldWnd->SetFocus();
}

/////////////////////////////////////////////////////////////////////////////

void CInfoWnd::OnRButtonDown(UINT nFlags, CPoint point) 
{
  SetSel(0, -1);	
	
	CEdit::OnRButtonDown(nFlags, point);
}
