// PageFiles.cpp : implementation file
//

#include "stdafx.h"
#include "NetManager.h"
#include "PageFiles.h"
#include "GlobalsExtern.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPageFiles property page

IMPLEMENT_DYNCREATE(CPageFiles, CPropertyPage)

CPageFiles::CPageFiles() : CPropertyPage(CPageFiles::IDD)
{
	//{{AFX_DATA_INIT(CPageFiles)
	m_sSourceCopyFile = _T("");
	m_sDestCopyFile = _T("");
	//}}AFX_DATA_INIT
}

CPageFiles::~CPageFiles()
{
}

void CPageFiles::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPageFiles)
	DDX_Control(pDX, IDC_FILESSPIN, m_FilesSpin);
	DDX_Control(pDX, IDB_AUTOSTART, m_AutoStart);
	DDX_Control(pDX, IDB_ONSTART_COPY, m_CopyOnStart);
	DDX_Control(pDX, IDB_ONEND_RETURN, m_ReturnOnEnd);
	DDX_Control(pDX, IDB_ONEND_DELETE, m_DeleteOnEnd);
	DDX_Control(pDX, IDC_FILEPATH, m_FilePath);
	DDX_Control(pDX, IDC_FILE_DEST, m_DestCopyFile);
	DDX_Control(pDX, IDC_FILE_SOURCE, m_SourceCopyFile);
	DDX_Text(pDX, IDC_FILE_SOURCE, m_sSourceCopyFile);
	DDX_Text(pDX, IDC_FILE_DEST, m_sDestCopyFile);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPageFiles, CPropertyPage)
	//{{AFX_MSG_MAP(CPageFiles)
	ON_BN_CLICKED(IDC_COPY_FILE, OnCopyFile)
	ON_BN_CLICKED(IDC_DELETE_FILE, OnDeleteFile)
	ON_BN_CLICKED(IDC_RETURN_FILE, OnReturnFile)
	ON_BN_CLICKED(IDC_BROWSE_SOURCEFILE, OnBrowseSourceFile)
	ON_BN_CLICKED(IDC_BROWSE_DESTFILE, OnBrowseDestFile)
	ON_BN_CLICKED(IDC_ADD_EXE, OnAddExe)
	ON_BN_CLICKED(IDC_REMOVE_EXE, OnRemoveExe)
	ON_BN_CLICKED(IDC_EXECUTE_EXE, OnExecuteExe)
	ON_BN_CLICKED(IDB_AUTOSTART, OnAutostart)
	ON_NOTIFY(UDN_DELTAPOS, IDC_FILESSPIN, OnDeltaposFilesspin)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPageFiles message handlers

UINT g_AddIcon(LPVOID pParam)
{
  CPtrArray* paIcon = ((CPtrArray*)pParam);
  CPageFilesExeList* pExeFiles = (CPageFilesExeList*)paIcon->GetAt(0);
  CStringArray* psArrayExeNames = (CStringArray*)paIcon->GetAt(1);
  CImageList* pImagesSmall = (CImageList*)paIcon->GetAt(2);
  CImageList* pImagesLarge = (CImageList*)paIcon->GetAt(3);

  CString sIconPath;
  char* psIconPath;
  int j = psArrayExeNames->GetSize();
  for(int i = 1; i < j; i += 2)
  {
    sIconPath = psArrayExeNames->GetAt(i);
    psIconPath = sIconPath.GetBuffer(MAX_PATH);

    WORD wIconIndex = 0;
    HICON hExeIcon;
    if((hExeIcon = ExtractIcon(AfxGetInstanceHandle(), psIconPath, 0)) != NULL)
    {
      pImagesSmall->Add(hExeIcon);
      pImagesLarge->Add(hExeIcon);
    }
    else if((hExeIcon = ExtractAssociatedIcon(AfxGetInstanceHandle(), psIconPath, &wIconIndex)) != NULL)
    {
      pImagesSmall->Add(hExeIcon);
      pImagesLarge->Add(hExeIcon);
    }
    psArrayExeNames->GetAt(i).ReleaseBuffer();

    pExeFiles->Update(i / 2);
  }

  paIcon->RemoveAll();
  delete paIcon;

  return 0;
}

/////////////////////////////////////////////////////////////////////////////

BOOL CPageFiles::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();

  m_CopyOnStart.SetCheck(g_pThisApp->GetProfileInt("Files Copy", "CopyOnStart", 0));
  m_ReturnOnEnd.SetCheck(g_pThisApp->GetProfileInt("Files Copy", "ReturnOnEnd", 0));
  m_DeleteOnEnd.SetCheck(g_pThisApp->GetProfileInt("Files Copy", "DeleteOnEnd", 0));

  m_ExeFiles.SubclassDlgItem(IDC_EXE_FILES, this);

// image list ---------------------------------------------------------------

  m_pImagesSmall = new CImageList;
  m_pImagesSmall->Create(16, 16, ILC_COLORDDB | ILC_MASK, 1, 100);
  m_pImagesLarge = new CImageList;
  m_pImagesLarge->Create(32, 32, ILC_COLORDDB | ILC_MASK, 1, 100);

  CImageList* pStates = new CImageList;
  pStates->Create(16, 16, ILC_COLORDDB | ILC_MASK, 2, 0);
  pStates->Add(g_pThisApp->LoadIcon(IDI_UNCHECKED));
  pStates->Add(g_pThisApp->LoadIcon(IDI_CHECKED));

	m_ExeFiles.SetImageList(pStates, LVSIL_STATE);

  int nWidth = g_pThisApp->GetProfileInt("NetManager", "ExeWindowWidth", 100);
  if(nWidth <= 0)
    nWidth = 100;
  m_FilesSpin.SetRange(32, 400);
  m_FilesSpin.SetPos(nWidth);
  m_ExeFiles.SetColumnWidth(0, nWidth);

  if(!g_bExeImages)
    SetSmallImages();
  else
    SetLargeImages();

// add items ----------------------------------------------------------------

  m_psArrayExePaths = new CStringArray;
  int i = m_psArrayExeNames->GetSize();

  int k = 0;
  int j = 0;
  WORD wIconIndex = 0;
  while(i != j)
  {
    m_ExeFiles.InsertItem(k, m_psArrayExeNames->GetAt(j));
    j++;
    m_ExeFiles.SetItem(k, NULL, LVIF_IMAGE, NULL, k, NULL, NULL, NULL);
    m_ExeFiles.SetItemState(k, INDEXTOSTATEIMAGEMASK(m_pArrayAutoStart->GetAt(k) + 1), LVIS_STATEIMAGEMASK);
    m_psArrayExePaths->Add(m_psArrayExeNames->GetAt(j));
    j++;
    k++;
  }

  CPtrArray* paIcon = new CPtrArray;
  paIcon->Add(&m_ExeFiles);
  paIcon->Add(m_psArrayExeNames);
  paIcon->Add(m_pImagesSmall);
  paIcon->Add(m_pImagesLarge);
  AfxBeginThread(g_AddIcon, paIcon);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

/////////////////////////////////////////////////////////////////////////////

void CPageFiles::SetSmallImages()
{
  m_ExeFiles.SetImageList(m_pImagesSmall, LVSIL_SMALL);
  m_ExeFiles.SetColumnWidth(0, m_FilesSpin.GetPos());
}

/////////////////////////////////////////////////////////////////////////////

void CPageFiles::SetLargeImages()
{
  m_ExeFiles.SetImageList(m_pImagesLarge, LVSIL_SMALL);
  m_ExeFiles.SetColumnWidth(0, m_FilesSpin.GetPos());
}

/////////////////////////////////////////////////////////////////////////////

void CPageFiles::UpdateArray()
{
  CString sWork;
  m_psArrayExeNames->RemoveAll();
  int i = 0;
  int j = m_ExeFiles.GetItemCount();
  while(i != j)
  {
    m_psArrayExeNames->Add(m_ExeFiles.GetItemText(i, NULL));
    m_psArrayExeNames->Add(m_psArrayExePaths->GetAt(i++));
  }
}

/////////////////////////////////////////////////////////////////////////////

UINT g_Execute(LPVOID pParam)
{
  CString sFileToExe = ((CStringArray*)pParam)->GetAt(0);
  CString sFileName = ((CStringArray*)pParam)->GetAt(1);
  ((CStringArray*)pParam)->RemoveAll();
  delete ((CStringArray*)pParam);

  if((int)ShellExecute(::GetDesktopWindow(), _T("open"), sFileToExe, NULL, NULL, SW_NORMAL) < 33)
    g_WriteToHistory(TRUE, "[Files] Error - Execute File " + sFileToExe);
  else
    g_WriteToHistory(TRUE, "[Files] Executed " + sFileName);
  return 0;
}

/////////////////////////////////////////////////////////////////////////////

void CPageFiles::FilesExecute(int nWhich) 
{
  g_AnimateWait->Play(0, -1, -1);

  CString sFileToExe;
  CStringArray* pasFiles = new CStringArray;
  pasFiles->Add(m_psArrayExePaths->GetAt(nWhich));
  pasFiles->Add(m_ExeFiles.GetItemText(nWhich, 0));
  AfxBeginThread(g_Execute, pasFiles);
}

/////////////////////////////////////////////////////////////////////////////

void CPageFiles::OnCopyFile() 
{
  UpdateData();
  FilesCopy();
}

/////////////////////////////////////////////////////////////////////////////

void CPageFiles::FilesCopy() 
{
  g_AnimateWait->Play(0, -1, -1);

  if(!CopyFile(m_sSourceCopyFile, m_sDestCopyFile, FALSE))
    g_WriteToHistory(TRUE, "[Files] Error - Copy file " + m_sSourceCopyFile + " -> " + m_sDestCopyFile);
  else
    g_WriteToHistory(TRUE, "[Files] File copied (" + m_sSourceCopyFile + " -> " + m_sDestCopyFile + ")");
}

/////////////////////////////////////////////////////////////////////////////

void CPageFiles::OnReturnFile() 
{
  UpdateData();
  FilesReturn();
}

/////////////////////////////////////////////////////////////////////////////

void CPageFiles::FilesReturn() 
{
  g_AnimateWait->Play(0, -1, -1);
  if(!CopyFile(m_sDestCopyFile, m_sSourceCopyFile, FALSE))
    g_WriteToHistory(TRUE, "[Files] Error - Return file " + m_sDestCopyFile + " -> " + m_sSourceCopyFile);
  else
    g_WriteToHistory(TRUE, "[Files] File returned (" + m_sDestCopyFile + " -> " + m_sSourceCopyFile + ")");
}

/////////////////////////////////////////////////////////////////////////////

void CPageFiles::OnDeleteFile() 
{
  UpdateData();
  FilesDelete();
}

/////////////////////////////////////////////////////////////////////////////

void CPageFiles::FilesDelete() 
{
  g_AnimateWait->Play(0, -1, -1);
  if(!DeleteFile(m_sDestCopyFile))
    g_WriteToHistory(TRUE, "[Files] Error - Delete file (" + m_sDestCopyFile + ")");
  else
    g_WriteToHistory(TRUE, "[Files] File deleted (" + m_sDestCopyFile + ")");
}

/////////////////////////////////////////////////////////////////////////////

void CPageFiles::OnBrowseSourceFile() 
{
  UpdateData();
  CFileDialog BrowseDialog(TRUE);
  if(BrowseDialog.DoModal() == IDOK)
  {
    m_sSourceCopyFile = BrowseDialog.GetPathName();
    m_SourceCopyFile.SetWindowText(m_sSourceCopyFile);
  }
}

/////////////////////////////////////////////////////////////////////////////

void CPageFiles::OnBrowseDestFile() 
{
  UpdateData();
  CFileDialog BrowseDialog(TRUE);
  if(BrowseDialog.DoModal() == IDOK)
  {
    m_sDestCopyFile = BrowseDialog.GetPathName();
    m_DestCopyFile.SetWindowText(m_sDestCopyFile);
  }
}

/////////////////////////////////////////////////////////////////////////////

void CPageFiles::OnAddExe() 
{
  CFileDialog AddExeDialog(TRUE);
  if(AddExeDialog.DoModal() == IDOK)
    AddExe(AddExeDialog.GetPathName());
}

/////////////////////////////////////////////////////////////////////////////

void CPageFiles::AddExe(CString sPath)
{
  m_psArrayExePaths->Add(sPath);
  m_pArrayAutoStart->Add(0);
  CString sName = sPath;
  sName.MakeReverse();
  sName = sName.Left(sName.Find('\\'));
  sName.MakeReverse();
  int i = m_ExeFiles.InsertItem(m_ExeFiles.GetItemCount(), sName);
  if(i != -1)
  {
    HICON hExeIcon;
    char* psIconPath;
    WORD wIconIndex = 0;
    psIconPath = sPath.GetBuffer(MAX_PATH);

    if((hExeIcon = ExtractIcon(AfxGetInstanceHandle(), psIconPath, 0)) != NULL)
    {
      m_pImagesSmall->Add(hExeIcon);
      m_pImagesLarge->Add(hExeIcon);
    }
    else if((hExeIcon = ExtractAssociatedIcon(AfxGetInstanceHandle(), psIconPath, &wIconIndex)) != NULL)
    {
      m_pImagesSmall->Add(hExeIcon);
      m_pImagesLarge->Add(hExeIcon);
    }
    sPath.ReleaseBuffer();
    m_ExeFiles.SetItem(i, NULL, LVIF_IMAGE, NULL, i, NULL, NULL, NULL);
    m_ExeFiles.SetItemState(i, INDEXTOSTATEIMAGEMASK(1), LVIS_STATEIMAGEMASK);

    g_WriteToHistory(TRUE, "[Files] Added " + sName);
  }
}

/////////////////////////////////////////////////////////////////////////////

void CPageFiles::OnRemoveExe() 
{
  if(m_ExeFiles.GetSelectedCount() != 0)
  {
    if(MessageBox("Remove this item???", NULL, MB_ICONQUESTION | MB_YESNO) == IDYES)
    {
      int nWhichItem = 0;
      if(m_ExeFiles.GetSelectedCount() == 1)
      {
        while(m_ExeFiles.GetItemState(nWhichItem, LVIS_SELECTED) != LVIS_SELECTED)
          nWhichItem++;
      }
      g_WriteToHistory(TRUE, "[Files] Removed " + m_ExeFiles.GetItemText(nWhichItem, 0));
      m_ExeFiles.DeleteItem(nWhichItem);
      m_psArrayExePaths->RemoveAt(nWhichItem);
      m_pArrayAutoStart->RemoveAt(nWhichItem);
      m_pImagesSmall->Remove(nWhichItem);
      m_pImagesLarge->Remove(nWhichItem);
      m_FilePath.SetWindowText("");

      int j = m_ExeFiles.GetItemCount();
      for(int i = 0; i < j; i++)
      {
        m_ExeFiles.SetItem(i, NULL, LVIF_IMAGE, NULL, i, NULL, NULL, NULL);
        m_ExeFiles.SetItemState(i, INDEXTOSTATEIMAGEMASK(m_pArrayAutoStart->GetAt(i) + 1), LVIS_STATEIMAGEMASK);
      }
    }
  }
}

/////////////////////////////////////////////////////////////////////////////

void CPageFiles::OnExecuteExe() 
{
  if(m_ExeFiles.GetSelectedCount() != 0)
  {
    int nWhichItem = 0;
    if(m_ExeFiles.GetSelectedCount() == 1)
    {
      while(m_ExeFiles.GetItemState(nWhichItem, LVIS_SELECTED) != LVIS_SELECTED)
        nWhichItem++;
    }
    FilesExecute(nWhichItem);
  }
}

/////////////////////////////////////////////////////////////////////////////

void CPageFiles::OnAutostart() 
{
  if(m_ExeFiles.GetSelectedCount() != 0)
    m_ExeFiles.SwitchExeAuto();
}

/////////////////////////////////////////////////////////////////////////////

BOOL CPageFiles::PreTranslateMessage(MSG* pMsg) 
{
  if(pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_RETURN)
  {
    switch(GetFocus()->GetDlgCtrlID())
    {
      case IDC_FILE_SOURCE:
        NextDlgCtrl();
        break;
      case IDC_FILE_DEST:
        NextDlgCtrl();
        break;
    }
  }	

	return CPropertyPage::PreTranslateMessage(pMsg);
}

/////////////////////////////////////////////////////////////////////////////

void CPageFiles::OnDeltaposFilesspin(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;

  m_ExeFiles.SetColumnWidth(0, m_FilesSpin.GetPos());
	
	*pResult = 0;
}

/////////////////////////////////////////////////////////////////////////////
