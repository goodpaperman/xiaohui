// PageNetList.cpp : implementation file
//

#include "stdafx.h"
#include "netmanager.h"
#include "PageNet.h"
#include "PageNetList.h"
#include "GlobalsExtern.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPageNetList

CPageNetList::CPageNetList()
{
}

CPageNetList::~CPageNetList()
{
}


BEGIN_MESSAGE_MAP(CPageNetList, CListBox)
	//{{AFX_MSG_MAP(CPageNetList)
	ON_WM_KEYDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPageNetList message handlers

void CPageNetList::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
  if(nChar == VK_DELETE)
  {
    int nCurSel = GetCurSel();
    if(nCurSel != LB_ERR)
    {
      if(MessageBox("Remove this item???", NULL, MB_ICONQUESTION | MB_YESNO) == IDYES)
      {
        g_WriteToHistory(TRUE, "[Net] Removed " + ((CPageNet*)GetParent())->m_psArrayNet->GetAt(nCurSel * 2));
        DeleteString(nCurSel);
        ((CPageNet*)GetParent())->m_psArrayNet->RemoveAt(nCurSel * 2 + 1);
        ((CPageNet*)GetParent())->m_psArrayNet->RemoveAt(nCurSel * 2);
        ((CPageNet*)GetParent())->m_StatusLine.SetWindowText("");
      }
    }
	}

	CListBox::OnKeyDown(nChar, nRepCnt, nFlags);
}

/////////////////////////////////////////////////////////////////////////////
