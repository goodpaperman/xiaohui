#if !defined(AFX_PAGEMAIL_H__E60D4643_763C_11D1_82BF_444553540000__INCLUDED_)
#define AFX_PAGEMAIL_H__E60D4643_763C_11D1_82BF_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// PageMail.h : header file
//

#include "PageMailDelCurrent.h"
#include "ComboBoxEx.h"

/////////////////////////////////////////////////////////////////////////////
// CPageMail dialog

class CPageMail : public CPropertyPage
{
	DECLARE_DYNCREATE(CPageMail)

// Construction
public:
	CPageMail();
	~CPageMail();

// Dialog Data
	//{{AFX_DATA(CPageMail)
	enum { IDD = IDD_PAGE_MAIL };
	CComboBox	m_Attachments;
	CButton	m_WithDate;
	CButton	m_WithMailer;
	CStatic	m_NumberOfChars;
	CButton	m_WithSignature;
	CButton	m_Clear;
	CEdit	m_Text;
	CString	m_sFrom;
	CString	m_sServer;
	CString	m_sSubject;
	CString	m_sText;
	CString	m_sTo;
	CString	m_sXMailer;
	//}}AFX_DATA

  CComboBoxEx m_Subject;
	CComboBoxEx	m_Program;
	CComboBoxEx	m_Server;
	CComboBoxEx	m_From;
	CComboBoxEx	m_To;
  CStringArray* m_psArrayMailServer;
  CStringArray* m_psArrayMailProgram;
  CStringArray* m_psArrayMailFrom;
  CStringArray* m_psArrayMailTo;
  CStringArray* m_psArrayMailSubject;
  CStringArray* m_psArrayMailSignature;
  CEdit* m_pOutput;
  CString m_sSignature;
  CPageMailDelCurrent m_DelCurrent;

  void UpdateArrays(CStringArray*, CComboBox*);

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPageMail)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPageMail)
	virtual BOOL OnInitDialog();
	afx_msg void OnSend();
	afx_msg void OnSettings();
	afx_msg void OnChangeText();
	afx_msg void OnWithSignature();
	afx_msg void OnAttachments();
	afx_msg void OnSetfocusAttachments();
	afx_msg void OnWithmailer();
	afx_msg void OnEditupdateAttachments();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PAGEMAIL_H__E60D4643_763C_11D1_82BF_444553540000__INCLUDED_)
