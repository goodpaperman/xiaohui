#if !defined(AFX_PAGEGENERAL_H__E60D4642_763C_11D1_82BF_444553540000__INCLUDED_)
#define AFX_PAGEGENERAL_H__E60D4642_763C_11D1_82BF_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// PageGeneral.h : header file
//

#include "Netnode.h"
#include "Ping.h"

/////////////////////////////////////////////////////////////////////////////
// CPageGeneral dialog

class CPageGeneral : public CPropertyPage
{
	DECLARE_DYNCREATE(CPageGeneral)

// Construction
public:
	CPageGeneral();
	~CPageGeneral();

//  CToolTipCtrl* m_ToolTip;

//  CString ResolveAddress(CString);

  CPing m_p;
  CPingReply m_pr;

  CNetNode* m_pRootNode;
  void CreateRootNode();
  void AddNodeToTree(CNetNode*, HTREEITEM);
  void UpdateDisplay(LPTV_ITEM);

// Dialog Data
	//{{AFX_DATA(CPageGeneral)
	enum { IDD = IDD_PAGE_GENERAL };
	CButton	m_Resolve;
	CButton	m_Ping;
	CButton	m_Enumerate;
	CEdit	m_Address;
	CTreeCtrl	m_Tree;
	CString	m_sDisplayType;
	CString	m_sLocalName;
	CString	m_sProvider;
	CString	m_sRemoteName;
	CString	m_sScope;
	CString	m_sType;
	CString	m_sUsage;
	CString	m_sComment;
	DWORD	m_dwPingTimeout;
	BYTE	m_bPingPacket;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPageGeneral)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPageGeneral)
	virtual BOOL OnInitDialog();
	afx_msg void OnResolve();
	afx_msg void OnItemexpandingTree(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSelchangedTree(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnEnumerate();
	afx_msg void OnPing();
	afx_msg void OnChangeAddress();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PAGEGENERAL_H__E60D4642_763C_11D1_82BF_444553540000__INCLUDED_)
