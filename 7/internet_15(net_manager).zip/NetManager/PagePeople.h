#if !defined(AFX_PAGEPEOPLE_H__E60D4644_763C_11D1_82BF_444553540000__INCLUDED_)
#define AFX_PAGEPEOPLE_H__E60D4644_763C_11D1_82BF_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// PagePeople.h : header file
//

#include "PagePeopleList.h"

#define   ICON_SERVER   0
#define   ICON_USER     1
#define   ICON_MANUAL   2
#define   ICON_MAIL     3
#define   ICON_EMPTY    4

/////////////////////////////////////////////////////////////////////////////
// CPagePeople dialog

class CPagePeople : public CPropertyPage
{
	DECLARE_DYNCREATE(CPagePeople)

// Construction
public:
	CPagePeople();
	~CPagePeople();

// Dialog Data
	//{{AFX_DATA(CPagePeople)
	enum { IDD = IDD_PAGE_PEOPLE };
	CButton	m_LocalNet;
	CSpinButtonCtrl	m_PeopleSpin;
	CButton	m_CheckAll;
	CButton	m_Active;
	CButton	m_IsManual;
	CButton	m_ActiveMail;
	CButton	m_Every;
	CButton	m_OnStart;
	CButton	m_OnEnd;
	CEdit	m_User;
	CEdit	m_Server;
	CString	m_sServer;
	CString	m_sUser;
	int		m_nPeopleMinutes;
	//}}AFX_DATA

  CImageList* m_pImagesSmall;
  CImageList* m_pImagesLarge;

  CPagePeopleList m_ServerTree;
	TV_INSERTSTRUCT* m_pTreeCtrlItem;
  CPtrArray* m_pAllServersArray;

  void ItemInsert(LPCTSTR);
  void ItemInsert(LPCTSTR, LPCTSTR);
  void FingerManual(CString, CString);
  void SavePeople();
  void AddServer();
  void AddUser();
  void ResetServersAndUsers();
  bool IfCanCheckAll();
  bool CheckAll(CString&);
  void SetSmallImages();
  void SetLargeImages();

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPagePeople)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
//protected:
public:
	// Generated message map functions
	//{{AFX_MSG(CPagePeople)
	virtual BOOL OnInitDialog();
	afx_msg void OnRemove();
	afx_msg void OnFinger();
	afx_msg void OnFingerManual();
	afx_msg void OnFingerCurrent();
	afx_msg void OnDblclkServertree(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnActive();
	afx_msg void OnActiveMail();
	afx_msg void OnIsManual();
	afx_msg void OnCheckAll();
	afx_msg void OnEvery();
	afx_msg void OnKillfocusMinutes();
	afx_msg void OnLocalNet();
	afx_msg void OnChangeFingerserver();
	afx_msg void OnChangeFingeruser();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PAGEPEOPLE_H__E60D4644_763C_11D1_82BF_444553540000__INCLUDED_)
