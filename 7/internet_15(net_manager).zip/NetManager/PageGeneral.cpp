// PageGeneral.cpp : implementation file
//

#include "stdafx.h"
#include "NetManager.h"
#include "PageGeneral.h"
#include "GlobalsExtern.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPageGeneral property page

IMPLEMENT_DYNCREATE(CPageGeneral, CPropertyPage)

CPageGeneral::CPageGeneral() : CPropertyPage(CPageGeneral::IDD)
{
	//{{AFX_DATA_INIT(CPageGeneral)
	m_sDisplayType = _T("");
	m_sLocalName = _T("");
	m_sProvider = _T("");
	m_sRemoteName = _T("");
	m_sScope = _T("");
	m_sType = _T("");
	m_sUsage = _T("");
	m_sComment = _T("");
	m_dwPingTimeout = 1000;
	m_bPingPacket = 32;
	//}}AFX_DATA_INIT
}

CPageGeneral::~CPageGeneral()
{
}

void CPageGeneral::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPageGeneral)
	DDX_Control(pDX, IDC_RESOLVE, m_Resolve);
	DDX_Control(pDX, IDC_PING, m_Ping);
	DDX_Control(pDX, IDC_ENUMERATE, m_Enumerate);
	DDX_Control(pDX, IDC_ADDRESS, m_Address);
	DDX_Control(pDX, IDC_TREE, m_Tree);
	DDX_Text(pDX, IDC_DISPLAY_TYPE, m_sDisplayType);
	DDX_Text(pDX, IDC_LOCAL_NAME, m_sLocalName);
	DDX_Text(pDX, IDC_PROVIDER, m_sProvider);
	DDX_Text(pDX, IDC_REMOTE_NAME, m_sRemoteName);
	DDX_Text(pDX, IDC_SCOPE, m_sScope);
	DDX_Text(pDX, IDC_TYPE, m_sType);
	DDX_Text(pDX, IDC_USAGE, m_sUsage);
	DDX_Text(pDX, IDC_COMMENT, m_sComment);
	DDX_Text(pDX, IDC_PING_TIMEOUT, m_dwPingTimeout);
	DDV_MinMaxDWord(pDX, m_dwPingTimeout, 0, 100000);
	DDX_Text(pDX, IDC_PING_PACKET, m_bPingPacket);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPageGeneral, CPropertyPage)
	//{{AFX_MSG_MAP(CPageGeneral)
	ON_BN_CLICKED(IDC_RESOLVE, OnResolve)
	ON_NOTIFY(TVN_ITEMEXPANDING, IDC_TREE, OnItemexpandingTree)
	ON_NOTIFY(TVN_SELCHANGED, IDC_TREE, OnSelchangedTree)
	ON_BN_CLICKED(IDC_ENUMERATE, OnEnumerate)
	ON_BN_CLICKED(IDC_PING, OnPing)
	ON_EN_CHANGE(IDC_ADDRESS, OnChangeAddress)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPageGeneral message handlers

BOOL CPageGeneral::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

/////////////////////////////////////////////////////////////////////////////

UINT g_ResolveAddress(LPVOID pParam)
{
  CString sAddress = *((CString*)pParam);
  delete ((CString*)pParam);

  CString sResolved;
  unsigned long ulIP;
  hostent* pHostent;
  sockaddr_in sin;

  ulIP = inet_addr(sAddress);

  if(ulIP != INADDR_NONE)
  {
    sin.sin_family = AF_INET;
    sin.sin_addr.S_un.S_addr = ulIP;
    pHostent = gethostbyaddr((char*)&sin.sin_addr, 4, PF_INET);
    if(pHostent)
      sResolved = pHostent->h_name;
    else
    {
      g_WriteToOutput(TRUE, "[Resolve] Cannot resolve " + sAddress);
      return 0;
    }
  }
  else
  {
    in_addr inetAddr;

    pHostent = gethostbyname(sAddress);
    if(pHostent)
    {
      LPSTR szAddr;
      ulIP = *(DWORD*)(*pHostent->h_addr_list);
      inetAddr.s_addr = ulIP;
      szAddr = inet_ntoa(inetAddr);
      sResolved = szAddr;
    }
    else
    {
      g_WriteToOutput(TRUE, "[Resolve] Cannot resolve " + sAddress);
      return 0;
    }
  }

  g_WriteToOutput(TRUE, "[Resolve] " + sAddress + " -> " + sResolved);

  return 0;
}

/////////////////////////////////////////////////////////////////////////////

void CPageGeneral::OnResolve() 
{
  g_AnimateWait->Play(0, -1, -1);

  CString sResolveAddress;
  m_Address.GetWindowText(sResolveAddress);

  CString* psAddress = new CString(sResolveAddress);
  AfxBeginThread(g_ResolveAddress, psAddress);
}

/////////////////////////////////////////////////////////////////////////////

void CPageGeneral::OnChangeAddress() 
{
  CString sText;
  m_Address.GetWindowText(sText);
  if(sText != "")
  {
    m_Resolve.EnableWindow(TRUE);
    m_Enumerate.EnableWindow(TRUE);
    m_Ping.EnableWindow(TRUE);
    GetDlgItem(IDC_PING_PACKET)->EnableWindow(TRUE);
    GetDlgItem(IDC_PING_TIMEOUT)->EnableWindow(TRUE);
  }
  else
  {
    m_Resolve.EnableWindow(FALSE);
    m_Enumerate.EnableWindow(FALSE);
    m_Ping.EnableWindow(FALSE);
    GetDlgItem(IDC_PING_PACKET)->EnableWindow(FALSE);
    GetDlgItem(IDC_PING_TIMEOUT)->EnableWindow(FALSE);
  }
}

/////////////////////////////////////////////////////////////////////////////

void CPageGeneral::CreateRootNode()
{
  m_pRootNode = new CNetNode;   // Create the root network node (use default constructor)
  AddNodeToTree(m_pRootNode, TVI_ROOT);   // Add root node to tree
  UpdateDisplay(NULL);
}

/////////////////////////////////////////////////////////////////////////////

void CPageGeneral::AddNodeToTree(CNetNode* pNode, HTREEITEM parent)
{
  TV_INSERTSTRUCT    tvIns = { 0 };

  tvIns.hParent = parent;
  tvIns.hInsertAfter = TVI_SORT;
  tvIns.item.mask = TVIF_TEXT | TVIF_CHILDREN | TVIF_PARAM;

  // It is safe to cast away the const-ness here because
  // we do not allow the tree labels to be edited
  tvIns.item.pszText =
    (char *) ((const char *)pNode->GetText());

  if (pNode->IsContainer())
    tvIns.item.cChildren = 1;
  tvIns.item.lParam = (LPARAM) pNode;

  HTREEITEM hItem = m_Tree.InsertItem(&tvIns);
}

/////////////////////////////////////////////////////////////////////////////

void CPageGeneral::OnItemexpandingTree(NMHDR* pNMHDR, LRESULT* pResult) 
{
  NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
  
  LPTV_ITEM pParent = &pNMTreeView->itemNew;

  // Assume we will return FALSE,
  // allowing the expansion to occur
  *pResult = FALSE;

  // If the action is NOT expand, or if we have
  // already expanded at least once, we don't need
  // to do anything here
  if ( pNMTreeView->action != TVE_EXPAND ||
       (pParent->state & TVIS_EXPANDEDONCE) )
    return;

  // Get a handle to the parent item
  TV_ITEM    tvItem;
  tvItem.hItem = pParent->hItem;
  tvItem.mask = TVIF_HANDLE;
  m_Tree.GetItem(&tvItem);

  // We are expanding an item for the first time
  // Enumerate its children and add them to the tree
  DWORD   numChildren = 0;
  DWORD   ret = 0;

  CNetNode * pParentNode = (CNetNode *) pParent->lParam;

  {
    CWaitCursor  wc;  // display hourglass cursor
    ret = pParentNode->EnumerateNetwork();
  }

  if (ret)
  {
    static const DWORD maxMsgLen = 1024;
    CString errMsg;
    char * pMsgBuf = errMsg.GetBuffer(maxMsgLen);

    DWORD formatRet = FormatMessage(
      FORMAT_MESSAGE_IGNORE_INSERTS |
      FORMAT_MESSAGE_FROM_SYSTEM,
      NULL, ret, 0, pMsgBuf, maxMsgLen, NULL);

    errMsg.ReleaseBuffer();

    if (formatRet == 0)
      errMsg.Format("Network enumeration failed.  \n\n"
      "Error code: %lu.", ret);

    MessageBox(errMsg, "Error",
     MB_ICONEXCLAMATION | MB_OK);
  }
  else
  {
    CNetNode * pChildNode;
    numChildren = pParentNode->GetChildCount();

    for (DWORD i = 0; i < numChildren; i++)
    {
      pChildNode = pParentNode->GetChildNode(i);
      AddNodeToTree(pChildNode, tvItem.hItem);
    }
  }

  // If there are no child items, or an error occurred,
  // remove the "+" from the parent item by indicating
  // it has no child items
  if (ret || numChildren == 0)
  {
    tvItem.mask |= TVIF_CHILDREN;
    tvItem.cChildren = 0;
    m_Tree.SetItem(&tvItem);

    // indicate that tree expansion should NOT occur
    *pResult = TRUE;
  }
}

/////////////////////////////////////////////////////////////////////////////

void CPageGeneral::OnSelchangedTree(NMHDR* pNMHDR, LRESULT* pResult) 
{
  NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;

  LPTV_ITEM pNewItem = &pNMTreeView->itemNew;
  UpdateDisplay(pNewItem);
  *pResult = 0;
}

/////////////////////////////////////////////////////////////////////////////

void CPageGeneral::UpdateDisplay(LPTV_ITEM pItem)
{
  CNetNode* pNode;

  if (pItem == NULL)
    pNode = m_pRootNode;
  else
    pNode = (CNetNode*)pItem->lParam;

  // Get text items from net node

  m_sLocalName = pNode->GetLocalName();
  m_sRemoteName = pNode->GetRemoteName();
  m_sComment = pNode->GetComment();
  m_sProvider = pNode->GetProvider();

  // Get numeric items from net node
  DWORD scope = pNode->GetScope();
  DWORD type = pNode->GetType();
  DWORD displayType = pNode->GetDisplayType();
  DWORD usage = pNode->GetUsage();

  // Convert numeric codes to text for display
  if (scope == RESOURCE_CONNECTED)
      m_sScope = "CONNECTED";
  else if (scope == RESOURCE_GLOBALNET)
      m_sScope = "GLOBALNET";
  else if (scope == RESOURCE_REMEMBERED)
      m_sScope = "REMEMBERED";
#if(WINVER >= 0x0400)
  else if (scope == RESOURCE_RECENT)
      m_sScope = "RECENT";
  else if (scope == RESOURCE_CONTEXT)
      m_sScope = "CONTEXT";
#endif // WINVER >= 0x0400

  if (type == RESOURCETYPE_UNKNOWN)
    m_sType = "UNKNOWN";
  else
  {
    m_sType = "";
    if (type & RESOURCETYPE_ANY)
      m_sType += "ANY ";
    if (type & RESOURCETYPE_DISK)
      m_sType += "DISK ";
    if (type & RESOURCETYPE_PRINT)
      m_sType += "PRINT ";
  }
    
  if (displayType == RESOURCEDISPLAYTYPE_GENERIC)
    m_sDisplayType = "GENERIC";
  else if (displayType == RESOURCEDISPLAYTYPE_DOMAIN)
    m_sDisplayType = "DOMAIN";
  else if (displayType == RESOURCEDISPLAYTYPE_SERVER)
    m_sDisplayType = "SERVER";
  else if (displayType == RESOURCEDISPLAYTYPE_SHARE)
    m_sDisplayType = "SHARE";
  else if (displayType == RESOURCEDISPLAYTYPE_FILE)
    m_sDisplayType = "FILE";
  else if (displayType == RESOURCEDISPLAYTYPE_GROUP)
    m_sDisplayType = "GROUP";
#if(WINVER >= 0x0400)
  else if (displayType == RESOURCEDISPLAYTYPE_NETWORK)
    m_sDisplayType = "NETWORK";
  else if (displayType == RESOURCEDISPLAYTYPE_ROOT)
    m_sDisplayType = "ROOT";
  else if (displayType == RESOURCEDISPLAYTYPE_SHAREADMIN)
    m_sDisplayType = "SHAREADMIN";
  else if (displayType == RESOURCEDISPLAYTYPE_DIRECTORY)
    m_sDisplayType = "DIRECTORY";
#endif /* WINVER >= 0x0400 */
  else if (displayType == RESOURCEDISPLAYTYPE_TREE)
    m_sDisplayType = "TREE";

  m_sUsage = "";
#if(WINVER >= 0x0400)
  if ((usage & RESOURCEUSAGE_ALL) == RESOURCEUSAGE_ALL)
    m_sUsage += "ALL ";
  else
#endif
  {
    if (usage & RESOURCEUSAGE_CONNECTABLE)
      m_sUsage += "CONNECTABLE ";
    if (usage & RESOURCEUSAGE_CONTAINER)
      m_sUsage += "CONTAINER ";
  }

  if (usage & RESOURCEUSAGE_NOLOCALDEVICE)
    m_sUsage += "NOLOCALDEVICE ";
  if (usage & RESOURCEUSAGE_SIBLING)
    m_sUsage += "SIBLING ";

  UpdateData(FALSE);  // copy member variables to screen
}

/////////////////////////////////////////////////////////////////////////////

UINT g_Enumerate(LPVOID pParam)
{
  CString sAddress = *((CString*)pParam);
  delete ((CString*)pParam);

  g_WriteToOutput(TRUE, "[Enumerate] Started: " + sAddress);
  g_AnimateWait->Play(0, -1, -1);

  CString sOutput;
  hostent* pHostent;

  unsigned long ulIpAddress = inet_addr(sAddress);

  if(ulIpAddress == INADDR_NONE)
  {
    pHostent = gethostbyname(sAddress);
    if(pHostent)
      ulIpAddress = *(DWORD*)(*pHostent->h_addr_list);
  }

  ulIpAddress &= 0x00ffffff;

  for(int i = 0; i < 255; i++)
  {
    if(pHostent = gethostbyaddr((LPCSTR)&ulIpAddress, 4, PF_INET))
    {
      sOutput = pHostent->h_name;
      in_addr inaddr;
      inaddr.s_addr = ulIpAddress;
      CString sIpAddress = inet_ntoa(inaddr);
      g_WriteToOutput(TRUE, sOutput + " - " + sIpAddress);
    }
    ulIpAddress += 0x01000000;
  }

  g_WriteToOutput(TRUE, "[Enumerate] Finished...");

  return 0;
}

/////////////////////////////////////////////////////////////////////////////

void CPageGeneral::OnEnumerate() 
{
  CString sAddress;
  m_Address.GetWindowText(sAddress);

  CString* psAddress = new CString(sAddress);
  AfxBeginThread(g_Enumerate, psAddress);
}

/////////////////////////////////////////////////////////////////////////////

void CPageGeneral::OnPing() 
{
  if(UpdateData())
  {
    CString sAddress;
    m_Address.GetWindowText(sAddress);

    char* psOutput = new char[1000];
    if(m_p.Ping(sAddress, m_pr, 10, m_dwPingTimeout, m_bPingPacket))
    {
      hostent* phostent = gethostbyaddr((char*)&m_pr.Address.S_un.S_addr, 4, PF_INET);
      sprintf(psOutput, "[Ping] %d.%d.%d.%d [%s], replied in RTT:%d ms", 
           m_pr.Address.S_un.S_un_b.s_b1, m_pr.Address.S_un.S_un_b.s_b2, m_pr.Address.S_un.S_un_b.s_b3, 
           m_pr.Address.S_un.S_un_b.s_b4, phostent->h_name, m_pr.RTT);
    }
    else
      sprintf(psOutput, "[Ping] Error %d", GetLastError());
  
    g_WriteToOutput(TRUE, psOutput);
    delete psOutput;
  }
}

/////////////////////////////////////////////////////////////////////////////

