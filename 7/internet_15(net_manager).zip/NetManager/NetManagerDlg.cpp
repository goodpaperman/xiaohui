// NetManagerDlg.cpp : implementation file
//

#include "stdafx.h"
#include "NetManager.h"
#include "NetManagerDlg.h"
#include "GlobalsExtern.h"
#include <afxpriv.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

static UINT auIDStatusBar[] = 
{ 
  ID_SEPARATOR
};

/////////////////////////////////////////////////////////////////////////////
// CNetManagerDlg dialog

CNetManagerDlg::CNetManagerDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CNetManagerDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CNetManagerDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32

  g_pThisApp = AfxGetApp();
	m_hIcon = g_pThisApp->LoadIcon(IDR_MAINFRAME);

  m_bDlgCreated = false;
  m_bStarted = false;

  m_dlgPropSheet =  new CPropertySheet;
  m_pPageGeneral =  new CPageGeneral;
  m_pPageFiles =    new CPageFiles;
  m_pPageYou =      new CPageYou;
  m_pPageNet =      new CPageNet;
  m_pPagePeople =   new CPagePeople;
  m_pPageMail =     new CPageMail;

  m_BlinkState = true;

  // init globals
  g_History = &m_History;
  g_Output = &m_Output;
  g_AnimateWait = &m_AnimateWait;
  g_AnimatePeople = &m_AnimatePeople;
  g_AnimateNet = &m_AnimateNet;
}

void CNetManagerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNetManagerDlg)
	DDX_Control(pDX, IDC_INFOTREE, m_InfoTree);
	DDX_Control(pDX, IDC_ANIMATE_WAIT, m_AnimateWait);
	DDX_Control(pDX, IDC_ANIMATE_NET, m_AnimateNet);
	DDX_Control(pDX, IDC_ANIMATE_PEOPLE, m_AnimatePeople);
	DDX_Control(pDX, IDB_CLEAR_OUTPUT, m_ClearOutput);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CNetManagerDlg, CDialog)
	//{{AFX_MSG_MAP(CNetManagerDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDB_SHOW_OUTPUT, OnShowOutput)
	ON_BN_CLICKED(IDB_CLEAR_OUTPUT, OnClearOutput)
	ON_BN_CLICKED(IDB_START, OnStart)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDB_END, OnEnd)
	ON_WM_HELPINFO()
	ON_EN_CHANGE(IDC_OUTPUT, OnChangeOutput)
	ON_WM_SIZE()
	ON_WM_GETMINMAXINFO()
	ON_WM_ACTIVATE()
	ON_NOTIFY(TCN_SELCHANGE, IDC_TABCTRL_OUTPUT, OnSelchangeTabctrlOutput)
	ON_EN_CHANGE(IDC_HISTORY, OnChangeHistory)
	ON_NOTIFY(TVN_SELCHANGED, IDC_INFOTREE, OnSelchangedInfotree)
	ON_WM_SETCURSOR()
	ON_WM_SETTINGCHANGE()
	ON_WM_MENUSELECT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNetManagerDlg message handlers

void CNetManagerDlg::OnGetMinMaxInfo(MINMAXINFO* lpMMI)
{
  if(m_bDlgCreated)
  {
    lpMMI->ptMinTrackSize.x = DLG_MIN_WIDTH;
    lpMMI->ptMaxTrackSize.x = DLG_MAX_WIDTH;
    lpMMI->ptMinTrackSize.y = m_nDlgHeight;
    lpMMI->ptMaxTrackSize.y = m_nDlgHeight;
  }
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerDlg::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);

  if(m_bDlgCreated)
  {
    ResizeWindows();

    // We need to resize the dialog to make room for control bars.
	  // First, figure out how big the control bars are.

	  CRect rcClientStart;
	  CRect rcClientNow;
	  GetClientRect(rcClientStart);
	  RepositionBars(AFX_IDW_CONTROLBAR_FIRST, AFX_IDW_CONTROLBAR_LAST, 0, reposQuery, rcClientNow);

	  // Now move all the controls so they are in the same relative
	  // position within the remaining client area as they would be
	  // with no control bars.

	  CPoint ptOffset(rcClientNow.left - rcClientStart.left, rcClientNow.top - rcClientStart.top); 

	  CRect  rcChild;					
	  CWnd* pwndChild = GetWindow(GW_CHILD);
	  while (pwndChild)
	  {                               
		  pwndChild->GetWindowRect(rcChild);
		  ScreenToClient(rcChild);
		  rcChild.OffsetRect(ptOffset);
		  pwndChild->MoveWindow(rcChild, FALSE);
		  pwndChild = pwndChild->GetNextWindow();
	  }

	  // Adjust the dialog window dimensions
	  CRect rcWindow;
	  GetWindowRect(rcWindow);
	  rcWindow.right += rcClientStart.Width() - rcClientNow.Width();
	  rcWindow.bottom += rcClientStart.Height() - rcClientNow.Height();
	  MoveWindow(rcWindow, FALSE);
	  
	  // And position the control bars
	  RepositionBars(AFX_IDW_CONTROLBAR_FIRST, AFX_IDW_CONTROLBAR_LAST, 0);
  }

/*
  // for menu (more than 1 row of main menu (while resizing))
  CRect rc;
  GetClientRect(rc);
  if(rc.Height() != m_nDlgClientHeight)
    m_nDlgHeight += m_nDlgClientHeight - rc.Height();   // new height
*/
}

/////////////////////////////////////////////////////////////////////////////

BOOL CNetManagerDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
  m_Output.SubclassDlgItem(IDC_OUTPUT, this);
  m_History.SubclassDlgItem(IDC_HISTORY, this);
  m_InfoWindow.SubclassDlgItem(IDC_INFOWINDOW, this);
  m_OutputTabCtrl.SubclassDlgItem(IDC_TABCTRL_OUTPUT, this);

  m_History.ShowWindow(SW_SHOWNA);
  m_Output.ShowWindow(SW_HIDE);
  m_InfoTree.ShowWindow(SW_HIDE);
  m_InfoWindow.ShowWindow(SW_HIDE);

// ToolTips -----------------------------------------------------------------

  m_ToolTip.Create(this);
  m_ToolTip.Activate(TRUE);

  CWnd* pWnd = GetWindow(GW_CHILD);
  while(pWnd)
  {
    int nID = pWnd->GetDlgCtrlID();
    if (nID != -1)
      m_ToolTip.AddTool(pWnd, pWnd->GetDlgCtrlID());
    pWnd = pWnd->GetWindow(GW_HWNDNEXT);
  }

//  m_pPageGeneral->m_ToolTip = &m_ToolTip;

// Tab control buttons ------------------------------------------------------

  CImageList* pOutputTabButtons = new CImageList;
  pOutputTabButtons->Create(16, 16, ILC_COLOR8 | ILC_MASK, 3, 0);
  pOutputTabButtons->Add(AfxGetApp()->LoadIcon(IDI_HISTORY));
  pOutputTabButtons->Add(AfxGetApp()->LoadIcon(IDI_OUTPUT));
  pOutputTabButtons->Add(AfxGetApp()->LoadIcon(IDI_INFO));
  m_OutputTabCtrl.SetImageList(pOutputTabButtons);
  TC_ITEM TabCtrlItem;
  TabCtrlItem.mask = TCIF_TEXT | TCIF_IMAGE;
  TabCtrlItem.iImage = 0;
  TabCtrlItem.pszText = "History";
  m_OutputTabCtrl.InsertItem(0, &TabCtrlItem);
  TabCtrlItem.iImage = 1;
  TabCtrlItem.pszText = "Output";
  m_OutputTabCtrl.InsertItem(1, &TabCtrlItem);
  TabCtrlItem.iImage = 2;
  TabCtrlItem.pszText = "Info";
  m_OutputTabCtrl.InsertItem(2, &TabCtrlItem);

// Info Tree ----------------------------------------------------------------

  CImageList* pInfoImages = new CImageList;
  pInfoImages->Create(16, 16, ILC_COLOR8 | ILC_MASK, 2, 0);
  pInfoImages->Add(AfxGetApp()->LoadIcon(IDI_INFOROOT));
  pInfoImages->Add(AfxGetApp()->LoadIcon(IDI_INFOROOTOPEN));
  pInfoImages->Add(AfxGetApp()->LoadIcon(IDI_INFOTEXT));
  pInfoImages->Add(AfxGetApp()->LoadIcon(IDI_INFOTEXTOPEN));
  m_InfoTree.SetImageList(pInfoImages, TVSIL_NORMAL);

  HTREEITEM hTreeItem1;
  HTREEITEM hTreeItem2;
  hTreeItem1 = m_InfoTree.InsertItem("NetManager", 0, 1, TVI_ROOT, TVI_LAST);
  m_InfoTree.SetItemData(hTreeItem1, IDS_INFO_NETMANAGER);
  hTreeItem2 = m_InfoTree.InsertItem("What is NetManager?", 2, 3, hTreeItem1, TVI_LAST);
  m_InfoTree.SetItemData(hTreeItem2, IDS_INFO_NETMANAGER_WHATIS);
  hTreeItem2 = m_InfoTree.InsertItem("Version", 2, 3, hTreeItem1, TVI_LAST);
  m_InfoTree.SetItemData(hTreeItem2, IDS_INFO_NETMANAGER_VERSION);
  hTreeItem2 = m_InfoTree.InsertItem("Author", 2, 3, hTreeItem1, TVI_LAST);
  m_InfoTree.SetItemData(hTreeItem2, IDS_INFO_NETMANAGER_AUTHOR);

  hTreeItem1 = m_InfoTree.InsertItem("General Functions", 0, 1, TVI_ROOT, TVI_LAST);
  m_InfoTree.SetItemData(hTreeItem1, IDS_INFO_GENERAL);
  hTreeItem2 = m_InfoTree.InsertItem("Start All", 2, 3, hTreeItem1, TVI_LAST);
  m_InfoTree.SetItemData(hTreeItem2, IDS_INFO_GENERAL_STARTALL);
  hTreeItem2 = m_InfoTree.InsertItem("End All", 2, 3, hTreeItem1, TVI_LAST);
  m_InfoTree.SetItemData(hTreeItem2, IDS_INFO_GENERAL_ENDALL);
  hTreeItem2 = m_InfoTree.InsertItem("Automatization", 2, 3, hTreeItem1, TVI_LAST);
  m_InfoTree.SetItemData(hTreeItem2, IDS_INFO_GENERAL_AUTOMATIZATION);

  hTreeItem1 = m_InfoTree.InsertItem("Page 1 - Utilities", 0, 1, TVI_ROOT, TVI_LAST);
  m_InfoTree.SetItemData(hTreeItem1, IDS_INFO_PAGE1);
  hTreeItem2 = m_InfoTree.InsertItem("Resolve Address", 2, 3, hTreeItem1, TVI_LAST);
  m_InfoTree.SetItemData(hTreeItem2, IDS_INFO_PAGE1_RESOLVE);
  hTreeItem2 = m_InfoTree.InsertItem("Ping a Computer", 2, 3, hTreeItem1, TVI_LAST);
  m_InfoTree.SetItemData(hTreeItem2, IDS_INFO_PAGE1_PING);
  hTreeItem2 = m_InfoTree.InsertItem("Browse Local Network", 2, 3, hTreeItem1, TVI_LAST);
  m_InfoTree.SetItemData(hTreeItem2, IDS_INFO_PAGE1_BROWSE);
  hTreeItem2 = m_InfoTree.InsertItem("Enumerate Any Address", 2, 3, hTreeItem1, TVI_LAST);
  m_InfoTree.SetItemData(hTreeItem2, IDS_INFO_PAGE1_ENUMERATE);

  hTreeItem1 = m_InfoTree.InsertItem("Page 2 - Files", 0, 1, TVI_ROOT, TVI_LAST);
  m_InfoTree.SetItemData(hTreeItem1, IDS_INFO_PAGE2);
  hTreeItem2 = m_InfoTree.InsertItem("Executables", 2, 3, hTreeItem1, TVI_LAST);
  m_InfoTree.SetItemData(hTreeItem2, IDS_INFO_PAGE2_EXECUTABLES);
  hTreeItem2 = m_InfoTree.InsertItem("Copying", 2, 3, hTreeItem1, TVI_LAST);
  m_InfoTree.SetItemData(hTreeItem2, IDS_INFO_PAGE2_COPYING);

  hTreeItem1 = m_InfoTree.InsertItem("Page 3 - You", 0, 1, TVI_ROOT, TVI_LAST);
  m_InfoTree.SetItemData(hTreeItem1, IDS_INFO_PAGE3);
  hTreeItem2 = m_InfoTree.InsertItem("On", 2, 3, hTreeItem1, TVI_LAST);
  m_InfoTree.SetItemData(hTreeItem2, IDS_INFO_PAGE3_ON);
  hTreeItem2 = m_InfoTree.InsertItem("Off", 2, 3, hTreeItem1, TVI_LAST);
  m_InfoTree.SetItemData(hTreeItem2, IDS_INFO_PAGE3_OFF);
  hTreeItem2 = m_InfoTree.InsertItem("HTML File", 2, 3, hTreeItem1, TVI_LAST);
  m_InfoTree.SetItemData(hTreeItem2, IDS_INFO_PAGE3_HTML);

  hTreeItem1 = m_InfoTree.InsertItem("Page 4 - Net", 0, 1, TVI_ROOT, TVI_LAST);
  m_InfoTree.SetItemData(hTreeItem1, IDS_INFO_PAGE4);
  hTreeItem2 = m_InfoTree.InsertItem("Check All", 2, 3, hTreeItem1, TVI_LAST);
  m_InfoTree.SetItemData(hTreeItem2, IDS_INFO_PAGE4_CHECKALL);
  hTreeItem2 = m_InfoTree.InsertItem("Monitoring", 2, 3, hTreeItem1, TVI_LAST);
  m_InfoTree.SetItemData(hTreeItem2, IDS_INFO_PAGE4_MONITORING);

  hTreeItem1 = m_InfoTree.InsertItem("Page 5 - People", 0, 1, TVI_ROOT, TVI_LAST);
  m_InfoTree.SetItemData(hTreeItem1, IDS_INFO_PAGE5);
  hTreeItem2 = m_InfoTree.InsertItem("Inserting Data", 2, 3, hTreeItem1, TVI_LAST);
  m_InfoTree.SetItemData(hTreeItem2, IDS_INFO_PAGE5_INSERTING);
  hTreeItem2 = m_InfoTree.InsertItem("Finger", 2, 3, hTreeItem1, TVI_LAST);
  m_InfoTree.SetItemData(hTreeItem2, IDS_INFO_PAGE5_FINGER);
  hTreeItem2 = m_InfoTree.InsertItem("Manual Finger", 2, 3, hTreeItem1, TVI_LAST);
  m_InfoTree.SetItemData(hTreeItem2, IDS_INFO_PAGE5_MANUAL);
  hTreeItem2 = m_InfoTree.InsertItem("Active", 2, 3, hTreeItem1, TVI_LAST);
  m_InfoTree.SetItemData(hTreeItem2, IDS_INFO_PAGE5_ACTIVE);
  hTreeItem2 = m_InfoTree.InsertItem("Check All", 2, 3, hTreeItem1, TVI_LAST);
  m_InfoTree.SetItemData(hTreeItem2, IDS_INFO_PAGE5_CHECKALL);
  hTreeItem2 = m_InfoTree.InsertItem("Monitoring", 2, 3, hTreeItem1, TVI_LAST);
  m_InfoTree.SetItemData(hTreeItem2, IDS_INFO_PAGE5_MONITORING);

  hTreeItem1 = m_InfoTree.InsertItem("Page 6 - Mail", 0, 1, TVI_ROOT, TVI_LAST);
  m_InfoTree.SetItemData(hTreeItem1, IDS_INFO_PAGE6);
  hTreeItem2 = m_InfoTree.InsertItem("Configuring", 2, 3, hTreeItem1, TVI_LAST);
  m_InfoTree.SetItemData(hTreeItem2, IDS_INFO_PAGE6_CONFIGURING);
  hTreeItem2 = m_InfoTree.InsertItem("Settings", 2, 3, hTreeItem1, TVI_LAST);
  m_InfoTree.SetItemData(hTreeItem2, IDS_INFO_PAGE6_SETTINGS);

  hTreeItem1 = m_InfoTree.InsertItem("Tips & FAQs", 0, 1, TVI_ROOT, TVI_LAST);
  m_InfoTree.SetItemData(hTreeItem1, IDS_INFO_TIPSFAQS);

// AVI Files ----------------------------------------------------------------

  if(m_AnimateWait.Open(IDR_AVI_WAIT) == 0)
    AfxMessageBox("Error - Could insert play AVI file");
  
  if(m_AnimatePeople.Open(IDR_AVI_PEOPLE) == 0)
    AfxMessageBox("Error - Could insert play AVI file");

  if(m_AnimateNet.Open(IDR_AVI_NET) == 0)
    AfxMessageBox("Error - Could insert play AVI file");

  m_ClearOutput.EnableWindow(FALSE);

  m_pOutput = (CEdit*)GetDlgItem(IDC_OUTPUT);

// Change the path for INI file ---------------------------------------------

  CString sModFileName;
  GetModuleFileName(NULL, sModFileName.GetBuffer(MAX_PATH), MAX_PATH);
  sModFileName.ReleaseBuffer();

  sModFileName.MakeReverse();
  m_sIniFilePath = sModFileName.Right(sModFileName.GetLength() - sModFileName.Find('\\'));
  m_sIniFilePath.MakeReverse();
  m_sIniFilePath += "netmanag.ini";
  sModFileName.MakeReverse();

  free((void*)g_pThisApp->m_pszProfileName);
  g_pThisApp->m_pszProfileName = _tcsdup(m_sIniFilePath);

// files exe ----------------------------------------------------------------

  m_pPageFiles->m_psArrayExeNames = new CStringArray;
  m_pPageFiles->m_pArrayAutoStart = new CUIntArray;
  IniToStringArray("Files Exe", "Executable", m_pPageFiles->m_psArrayExeNames);

  int i = m_pPageFiles->m_psArrayExeNames->GetSize();
  if(i == 1)
    m_pPageFiles->m_psArrayExeNames->RemoveAll();
  else if(i % 2 == 1)
  {
    AfxMessageBox("Error: The INI file contains odd number of exe-files items.\nThere is an invalid item. Repair it!\nTerminating the application...");
    CDialog::OnCancel();
    return FALSE;
  }
  else
  {
    int j = m_pPageFiles->m_psArrayExeNames->GetSize();
    for(i = 0; i <= (j - 2); i += 2)
      m_pPageFiles->m_pArrayAutoStart->Add(g_pThisApp->GetProfileInt("Files Exe", m_pPageFiles->m_psArrayExeNames->GetAt(i), 0));
  }

// net ----------------------------------------------------------------------

  m_pPageNet->m_psArrayNet = new CStringArray;
  IniToStringArray("Net URLs", "File", m_pPageNet->m_psArrayNet);

  m_pPageNet->m_psArrayNetLastModified = new CStringArray;
  i = 0;
  int j = m_pPageNet->m_psArrayNet->GetSize();
  while(i <= (j - 2))
  {
    m_pPageNet->m_psArrayNetLastModified->Add(g_pThisApp->GetProfileString("Net URLs", m_pPageNet->m_psArrayNet->GetAt(i), "not tested"));
    i += 2;
  }

// menu ---------------------------------------------------------------------

  CMenu* pMenu = GetMenu();

  if(g_pThisApp->GetProfileInt("NetManager", "Starting", 0))
  {
    pMenu->CheckMenuItem(IDM_STARTING, MF_CHECKED | MF_BYCOMMAND);
    g_bStarting = true;
  }
  else
  {
    pMenu->CheckMenuItem(IDM_STARTING, MF_UNCHECKED | MF_BYCOMMAND);
    g_bStarting = false;
  }

  if(g_pThisApp->GetProfileInt("NetManager", "Ending", 0))
  {
    pMenu->CheckMenuItem(IDM_ENDING, MF_CHECKED | MF_BYCOMMAND);
    g_bEnding = true;
  }
  else
  {
    pMenu->CheckMenuItem(IDM_ENDING, MF_UNCHECKED | MF_BYCOMMAND);
    g_bEnding = false;
  }

  if(g_pThisApp->GetProfileInt("NetManager", "AutoNetMonitoring", 0))
  {
    pMenu->CheckMenuItem(IDM_NETMONITORING, MF_CHECKED | MF_BYCOMMAND);
    g_bNetMonitoring = true;
  }
  else
  {
    pMenu->CheckMenuItem(IDM_NETMONITORING, MF_UNCHECKED | MF_BYCOMMAND);
    g_bNetMonitoring = false;
  }

  if(g_pThisApp->GetProfileInt("NetManager", "AutoPeopleMonitoring", 0))
  {
    pMenu->CheckMenuItem(IDM_PEOPLEMONITORING, MF_CHECKED | MF_BYCOMMAND);
    g_bPeopleMonitoring = true;
  }
  else
  {
    pMenu->CheckMenuItem(IDM_PEOPLEMONITORING, MF_UNCHECKED | MF_BYCOMMAND);
    g_bPeopleMonitoring = false;
  }

  if(g_pThisApp->GetProfileInt("NetManager", "AutoSaveSettings", 1))
  {
    pMenu->CheckMenuItem(IDM_AUTOSAVE, MF_CHECKED | MF_BYCOMMAND);
    g_bAutoSaveSettings = true;
  }
  else
  {
    pMenu->CheckMenuItem(IDM_AUTOSAVE, MF_UNCHECKED | MF_BYCOMMAND);
    g_bAutoSaveSettings = false;
  }

  if(g_pThisApp->GetProfileInt("NetManager", "WindowMaximizing", 1))
  {
    pMenu->CheckMenuItem(IDM_NOTIFICATION_WIN, MF_CHECKED | MF_BYCOMMAND);
    g_bWinNotification = true;
  }
  else
  {
    pMenu->CheckMenuItem(IDM_NOTIFICATION_ICON, MF_CHECKED | MF_BYCOMMAND);
    g_bWinNotification = false;
  }

  if(g_pThisApp->GetProfileInt("NetManager", "ExeImages", 0))
  {
    pMenu->CheckMenuItem(IDM_EXEIMAGES_LARGE, MF_CHECKED | MF_BYCOMMAND);
    g_bExeImages = true;
  }
  else
  {
    pMenu->CheckMenuItem(IDM_EXEIMAGES_SMALL, MF_CHECKED | MF_BYCOMMAND);
    g_bExeImages = false;
  }

  if(g_pThisApp->GetProfileInt("NetManager", "PeopleImages", 0))
  {
    pMenu->CheckMenuItem(IDM_PEOPLEIMAGES_LARGE, MF_CHECKED | MF_BYCOMMAND);
    g_bPeopleImages = true;
  }
  else
  {
    pMenu->CheckMenuItem(IDM_PEOPLEIMAGES_SMALL, MF_CHECKED | MF_BYCOMMAND);
    g_bPeopleImages = false;
  }

  m_pPageNet->m_nNetMinutes = g_pThisApp->GetProfileInt("Net", "Minutes", 60);
  m_pPagePeople->m_nPeopleMinutes = g_pThisApp->GetProfileInt("People", "Minutes", 3);
  m_pPageFiles->m_sSourceCopyFile = g_pThisApp->GetProfileString("Files Copy", "Source", "x:/sourcefile");
  m_pPageFiles->m_sDestCopyFile   = g_pThisApp->GetProfileString("Files Copy", "Destination", "d:/destinationfile");
  m_pPageYou->m_sServerName       = g_pThisApp->GetProfileString("You", "Server", "server-name");
  m_pPageYou->m_sUserName         = g_pThisApp->GetProfileString("You", "User", "user-name");
  m_pPageYou->m_sPassword         = g_pThisApp->GetProfileString("You", "Password", "password");
  m_pPageYou->m_sSourceFile1      = g_pThisApp->GetProfileString("You", "SourceFileOn", "x:/sourcefile.htm");
  m_pPageYou->m_sSourceFile2      = g_pThisApp->GetProfileString("You", "SourceFileOff", "x:/destinationfile.htm");
  m_pPageYou->m_sDestinationDir   = g_pThisApp->GetProfileString("You", "DestinationDir", "html");
  m_pPageYou->m_sDestination      = g_pThisApp->GetProfileString("You", "DestinationName", "filename.html");
  m_pPageYou->m_sTagMachine       = g_pThisApp->GetProfileString("You", "TagMachine", "-MACHINE-");
  m_pPageYou->m_sTagDate          = g_pThisApp->GetProfileString("You", "TagDate", "-DATE-");

  m_pPageMail->m_psArrayMailServer = new CStringArray;
  IniToStringArray("Mail Server", "server name", m_pPageMail->m_psArrayMailServer);
  m_pPageMail->m_psArrayMailProgram = new CStringArray;
  IniToStringArray("Mail Program", "NetManager", m_pPageMail->m_psArrayMailProgram);
  m_pPageMail->m_psArrayMailFrom = new CStringArray;
  IniToStringArray("Mail From", "Your Name <You@server.domain.cz>", m_pPageMail->m_psArrayMailFrom);
  m_pPageMail->m_psArrayMailTo = new CStringArray;
  IniToStringArray("Mail To", "Name <to@server.domain.cz>", m_pPageMail->m_psArrayMailTo);
  m_pPageMail->m_psArrayMailSubject = new CStringArray;
  IniToStringArray("Mail Subject", "no subject", m_pPageMail->m_psArrayMailSubject);

  m_pPageMail->m_psArrayMailSignature = new CStringArray;
  IniToStringArray("Mail Signature", "---------- used NetManager ----------", m_pPageMail->m_psArrayMailSignature);

// fill out tree control ----------------------------------------------------

  CStringArray* psServersArray = new CStringArray;
  m_pPagePeople->m_pAllServersArray = new CPtrArray;
  CStringArray* pServerArray;

  IniToStringArray("People Servers", "server.domain.cz", psServersArray);
  i = 0;
  j = psServersArray->GetSize();
  while(i != j)
  {
    pServerArray = new CStringArray;
    m_pPagePeople->m_pAllServersArray->Add(pServerArray);
    pServerArray->Add(psServersArray->GetAt(i));
    IniToStringArray(psServersArray->GetAt(i), "user", pServerArray);
    i++;
  }

  m_nHistoryFontSize = g_pThisApp->GetProfileInt("NetManager", "HistoryFontSize", 8);
  m_sHistoryFontFace = g_pThisApp->GetProfileString("NetManager", "HistoryFontFace", "Arial");

  m_nOutputFontSize = g_pThisApp->GetProfileInt("NetManager", "OutputFontSize", 10);
  m_sOutputFontFace = g_pThisApp->GetProfileString("NetManager", "OutputFontFace", "Courier");

// init prop. sheet ---------------------------------------------------------

  m_dlgPropSheet->AddPage(m_pPageGeneral);
  m_dlgPropSheet->AddPage(m_pPageFiles);
  m_dlgPropSheet->AddPage(m_pPageYou);
  m_dlgPropSheet->AddPage(m_pPageNet);
  m_dlgPropSheet->AddPage(m_pPagePeople);
  m_dlgPropSheet->AddPage(m_pPageMail);

  m_dlgPropSheet->Create(this, WS_CHILD | WS_VISIBLE, 0);
  m_dlgPropSheet->ModifyStyle(0, WS_TABSTOP);
  m_dlgPropSheet->ModifyStyleEx(0, WS_EX_CONTROLPARENT);

  CImageList* pButtonImages = new CImageList;
  pButtonImages->Create(16, 16, ILC_COLORDDB | ILC_MASK, 5, 0);

  pButtonImages->Add(g_pThisApp->LoadIcon(IDI_GENERAL));
  pButtonImages->Add(g_pThisApp->LoadIcon(IDI_FILES));
  pButtonImages->Add(g_pThisApp->LoadIcon(IDI_YOU));
  pButtonImages->Add(g_pThisApp->LoadIcon(IDI_NET));
  pButtonImages->Add(g_pThisApp->LoadIcon(IDI_PEOPLE));
  pButtonImages->Add(g_pThisApp->LoadIcon(IDI_MAIL));

  CTabCtrl *pTab = m_dlgPropSheet->GetTabControl();
  pTab->SetImageList(pButtonImages);

  TC_ITEM tcItem;
  tcItem.mask = TCIF_IMAGE;
  for(i = 0; i < 6; i++)
  {
    tcItem.iImage = i;
    pTab->SetItem(i, &tcItem);
  }

  CRect rcSheet;
  GetWindowRect(&rcSheet);
  m_dlgPropSheet->SetWindowPos(NULL, rcSheet.left - 4, rcSheet.top - 4, rcSheet.Width(), rcSheet.Height(),
                SWP_NOZORDER | SWP_NOSIZE | SWP_NOACTIVATE);

  m_pHistoryFont = new CFont;
  if(!(m_pHistoryFont->CreatePointFont(m_nHistoryFontSize * 10, m_sHistoryFontFace)))
    m_pHistoryFont->CreateFont(0, 0, 1, 0, 0, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_CHARACTER_PRECIS, CLIP_CHARACTER_PRECIS, 0, 0, NULL);
  m_History.SetFont(m_pHistoryFont);

  m_pOutputFont = new CFont;
  if(!(m_pOutputFont->CreatePointFont(m_nOutputFontSize * 10, m_sOutputFontFace)))
    m_pOutputFont->CreateFont(0, 0, 1, 0, 0, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_CHARACTER_PRECIS, CLIP_CHARACTER_PRECIS, 0, 0, NULL);
  m_Output.SetFont(m_pOutputFont);

  m_dlgPropSheet->SetActivePage(1);
  m_dlgPropSheet->SetActivePage(2);
  m_dlgPropSheet->SetActivePage(3);
  m_dlgPropSheet->SetActivePage(4);
  m_dlgPropSheet->SetActivePage(5);
  m_dlgPropSheet->SetActivePage(0);

  int nWindowWidth =  g_pThisApp->GetProfileInt("NetManager", "WindowWidth", DLG_MIN_WIDTH);
  int nMaxWindowWidth = DLG_MAX_WIDTH;
  if(nWindowWidth > nMaxWindowWidth)
    nWindowWidth = nMaxWindowWidth;

  CRect rcDlg;
  GetWindowRect(&rcDlg);
  m_nDlgDefaultWidth = rcDlg.Width(); // right - rcDlg.left;
  rcDlg.right = rcDlg.left + nWindowWidth;
  MoveWindow(rcDlg);

  ///////////////////////////////////////////////////////////////////////////
	// Create status bar at the bottom of the dialog window	               

	if(m_StatusBar.Create(this))
	{                           
		m_StatusBar.SetIndicators(auIDStatusBar, sizeof(auIDStatusBar) / sizeof(UINT));
    m_StatusBar.SetWindowText("NetManager");		
    m_StatusBar.SetPaneInfo(0, m_StatusBar.GetItemID(0), SBPS_STRETCH, NULL );
	}             
  else
    AfxMessageBox("Error - Statusbar");

  // We need to resize the dialog to make room for control bars.
	// First, figure out how big the control bars are.

	CRect rcClientStart;
	CRect rcClientNow;
	GetClientRect(rcClientStart);
	RepositionBars(AFX_IDW_CONTROLBAR_FIRST, AFX_IDW_CONTROLBAR_LAST, 0, reposQuery, rcClientNow);
	
	// Now move all the controls so they are in the same relative
	// position within the remaining client area as they would be
	// with no control bars.

	CPoint ptOffset(rcClientNow.left - rcClientStart.left, rcClientNow.top - rcClientStart.top); 

	CRect  rcChild;					
	CWnd* pwndChild = GetWindow(GW_CHILD);
	while (pwndChild)
	{                               
		pwndChild->GetWindowRect(rcChild);
		ScreenToClient(rcChild);
		rcChild.OffsetRect(ptOffset);
		pwndChild->MoveWindow(rcChild, FALSE);
		pwndChild = pwndChild->GetNextWindow();
	}

	// Adjust the dialog window dimensions
	CRect rcWindow;
	GetWindowRect(rcWindow);
	rcWindow.right += rcClientStart.Width() - rcClientNow.Width();
	rcWindow.bottom += rcClientStart.Height() - rcClientNow.Height();
	MoveWindow(rcWindow, FALSE);
	
	// And position the control bars
	RepositionBars(AFX_IDW_CONTROLBAR_FIRST, AFX_IDW_CONTROLBAR_LAST, 0);

// Dialog windows resizing //////////////////////////////////////////////////

  GetClientRect(&rcDlg);
  m_nDlgHeight = 10 + rcDlg.Height() + GetSystemMetrics(SM_CYMENUSIZE) + GetSystemMetrics(SM_CYSIZE);
  ResizeWindows();

  // for menu (number of lines)
  CRect rc;
  GetClientRect(rc);
  m_nDlgClientHeight = rc.Height();

/*
  CRect rcOriginal;
  GetClientRect(rcOriginal);
  if(rcOriginal.Height() < (rc.Height() + GetSystemMetrics(SM_CYMENUSIZE)))
  {
    m_nDlgHeight += GetSystemMetrics(SM_CYMENUSIZE);
    m_nDlgClientHeight += GetSystemMetrics(SM_CYMENUSIZE);
  }
*/

/////////////////////////////////////////////////////////////////////////////

  m_pPageGeneral->CreateRootNode();

// IP Address ---------------------------------------------------------------

  unsigned long ulIpAddress = 0;

  hostent* pHostent;// = new HOSTENT;
  char abHostName[255];

  if((!gethostname(abHostName, sizeof(abHostName)))  &&
     ((pHostent = gethostbyname(abHostName)) != NULL) &&
     (pHostent->h_length == 4))
  {
    CopyMemory(&ulIpAddress, pHostent->h_addr, 4);
  }

  in_addr inaddr;
  inaddr.s_addr = ulIpAddress;
  CString sIpAddress = inet_ntoa(inaddr);

  if((pHostent = gethostbyaddr((LPCSTR)&ulIpAddress, 4, PF_INET)) != NULL)
    strcpy(abHostName, pHostent->h_name);

  m_pPageYou->m_sIP = sIpAddress;
  m_pPageYou->m_sIPName = abHostName;


  m_bDlgCreated = true;

	return TRUE;  // return TRUE  unless you set the focus to a control
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerDlg::ResizeWindows()
{
  CRect rcDlg;
  GetWindowRect(&rcDlg);

  if(rcDlg.Width() > DLG_MIN_WIDTH)
    GetDlgItem(IDB_SHOW_OUTPUT)->SetWindowText("Hide <<");
  else
    GetDlgItem(IDB_SHOW_OUTPUT)->SetWindowText("Show >>");

  CRect rcTabCtrl;
  m_OutputTabCtrl.GetWindowRect(&rcTabCtrl);
  rcTabCtrl.right = rcDlg.right - 3;
  ScreenToClient(&rcTabCtrl);
  m_OutputTabCtrl.MoveWindow(rcTabCtrl);

  CRect rcOutput;
  m_Output.GetWindowRect(&rcOutput);
  ScreenToClient(&rcOutput);
  rcTabCtrl.left += 2;
  rcTabCtrl.right -= 4;
  rcTabCtrl.top = rcOutput.top;
  rcTabCtrl.bottom -= 3;
  m_Output.MoveWindow(rcTabCtrl);
  m_History.MoveWindow(rcTabCtrl);

  CRect rcInfoTree;
  CRect rcInfoWindow;
  m_InfoTree.GetWindowRect(&rcInfoTree);
  m_InfoWindow.GetWindowRect(&rcInfoWindow);
  ScreenToClient(&rcInfoTree);
  ScreenToClient(&rcInfoWindow);
  int nWork = rcTabCtrl.bottom;
  rcTabCtrl.bottom = rcInfoTree.bottom;
  m_InfoTree.MoveWindow(rcTabCtrl);
  rcTabCtrl.top = rcInfoWindow.top;
  rcTabCtrl.bottom = nWork;
  m_InfoWindow.MoveWindow(rcTabCtrl);
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerDlg::IniToStringArray(LPCTSTR lpszTag, LPCTSTR lpszDefault, CStringArray* psArray)
{
  char* ps_INI_Buffer = new char[64000];

  DWORD nStringsNum = GetPrivateProfileString(lpszTag, NULL, NULL, ps_INI_Buffer, 64000, m_sIniFilePath);

  if(nStringsNum == 0)
  {
    strcpy(ps_INI_Buffer, lpszDefault);
    nStringsNum = strlen(lpszDefault);
  }
  psArray->Add(ps_INI_Buffer);
  DWORD dwCounter = 0;
  while(dwCounter != (nStringsNum-1))
  {
    if(*(ps_INI_Buffer + dwCounter) == '\0')
      psArray->Add(ps_INI_Buffer + dwCounter + 1);
    dwCounter++;
  }
  delete ps_INI_Buffer;
}

/////////////////////////////////////////////////////////////////////////////
// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CNetManagerDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
  	dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
    DrawLogoText();

    if(g_bStarting && !m_bStarted)
    {
      m_bStarted = true;
      OnStart();
    }
	}
}

/////////////////////////////////////////////////////////////////////////////
// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.

HCURSOR CNetManagerDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerDlg::DrawLogoText()
{
	CWindowDC dc(this);
  CString m_LogoText = "NetManager";
  CFont m_fontLogo;
  dc.SetBkMode(TRANSPARENT);
  CRect rectText;
  rectText.left = 400;
  rectText.top = GetSystemMetrics(SM_CYSIZE) + 2;
  rectText.bottom = rectText.top + 18;
  rectText.right = 650;
  CFont* OldFont = dc.SelectObject(&m_fontLogo);
  COLORREF OldColor = dc.SetTextColor(::GetSysColor( COLOR_3DHILIGHT));  // draw text in DC
  dc.DrawText(m_LogoText, rectText + CPoint(1,1), DT_SINGLELINE | DT_LEFT | DT_VCENTER);
  dc.SetTextColor(::GetSysColor( COLOR_3DSHADOW));
  dc.DrawText(m_LogoText, rectText, DT_SINGLELINE | DT_LEFT | DT_VCENTER);
  dc.SetTextColor(OldColor);    // restore old text color
  dc.SelectObject(OldFont);     // restore old font
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerDlg::OnCancel() 
{
  int nResult = MessageBox("Really Quit???", NULL, MB_ICONQUESTION | MB_YESNO);
  if(nResult != IDNO)
  {
    if(g_bEnding)
      OnEnd();
    if(g_bAutoSaveSettings)
      SaveSettings();
    CDialog::EndDialog(0);
  }
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerDlg::OnShowOutput() 
{
  CRect rect;
  GetWindowRect(&rect);
  if(rect.Width() > DLG_MIN_WIDTH)
    HideOutput();
  else
    ShowOutput();
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerDlg::ShowOutput()
{
  CRect rcDlg;
  GetWindowRect(&rcDlg);
  rcDlg.right = rcDlg.left + m_nDlgDefaultWidth;
  GetDlgItem(IDB_SHOW_OUTPUT)->SetWindowText("Show >>");
  MoveWindow(rcDlg);
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerDlg::HideOutput()
{
  CRect rcDlg;
  GetWindowRect(&rcDlg);
  rcDlg.right = rcDlg.left + DLG_MIN_WIDTH;
  GetDlgItem(IDB_SHOW_OUTPUT)->SetWindowText("Hide <<");
  MoveWindow(rcDlg);
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerDlg::OnStart() 
{
  m_dlgPropSheet->SetActivePage(0);

  g_WriteToHistory(TRUE, ">>> NETMANAGER FUNCTIONS STARTED <<<");

  // files

  if(m_pPageFiles->m_CopyOnStart.GetCheck())
    m_pPageFiles->FilesCopy();	

  int i = 0;
  int j = m_pPageFiles->m_pArrayAutoStart->GetSize();
  while(i != j)
  {
    if(m_pPageFiles->m_pArrayAutoStart->GetAt(i))
      m_pPageFiles->FilesExecute(i);
    i++;
  }

  // net

  if(m_pPageNet->m_OnStart.GetCheck())
  {
    g_AnimateWait->Play(0, -1, -1);

    CString sOutput;
    m_pPageNet->CheckAll(sOutput);
    g_WriteToHistory(TRUE, sOutput);
  }

  // people

  if(m_pPagePeople->m_OnStart.GetCheck())
  {
    g_AnimateWait->Play(0, -1, -1);

    m_pPagePeople->ResetServersAndUsers();
    CString sOutput;
    m_pPagePeople->CheckAll(sOutput);
    g_WriteToHistory(TRUE, sOutput);
  }

  // you

  if(m_pPageYou->m_OnlineOnStart.GetCheck())
    m_pPageYou->OnOnline();
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerDlg::OnEnd() 
{
  m_dlgPropSheet->SetActivePage(0);

  g_WriteToHistory(TRUE, ">>> NETMANAGER FUNCTIONS FINISHED <<<");
  if(m_pPageFiles->m_ReturnOnEnd.GetCheck())
    m_pPageFiles->FilesReturn();	
  if(m_pPageFiles->m_DeleteOnEnd.GetCheck())
    m_pPageFiles->FilesDelete();	

  if(m_pPageYou->m_OfflineOnEnd.GetCheck())
    m_pPageYou->OnOffline();

  // people

  if(m_pPagePeople->m_OnEnd.GetCheck())
  {
    g_AnimateWait->Play(0, -1, -1);

    m_pPagePeople->ResetServersAndUsers();
    CString sOutput;
    m_pPagePeople->CheckAll(sOutput);
    g_WriteToHistory(TRUE, sOutput);
  }

  // net

  if(m_pPageNet->m_OnEnd.GetCheck())
  {
    g_AnimateWait->Play(0, -1, -1);

    CString sOutput;
    m_pPageNet->CheckAll(sOutput);
    g_WriteToHistory(TRUE, sOutput);
  }
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerDlg::OnTimer(UINT nIDEvent) 
{
  if(nIDEvent == TIMER_NET_ID)
  {
    CString sOutput;
    if(m_pPageNet->CheckAll(sOutput))
    {
      MessageBeep(0);
      if(g_bWinNotification)
      {
        ShowWindow(SW_SHOWMINIMIZED);
        ShowWindow(SW_RESTORE);
      }
      else
      {
        m_BlinkState = true;
        m_BlinkIcon = g_pThisApp->LoadIcon(IDI_NET);
        SetTimer(TIMER_ICON_BLINKING_ID, 500, NULL);
      }
      g_WriteToHistory(TRUE, sOutput);
    }
  }

  if(nIDEvent == TIMER_PEOPLE_ID)
  {
    CString sOutput;
    if(m_pPagePeople->CheckAll(sOutput))
    {
      MessageBeep(0);
      if(g_bWinNotification)
      {
        ShowWindow(SW_SHOWMINIMIZED);
        ShowWindow(SW_RESTORE);
      }
      else
      {
        SetTimer(TIMER_ICON_BLINKING_ID, 500, NULL);
        m_BlinkIcon = g_pThisApp->LoadIcon(IDI_PEOPLE);
      }
      g_WriteToHistory(TRUE, sOutput);
    }
  }

  if(nIDEvent == TIMER_ICON_BLINKING_ID)
  {
    if(m_BlinkState ^= true)
    {
      g_pMainWnd->SetIcon(g_pThisApp->LoadIcon(IDR_MAINFRAME), FALSE);
      g_pMainWnd->SetWindowText("NetManager");
    }
    else
    {
      g_pMainWnd->SetIcon(m_BlinkIcon, FALSE);
      g_pMainWnd->SetWindowText("");
    }
  }

	CDialog::OnTimer(nIDEvent);
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerDlg::SaveArrayToIni(LPCTSTR lpszTag, CStringArray* pArray) 
{
  int i = 0;
  int j = pArray->GetSize();
  while(i != j)
    g_pThisApp->WriteProfileString(lpszTag, pArray->GetAt(i++), "");
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerDlg::SaveSettings() 
{
  // delete old items in INI file -------------------------------------------

  g_pThisApp->WriteProfileString("NetManager", NULL, NULL);
  g_pThisApp->WriteProfileString("Files Exe", NULL, NULL);
  g_pThisApp->WriteProfileString("Files Copy", NULL, NULL);
  g_pThisApp->WriteProfileString("You", NULL, NULL);
  g_pThisApp->WriteProfileString("Net", NULL, NULL);
  g_pThisApp->WriteProfileString("Net URLs", NULL, NULL);
  g_pThisApp->WriteProfileString("Mail", NULL, NULL);
  g_pThisApp->WriteProfileString("Mail Server", NULL, NULL);
  g_pThisApp->WriteProfileString("Mail From", NULL, NULL);
  g_pThisApp->WriteProfileString("Mail To", NULL, NULL);
  g_pThisApp->WriteProfileString("Mail Subject", NULL, NULL);
  g_pThisApp->WriteProfileString("Mail Program", NULL, NULL);
  g_pThisApp->WriteProfileString("Mail Signature", NULL, NULL);
  g_pThisApp->WriteProfileString("People", NULL, NULL);

  CStringArray* psServersArray = new CStringArray;
  IniToStringArray("People Servers", "server.domain.cz", psServersArray);

  g_pThisApp->WriteProfileString("People Servers", NULL, NULL);

  int j = psServersArray->GetSize();
  for(int i = 0; i < j; i++)
    g_pThisApp->WriteProfileString(psServersArray->GetAt(i), NULL, NULL);  // smaze vsechny servry

  // save new items ---------------------------------------------------------

  m_dlgPropSheet->SetActivePage(0);

  g_pThisApp->WriteProfileInt("NetManager", "Starting", g_bStarting);
  g_pThisApp->WriteProfileInt("NetManager", "Ending", g_bEnding);
  g_pThisApp->WriteProfileInt("NetManager", "AutoNetMonitoring", g_bNetMonitoring);
  g_pThisApp->WriteProfileInt("NetManager", "AutoPeopleMonitoring", g_bPeopleMonitoring);
  g_pThisApp->WriteProfileInt("NetManager", "AutoSaveSettings", g_bAutoSaveSettings);
  g_pThisApp->WriteProfileInt("NetManager", "HistoryFontSize", m_nHistoryFontSize);
  g_pThisApp->WriteProfileString("NetManager", "HistoryFontFace", m_sHistoryFontFace);
  g_pThisApp->WriteProfileInt("NetManager", "OutputFontSize", m_nOutputFontSize);
  g_pThisApp->WriteProfileString("NetManager", "OutputFontFace", m_sOutputFontFace);
  g_pThisApp->WriteProfileInt("NetManager", "WindowMaximizing", g_bWinNotification);
  g_pThisApp->WriteProfileInt("NetManager", "ExeImages", g_bExeImages);
  g_pThisApp->WriteProfileInt("NetManager", "PeopleImages", g_bPeopleImages);

  CRect rect;
  GetWindowRect(&rect);
  g_pThisApp->WriteProfileInt("NetManager", "WindowWidth", rect.Width());
  g_pThisApp->WriteProfileInt("NetManager", "ExeWindowWidth", m_pPageFiles->m_ExeFiles.GetColumnWidth(0));

  // files exe

  m_pPageFiles->UpdateArray();
  i = 0;
  j = m_pPageFiles->m_psArrayExeNames->GetSize();
  int k = 0;
  while(i != j)
  {
    g_pThisApp->WriteProfileInt("Files Exe", m_pPageFiles->m_psArrayExeNames->GetAt(i++), m_pPageFiles->m_pArrayAutoStart->GetAt(k++));
    g_pThisApp->WriteProfileString("Files Exe", m_pPageFiles->m_psArrayExeNames->GetAt(i++), "");
  }

  // others

  g_pThisApp->WriteProfileString("Files Copy", "Source", m_pPageFiles->m_sSourceCopyFile);
  g_pThisApp->WriteProfileString("Files Copy", "Destination", m_pPageFiles->m_sDestCopyFile);
  g_pThisApp->WriteProfileInt("Files Copy", "CopyOnStart", m_pPageFiles->m_CopyOnStart.GetCheck());
  g_pThisApp->WriteProfileInt("Files Copy", "ReturnOnEnd", m_pPageFiles->m_ReturnOnEnd.GetCheck());
  g_pThisApp->WriteProfileInt("Files Copy", "DeleteOnEnd", m_pPageFiles->m_DeleteOnEnd.GetCheck());

  // net

  g_pThisApp->WriteProfileInt("Net", "OnStart", m_pPageNet->m_OnStart.GetCheck());
  g_pThisApp->WriteProfileInt("Net", "OnEnd", m_pPageNet->m_OnEnd.GetCheck());
  g_pThisApp->WriteProfileInt("Net", "Minutes", m_pPageNet->m_nNetMinutes);

  i = 0;
  j = m_pPageNet->m_psArrayNet->GetSize();
  k = 0;
  while(i != j)
  {
    g_pThisApp->WriteProfileString("Net URLs", m_pPageNet->m_psArrayNet->GetAt(i++), '"' + m_pPageNet->m_psArrayNetLastModified->GetAt(k++) + '"');
    g_pThisApp->WriteProfileString("Net URLs", m_pPageNet->m_psArrayNet->GetAt(i++), "");
  }

  m_pPageYou->SaveSettings();
  m_pPageMail->UpdateArrays(m_pPageMail->m_psArrayMailServer, &(m_pPageMail->m_Server));
  SaveArrayToIni("Mail Server", m_pPageMail->m_psArrayMailServer);
  m_pPageMail->UpdateArrays(m_pPageMail->m_psArrayMailFrom, &(m_pPageMail->m_From));
  SaveArrayToIni("Mail From", m_pPageMail->m_psArrayMailFrom);
  m_pPageMail->UpdateArrays(m_pPageMail->m_psArrayMailTo, &(m_pPageMail->m_To));
  SaveArrayToIni("Mail To", m_pPageMail->m_psArrayMailTo);
  m_pPageMail->UpdateArrays(m_pPageMail->m_psArrayMailSubject, &(m_pPageMail->m_Subject));
  SaveArrayToIni("Mail Subject", m_pPageMail->m_psArrayMailSubject);
  m_pPageMail->UpdateArrays(m_pPageMail->m_psArrayMailProgram, &(m_pPageMail->m_Program));
  SaveArrayToIni("Mail Program", m_pPageMail->m_psArrayMailProgram);
  SaveArrayToIni("Mail Signature", m_pPageMail->m_psArrayMailSignature);
  g_pThisApp->WriteProfileInt("Mail", "Clear", m_pPageMail->m_Clear.GetCheck());
  g_pThisApp->WriteProfileInt("Mail", "WithDate", m_pPageMail->m_WithDate.GetCheck());
  g_pThisApp->WriteProfileInt("Mail", "WithSignature", m_pPageMail->m_WithSignature.GetCheck());
  g_pThisApp->WriteProfileInt("Mail", "WithMailer", m_pPageMail->m_WithMailer.GetCheck());
  g_pThisApp->WriteProfileInt("People", "OnStart", m_pPagePeople->m_OnStart.GetCheck());
  g_pThisApp->WriteProfileInt("People", "OnEnd", m_pPagePeople->m_OnEnd.GetCheck());
  g_pThisApp->WriteProfileInt("People", "Minutes", m_pPagePeople->m_nPeopleMinutes);

  m_pPagePeople->SavePeople();

  g_WriteToHistory(TRUE, ">>> SETTINGS SAVED <<<");
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerDlg::OnClearOutput() 
{
  if(m_OutputTabCtrl.GetCurSel() == 0)
  {
    m_History.SetReadOnly(FALSE);
    m_History.SetSel(0, -1);	
    m_History.Clear();	
    m_History.SetReadOnly();
  }
  else
  {
    m_Output.SetReadOnly(FALSE);
    m_Output.SetSel(0, -1);	
    m_Output.Clear();	
    m_Output.SetReadOnly();
  }
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerDlg::OnChangeHistory() 
{
  CString sHistory;
  m_History.GetWindowText(sHistory);
  if(sHistory == "" && m_OutputTabCtrl.GetCurSel() == 0)
  {
    m_ClearOutput.EnableWindow(FALSE);
    g_pMainWnd->GetMenu()->EnableMenuItem(IDM_OUTPUT_CLEAR, MF_GRAYED);
  }
  else
  {
    m_ClearOutput.EnableWindow(TRUE);
    g_pMainWnd->GetMenu()->EnableMenuItem(IDM_OUTPUT_CLEAR, MF_ENABLED);
  }
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerDlg::OnChangeOutput() 
{
  CString sOutput;
  m_Output.GetWindowText(sOutput);
  if(sOutput == "" && m_OutputTabCtrl.GetCurSel() == 1)
  {
    m_ClearOutput.EnableWindow(FALSE);
    g_pMainWnd->GetMenu()->EnableMenuItem(IDM_OUTPUT_CLEAR, MF_GRAYED);
  }
  else
  {
    m_ClearOutput.EnableWindow(TRUE);
    g_pMainWnd->GetMenu()->EnableMenuItem(IDM_OUTPUT_CLEAR, MF_ENABLED);
  }
}

/////////////////////////////////////////////////////////////////////////////

BOOL CNetManagerDlg::OnHelpInfo(HELPINFO* pHelpInfo) 
{
  GoToHelp();
	return 0;     //CDialog::OnHelpInfo(pHelpInfo);
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerDlg::OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized) 
{
	CDialog::OnActivate(nState, pWndOther, bMinimized);

  KillTimer(TIMER_ICON_BLINKING_ID);
  g_pMainWnd->SetIcon(g_pThisApp->LoadIcon(IDR_MAINFRAME), FALSE);
  g_pMainWnd->SetWindowText("NetManager");
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerDlg::OnSelchangeTabctrlOutput(NMHDR* pNMHDR, LRESULT* pResult) 
{
  switch(m_OutputTabCtrl.GetCurSel())
	{
    case 0:
      OnChangeHistory();
      m_History.ShowWindow(SW_SHOWNA);
      m_Output.ShowWindow(SW_HIDE);
      m_InfoTree.ShowWindow(SW_HIDE);
      m_InfoWindow.ShowWindow(SW_HIDE);
      m_History.SetSel(-1, -1);
      break;

    case 1:
      OnChangeOutput();
      m_Output.ShowWindow(SW_SHOWNA);
      m_History.ShowWindow(SW_HIDE);
      m_InfoTree.ShowWindow(SW_HIDE);
      m_InfoWindow.ShowWindow(SW_HIDE);
      m_Output.SetSel(-1, -1);
      break;

    case 2:
      GoToHelp();
      break;
  }

	*pResult = 0;
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerDlg::GoToHelp() 
{
  m_OutputTabCtrl.SetCurSel(2);
  m_InfoTree.ShowWindow(SW_SHOWNA);
  m_InfoWindow.ShowWindow(SW_SHOWNA);
  m_ClearOutput.EnableWindow(FALSE);
  m_Output.ShowWindow(SW_HIDE);
  m_History.ShowWindow(SW_HIDE);
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerDlg::OnSelchangedInfotree(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;

  CString sText;
  sText.LoadString(m_InfoTree.GetItemData(m_InfoTree.GetSelectedItem()));
  sText = g_MakeWindowsTextLines(sText);

  m_InfoWindow.SetSel(0, -1);
  m_InfoWindow.ReplaceSel(sText);
  m_InfoWindow.SetSel(-1, -1);
	
	*pResult = 0;
}

/////////////////////////////////////////////////////////////////////////////

BOOL CNetManagerDlg::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
  // if the cursor is not over a child window control, revert
  // to the default status bar text

  if(pWnd == this)
    SetPaneText();
  else
  {
    if(DYNAMIC_DOWNCAST(CComboBox, pWnd->GetOwner()))
      SetPaneText(pWnd->GetOwner()->GetDlgCtrlID());    // only for combobox	
    else
      SetPaneText(pWnd->GetDlgCtrlID());	              // others controls
  }

	return CDialog::OnSetCursor(pWnd, nHitTest, message);
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerDlg::SetPaneText(UINT nID)
{
  CString sText;
  if(!sText.LoadString(nID) || nID == (UINT)m_StatusBar.GetDlgCtrlID())
    sText = "NetManager";
  m_StatusBar.SetPaneText(0, sText);
}

/////////////////////////////////////////////////////////////////////////////

BOOL CNetManagerDlg::PreTranslateMessage(MSG* pMsg) 
{
  {
    // transate the message based on TTM_WINDOWFROMPOINT
    MSG msg = *pMsg;
    msg.hwnd = (HWND)m_ToolTip.SendMessage(TTM_WINDOWFROMPOINT, 0, (LPARAM)&msg.pt);
    CPoint pt = pMsg->pt;
    if (msg.message >= WM_MOUSEFIRST && msg.message <= WM_MOUSELAST)
            ::ScreenToClient(msg.hwnd, &pt);
    msg.lParam = MAKELONG(pt.x, pt.y);

    // Let the ToolTip process this message.
    m_ToolTip.RelayEvent(&msg);
  }

/*
    if(FromHandle(m_hWnd)->GetDlgCtrlID() == IDD_PAGE_FILES)
    if(FromHandle(pMsg->hwnd) == m_dlgPropSheet)
  if (m_hWnd)
  {
    m_ToolTip.RelayEvent (pMsg);

    return CDialog::PreTranslateMessage(pMsg);
  }
  return (FALSE);	
*/

	return CDialog::PreTranslateMessage(pMsg);
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerDlg::OnSettingChange(UINT uFlags, LPCTSTR lpszSection) 
{
	CDialog::OnSettingChange(uFlags, lpszSection);
	
  // for menu (more than 1 row of main menu (while resizing))
  CRect rc;
  GetClientRect(rc);
  if(rc.Height() != m_nDlgClientHeight)
    m_nDlgHeight += m_nDlgClientHeight - rc.Height();   // new height

  RedrawWindow();
  GetWindowRect(rc);
  MoveWindow(rc);
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerDlg::OnMenuSelect(UINT nItemID, UINT nFlags, HMENU hSysMenu) 
{
	CDialog::OnMenuSelect(nItemID, nFlags, hSysMenu);
	
  TCHAR szFullText[256];
  CString cstStatusText;

  if (nItemID != 0) // will be zero on a separator
  {
    AfxLoadString(nItemID, szFullText);     // this is the command id, not the button index
    AfxExtractSubString(cstStatusText, szFullText, 0, '\n');
    m_StatusBar.SetPaneText(0, cstStatusText);
  }
}

/////////////////////////////////////////////////////////////////////////////

