// PageMailDelCurrent.cpp : implementation file
//

#include "stdafx.h"
#include "netmanager.h"
#include "PageMailDelCurrent.h"
#include "GlobalsExtern.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPageMailDelCurrent

CPageMailDelCurrent::CPageMailDelCurrent()
{
}

CPageMailDelCurrent::~CPageMailDelCurrent()
{
}


BEGIN_MESSAGE_MAP(CPageMailDelCurrent, CButton)
	//{{AFX_MSG_MAP(CPageMailDelCurrent)
	ON_CONTROL_REFLECT(BN_CLICKED, OnClicked)
	ON_WM_SETFOCUS()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPageMailDelCurrent message handlers

void CPageMailDelCurrent::OnClicked() 
{
  UpdateData();
  CWnd* pCurrent = m_pOldFocus->GetOwner();
  int nCurrent = pCurrent->GetDlgCtrlID();

  if(nCurrent == IDC_FROM
    || nCurrent == IDC_TO
    || nCurrent == IDC_SERVER
    || nCurrent == IDC_SUBJECT
    || nCurrent == IDC_XMAILER
    || nCurrent == IDC_ATTACHMENTS
    )
  {
    if(MessageBox("Remove this item???", NULL, MB_ICONQUESTION | MB_YESNO) == IDYES)
    {
      CString sCurrent;
      pCurrent->GetWindowText(sCurrent);
      int nCurrent = ((CComboBox*)pCurrent)->FindStringExact(0, sCurrent);
      if(nCurrent != CB_ERR)
        if(((CComboBox*)pCurrent)->DeleteString(nCurrent) != CB_ERR)
        {
          g_WriteToHistory(TRUE, "[Mail] Removed " + sCurrent);
          pCurrent->SetWindowText("");
        }
    }
    pCurrent->SetFocus();
  }
}

/////////////////////////////////////////////////////////////////////////////

void CPageMailDelCurrent::OnSetFocus(CWnd* pOldWnd) 
{
	CButton::OnSetFocus(pOldWnd);

  m_pOldFocus = pOldWnd;
}
