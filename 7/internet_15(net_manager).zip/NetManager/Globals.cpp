#include "StdAfx.h"
#include "Globals.h"
#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////

void g_WriteToOutput(BOOL bTerminate, LPCTSTR lpText)
{
  CString sText = lpText;
  if(bTerminate)
    sText += "\r\n";

  ((CTabCtrl*)AfxGetMainWnd()->GetDlgItem(IDC_TABCTRL_OUTPUT))->SetCurSel(1);
  g_Output->ShowWindow(SW_SHOWNA);
  g_History->ShowWindow(SW_HIDE);

  g_Output->SetSel(0, -1);
  g_Output->SetSel(-1, -1);
  g_Output->ReplaceSel(sText);

  g_AnimateWait->Play(0, 0, 0);
}

/////////////////////////////////////////////////////////////////////////////

void g_WriteToHistory(BOOL bTerminate, LPCTSTR lpText)
{
  CTime Time = CTime::GetCurrentTime();;
  CString sText = lpText;
  int nLength = strlen(lpText);
  if(*(lpText + nLength - 2) == '\r' && *(lpText + nLength - 1) == '\n')
    sText = sText.Left(sText.GetLength() - 2);    
  sText += Time.Format(" - %A, %B %d, %Y, %H:%M:%S");
  if(bTerminate)
    sText += "\r\n";

  ((CTabCtrl*)AfxGetMainWnd()->GetDlgItem(IDC_TABCTRL_OUTPUT))->SetCurSel(0);
  g_History->ShowWindow(SW_SHOWNA);
  g_Output->ShowWindow(SW_HIDE);

  g_History->SetSel(0, -1);
  g_History->SetSel(-1, -1);
  g_History->ReplaceSel(sText);

  g_AnimateWait->Play(0, 0, 0);
}

/////////////////////////////////////////////////////////////////////////////

CString g_MakeWindowsTextLines(CString sInputText)
{
  int nInLen = sInputText.GetLength();
  char* psInput = sInputText.GetBuffer(nInLen);
  char* psOutputBuffer = new char[nInLen + 5000];
  char* psOutputText = psOutputBuffer;

  for(int i = 0; i < nInLen; i++)
  {
    *psOutputBuffer++ = *psInput++;

    if(*psInput == '\n')
    {
      if(*(psInput - 1) != '\r')
      {
        *psOutputBuffer++ = '\r';
        *psOutputBuffer = '\n';
      }
    }
  }
  *psOutputBuffer++ = '\0';

  sInputText.ReleaseBuffer();
  CString sOutput = psOutputText;
  delete psOutputText;
  return sOutput;
}

/////////////////////////////////////////////////////////////////////////////
