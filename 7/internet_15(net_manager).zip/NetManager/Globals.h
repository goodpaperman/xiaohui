// global macros, variables and functions

  CEdit* g_Output;
  CEdit* g_History;
  CAnimateCtrl* g_AnimateWait;
  CAnimateCtrl* g_AnimatePeople;
  CAnimateCtrl* g_AnimateNet;
  CWinApp*  g_pThisApp;
  CWnd* g_pMainWnd;

  bool  g_bStarting;
  bool  g_bEnding;
  bool  g_bNetMonitoring;
  bool  g_bPeopleMonitoring;
  bool  g_bAutoSaveSettings;
  bool  g_bWinNotification;
  bool  g_bExeImages;
  bool  g_bPeopleImages;
  void  g_WriteToOutput(BOOL, LPCTSTR);
  void  g_WriteToHistory(BOOL, LPCTSTR);
  CString g_MakeWindowsTextLines(CString);

