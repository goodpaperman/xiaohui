/*
Module : PING.H
Purpose: Interface for an MFC wrapper class to encapsulate PING
Created: PJN / 10-06-1998
History: None

Copyright (c) 1998 by PJ Naughter.  
All rights reserved.

*/

#include "afxpriv.h"

/////////////////////////// Macros ///////////////////////////

#ifndef __PING_H__
#define __PING_H__


#ifndef __AFXPRIV_H__
#pragma message("The class CPing requires AFXPRIV.H in your PCH")
#endif


/////////////////////////// Classes /////////////////////////////////


struct CPingReply
{
	in_addr	 Address;  //The IP address of the replier
	unsigned long RTT; //Round Trip time in Milliseconds
};

class CPing
{
public:
//Constructors / Destructors
	CPing();
	~CPing();

//Methods
	BOOL Ping(LPCTSTR pszHostName, CPingReply& pr, UCHAR nTTL = 10, DWORD dwTimeout = 1000, UCHAR nPacketSize = 32) const;

protected:
	BOOL Initialise() const;

	static int sm_nCount;
  static BOOL sm_bWinsock2OK;
  static __int64 sm_TimerFrequency;
};



#endif //__PING_H__

