#if !defined(AFX_PAGENETLIST_H__04DEFF02_A2F7_11D1_82C0_444553540000__INCLUDED_)
#define AFX_PAGENETLIST_H__04DEFF02_A2F7_11D1_82C0_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// PageNetList.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPageNetList window

class CPageNetList : public CListBox
{
// Construction
public:
	CPageNetList();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPageNetList)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CPageNetList();

	// Generated message map functions
protected:
	//{{AFX_MSG(CPageNetList)
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PAGENETLIST_H__04DEFF02_A2F7_11D1_82C0_444553540000__INCLUDED_)
