// PagePeople.cpp : implementation file
//

#include "stdafx.h"
#include "NetManager.h"
#include "PagePeople.h"
#include "PagePeopleList.h"
#include "GlobalsExtern.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// finger

#define WSVERSION 0x101                   // Windows Sockets version
#define INET_ADDR inet_addr            // WS DLL has the right inet_addr
typedef unsigned long IPA;
typedef IPA FAR *LPIPA;
typedef LPIPA FAR *LPPIPA;

#define FE_ERROR    1     // finger operation was not successful
#define FE_NOPORT   2     // failure to resolve finger service to a port 
#define FE_NOHOST   3     // failure to resolve host specifier
#define FE_NOSOCK   4     // failure to obtain socket for connection
#define FE_NOCONN   5     // failure to connect to remote finger server
#define FE_NOSEND   6     // failure to send finger query
#define FE_NORECV   7     // failure to receive finger data

IPA g_GetHostAddr(char*);
bool g_Finger(CString, CString, CString&);
UINT g_FingerThread(LPVOID);

/////////////////////////////////////////////////////////////////////////////
// CPagePeople property page

IMPLEMENT_DYNCREATE(CPagePeople, CPropertyPage)

CPagePeople::CPagePeople() : CPropertyPage(CPagePeople::IDD)
{
	//{{AFX_DATA_INIT(CPagePeople)
	m_sServer = _T("");
	m_sUser = _T("");
	m_nPeopleMinutes = 0;
	//}}AFX_DATA_INIT
}

CPagePeople::~CPagePeople()
{
}

void CPagePeople::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPagePeople)
	DDX_Control(pDX, IDC_LOCAL_NET, m_LocalNet);
	DDX_Control(pDX, IDC_SPIN_PEOPLE, m_PeopleSpin);
	DDX_Control(pDX, IDB_CHECK_ALL, m_CheckAll);
	DDX_Control(pDX, IDB_ACTIVE, m_Active);
	DDX_Control(pDX, IDB_ISMANUAL, m_IsManual);
	DDX_Control(pDX, IDB_ACTIVE_MAIL, m_ActiveMail);
	DDX_Control(pDX, IDB_EVERY, m_Every);
	DDX_Control(pDX, IDB_ONSTART, m_OnStart);
	DDX_Control(pDX, IDB_ONEND, m_OnEnd);
	DDX_Control(pDX, IDC_FINGERUSER, m_User);
	DDX_Control(pDX, IDC_FINGERSERVER, m_Server);
	DDX_Text(pDX, IDC_FINGERSERVER, m_sServer);
	DDV_MaxChars(pDX, m_sServer, 40);
	DDX_Text(pDX, IDC_FINGERUSER, m_sUser);
	DDV_MaxChars(pDX, m_sUser, 40);
	DDX_Text(pDX, IDC_MINUTES, m_nPeopleMinutes);
	DDV_MinMaxInt(pDX, m_nPeopleMinutes, 0, 10000);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPagePeople, CPropertyPage)
	//{{AFX_MSG_MAP(CPagePeople)
	ON_BN_CLICKED(IDB_REMOVE, OnRemove)
	ON_BN_CLICKED(IDB_FINGER, OnFinger)
	ON_BN_CLICKED(IDB_FINGER_MANUAL, OnFingerManual)
	ON_BN_CLICKED(IDC_FINGER_CURRENT, OnFingerCurrent)
	ON_NOTIFY(NM_DBLCLK, IDC_SERVERTREE, OnDblclkServertree)
	ON_BN_CLICKED(IDB_ACTIVE, OnActive)
	ON_BN_CLICKED(IDB_ACTIVE_MAIL, OnActiveMail)
	ON_BN_CLICKED(IDB_ISMANUAL, OnIsManual)
	ON_BN_CLICKED(IDB_CHECK_ALL, OnCheckAll)
	ON_BN_CLICKED(IDB_EVERY, OnEvery)
	ON_EN_KILLFOCUS(IDC_MINUTES, OnKillfocusMinutes)
	ON_BN_CLICKED(IDC_LOCAL_NET, OnLocalNet)
	ON_EN_CHANGE(IDC_FINGERSERVER, OnChangeFingerserver)
	ON_EN_CHANGE(IDC_FINGERUSER, OnChangeFingeruser)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPagePeople message handlers

void CPagePeople::ItemInsert(LPCTSTR sServer)
{
  int nValue;

  m_pTreeCtrlItem->item.pszText = (LPSTR)sServer;
  m_pTreeCtrlItem->item.iImage = ICON_SERVER;
  m_pTreeCtrlItem->item.iSelectedImage = ICON_SERVER;

  nValue = g_pThisApp->GetProfileInt("People Servers", sServer, 0);
  switch(nValue)
  {
    case 0:
      m_pTreeCtrlItem->item.state = INDEXTOSTATEIMAGEMASK(ICON_EMPTY);
      m_pTreeCtrlItem->item.stateMask = TVIS_STATEIMAGEMASK;
      break;
    case 1:
      m_pTreeCtrlItem->item.state = INDEXTOSTATEIMAGEMASK(ICON_EMPTY) | TVIS_BOLD;
      m_pTreeCtrlItem->item.stateMask = TVIS_STATEIMAGEMASK | TVIS_BOLD;
      break;
    case 2:
      m_pTreeCtrlItem->item.state = INDEXTOSTATEIMAGEMASK(ICON_MANUAL);
      m_pTreeCtrlItem->item.stateMask = TVIS_STATEIMAGEMASK;
      break;
    default:
      m_pTreeCtrlItem->item.state = INDEXTOSTATEIMAGEMASK(ICON_MANUAL) | TVIS_BOLD;
      m_pTreeCtrlItem->item.stateMask = TVIS_STATEIMAGEMASK | TVIS_BOLD;
  }
  m_pTreeCtrlItem->hParent = TVI_ROOT;
  m_pTreeCtrlItem->hParent = m_ServerTree.InsertItem(m_pTreeCtrlItem);
}

/////////////////////////////////////////////////////////////////////////////

void CPagePeople::ItemInsert(LPCTSTR sServer, LPCTSTR sUser)
{
  int nValue;
  m_pTreeCtrlItem->item.pszText = (LPSTR)sUser;
  m_pTreeCtrlItem->item.iImage = ICON_USER;
  m_pTreeCtrlItem->item.iSelectedImage = ICON_USER;

  nValue = g_pThisApp->GetProfileInt(sServer, sUser, 0);
  switch(nValue)
  {
    case 0:
      m_pTreeCtrlItem->item.state = INDEXTOSTATEIMAGEMASK(ICON_EMPTY);
      m_pTreeCtrlItem->item.stateMask = TVIS_STATEIMAGEMASK;
      break;
    case 1:
      m_pTreeCtrlItem->item.state = INDEXTOSTATEIMAGEMASK(ICON_EMPTY) | TVIS_BOLD;
      m_pTreeCtrlItem->item.stateMask = TVIS_STATEIMAGEMASK | TVIS_BOLD;
      break;
    case 2:
      m_pTreeCtrlItem->item.state = INDEXTOSTATEIMAGEMASK(ICON_MAIL);
      m_pTreeCtrlItem->item.stateMask = TVIS_STATEIMAGEMASK;
      break;
    default:
      m_pTreeCtrlItem->item.state = INDEXTOSTATEIMAGEMASK(ICON_MAIL) | TVIS_BOLD;
      m_pTreeCtrlItem->item.stateMask = TVIS_STATEIMAGEMASK | TVIS_BOLD;
  }
	m_ServerTree.InsertItem(m_pTreeCtrlItem);
}

/////////////////////////////////////////////////////////////////////////////

void CPagePeople::SavePeople()
{
  HTREEITEM hServerItem = m_ServerTree.GetRootItem();
  HTREEITEM hUserItem;

  CString sServer;
  CString sUser;
  int nValue;
  do
  {
    sServer = m_ServerTree.GetItemText(hServerItem);

    nValue = 0;
    if(m_ServerTree.GetItemState(hServerItem, TVIF_STATE) & TVIS_BOLD)
      nValue = nValue|1;
    if((m_ServerTree.GetItemState(hServerItem, TVIS_STATEIMAGEMASK) & TVIS_STATEIMAGEMASK) == INDEXTOSTATEIMAGEMASK(ICON_MANUAL))
      nValue = nValue|2;

    g_pThisApp->WriteProfileInt("People Servers", sServer, nValue);
  
    if(hUserItem = m_ServerTree.GetChildItem(hServerItem))
    {
      do
      {
        sUser = m_ServerTree.GetItemText(hUserItem);
        nValue = 0;
        if(m_ServerTree.GetItemState(hUserItem, TVIF_STATE) & TVIS_BOLD)
          nValue = nValue|1;
        if((m_ServerTree.GetItemState(hUserItem, TVIS_STATEIMAGEMASK) & TVIS_STATEIMAGEMASK) == INDEXTOSTATEIMAGEMASK(ICON_MAIL))
          nValue = nValue|2;
        g_pThisApp->WriteProfileInt(sServer, sUser, nValue);
        hUserItem = m_ServerTree.GetNextSiblingItem(hUserItem);
      }
      while(hUserItem);
    }
    hServerItem = m_ServerTree.GetNextSiblingItem(hServerItem);
  }
  while(hServerItem);
}

/////////////////////////////////////////////////////////////////////////////

BOOL CPagePeople::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
  m_OnStart.SetCheck(g_pThisApp->GetProfileInt("People", "OnStart", 0));
  m_OnEnd.SetCheck(g_pThisApp->GetProfileInt("People", "OnEnd", 0));

  m_ServerTree.SubclassDlgItem(IDC_SERVERTREE, this);
  m_PeopleSpin.SetRange(0, 10000);

	m_pTreeCtrlItem = new TV_INSERTSTRUCT;
	m_pTreeCtrlItem->item.mask = (TVIF_IMAGE | TVIF_SELECTEDIMAGE | TVIF_TEXT | TVIF_STATE);

// fill out treecontrol from ini file --------------------------------------

  CStringArray* psCurrentServerArray;
  int nServerNum = m_pAllServersArray->GetSize();
  for(int nServerIndex = 0; nServerIndex < nServerNum; nServerIndex++)
  {
    psCurrentServerArray = (CStringArray*)m_pAllServersArray->GetAt(nServerIndex);
    int nItemNum = psCurrentServerArray->GetSize();
    ItemInsert(psCurrentServerArray->GetAt(0));   // first item - server

    for(int nUserIndex = 1; nUserIndex < nItemNum; nUserIndex++)
      ItemInsert(psCurrentServerArray->GetAt(0), psCurrentServerArray->GetAt(nUserIndex));
  }

// image list ---------------------------------------------------------------

  HICON Icon0 = g_pThisApp->LoadIcon(IDI_SERVER);
  HICON Icon1 = g_pThisApp->LoadIcon(IDI_USER);
  HICON Icon2 = g_pThisApp->LoadIcon(IDI_MANUAL);
  HICON Icon3 = g_pThisApp->LoadIcon(IDI_MAIL);
  HICON Icon4 = g_pThisApp->LoadIcon(IDI_LINE);

  m_pImagesSmall = new CImageList;
  m_pImagesSmall->Create(16, 16, ILC_COLORDDB | ILC_MASK, 5, 0);
  m_pImagesLarge = new CImageList;
  m_pImagesLarge->Create(32, 32, ILC_COLORDDB | ILC_MASK, 5, 0);

  m_pImagesSmall->Add(Icon0);
  m_pImagesSmall->Add(Icon1);
  m_pImagesSmall->Add(Icon2);
  m_pImagesSmall->Add(Icon3);
  m_pImagesSmall->Add(Icon4);

  m_pImagesLarge->Add(Icon0);
  m_pImagesLarge->Add(Icon1);
  m_pImagesLarge->Add(Icon2);
  m_pImagesLarge->Add(Icon3);
  m_pImagesLarge->Add(Icon4);

  if(!g_bPeopleImages)
    SetSmallImages();
  else
    SetLargeImages();

  if(m_ServerTree.GetRootItem())
    m_ServerTree.SelectItem(m_ServerTree.GetRootItem());

  if(IfCanCheckAll())
  {
    if(g_bPeopleMonitoring)
    {
      m_Every.SetCheck(1);
      OnEvery();
    }
  }
  else
    m_Every.SetCheck(0);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

/////////////////////////////////////////////////////////////////////////////

void CPagePeople::SetSmallImages()
{
  m_ServerTree.SetImageList(m_pImagesSmall, TVSIL_NORMAL);
  m_ServerTree.SetImageList(m_pImagesSmall, TVSIL_STATE);
}

/////////////////////////////////////////////////////////////////////////////

void CPagePeople::SetLargeImages()
{
  m_ServerTree.SetImageList(m_pImagesLarge, TVSIL_NORMAL);
  m_ServerTree.SetImageList(m_pImagesLarge, TVSIL_STATE);
}

/////////////////////////////////////////////////////////////////////////////

void CPagePeople::AddServer() 
{
  UpdateData();
  if(m_sServer != "")
  {
    m_pTreeCtrlItem->item.pszText = m_sServer.GetBuffer(MAX_PATH);
    m_sServer.ReleaseBuffer();
    m_pTreeCtrlItem->item.iImage = 0;
    m_pTreeCtrlItem->item.iSelectedImage = 0;
    m_pTreeCtrlItem->hParent = TVI_ROOT;
    m_pTreeCtrlItem->hParent = m_ServerTree.InsertItem(m_pTreeCtrlItem);

    g_WriteToHistory(TRUE, "[People] Added " + m_sServer);
    m_Server.SetWindowText("");
  }
  else
    AfxMessageBox("You must enter a server");	

  m_ServerTree.RedrawWindow();
}

/////////////////////////////////////////////////////////////////////////////

void CPagePeople::AddUser() 
{
  UpdateData();

  if(m_sUser != "")
  {
    HTREEITEM hCurrItem = m_ServerTree.GetSelectedItem();
    if(hCurrItem)
    {
      HTREEITEM hCurrServer;
      if(hCurrServer = m_ServerTree.GetParentItem(hCurrItem))
        hCurrItem = hCurrServer;

      m_pTreeCtrlItem->hParent = hCurrItem;
      m_pTreeCtrlItem->item.pszText = (LPSTR)m_sUser.GetBuffer(MAX_PATH);
      m_ServerTree.SetItemImage(m_pTreeCtrlItem->hParent = m_ServerTree.InsertItem(m_pTreeCtrlItem), 1, 1);
      m_sUser.ReleaseBuffer();

      g_WriteToHistory(TRUE, "[People] Added " + m_sUser + " to " + m_ServerTree.GetItemText(hCurrItem));
      m_User.SetWindowText("");
    }
    else
      AfxMessageBox("Select a server");	
  }
  else
    AfxMessageBox("You must enter a user");	

  m_ServerTree.RedrawWindow();
}

/////////////////////////////////////////////////////////////////////////////

void CPagePeople::OnRemove() 
{
  HTREEITEM hCurrItem = m_ServerTree.GetSelectedItem();
  if(hCurrItem)
  {
    if(MessageBox("Remove this item???", NULL, MB_ICONQUESTION | MB_YESNO) == IDYES)
    {
      g_WriteToHistory(TRUE, "[People] Removed " + m_ServerTree.GetItemText(hCurrItem));
      m_ServerTree.DeleteItem(hCurrItem);	
    }
  }
  else
    AfxMessageBox("Nothing selected");	
}

/////////////////////////////////////////////////////////////////////////////

void CPagePeople::OnIsManual() 
{
  HTREEITEM hCurrItem = m_ServerTree.GetSelectedItem();
  if((m_ServerTree.GetItemState(hCurrItem, TVIS_STATEIMAGEMASK) & TVIS_STATEIMAGEMASK) == INDEXTOSTATEIMAGEMASK(ICON_MANUAL))
    m_ServerTree.SetItemState(hCurrItem, INDEXTOSTATEIMAGEMASK(ICON_EMPTY), TVIS_STATEIMAGEMASK);
  else
    m_ServerTree.SetItemState(hCurrItem, INDEXTOSTATEIMAGEMASK(ICON_MANUAL), TVIS_STATEIMAGEMASK);
}

/////////////////////////////////////////////////////////////////////////////

void CPagePeople::OnActive() 
{
  HTREEITEM hCurrItem = m_ServerTree.GetSelectedItem();
  m_ServerTree.SetItemData(hCurrItem, 0);
  if(m_ServerTree.GetItemState(hCurrItem, TVIF_STATE) & TVIS_BOLD)
    m_ServerTree.SetItemState(hCurrItem, NULL, TVIS_BOLD);
  else
    m_ServerTree.SetItemState(hCurrItem, TVIS_BOLD, TVIS_BOLD);

  IfCanCheckAll();
}

/////////////////////////////////////////////////////////////////////////////

void CPagePeople::OnActiveMail() 
{
  HTREEITEM hCurrItem = m_ServerTree.GetSelectedItem();
  if((m_ServerTree.GetItemState(hCurrItem, TVIS_STATEIMAGEMASK) & TVIS_STATEIMAGEMASK) == INDEXTOSTATEIMAGEMASK(ICON_MAIL))
    m_ServerTree.SetItemState(hCurrItem, INDEXTOSTATEIMAGEMASK(ICON_EMPTY), TVIS_STATEIMAGEMASK);
  else
    m_ServerTree.SetItemState(hCurrItem, INDEXTOSTATEIMAGEMASK(ICON_MAIL), TVIS_STATEIMAGEMASK);

  IfCanCheckAll();
}

/////////////////////////////////////////////////////////////////////////////

void CPagePeople::OnDblclkServertree(NMHDR* pNMHDR, LRESULT* pResult) 
{
  HTREEITEM hParentItem;
  HTREEITEM hCurrItem = m_ServerTree.GetSelectedItem();
  CString sServer;
  CString sUser;
  sUser = m_ServerTree.GetItemText(hCurrItem);

  if(hParentItem = m_ServerTree.GetParentItem(hCurrItem))
  {
    sServer = m_ServerTree.GetItemText(hParentItem);
    if((m_ServerTree.GetItemState(hParentItem, TVIS_STATEIMAGEMASK) & TVIS_STATEIMAGEMASK) == INDEXTOSTATEIMAGEMASK(ICON_MANUAL))
      FingerManual(sServer, sUser);       // manual finger
    else
    {
      CStringArray* pasFinger = new CStringArray;
      pasFinger->Add(sServer);
      pasFinger->Add(sUser);
      AfxBeginThread(g_FingerThread, pasFinger);
    }
  }  

	*pResult = 0;
}

/////////////////////////////////////////////////////////////////////////////

void CPagePeople::OnFingerManual() 
{
  UpdateData();
  if(m_sServer == "" || m_sUser == "")
    AfxMessageBox("You must enter a server and a user!");
  else
  {
    CString sUserFind = m_sUser;
    if(sUserFind.GetAt(0) == '"')
      sUserFind = sUserFind.Mid(1, sUserFind.GetLength()-2);

    FingerManual(m_sServer, sUserFind);
  }
}

/////////////////////////////////////////////////////////////////////////////

void CPagePeople::FingerManual(CString sServer, CString sUser) 
{
  CString sFingerText;
  if(g_Finger(sServer, sUser, sFingerText))
  {
    CString sUserFind = sUser;
    if(sUserFind.GetAt(0) == '"')
      sUserFind = sUserFind.Mid(1, sUserFind.GetLength()-2);
    sUserFind.MakeUpper();
    sFingerText.MakeUpper();
    CString sOutput;
    if(sFingerText.Find(sUserFind) != -1)
      sOutput = "[People] User " + sUser + " is ON-Line!";
    else
      sOutput = "[People] User " + sUser + " is OFF-Line!";

    g_WriteToHistory(TRUE, sOutput);
  }
  else
  {
    CString sOutputText = g_MakeWindowsTextLines(sFingerText);
    g_WriteToHistory(TRUE, sOutputText);
  }
}

/////////////////////////////////////////////////////////////////////////////

void CPagePeople::OnCheckAll() 
{
  ResetServersAndUsers();

  CString sOutput;
  CheckAll(sOutput);
  g_WriteToOutput(TRUE, sOutput);
}

/////////////////////////////////////////////////////////////////////////////

void CPagePeople::OnEvery() 
{
  if(m_Every.GetCheck())
  {
    UINT nSpeed = m_nPeopleMinutes * TIMER_DELAY;
    if(nSpeed == 0)
      nSpeed = 10*1000;

    ResetServersAndUsers();
    GetParentOwner()->SetTimer(TIMER_PEOPLE_ID, nSpeed, NULL);
    g_AnimatePeople->Play(0, -1, -1);
    g_WriteToHistory(TRUE, "[People] Monitoring started...");

    g_pMainWnd->GetMenu()->CheckMenuItem(IDM_PEOPLEMONITOR, MF_CHECKED | MF_BYCOMMAND);
  }
  else
  {
    g_AnimatePeople->Play(0, 0, 0);
    GetParentOwner()->KillTimer(TIMER_PEOPLE_ID);
    g_WriteToHistory(TRUE, "[People] Monitoring stopped...");

    g_pMainWnd->GetMenu()->CheckMenuItem(IDM_PEOPLEMONITOR, MF_UNCHECKED | MF_BYCOMMAND);
  }
}

/////////////////////////////////////////////////////////////////////////////

void CPagePeople::OnKillfocusMinutes() 
{
  UpdateData(); 

  if(m_Every.GetCheck())
  {
    UINT nSpeed = m_nPeopleMinutes * TIMER_DELAY;
    if(nSpeed == 0)
      nSpeed = 10*1000;
    GetParentOwner()->SetTimer(TIMER_PEOPLE_ID, nSpeed, NULL);
  }
}

/////////////////////////////////////////////////////////////////////////////

void CPagePeople::ResetServersAndUsers()
{
  HTREEITEM hServerItem = m_ServerTree.GetRootItem();
  HTREEITEM hUserItem;
  CString sItem;
  do
  {
    sItem = m_ServerTree.GetItemText(hServerItem);
    m_ServerTree.SetItemData(hServerItem, 0);
    if(hUserItem = m_ServerTree.GetChildItem(hServerItem))
    {
      do
      {
        sItem = m_ServerTree.GetItemText(hUserItem);
        m_ServerTree.SetItemData(hUserItem, 0);
        hUserItem = m_ServerTree.GetNextSiblingItem(hUserItem);
      }
      while(hUserItem);
    }
    hServerItem = m_ServerTree.GetNextSiblingItem(hServerItem);
  }
  while(hServerItem);
}

/////////////////////////////////////////////////////////////////////////////

bool CPagePeople::IfCanCheckAll()
{
  bool bResult = FALSE;
  bool bServer;
  HTREEITEM hServerItem = m_ServerTree.GetRootItem();
  HTREEITEM hUserItem;
  CString sItem;
  do
  {
    bServer = FALSE;
    if(m_ServerTree.GetItemState(hServerItem, TVIF_STATE) & TVIS_BOLD)
      bServer = TRUE;
    if(hUserItem = m_ServerTree.GetChildItem(hServerItem))
    {
      do
      {
        if(bServer == TRUE)
        {
          if(m_ServerTree.GetItemState(hUserItem, TVIF_STATE) & TVIS_BOLD)
            bResult = TRUE;
          if((m_ServerTree.GetItemState(hUserItem, TVIS_STATEIMAGEMASK) & TVIS_STATEIMAGEMASK) == INDEXTOSTATEIMAGEMASK(ICON_MAIL))
            bResult = TRUE;
        }
        hUserItem = m_ServerTree.GetNextSiblingItem(hUserItem);
      }
      while(hUserItem);
    }
    hServerItem = m_ServerTree.GetNextSiblingItem(hServerItem);
  }
  while(hServerItem);

  if(bResult)
  {
    m_CheckAll.EnableWindow(TRUE);
    m_Every.EnableWindow(TRUE);

    g_pMainWnd->GetMenu()->EnableMenuItem(IDM_PEOPLEMONITOR, MF_ENABLED);
  }
  else
  {
    m_CheckAll.EnableWindow(FALSE);
    m_Every.EnableWindow(FALSE);

    g_pMainWnd->GetMenu()->CheckMenuItem(IDM_PEOPLEMONITOR, MF_UNCHECKED | MF_BYCOMMAND);
    g_pMainWnd->GetMenu()->EnableMenuItem(IDM_PEOPLEMONITOR, MF_GRAYED);

    m_Every.SetCheck(0);
    g_AnimatePeople->Play(0, 0, 0);
    GetParentOwner()->KillTimer(TIMER_PEOPLE_ID);

  }
  return bResult;
}

/////////////////////////////////////////////////////////////////////////////

bool CPagePeople::CheckAll(CString& sOutputText)
{
#define   USER_CHECKED_ACTIVE   1
#define   USER_CHECKED_MAIL     2

  bool bCheckStatus = false;
  if(IfCanCheckAll())
  {
    HTREEITEM hServerItem = m_ServerTree.GetRootItem();
    HTREEITEM hUserItem;
    CString sServer, sUser, sUserFind;
    CString sFingerText, sFingerTextNM;
    DWORD dwUserData;
    int n;
    bool bFingerStatus;

    do
    {
      if(m_ServerTree.GetItemState(hServerItem, TVIF_STATE) & TVIS_BOLD) // is the server active?
      {
        bFingerStatus = false;
        sFingerText = "";
        sFingerTextNM = "";
        if(hUserItem = m_ServerTree.GetChildItem(hServerItem))
        {
          do
          {
            dwUserData = m_ServerTree.GetItemData(hUserItem);     // get the data

            // login or logout ------------------------------------------------
        
            if((m_ServerTree.GetItemState(hUserItem, TVIF_STATE) & TVIS_BOLD)) // is the user active?
            {
              if(!bFingerStatus)
              {
                bFingerStatus = true;
                sServer = m_ServerTree.GetItemText(hServerItem);
                if(!g_Finger(sServer, "", sFingerText))
                {
                  sOutputText += g_MakeWindowsTextLines(sFingerText);
                  sOutputText += "\r\n\0";
                  bCheckStatus = true;
                }
                else
                  sFingerText.MakeUpper();
              }

              sUser = m_ServerTree.GetItemText(hUserItem);
              if((n = sUser.Find('.')) != -1)
                sUser.SetAt(n, ' ');  
              if((n = sUser.Find('_')) != -1)
                sUser.SetAt(n, ' ');  
              sUserFind = sUser;
              sUserFind.MakeUpper();

              if(sUserFind.GetAt(0) == '"')
                sUserFind = sUserFind.Mid(1, sUserFind.GetLength() - 2);

              if(sFingerText.Find(sUserFind) != -1)
              {
                if(!(dwUserData & USER_CHECKED_ACTIVE))
                {
                  dwUserData |= USER_CHECKED_ACTIVE;
                  sOutputText += ("[People] User " + sUser + " is ON-Line! (" + sServer +")\r\n");
                  bCheckStatus = true;
                }
              }
              else
              {
                if(dwUserData & USER_CHECKED_ACTIVE)
                {
                  dwUserData ^= USER_CHECKED_ACTIVE;
                  sOutputText += ("[People] User " + sUser + " is OFF-Line! (" + sServer + ")\r\n");
                  bCheckStatus = true;
                }
              }
            }

            // new mail -------------------------------------------------------
        
            if((m_ServerTree.GetItemState(hUserItem, TVIS_STATEIMAGEMASK) & TVIS_STATEIMAGEMASK) == INDEXTOSTATEIMAGEMASK(ICON_MAIL)) // kontrolovat mail?
            {
              sServer = m_ServerTree.GetItemText(hServerItem);
              sUser = m_ServerTree.GetItemText(hUserItem);
              if(!g_Finger(sServer, sUser, sFingerTextNM))
              {
                sOutputText += g_MakeWindowsTextLines(sFingerTextNM);
                sOutputText += "\r\n\0";
                bCheckStatus = true;
              }
              else
              {
                sFingerTextNM.MakeUpper();
                if(!(sFingerTextNM.Find("NO MAIL") != -1 || sFingerTextNM.Find("NO UNREAD") != -1))
                  if(!(dwUserData & USER_CHECKED_MAIL))
                  {
                    dwUserData |= USER_CHECKED_MAIL;
                    sOutputText += ("[People] User " + sUser + " has New Mail! (" + sServer + ")\r\n");
                    bCheckStatus = true;
                  }
              }
            }

            // ----------------------------------------------------------------

            m_ServerTree.SetItemData(hUserItem, dwUserData);
            hUserItem = m_ServerTree.GetNextSiblingItem(hUserItem);
          }
          while(hUserItem);
        }
      }
      hServerItem = m_ServerTree.GetNextSiblingItem(hServerItem);
    }
    while(hServerItem);

    if(!bCheckStatus)
      sOutputText = "[People] - No changes, Nobody Online\r\n";
  }
  else
    sOutputText = "[People] - Nothing to check\r\n";

  return bCheckStatus;
}

/////////////////////////////////////////////////////////////////////////////

UINT g_LocalNet(LPVOID pParam)
{
  CPagePeople* pOwner = (CPagePeople*)pParam;

  CString sIpAddress;
  unsigned long ulIpAddress = 0x0;

  hostent* phe;
  char abHostName[255];

  if((!gethostname(abHostName, sizeof(abHostName)))  &&
     ((phe = gethostbyname(abHostName)) != NULL) &&
     (phe->h_length == 4))
  {
    CopyMemory(&ulIpAddress, phe->h_addr, 4);

    ulIpAddress &= 0x00ffffff;

    CString sIP;
    for(int i = 0; i < 255; i++)
	  {
		  if(phe = gethostbyaddr((LPCSTR)&ulIpAddress, 4, PF_INET))
      {
        pOwner->ItemInsert(phe->h_name);

        in_addr inaddr;
        inaddr.s_addr = ulIpAddress;
        CString sIpAddress = inet_ntoa(inaddr);
      }
      ulIpAddress += 0x01000000;
    }
  }

  g_AnimateWait->Play(0, 0, 0);
  g_WriteToOutput(TRUE, "[People] Looking up hostnames finished...");

  return 0;
}

/////////////////////////////////////////////////////////////////////////////

void CPagePeople::OnLocalNet() 
{
  AfxBeginThread(g_LocalNet, this);
  g_WriteToOutput(TRUE, "[People] Looking up hostnames, please wait...");
}

/////////////////////////////////////////////////////////////////////////////

BOOL CPagePeople::PreTranslateMessage(MSG* pMsg) 
{
  if(pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_RETURN)
  {
    switch(GetFocus()->GetDlgCtrlID())
    {
      case IDC_FINGERSERVER:
        AddServer();
        break;
      case IDC_FINGERUSER:
        AddUser();
        break;
      case IDC_MINUTES:
        m_Every.SetFocus();
        break;
    }
  }

	return CPropertyPage::PreTranslateMessage(pMsg);
}

/////////////////////////////////////////////////////////////////////////////

void CPagePeople::OnChangeFingerserver() 
{
  UpdateData();

  CString sServer;
  m_Server.GetWindowText(sServer);
  CString sUser;
  m_User.GetWindowText(sUser);

  if(sServer != "")
  	GetDlgItem(IDB_FINGER)->EnableWindow(TRUE);
  else
  	GetDlgItem(IDB_FINGER)->EnableWindow(FALSE);

  if(sServer != "" && sUser != "")
  	GetDlgItem(IDB_FINGER_MANUAL)->EnableWindow(TRUE);
  else
  	GetDlgItem(IDB_FINGER_MANUAL)->EnableWindow(FALSE);
}

/////////////////////////////////////////////////////////////////////////////

void CPagePeople::OnChangeFingeruser() 
{
  UpdateData();

  CString sServer;
  m_Server.GetWindowText(sServer);
  CString sUser;
  m_User.GetWindowText(sUser);
  if(sUser != "" && sServer != "")
  	GetDlgItem(IDB_FINGER_MANUAL)->EnableWindow(TRUE);
  else
  	GetDlgItem(IDB_FINGER_MANUAL)->EnableWindow(FALSE);
}

///////////////////////////////////////////////////////////////////////////////
// GetHostAddr -- gets host's internet address. Interprets argument first    //
// as dotted internet address string, and failing that, as a DNS host name.  //
///////////////////////////////////////////////////////////////////////////////

IPA g_GetHostAddr(char* szHostName)
{
  IPA ipa;
  HOSTENT FAR *phe; // pts to host info struct (internally allocated)

  if((ipa = INET_ADDR(szHostName)) != INADDR_NONE)
    return ipa;

  if(phe = gethostbyname(szHostName))
  {
    ipa = *(IPA FAR*)*(phe->h_addr_list);
    return ipa;
  }
  return INADDR_NONE;
}

///////////////////////////////////////////////////////////////////////////////
// Finger -- queries remote finger server for list of users currently        //
// logged in. We start by resolving the finger tcp service                   //
// to a port number, and then we resolve the host specifier to an IP address.//
// Finger then establishes the connection, submits query, and retrieves      //
// results.                                                                  //
///////////////////////////////////////////////////////////////////////////////

bool g_Finger(CString sHost, CString sUser, CString& sFingerOutput)
{
  g_AnimateWait->Play(0, -1, -1);           // start animation

  bool bFingerRet = true;                   // assume success
  SERVENT FAR *pse;                         // pts to "service" data (internally allocated)

  char szHostName[40];
  char szUserName[40];

  strcpy(szHostName, sHost);
  strcpy(szUserName, sUser);

  if(pse = getservbyname("finger", NULL))   // looking for finger tcp port
  {
    UINT FingerPort;	                      // hold the data returned by getservbyname
                                            // because the standard says you *must* copy this
                                            // data out before calling any winsock API function
    IPA ipa;                                // holds internet protocol address

    FingerPort = pse->s_port;

    if((ipa = g_GetHostAddr((szHostName))) != INADDR_NONE)
    {
      SOCKET strFingerSocket;               // communications end point

      if((strFingerSocket = socket(AF_INET, SOCK_STREAM, 0)) >= 0)
      {
        SOCKADDR_IN strFingerServer;
        memset(&strFingerServer, 0, sizeof(strFingerServer));   // address of the finger server
        strFingerServer.sin_family = AF_INET;
        strFingerServer.sin_port = FingerPort;
        strFingerServer.sin_addr.s_addr = ipa;

        // establish a stream connection to server
        if(!connect(strFingerSocket, (SOCKADDR *)&strFingerServer, sizeof(strFingerServer)))
        {
          char msg[40 + 3];
          int msglen;

          strcpy(msg, szUserName);
          strcat(msg, "\r\n");
          msglen = strlen(msg);

          if(send(strFingerSocket, msg, msglen, 0) == msglen)
          {
            static char buf[500];               // receive buffer
            int nchars;                         // n chars just received, or error

            while((nchars = recv(strFingerSocket, (char FAR *)&buf, sizeof(buf), 0)) > 0)
            {
              *(buf + nchars) = 0;
              sFingerOutput += buf;
            }

            if (nchars < 0)
            {
              sFingerOutput = "[People] Finger Error (error during receive) - " + sHost;  //FE_NORECV
              bFingerRet = false;
            }
          }
          else
          {
            sFingerOutput = "[People] Finger Error (didn't send it (all) - " + sHost;     //FE_NOSEND
            bFingerRet = false;
          }
        }
        else
        {
          sFingerOutput = "[People] Finger Error (cannot connect to server) - " + sHost;  //FE_NOCONN
          closesocket(strFingerSocket);
          bFingerRet = false;
        }
      }
      else
      {
        sFingerOutput = "[People] Finger Error (cannot get socket) - " + sHost;           //FE_NOSOCK
        bFingerRet = false;
      }
    }
    else
    {
      sFingerOutput = "[People] Finger Error (don't recognize host name) - " + sHost;     //FE_NOHOST 
      bFingerRet = false;
    }
  }
  else
  {
    sFingerOutput = "[People] Finger Error (can't find port) - " + sHost;          //FE_NOPORT
    bFingerRet = false;
  }
  g_AnimateWait->Play(0, 0, 0);

  return (bFingerRet);
}

/////////////////////////////////////////////////////////////////////////////

UINT g_FingerThread(LPVOID pParam)
{
  CString sHost = ((CStringArray*)pParam)->GetAt(0);
  CString sUser = ((CStringArray*)pParam)->GetAt(1);
  ((CStringArray*)pParam)->RemoveAll();
  delete ((CStringArray*)pParam);

  CString sOutput;
  g_AnimateWait->Play(0, -1, -1);           // start animation

  SERVENT FAR *pse;                         // pts to "service" data (internally allocated)
  char szHostName[40];
  char szUserName[40];

  strcpy(szHostName, sHost);
  strcpy(szUserName, sUser);

  if(pse = getservbyname("finger", NULL))   // looking for finger tcp port
  {
    UINT FingerPort;	                      // hold the data returned by getservbyname
                                            // because the standard says you *must* copy this
                                            // data out before calling any winsock API function
    IPA ipa;                                // holds internet protocol address

    FingerPort = pse->s_port;

    if((ipa = g_GetHostAddr((szHostName))) != INADDR_NONE)
    {
      SOCKET strFingerSocket;               // communications end point

      if((strFingerSocket = socket(AF_INET, SOCK_STREAM, 0)) >= 0)
      {
        SOCKADDR_IN strFingerServer;
        memset(&strFingerServer, 0, sizeof(strFingerServer));   // address of the finger server
        strFingerServer.sin_family = AF_INET;
        strFingerServer.sin_port = FingerPort;
        strFingerServer.sin_addr.s_addr = ipa;

        // establish a stream connection to server
        if(!connect(strFingerSocket, (SOCKADDR *)&strFingerServer, sizeof(strFingerServer)))
        {
          char msg[40 + 3];
          int msglen;

          strcpy(msg, szUserName);
          strcat(msg, "\r\n");
          msglen = strlen(msg);

          if(send(strFingerSocket, msg, msglen, 0) == msglen)
          {
            static char buf[500];               // receive buffer
            int nchars;                         // n chars just received, or error

            while((nchars = recv(strFingerSocket, (char FAR *)&buf, sizeof(buf), 0)) > 0)
            {
              *(buf + nchars) = 0;
              sOutput += buf;
            }

            if (nchars < 0)
              sOutput = "[People] Finger Error (error during receive) - " + sHost;  //FE_NORECV
          }
          else
            sOutput = "[People] Finger Error (didn't send it (all) - " + sHost;     //FE_NOSEND
        }
        else
        {
          sOutput = "[People] Finger Error (cannot connect to server) - " + sHost;  //FE_NOCONN
          closesocket(strFingerSocket);
        }
      }
      else
        sOutput = "[People] Finger Error (cannot get socket) - " + sHost;           //FE_NOSOCK
    }
    else
      sOutput = "[People] Finger Error (don't recognize host name) - " + sHost;     //FE_NOHOST 
  }
  else
    sOutput = "[People] Finger Error (can't find port) - " + sHost;                 //FE_NOPORT

  g_AnimateWait->Play(0, 0, 0);

  CString sOutputText = g_MakeWindowsTextLines(sOutput);
  g_WriteToOutput(TRUE, sOutputText);

  return 0;
}

/////////////////////////////////////////////////////////////////////////////

void CPagePeople::OnFinger() 
{
  UpdateData();

  CStringArray* pasFinger = new CStringArray;
  pasFinger->Add(m_sServer);
  pasFinger->Add(m_sUser);
  AfxBeginThread(g_FingerThread, pasFinger);
}

/////////////////////////////////////////////////////////////////////////////

void CPagePeople::OnFingerCurrent() 
{
  bool bManual = false;
  HTREEITEM hParentItem;
  HTREEITEM hCurrItem = m_ServerTree.GetSelectedItem();
  if(hCurrItem)
  {
    CString sServer;
    CString sUser;
    sUser = m_ServerTree.GetItemText(hCurrItem);

    if(hParentItem = m_ServerTree.GetParentItem(hCurrItem))
    {
      sServer = m_ServerTree.GetItemText(hParentItem);
      if((m_ServerTree.GetItemState(hParentItem, TVIS_STATEIMAGEMASK) & TVIS_STATEIMAGEMASK) == INDEXTOSTATEIMAGEMASK(ICON_MANUAL))
        bManual = true;
    }  
    else
    {
      sServer = sUser;
      sUser = "";
    }

    if(bManual)
      FingerManual(sServer, sUser);       // manual finger
    else
    {
      CStringArray* pasFinger = new CStringArray;
      pasFinger->Add(sServer);
      pasFinger->Add(sUser);
      AfxBeginThread(g_FingerThread, pasFinger);
    }
  }
  else
    AfxMessageBox("Nothing selected");	
}

/////////////////////////////////////////////////////////////////////////////
