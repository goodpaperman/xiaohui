// NetManager.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "NetManager.h"
#include "NetManagerDlg.h"
#include "Splash.h"
#include "GlobalsExtern.h"
#include "AboutDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNetManagerApp

BEGIN_MESSAGE_MAP(CNetManagerApp, CWinApp)
	//{{AFX_MSG_MAP(CNetManagerApp)
	ON_COMMAND(IDM_STARTALL, OnStartall)
	ON_COMMAND(IDM_ENDALL, OnEndall)
	ON_COMMAND(IDM_NETMONITOR, OnNetmonitor)
	ON_COMMAND(IDM_PEOPLEMONITOR, OnPeoplemonitor)
	ON_COMMAND(IDM_QUIT, OnQuit)
	ON_COMMAND(IDM_STARTING, OnStarting)
	ON_COMMAND(IDM_ENDING, OnEnding)
	ON_COMMAND(IDM_NETMONITORING, OnNetmonitoring)
	ON_COMMAND(IDM_PEOPLEMONITORING, OnPeoplemonitoring)
	ON_COMMAND(IDM_AUTOSAVE, OnAutosave)
	ON_COMMAND(IDM_EDITINIFILE, OnEditinifile)
	ON_COMMAND(IDM_FONT, OnFont)
	ON_COMMAND(IDM_SAVE, OnSave)
	ON_COMMAND(IDM_ABOUT, OnAbout)
	ON_COMMAND(IDM_NOTIFICATION_ICON, OnNotificationIcon)
	ON_COMMAND(IDM_NOTIFICATION_WIN, OnNotificationWin)
	ON_COMMAND(IDM_OUTPUT_HIDE, OnOutputHide)
	ON_COMMAND(IDM_OUTPUT_SHOW, OnOutputShow)
	ON_COMMAND(IDM_OUTPUT_CLEAR, OnOutputClear)
	ON_COMMAND(IDM_EXEIMAGES_LARGE, OnExeimagesLarge)
	ON_COMMAND(IDM_EXEIMAGES_SMALL, OnExeimagesSmall)
	ON_COMMAND(IDM_PEOPLEIMAGES_SMALL, OnPeopleimagesSmall)
	ON_COMMAND(IDM_PEOPLEIMAGES_LARGE, OnPeopleimagesLarge)
	ON_COMMAND(IDM_HISTORYFONT, OnHistoryfont)
	ON_COMMAND(IDM_CONTENTS, OnContents)
	//}}AFX_MSG_MAP
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNetManagerApp construction

CNetManagerApp::CNetManagerApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CNetManagerApp object

CNetManagerApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CNetManagerApp initialization

BOOL CNetManagerApp::InitInstance()
{
	if(!AfxSocketInit())
	{
		AfxMessageBox("Windows sockets initialization failed.");
		return FALSE;
	}

  CMySplashWnd* pSplashWnd = new CMySplashWnd(IDB_SPLASH, 100);   // splash window
  pSplashWnd->Create();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

	::CoInitialize(NULL);   // for CDropEdit!!

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	CNetManagerDlg dlg;
	m_pMainWnd = &dlg;
  g_pMainWnd = &dlg;

	int nResponse = dlg.DoModal();

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}

/////////////////////////////////////////////////////////////////////////////

int CNetManagerApp::ExitInstance() 
{
  ::CoInitialize(NULL);         // for CDropEdit!!
	
	return CWinApp::ExitInstance();
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerApp::OnStarting() 
{
  CMenu* pMenu = g_pMainWnd->GetMenu();
  if(pMenu->GetMenuState(IDM_STARTING, MF_UNCHECKED) == MF_UNCHECKED)
  {
    pMenu->CheckMenuItem(IDM_STARTING, MF_CHECKED | MF_BYCOMMAND);
    g_bStarting = true;
  }
  else
  {
    pMenu->CheckMenuItem(IDM_STARTING, MF_UNCHECKED | MF_BYCOMMAND);
    g_bStarting = false;
  }
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerApp::OnEnding() 
{
  CMenu* pMenu = g_pMainWnd->GetMenu();
  if(pMenu->GetMenuState(IDM_ENDING, MF_UNCHECKED) == MF_UNCHECKED)
  {
    pMenu->CheckMenuItem(IDM_ENDING, MF_CHECKED | MF_BYCOMMAND);
    g_bEnding = true;
  }
  else
  {
    pMenu->CheckMenuItem(IDM_ENDING, MF_UNCHECKED | MF_BYCOMMAND);
    g_bEnding = false;
  }
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerApp::OnNetmonitoring() 
{
  CMenu* pMenu = g_pMainWnd->GetMenu();
  if(pMenu->GetMenuState(IDM_NETMONITORING, MF_UNCHECKED) == MF_UNCHECKED)
  {
    pMenu->CheckMenuItem(IDM_NETMONITORING, MF_CHECKED | MF_BYCOMMAND);
    g_bNetMonitoring = true;
  }
  else
  {
    pMenu->CheckMenuItem(IDM_NETMONITORING, MF_UNCHECKED | MF_BYCOMMAND);
    g_bNetMonitoring = false;
  }
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerApp::OnPeoplemonitoring() 
{
  CMenu* pMenu = g_pMainWnd->GetMenu();
  if(pMenu->GetMenuState(IDM_PEOPLEMONITORING, MF_UNCHECKED) == MF_UNCHECKED)
  {
    pMenu->CheckMenuItem(IDM_PEOPLEMONITORING, MF_CHECKED | MF_BYCOMMAND);
    g_bPeopleMonitoring = true;
  }
  else
  {
    pMenu->CheckMenuItem(IDM_PEOPLEMONITORING, MF_UNCHECKED | MF_BYCOMMAND);
    g_bPeopleMonitoring = false;
  }
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerApp::OnAutosave() 
{
  CMenu* pMenu = g_pMainWnd->GetMenu();
  if(pMenu->GetMenuState(IDM_AUTOSAVE, MF_UNCHECKED) == MF_UNCHECKED)
  {
    pMenu->CheckMenuItem(IDM_AUTOSAVE, MF_CHECKED | MF_BYCOMMAND);
    g_bAutoSaveSettings = true;
  }
  else
  {
    pMenu->CheckMenuItem(IDM_AUTOSAVE, MF_UNCHECKED | MF_BYCOMMAND);
    g_bAutoSaveSettings = false;
  }
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerApp::OnEditinifile() 
{
  if((int)ShellExecute(::GetDesktopWindow(), _T("open"), ((CNetManagerDlg*)m_pMainWnd)->m_sIniFilePath, NULL, NULL, SW_NORMAL)<33)
    AfxMessageBox("Error - Opening INI File ");
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerApp::OnFont() 
{
  delete ((CNetManagerDlg*)m_pMainWnd)->m_pOutputFont;
  ((CNetManagerDlg*)m_pMainWnd)->m_pOutputFont = new CFont;

  CFontDialog dlgFont;
  if(dlgFont.DoModal() == IDOK)
  {
    if(((CNetManagerDlg*)m_pMainWnd)->m_pOutputFont->CreatePointFont(dlgFont.GetSize(), dlgFont.GetFaceName()))
    {
      ((CNetManagerDlg*)m_pMainWnd)->m_pOutput->SetFont(((CNetManagerDlg*)m_pMainWnd)->m_pOutputFont);
      ((CNetManagerDlg*)m_pMainWnd)->m_nOutputFontSize = (dlgFont.GetSize()) / 10;
      ((CNetManagerDlg*)m_pMainWnd)->m_sOutputFontFace = dlgFont.GetFaceName();
    }
    else
      AfxMessageBox("Error - Setting font");
  }
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerApp::OnHistoryfont() 
{
  delete ((CNetManagerDlg*)m_pMainWnd)->m_pHistoryFont;
  ((CNetManagerDlg*)m_pMainWnd)->m_pHistoryFont = new CFont;

  CFontDialog dlgFont;
  if(dlgFont.DoModal() == IDOK)
  {
    if(((CNetManagerDlg*)m_pMainWnd)->m_pHistoryFont->CreatePointFont(dlgFont.GetSize(), dlgFont.GetFaceName()))
    {
      ((CNetManagerDlg*)m_pMainWnd)->m_History.SetFont(((CNetManagerDlg*)m_pMainWnd)->m_pHistoryFont);
      ((CNetManagerDlg*)m_pMainWnd)->m_nHistoryFontSize = (dlgFont.GetSize()) / 10;
      ((CNetManagerDlg*)m_pMainWnd)->m_sHistoryFontFace = dlgFont.GetFaceName();
    }
    else
      AfxMessageBox("Error - Setting font");
  }
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerApp::OnSave() 
{
  ((CNetManagerDlg*)m_pMainWnd)->SaveSettings();
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerApp::OnStartall() 
{
  ((CNetManagerDlg*)m_pMainWnd)->OnStart();
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerApp::OnEndall() 
{
  ((CNetManagerDlg*)m_pMainWnd)->OnEnd();
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerApp::OnQuit() 
{
  ((CNetManagerDlg*)m_pMainWnd)->OnCancel();
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerApp::OnAbout() 
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerApp::OnNetmonitor() 
{
  CMenu* pMenu = g_pMainWnd->GetMenu();
  if(pMenu->GetMenuState(IDM_NETMONITOR, MF_UNCHECKED) == MF_UNCHECKED)
  {
    pMenu->CheckMenuItem(IDM_NETMONITOR, MF_CHECKED | MF_BYCOMMAND);
    ((CNetManagerDlg*)m_pMainWnd)->m_pPageNet->m_Every.SetCheck(1);
  }
  else
  {
    pMenu->CheckMenuItem(IDM_NETMONITOR, MF_UNCHECKED | MF_BYCOMMAND);
    ((CNetManagerDlg*)m_pMainWnd)->m_pPageNet->m_Every.SetCheck(0);
  }
  ((CNetManagerDlg*)m_pMainWnd)->m_pPageNet->OnEvery2();
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerApp::OnPeoplemonitor() 
{
  CMenu* pMenu = g_pMainWnd->GetMenu();
  if(pMenu->GetMenuState(IDM_PEOPLEMONITOR, MF_UNCHECKED) == MF_UNCHECKED)
  {
    pMenu->CheckMenuItem(IDM_PEOPLEMONITOR, MF_CHECKED | MF_BYCOMMAND);
    ((CNetManagerDlg*)m_pMainWnd)->m_pPagePeople->m_Every.SetCheck(1);
  }
  else
  {
    pMenu->CheckMenuItem(IDM_PEOPLEMONITOR, MF_UNCHECKED | MF_BYCOMMAND);
    ((CNetManagerDlg*)m_pMainWnd)->m_pPagePeople->m_Every.SetCheck(0);
  }
  ((CNetManagerDlg*)m_pMainWnd)->m_pPagePeople->OnEvery();
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerApp::OnNotificationIcon() 
{
  CMenu* pMenu = g_pMainWnd->GetMenu();
  pMenu->CheckMenuItem(IDM_NOTIFICATION_ICON, MF_CHECKED | MF_BYCOMMAND);
  pMenu->CheckMenuItem(IDM_NOTIFICATION_WIN, MF_UNCHECKED | MF_BYCOMMAND);
  g_bWinNotification = false;
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerApp::OnNotificationWin() 
{
  CMenu* pMenu = g_pMainWnd->GetMenu();
  pMenu->CheckMenuItem(IDM_NOTIFICATION_WIN, MF_CHECKED | MF_BYCOMMAND);
  pMenu->CheckMenuItem(IDM_NOTIFICATION_ICON, MF_UNCHECKED | MF_BYCOMMAND);
  g_bWinNotification = true;
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerApp::OnOutputHide() 
{
  ((CNetManagerDlg*)m_pMainWnd)->HideOutput();
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerApp::OnOutputShow() 
{
  ((CNetManagerDlg*)m_pMainWnd)->ShowOutput();
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerApp::OnOutputClear() 
{
  ((CNetManagerDlg*)m_pMainWnd)->OnClearOutput();
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerApp::OnExeimagesSmall() 
{
  CMenu* pMenu = g_pMainWnd->GetMenu();
  pMenu->CheckMenuItem(IDM_EXEIMAGES_SMALL, MF_CHECKED | MF_BYCOMMAND);
  pMenu->CheckMenuItem(IDM_EXEIMAGES_LARGE, MF_UNCHECKED | MF_BYCOMMAND);
  g_bExeImages = false;
  ((CNetManagerDlg*)m_pMainWnd)->m_pPageFiles->SetSmallImages();
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerApp::OnExeimagesLarge() 
{
  CMenu* pMenu = g_pMainWnd->GetMenu();
  pMenu->CheckMenuItem(IDM_EXEIMAGES_LARGE, MF_CHECKED | MF_BYCOMMAND);
  pMenu->CheckMenuItem(IDM_EXEIMAGES_SMALL, MF_UNCHECKED | MF_BYCOMMAND);
  g_bExeImages = true;
  ((CNetManagerDlg*)m_pMainWnd)->m_pPageFiles->SetLargeImages();
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerApp::OnPeopleimagesSmall() 
{
  CMenu* pMenu = g_pMainWnd->GetMenu();
  pMenu->CheckMenuItem(IDM_PEOPLEIMAGES_SMALL, MF_CHECKED | MF_BYCOMMAND);
  pMenu->CheckMenuItem(IDM_PEOPLEIMAGES_LARGE, MF_UNCHECKED | MF_BYCOMMAND);
  g_bPeopleImages = false;
  ((CNetManagerDlg*)m_pMainWnd)->m_pPagePeople->SetSmallImages();
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerApp::OnPeopleimagesLarge() 
{
  CMenu* pMenu = g_pMainWnd->GetMenu();
  pMenu->CheckMenuItem(IDM_PEOPLEIMAGES_LARGE, MF_CHECKED | MF_BYCOMMAND);
  pMenu->CheckMenuItem(IDM_PEOPLEIMAGES_SMALL, MF_UNCHECKED | MF_BYCOMMAND);
  g_bPeopleImages = true;
  ((CNetManagerDlg*)m_pMainWnd)->m_pPagePeople->SetLargeImages();
}

/////////////////////////////////////////////////////////////////////////////

void CNetManagerApp::OnContents() 
{
  ((CNetManagerDlg*)m_pMainWnd)->GoToHelp();
  ((CNetManagerDlg*)m_pMainWnd)->ShowOutput();
}

/////////////////////////////////////////////////////////////////////////////
