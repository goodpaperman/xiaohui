#if !defined(AFX_INFOWND_H__CEEF4484_0E92_11D2_800B_D3246F5E6F4A__INCLUDED_)
#define AFX_INFOWND_H__CEEF4484_0E92_11D2_800B_D3246F5E6F4A__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// InfoWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CInfoWnd window

class CInfoWnd : public CEdit
{
// Construction
public:
	CInfoWnd();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CInfoWnd)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CInfoWnd();

	// Generated message map functions
protected:
	//{{AFX_MSG(CInfoWnd)
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INFOWND_H__CEEF4484_0E92_11D2_800B_D3246F5E6F4A__INCLUDED_)
