// PageNet.cpp : implementation file
//

#include "stdafx.h"
#include "NetManager.h"
#include "PageNet.h"
#include "GlobalsExtern.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPageNet property page

IMPLEMENT_DYNCREATE(CPageNet, CPropertyPage)

CPageNet::CPageNet() : CPropertyPage(CPageNet::IDD)
{
	//{{AFX_DATA_INIT(CPageNet)
	m_sURL = _T("");
	m_sName = _T("");
	m_nNetMinutes = 0;
	//}}AFX_DATA_INIT
}

CPageNet::~CPageNet()
{
}

void CPageNet::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPageNet)
	DDX_Control(pDX, IDC_SPIN_NET, m_NetSpin);
	DDX_Control(pDX, IDB_ONSTART2, m_OnStart);
	DDX_Control(pDX, IDB_ONEND2, m_OnEnd);
	DDX_Control(pDX, IDB_EVERY2, m_Every);
	DDX_Control(pDX, IDC_STATUSLINE, m_StatusLine);
	DDX_Control(pDX, IDC_URL, m_URL);
	DDX_Control(pDX, IDC_NAME, m_Name);
	DDX_Text(pDX, IDC_URL, m_sURL);
	DDV_MaxChars(pDX, m_sURL, 128);
	DDX_Text(pDX, IDC_NAME, m_sName);
	DDV_MaxChars(pDX, m_sName, 64);
	DDX_Text(pDX, IDC_MINUTES2, m_nNetMinutes);
	DDV_MinMaxInt(pDX, m_nNetMinutes, 0, 10000);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPageNet, CPropertyPage)
	//{{AFX_MSG_MAP(CPageNet)
	ON_LBN_SELCHANGE(IDC_LIST, OnSelChangeList)
	ON_LBN_DBLCLK(IDC_LIST, OnDblclkList)
	ON_BN_CLICKED(IDB_CHECK, OnCheckAll)
	ON_BN_CLICKED(IDB_REMOVE, OnRemove)
	ON_EN_KILLFOCUS(IDC_MINUTES2, OnKillfocusMinutes2)
	ON_BN_CLICKED(IDB_EVERY2, OnEvery2)
	ON_BN_CLICKED(IDB_EDIT, OnEdit)
	ON_EN_SETFOCUS(IDC_URL, OnSetfocusUrl)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPageNet message handlers

BOOL CPageNet::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
  m_URL.SetWindowText("http://");
  m_NetSpin.SetRange(0, 10000);
  m_List.SubclassDlgItem(IDC_LIST, this);
  m_OnStart.SetCheck(g_pThisApp->GetProfileInt("Net", "OnStart", 0));
  m_OnEnd.SetCheck(g_pThisApp->GetProfileInt("Net", "OnEnd", 0));

  int i = 0;
  int j = m_psArrayNet->GetSize();

  if(j == 1)
  {
    m_psArrayNet->Add("http://server.domain.cz/file.html");
    m_psArrayNetLastModified->Add("not tested");
    j = 2;
  }
  while(i <= (j - 2))
  {
    m_List.AddString(m_psArrayNet->GetAt(i));
    i += 2;
  }

  m_List.SetCurSel(0);

  if(g_bNetMonitoring)
  {
    m_Every.SetCheck(1);
    OnEvery2();
  }

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

/////////////////////////////////////////////////////////////////////////////

void CPageNet::OnSelChangeList() 
{
  int nItem = m_List.GetCurSel();	
  m_StatusLine.SetWindowText(m_psArrayNet->GetAt(nItem*2+1));
}

/////////////////////////////////////////////////////////////////////////////

void CPageNet::Add() 
{
  UpdateData();
  if(m_sName != "" && m_sURL.GetLength() > 7)
  {
    DWORD dwServiceType;
    CString sServer;
    CString sObject;
    INTERNET_PORT nNetPort;

    AfxParseURL(m_sURL, dwServiceType, sServer, sObject, nNetPort);
    if(dwServiceType == AFX_INET_SERVICE_HTTP)
    {
      m_List.AddString(m_sName);	
      m_psArrayNet->Add(m_sName);
      m_psArrayNet->Add(m_sURL);
      m_psArrayNetLastModified->Add("not tested");
      m_Name.SetWindowText("");
      m_URL.SetWindowText("");
      g_WriteToHistory(TRUE, "[Net] Added " + m_sName);
    }
    else
      AfxMessageBox("Sorry, only http:// services supported");
  }
  else
    AfxMessageBox("Enter Name and URL");
}

/////////////////////////////////////////////////////////////////////////////

void CPageNet::OnRemove() 
{
  UpdateData();
  int nCurSel = m_List.GetCurSel();
  if(nCurSel != LB_ERR)
  {
    if(MessageBox("Remove this item???", NULL, MB_ICONQUESTION | MB_YESNO) == IDYES)
    {
      g_WriteToHistory(TRUE, "[Net] Removed " + m_psArrayNet->GetAt(nCurSel * 2));
      m_List.DeleteString(nCurSel);
      m_psArrayNet->RemoveAt(nCurSel * 2 + 1);
      m_psArrayNet->RemoveAt(nCurSel * 2);
      m_StatusLine.SetWindowText("");
    }
  }
}

/////////////////////////////////////////////////////////////////////////////

void CPageNet::OnEdit() 
{
  UpdateData();
  int nCurSel = m_List.GetCurSel();
  if(nCurSel != LB_ERR)
  {
    int nCurSel = m_List.GetCurSel(); 
    m_Name.SetWindowText(m_psArrayNet->GetAt(nCurSel * 2));
    m_URL.SetWindowText(m_psArrayNet->GetAt(nCurSel * 2 + 1));
  }
}

/////////////////////////////////////////////////////////////////////////////

void CPageNet::OnDblclkList() 
{
  UpdateData();
  int nCurSel = m_List.GetCurSel(); 
  CString sOutput;
  Check(nCurSel, sOutput);
  g_WriteToOutput(TRUE, sOutput);
}

/////////////////////////////////////////////////////////////////////////////

void CPageNet::OnKillfocusMinutes2() 
{
  UpdateData(); 

  if(m_Every.GetCheck())
  {
    UINT nSpeed = m_nNetMinutes * TIMER_DELAY;
    if(nSpeed == 0)
      nSpeed = 10 * 1000;
    GetParentOwner()->SetTimer(TIMER_NET_ID, nSpeed, NULL);
  }
}

/////////////////////////////////////////////////////////////////////////////

void CPageNet::OnEvery2() 
{
  if(m_Every.GetCheck())
  {
    UINT nSpeed = m_nNetMinutes * TIMER_DELAY;
    if(nSpeed == 0)
      nSpeed = 10 * 1000;
    GetParentOwner()->SetTimer(TIMER_NET_ID, nSpeed, NULL);
    g_AnimateNet->Play(0, -1, -1);
    g_WriteToHistory(TRUE, "[Net] Monitoring started...");

    g_pMainWnd->GetMenu()->CheckMenuItem(IDM_NETMONITOR, MF_CHECKED | MF_BYCOMMAND);
  }
  else
  {
    GetParentOwner()->KillTimer(TIMER_NET_ID);
    g_AnimateNet->Play(0, 0, 0);
    g_WriteToHistory(TRUE, "[Net] Monitoring stopped...");

    g_pMainWnd->GetMenu()->CheckMenuItem(IDM_NETMONITOR, MF_UNCHECKED | MF_BYCOMMAND);
  }
}

/////////////////////////////////////////////////////////////////////////////

void CPageNet::OnCheckAll()
{
  CString sOutput;
  CheckAll(sOutput);
  g_WriteToHistory(TRUE, sOutput);
}

/////////////////////////////////////////////////////////////////////////////

bool CPageNet::CheckAll(CString& sOutput)
{
  UpdateData();
  bool bResult = false;
  int nItemNum = m_List.GetCount();
  for(int nItem = 0; nItem < nItemNum; nItem++)
  {
    if(Check(nItem, sOutput))
      bResult = true;
  }
  return bResult;
}

/////////////////////////////////////////////////////////////////////////////

bool CPageNet::Check(int nItem, CString& sOutputText)
{
  bool bResult = false;
  CString sURL = m_psArrayNet->GetAt(nItem * 2 + 1);

  CString sOldModified = m_psArrayNetLastModified->GetAt(nItem);

  DWORD dwServiceType;
  CString sServer;
  CString sObject;
  INTERNET_PORT nNetPort;

  AfxParseURL(sURL, dwServiceType, sServer, sObject, nNetPort);

  // http service -----------------------------------------------------------

  if(dwServiceType == AFX_INET_SERVICE_HTTP)
  {
    sOutputText += "[Net:] Checking " + m_psArrayNet->GetAt(nItem * 2) + ' ';

    HINTERNET m_Session;
    m_Session = ::InternetOpen(AfxGetAppName(), INTERNET_OPEN_TYPE_DIRECT, NULL, NULL, 0);

    if(!m_Session)
    {
      sOutputText += "Error - HTTP Session";
      bResult = true;
    }
    else
    {
      HINTERNET hHttpFile;
      char szLastModified[32];
      DWORD dwLengthLastModified = sizeof(szLastModified); 

      hHttpFile = InternetOpenUrl(m_Session, (const char*) sURL, NULL, 0, 0, 0); // Opening the Url and getting a Handle for HTTP file

      if(hHttpFile)
      {    
        if(::HttpQueryInfo(hHttpFile, HTTP_QUERY_LAST_MODIFIED, szLastModified, &dwLengthLastModified, NULL))  // Getting the size of HTTP Files
        {
          sOutputText += szLastModified;
          if(sOldModified.CompareNoCase(szLastModified) != 0)
          {
            m_psArrayNetLastModified->SetAt(nItem, szLastModified);
            sOutputText += "- File updated!";
            bResult = true;
          }
        }
        ::InternetCloseHandle(hHttpFile);           // Close the connection.
      }
      else
      {
        sOutputText += "Error - HTTP File " + sURL;
        bResult = true;
      }
      ::InternetCloseHandle(m_Session);
    }
  }
  else
    sOutputText += "[Net:] Sorry, only http:// services supported";

  return bResult;
}

/////////////////////////////////////////////////////////////////////////////

BOOL CPageNet::PreTranslateMessage(MSG* pMsg) 
{
  if(pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_RETURN)
  {
    switch(GetFocus()->GetDlgCtrlID())
    {
      case IDC_NAME:
        m_URL.SetFocus();
        break;
      case IDC_URL:
        Add();
        m_Name.SetFocus();
        break;
      case IDC_MINUTES2:
        m_Every.SetFocus();
        break;
    }
  }
	
	return CPropertyPage::PreTranslateMessage(pMsg);
}

/////////////////////////////////////////////////////////////////////////////

void CPageNet::OnSetfocusUrl() 
{
  CString sOldText;
  m_URL.GetWindowText(sOldText);

  DWORD dwServiceType;
  CString sServer;
  CString sObject;
  INTERNET_PORT nNetPort;

  AfxParseURL(sOldText, dwServiceType, sServer, sObject, nNetPort);
  if(dwServiceType == AFX_INET_SERVICE_HTTP)
    m_URL.SetWindowText(sOldText);
  else
  {
    if(sOldText.GetLength() <= 7)
      m_URL.SetWindowText("http://");
    else
      m_URL.SetWindowText("http://" + sOldText);
  }
  m_URL.SetSel(7, -1);	
}

/////////////////////////////////////////////////////////////////////////////
