#if !defined(AFX_PAGEFILESEXELIST_H__2D416F02_8871_11D1_82C0_444553540000__INCLUDED_)
#define AFX_PAGEFILESEXELIST_H__2D416F02_8871_11D1_82C0_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// PageFilesExeList.h : header file
//

#include <afxole.h>

/////////////////////////////////////////////////////////////////////////////
// CPageFilesExeList window

class CPageFilesExeList : public CListCtrl
{
// Construction
public:
	CPageFilesExeList();

// Attributes
public:

// Operations
public:

  int GetCurrentSelection();
  CString ExpandShortcut(CString &inFile);    // pro drag & drop
  void RemoveItem(int);
  void SwitchExeAuto();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPageFilesExeList)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CPageFilesExeList();

	// Generated message map functions
protected:
	//{{AFX_MSG(CPageFilesExeList)
	afx_msg void OnDblclk(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnBeginlabeledit(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnEndlabeledit(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnClick(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnDropFiles(HDROP hDropInfo);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg void OnExefilesRename();
	afx_msg void OnExefilesRemove();
	afx_msg void OnExefilesExecute();
	afx_msg void OnExefilesAdd();
	afx_msg void OnExefilesAutostart();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PAGEFILESEXELIST_H__2D416F02_8871_11D1_82C0_444553540000__INCLUDED_)
