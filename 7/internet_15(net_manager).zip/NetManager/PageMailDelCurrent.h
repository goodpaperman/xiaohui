#if !defined(AFX_PAGEMAILDELCURRENT_H__99FF4AE2_86E6_11D1_82C0_444553540000__INCLUDED_)
#define AFX_PAGEMAILDELCURRENT_H__99FF4AE2_86E6_11D1_82C0_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// PageMailDelCurrent.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPageMailDelCurrent window

class CPageMailDelCurrent : public CButton
{
// Construction
public:
	CPageMailDelCurrent();

// Attributes
public:

  CWnd* m_pOldFocus;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPageMailDelCurrent)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CPageMailDelCurrent();

	// Generated message map functions
protected:
	//{{AFX_MSG(CPageMailDelCurrent)
	afx_msg void OnClicked();
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PAGEMAILDELCURRENT_H__99FF4AE2_86E6_11D1_82C0_444553540000__INCLUDED_)
