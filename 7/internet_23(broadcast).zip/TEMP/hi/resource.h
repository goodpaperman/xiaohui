//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CMulticastSocket.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CMULTICASTSOCKET_DIALOG     102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDD_JOINGROUP_DIALOG            129
#define IDQUIT                          1000
#define IDC_CHATWINDOW                  1001
#define IDC_CHATMESSAGE                 1002
#define IDSEND                          1004
#define IDC_JOIN                        1005
#define IDC_LEAVE                       1006
#define IDC_PORT                        1008
#define IDC_TTL                         1009
#define IDC_LOOPBACK                    1010
#define IDC_IPADDRESS                   1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
