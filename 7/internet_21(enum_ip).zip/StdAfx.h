#define VC_EXTRALEAN

#include <afxext.h> 
#include <winsock.h>




