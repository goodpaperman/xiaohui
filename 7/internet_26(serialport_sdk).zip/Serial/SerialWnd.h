//	SerialWnd.h - Definition of the CSerialWnd class
//
//	Copyright (C) 1999-2001 Ramon de Klein (R.de.Klein@iaf.nl)
//
// This program is free software; you can redistribute it and/ormodify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.


#ifndef __SERIAL_WND_H
#define __SERIAL_WND_H


//////////////////////////////////////////////////////////////////////
// Include CSerial base class

#include "Serial.h"


//////////////////////////////////////////////////////////////////////
//
// CSerialWnd - Win32 message-based wrapper for serial communications
//
// A lot of MS-Windows GUI based programs use a central message
// loop, so the application cannot block to wait for objects. This
// make serial communication difficult, because it isn't event
// driven using a message queue. This class makes the CSerial based
// classes suitable for use with such a messagequeue. Whenever
// an event occurs on the serial port, a user-defined message will
// be sent to a user-defined window. It can then use the standard
// message dispatching to handle the event.
//
// Pros:
// -----
//	- Easy to use
//	- Fully ANSI and Unicode aware
//  - Integrates easily in GUI applications and is intuitive to
//    use for GUI application programmers
//
// Cons:
// -----
//  - Uses a thread for each COM-port, which has been opened.
//  - More overhead, due to thread switching and message queues.
//  - Requires a window, but that's probably why you're using
//    this class.
//
// Copyright (C) 1999-2001 Ramon de Klein
//                         (R.de.Klein@iaf.nl)

class CSerialWnd : public CSerial
{
// Construction
public:
	CSerialWnd();
	virtual ~CSerialWnd();

// Operations
public:
	// Open the serial communications for a particular COM port. You
	// need to use the full devicename (i.e. "COM1") to open the port.
	virtual LONG Open (LPCTSTR lpszDevice, HWND hwndDest, UINT nComMsg=WM_NULL, LPARAM lParam=0, DWORD dwInQueue = 2048, DWORD dwOutQueue = 2048);

	// Close the serial port.
	virtual LONG Close (void);

protected:
	// Each opened COM-port uses its own specific thread, which will
	// wait for one of the events to happen. When an event happens,
	// then the client window is send a message informing about the
	// event.
	static DWORD WINAPI ThreadProc (LPVOID lpArg);
	virtual DWORD ThreadProc (void);

protected:
	// The WaitEvent method is being used by this class internally
	// and shouldn't be used by client applications. Client
	// application should monior the messages.
	using CSerial::WaitEvent;

	// The event-type is send in the WPARAM of the message and
	// the GetEventType method returns the wrong data, so we'll
	// hide this method for client applications to avoid problems.
	using CSerial::GetEventType;
	using CSerial::GetError;

public:
	// Default Serial notification message
	static const UINT mg_nDefaultComMsg;

protected:
	// Internal attributes
	HANDLE	m_hThread;
	HANDLE	m_hevtStop, m_hevtCommEvent;
	HWND	m_hwndDest;
	UINT	m_nComMsg;
	LPARAM	m_lParam;
};

#endif	// __SERIAL_WND_H
