// ByteArrayFile.h: interface for the CByteArrayFile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BYTEARRAYFILE_H__39452724_D30B_11D2_848A_0000E85B73B5__INCLUDED_)
#define AFX_BYTEARRAYFILE_H__39452724_D30B_11D2_848A_0000E85B73B5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CByteArrayFile : public CMemFile  
{
	DECLARE_DYNAMIC(CByteArrayFile)

public:
	CByteArrayFile(UINT nGrowBytes = 4096);
	virtual ~CByteArrayFile();

// Attributes
	CByteArray* Detach();
	void SetArray(CByteArray* pArray, BOOL bAllowGrow = TRUE);

protected:
	virtual BYTE* Alloc(DWORD nBytes);
	virtual BYTE* Realloc(BYTE* lpMem, DWORD nBytes);
	virtual void Free(BYTE* lpMem);

protected:
	BOOL m_bAllowGrow;
	CByteArray*		m_pByteArray;
};

#endif // !defined(AFX_BYTEARRAYFILE_H__39452724_D30B_11D2_848A_0000E85B73B5__INCLUDED_)
