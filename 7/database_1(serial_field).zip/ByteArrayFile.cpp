// ByteArrayFile.cpp: implementation of the CByteArrayFile class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ByteArrayFile.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CByteArrayFile::CByteArrayFile(UINT nGrowBytes)
	: CMemFile(nGrowBytes)
{
	m_pByteArray = NULL;
	m_bAllowGrow = TRUE;
}

CByteArrayFile::~CByteArrayFile()
{
	if (m_lpBuffer)
		Close();        // call appropriate Close/Free
	ASSERT(m_lpBuffer == NULL);
}

void CByteArrayFile::SetArray(CByteArray* pArray, BOOL bAllowGrow)
{
	ASSERT(m_pByteArray == NULL);        // do once only
	ASSERT(m_lpBuffer == NULL);     // do once only
	ASSERT(m_nPosition == 0);

	m_pByteArray = pArray;
	m_lpBuffer = (BYTE*)m_pByteArray->GetData();
	m_nBufferSize = m_nFileSize = m_pByteArray->GetSize();
	m_bAllowGrow = bAllowGrow;
}

BYTE* CByteArrayFile::Alloc(DWORD nBytes)
{
	ASSERT(m_pByteArray != NULL);       // do once only
	m_pByteArray->SetSize(nBytes);
	return m_pByteArray->GetData();
}

BYTE* CByteArrayFile::Realloc(BYTE*, DWORD nBytes)
{
	if (!m_bAllowGrow)
		return NULL;
	ASSERT(m_pByteArray != NULL);
	m_pByteArray->SetSize(nBytes);
	return m_pByteArray->GetData();
}

void CByteArrayFile::Free(BYTE*)
{
	ASSERT(m_pByteArray != NULL);
	m_pByteArray->RemoveAll();
}

CByteArray* CByteArrayFile::Detach()
{
	CByteArray* pRet;
	ASSERT(m_pByteArray != NULL);

	// shrink memory
	m_pByteArray->SetSize(m_nFileSize);
	m_pByteArray->FreeExtra();

	pRet = m_pByteArray;

	m_pByteArray = NULL;

	// re-initialize the CMemFile parts too
	m_lpBuffer = NULL;
	m_nBufferSize = 0;
	return pRet;
}

IMPLEMENT_DYNAMIC(CByteArrayFile, CMemFile)