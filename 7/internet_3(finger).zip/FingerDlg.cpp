// FingerDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Finger.h"
#include "FingerDlg.h"
#include "FingerSocket.h"
#include "FingerThread.h"

#define WM_THREAD_EVENT (WM_USER + 1)

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFingerDlg dialog

CFingerDlg::CFingerDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFingerDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFingerDlg)
	m_sOutput = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_iCurrentItem = 0;
	m_iActiveThreads = 0;
	m_bViewSummary = true;
}

void CFingerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFingerDlg)
	DDX_Control(pDX, IDC_COMBO1, m_cInput);
	DDX_Text(pDX, IDC_EDIT1, m_sOutput);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CFingerDlg, CDialog)
	//{{AFX_MSG_MAP(CFingerDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_FINGER, OnFinger)
	ON_CBN_SELCHANGE(IDC_COMBO1, OnSelchangeCombo)
	ON_BN_CLICKED(IDC_OPTIONS, OnOptions)
	ON_BN_CLICKED(IDC_ABOUT, OnAbout)
	ON_BN_CLICKED(IDC_HELPBTN, OnHelp)
	ON_COMMAND(ID_OPTIONS_CLEANSUM, OnOptionsCleanSummary)
	ON_COMMAND(ID_OPTIONS_VIEWSUMMARYONNEW, OnOptionsViewSummary)
	ON_COMMAND(ID_OPTIONS_REFRESHCURRENT, OnOptionsRefreshCurrent)
	ON_COMMAND(ID_OPTIONS_DELETECURRENT, OnOptionsDeleteCurrent)
	ON_COMMAND(ID_OPTIONS_DELETEALL, OnOptionsDeleteAll)
	ON_COMMAND(ID_OPTIONS_REFRESHALL, OnOptionsRefreshAll)
	ON_COMMAND(ID_OPTIONS_ABOUT, OnOptionsAbout)
	ON_COMMAND(ID_OPTIONS_HELP, OnOptionsHelp)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_THREAD_EVENT, OnThreadEvent)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFingerDlg message handlers

BOOL CFingerDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}

		// Disable size and maximize buttons
		pSysMenu->EnableMenuItem( 2, MF_BYPOSITION |MF_DISABLED |MF_GRAYED );
		pSysMenu->EnableMenuItem( 4, MF_BYPOSITION |MF_DISABLED |MF_GRAYED );
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	// Init combo
	m_cInput.AddString("summary");
	
	// Init menu
	m_cMenu.LoadMenu(IDR_MENU1);

	// Set title
	m_iActiveThreads = 1;
	UpdateTitleDec();
	
	// Show prompt
	m_sOutput = "Finger started, and is waiting for your request.\r\n";
	m_sOutput += "To see examples press F4.\r\n";
	UpdateData(FALSE);

	// Insert examples
	// Prepare prompt
	CString sPrompt = "This is an example request.\r\n";
	sPrompt += "Click 'Finger' or press Enter to see how it works.\r\n";
	// Insert one
	{
		CString sInput = ms_sExamples[0];
		m_cInput.InsertString(1,sInput);
		CFingerThread *pFingerThread = new CFingerThread(this, sInput);
		pFingerThread->Init(sPrompt);
		m_cInput.SetItemDataPtr(1, pFingerThread);
	}
	// Insert two
	{
		CString sInput = ms_sExamples[1];
		m_cInput.InsertString(2,sInput);
		CFingerThread *pFingerThread = new CFingerThread(this, sInput);
		pFingerThread->Init(sPrompt);
		m_cInput.SetItemDataPtr(2, pFingerThread);
	}
	m_cInput.SetCurSel(2);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CFingerDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CFingerDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CFingerDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CFingerDlg::OnFinger() 
{
	// Get user input
	CString sInput;
	m_cInput.GetWindowText(sInput);
	if( sInput.IsEmpty()) return;

	// Check if it is an example
	if( IsExample(sInput) )
	{
		// We should delete corresponding item, to pass existance check
		RemoveQuery( m_cInput.FindStringExact(1, sInput));
	}

	Finger(sInput);
}
	
// Main finger routine
//
void CFingerDlg::Finger(const CString& sInput) 
{
	// Check if we already processing it
	if( AlreadyExist(sInput) ) return;
	
	if( m_bViewSummary ) m_iCurrentItem = 0;
	else m_iCurrentItem = 1;

	// Insert new item
	m_cInput.InsertString(1,sInput);
	m_cInput.SetCurSel(1);

	// Construct new thread object
	CFingerThread *pFingerThread = new CFingerThread(this, sInput);

	// Associate a pointer with an item
	m_cInput.SetItemDataPtr(1,pFingerThread);
	
	// Start new thread
	pFingerThread->CreateThread();

	// Update title
	UpdateTitleInc();
}

// Check if requred string has already been submitted
//
bool CFingerDlg::AlreadyExist(const CString &sInput)
{
	int n = m_cInput.FindStringExact(1, sInput); if( n == CB_ERR ) return false;
	
	if( n == 0 )  // Show summary
	{
		m_iCurrentItem = 0;	ShowResult();
		return true;
	}

	// Get associated threads object
	CFingerThread *pFingerThread = static_cast<CFingerThread*>(m_cInput.GetItemDataPtr( n ));

	DWORD dwStatus;
	VERIFY(::GetExitCodeThread(pFingerThread->m_hThread, &dwStatus));

	if (dwStatus == STILL_ACTIVE)
	{
		if( AfxMessageBox("This query is already processing.\nDo you want to abort it and retry?", MB_YESNO) == IDYES )
		{				
			// Perform thread termination, 
			// it automatically deletes threads object
			pFingerThread->Terminate();

			// Delete threads item
			m_cInput.DeleteString(n);

			// Restart thread
			return false;
		}
		else
		{
			// Show threads progress
			m_iCurrentItem = n;	
			ShowResult();
		}
	}
	else
	{
		// We already have results on this query

		// Put the item on top
		m_cInput.DeleteString(n);
		m_cInput.InsertString(1,sInput);
		m_cInput.SetItemDataPtr(1,pFingerThread);
		m_cInput.SetCurSel(1);
		// Show cached result
		m_iCurrentItem = 1;
		ShowResult();
		// Inform user
		CString tmp = "This query has already been processed. ";
		tmp += "Below you see cached results.\r\n";
		tmp += "You may force execution by clicking 'Options->Refresh current'.\r\n\r\n";
		m_sOutput.Insert(0, tmp);
		UpdateData(FALSE);
	}

	return true;
}

// Remove query indicated by n-th item in combo, i.e.
// terminate thread, delete threads object and delete string in combo
//
void CFingerDlg::RemoveQuery(int n)
{
	// Get associated threads object
	CFingerThread *pFingerThread = static_cast<CFingerThread*>(m_cInput.GetItemDataPtr( n ));
	VERIFY(pFingerThread != NULL);

	DWORD dwStatus;

	if( pFingerThread->m_hThread )
		VERIFY(::GetExitCodeThread(pFingerThread->m_hThread, &dwStatus));
	else
		 // It's an example case, so doesn't have a real threads handle
		dwStatus = !STILL_ACTIVE;

	if (dwStatus == STILL_ACTIVE)
	{
		// Perform thread termination, 
		// it automatically deletes threads object
		pFingerThread->Terminate();
	}
	else
	{
		// Delete threads object, since it persists on heap
		// if we don't call Terminate()
		delete pFingerThread;
	}

	// Delete threads item
	m_cInput.DeleteString(n);
}

void CFingerDlg::ShowResult()
{
	int n = m_iCurrentItem;
	
	// Save user input
	UpdateData();

	// Show selected item progress
	if( n ) 
	{
		// View specific thread

		// Get associated threads object
		CFingerThread *pFingerThread = static_cast<CFingerThread*>(m_cInput.GetItemDataPtr( n ));
		
		// Show threads progress
		m_sOutput = pFingerThread->Result();
	}
	else
		// View all threads

		m_sOutput = m_sResult;

	// Refresh back
	UpdateData(FALSE);
}

// Called from any spawned thread
//
void CFingerDlg::ProcessThread(void* pThread, const CString& sMsg, bool bState)
{
	// Enter critical section
	m_CritSection.Lock();
	
	// Update summary
	m_sResult.Insert(0,sMsg);
	
	// Update view if need
	if( m_iCurrentItem == 0 || 
		m_cInput.GetItemDataPtr( m_iCurrentItem ) == pThread )

		PostMessage( WM_THREAD_EVENT, 1 );

	// Leave critical section
	m_CritSection.Unlock();
}

// Called from any spawned thread
//
void CFingerDlg::ProcessThreadExit()
{
	PostMessage( WM_THREAD_EVENT );
}


LRESULT CFingerDlg::OnThreadEvent(WPARAM wParam, LPARAM lParam)
{
	if( wParam ) ShowResult();	// Update output
	else UpdateTitleDec();		// One thread terminated
	return 0;
}


void CFingerDlg::OnSelchangeCombo() 
{
	// Get selection
	int n = m_cInput.GetCurSel(); if( n == CB_ERR ) return;
	m_iCurrentItem = n;
	ShowResult();
}

// Button handlers
//
void CFingerDlg::OnAbout() 
{
	CAboutDlg dlgAbout;
	dlgAbout.DoModal();
}


void CFingerDlg::OnOptions() 
{
	// Get cursor position
	POINT pt;
	::GetCursorPos(&pt);
	// Track menu
	CMenu &menu = *m_cMenu.GetSubMenu(0);
	menu.TrackPopupMenu( TPM_LEFTALIGN |TPM_RIGHTBUTTON, pt.x, pt.y, this);
}


// Menu handlers
//
void CFingerDlg::OnOptionsViewSummary() 
{
	// Flip state
	m_bViewSummary = !m_bViewSummary;

	// Check/uncheck menu
	CMenu &menu = *m_cMenu.GetSubMenu(0);
	menu.CheckMenuItem( 0, MF_BYPOSITION |(m_bViewSummary ? MF_CHECKED : MF_UNCHECKED));

	// Test critical sections
#if 0
	static bool b = true;
	
	if( b )
	{
		// Suspend results output
		m_CritSection.Lock();
	}
	else
	{
		// Resume results output
		m_CritSection.Unlock();
	}

	b != b;
#endif
}

void CFingerDlg::OnOptionsCleanSummary() 
{
	// Enter critical section
	m_CritSection.Lock();
	
	// Clean summary
	m_sResult.Empty();
	m_sOutput.Empty();
	UpdateData(FALSE);

	// Leave critical section
	m_CritSection.Unlock();
}


void CFingerDlg::OnOptionsRefreshCurrent() 
{
	// Get user input
	CString sInput;
	m_cInput.GetWindowText(sInput);
	if( sInput.IsEmpty()) return;

	// Find that string
	int n = m_cInput.FindStringExact(1, sInput);

	// Nothing found
	if( n == CB_ERR )
	{
		if( AfxMessageBox( CString("There are no such query: '") + 
			sInput + "'. Submit?", MB_YESNO) == IDYES ) 
			Finger(sInput);
		return;
	}
	
	// If summary
	if( n == 0 )  // Show summary
	{
		m_iCurrentItem = 0;	ShowResult();
		return;
	}

	// Corresponding item's been found
	RemoveQuery(n);
	
	// Restart thread
	Finger(sInput);
}


void CFingerDlg::OnOptionsDeleteCurrent() 
{
	// Get user input
	CString sInput;
	m_cInput.GetWindowText(sInput);
	if( sInput.IsEmpty()) return;

	// Find that string
	int n = m_cInput.FindStringExact(1, sInput);

	// Nothing found
	if( n == CB_ERR )
	{
		AfxMessageBox( CString("There are no such query: '") + sInput + "'." );
		return;
	}
	
	// If summary
	if( n == 0 )
	{
		AfxMessageBox("Summary can't be deleted.");
		return;
	}

	// Corresponding item's been found
	RemoveQuery(n);
	
	// Set selection to summary
	m_cInput.SetCurSel(0);
	m_iCurrentItem = 0;
	ShowResult();
}


void CFingerDlg::OnOptionsDeleteAll() 
{
	if( AfxMessageBox( "Really cancel all queries?", MB_YESNO) == IDNO ) return;

	// It's important to go down, to escape mess
	for( int i = m_cInput.GetCount()-1; i > 0; i-- ) RemoveQuery(i);

	// Set selection to summary
	m_cInput.SetCurSel(0);
	m_iCurrentItem = 0;
	ShowResult();
}

void CFingerDlg::OnOptionsRefreshAll() 
{
	for( int i = 1; i < m_cInput.GetCount(); i++ )
	{
		// Get query string
		CString tmp;
		m_cInput.GetLBText( i, tmp );

		// Remove query
		RemoveQuery(i);
		
		// Submit it again
		Finger(tmp);
	}

	// Set selection to summary
	m_cInput.SetCurSel(0);
	m_iCurrentItem = 0;
	ShowResult();
}

void CFingerDlg::OnOptionsAbout() 
{
	OnAbout();
}

// Update title procedures
//
void CFingerDlg::UpdateTitleInc()
{
	// Increase threads count
	m_iActiveThreads++;
	
	// Update title
	CString str;
	str.Format("Finger - %d active queries", m_iActiveThreads );
	
	SetWindowText(str);
}

void CFingerDlg::UpdateTitleDec()
{
	// Decrease threads count
	m_iActiveThreads--;
	
	CString str;

	// Update title
	if( m_iActiveThreads )
		str.Format("Finger - %d active queries", m_iActiveThreads );
	else
		str = "Finger - waiting for a query";
	
	SetWindowText(str);
}

// Initialize static members
//
const CString CFingerDlg::ms_sExamples[] = 
{ 
	"@mit.edu",
	"alexv@mit.edu"
};

// Verify if a request is from an examples list
// if so, execute it and invalidate as example,
// so it becomes an ordinary request

bool CFingerDlg::IsExample(const CString &sInput)
{
	static bool abExState[2] = { true, true };

	if(	abExState[0] && sInput == ms_sExamples[0] )
	{
		abExState[0] = false; // Not an example after we've tried it
		return true;
	}

	if(	abExState[1] && sInput == ms_sExamples[1] )
	{
		abExState[1] = false; // Not an example after we've tried it
		return true;
	}

	return false;
}


// Help handlers
//
void CFingerDlg::OnHelp() 
{
	const char *asLocations[] = { "finger.hlp", "hlp\\finger.hlp", "..\\hlp\\finger.hlp" };
	
	// Check possible locations of hlp file
	for( int i = 0; i < 3; i++ )

		if( ::GetFileAttributes( asLocations[i] ) != -1 ) break;
		
	// If failed to find file, invoke help anyway
	if( i >= 3 ) i = 0;

	// Invoke help
	::WinHelp( m_hWnd, asLocations[i], HELP_INDEX, 0 );
}


void CFingerDlg::OnOptionsHelp()
{
	OnHelp();
}


