//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Finger.rc
//
#define IDS_CANNOT_RUN_ON_16BIT_WINDOWS_LT_4 3
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_FINGER_DIALOG               102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDR_MENU1                       129
#define ID_MESSAGES                     130
#define ID_CONNECTIONS                  131
#define IDC_EDIT1                       1000
#define IDC_EDIT2                       1001
#define IDC_FINGER                      1002
#define IDC_COMBO1                      1006
#define IDC_OPTIONS                     1008
#define IDC_HELPBTN                     1009
#define IDC_ABOUT                       1010
#define IDS_CREATEFAILED                32102
#define IDS_SERVERRESET                 32105
#define ID_OPTIONS_REFRESHCURRENT       32771
#define ID_OPTIONS_CLEANSUM             32772
#define ID_OPTIONS_DELETECURRENT        32773
#define ID_OPTIONS_DELETEALL            32774
#define ID_OPTIONS_VIEWSUMMARYONNEW     32775
#define ID_OPTIONS_REFRESHALL           32776
#define ID_OPTIONS_HELP                 32778
#define ID_OPTIONS_ABOUT                32779

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32780
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
