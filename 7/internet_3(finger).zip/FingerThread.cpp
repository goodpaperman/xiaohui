// FingerThread.cpp: implementation of the CFingerThread class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Finger.h"
#include "FingerThread.h"
#include "FingerSocket.h"
#include "FingerDlg.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#define WM_KILL_THREAD (WM_USER + 101)

/////////////////////////////////////////////////////////////////////////////
// CFingerThread

IMPLEMENT_DYNCREATE(CFingerThread, CWinThread)

CFingerThread::CFingerThread(CFingerDlg* pOwner, const CString& sInput):
	m_pOwner(pOwner),
	m_sInput(sInput)
{
	m_pSocket = NULL;
	m_bAutoDelete = FALSE;
}

CFingerThread::CFingerThread()
{
	m_pOwner = NULL;
	m_pSocket = NULL;
}

void CFingerThread::Init(const CString& sResult)
{
	// Set initial result
	m_sResult = sResult;
}

CFingerThread::~CFingerThread()
{
}

BOOL CFingerThread::InitInstance()
{
	if( m_pOwner == NULL ) return FALSE;

	// Clear result
	m_sResult.Empty();
	
	// Create socket, connect and request
	m_pSocket = new CFingerSocket(this);
	m_pSocket->Open( m_sInput );

	return TRUE;
}

int CFingerThread::ExitInstance()
{
	// Destroy socket
	delete m_pSocket;

	return CWinThread::ExitInstance();
}

// Process socket event
//
void CFingerThread::ProcessSocket()
{
	// Get socket message
	CString str = m_pSocket->Result() + "\r\n";
	
	// Refesh current state
	m_sResult += str;
	
	// Adjust string
	CString tmp = CString("(") + m_sInput + "): ";
	str.Insert(0, tmp);
	
	// Contact main thread
	m_pOwner->ProcessThread(this, str, m_pSocket->Successful());

	// If completed exit thread
	if( m_pSocket->Completed() )
	{
		::PostQuitMessage(0);	// Exit thread
		
		// Inform dialog about termination
		if( !m_bAutoDelete ) m_pOwner->ProcessThreadExit();
	}
}


void CFingerThread::Terminate()
{
	m_bAutoDelete = TRUE;
	m_pSocket->CancelBlockingCall();
	PostThreadMessage(WM_KILL_THREAD,0,0);
}

void CFingerThread::OnKillThread(UINT wParam, LONG lParam)
{
	::PostQuitMessage(0);
	//AfxEndThread(0);

	// Inform dialog about termination
	m_pOwner->ProcessThreadExit();
}


BEGIN_MESSAGE_MAP(CFingerThread, CWinThread)
	//{{AFX_MSG_MAP(CFingerThread)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
	ON_THREAD_MESSAGE(WM_KILL_THREAD, OnKillThread)
END_MESSAGE_MAP()
