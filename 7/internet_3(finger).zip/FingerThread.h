// FingerThread.h: interface for the CFingerThread class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FINGERTHREAD_H__C790ACFA_A242_11D3_A956_005004033132__INCLUDED_)
#define AFX_FINGERTHREAD_H__C790ACFA_A242_11D3_A956_005004033132__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CFingerDlg;
class CFingerSocket;

class CFingerThread : public CWinThread  
{
	DECLARE_DYNCREATE(CFingerThread)

public:
	CFingerThread(CFingerDlg* pOwner, const CString& sInput);

protected:
	CFingerThread();           // protected constructor used by dynamic creation

// Attributes
protected:
	CFingerDlg* m_pOwner;
	CFingerSocket* m_pSocket;
	CString m_sInput, m_sResult;

// Operations
public:
	const CString& Result() const { return m_sResult; }
	void Init(const CString& sResult);
	void Terminate();
	void ProcessSocket();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFingerThread)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CFingerThread();

	// Generated message map functions
	//{{AFX_MSG(CFingerThread)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	afx_msg void OnKillThread( UINT, LONG );
	DECLARE_MESSAGE_MAP()
};


#endif // !defined(AFX_FINGERTHREAD_H__C790ACFA_A242_11D3_A956_005004033132__INCLUDED_)
