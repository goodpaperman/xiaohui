// FingerSocket.cpp: implementation of the CFingerSocket class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Finger.h"
#include "FingerSocket.h"
#include "FingerThread.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

static short dummy()
{
	return ntohs( (::getservbyname("finger", "tcp"))->s_port );
}

// Assign finger port
//
const UINT CFingerSocket::ms_uFingerPort = 79;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CFingerSocket::CFingerSocket(CFingerThread *pOwner):
	m_pOwner(pOwner),
	m_bSuccessful(false),
	m_bCompleted(false)
{
	m_pFile = NULL;
}

CFingerSocket::~CFingerSocket()
{
	if( m_pFile )
	{
		delete m_pArchiveIn;
		delete m_pArchiveOut;
		// Delete file last, because archives may throw expeption
		delete m_pFile;
	}
}

// Create socket and connect
//
void CFingerSocket::Open( const CString& sConnectString )
{
	// Parse user input
	int at = sConnectString.Find('@');
	m_sUser = sConnectString.Left( at ) + "\n";
	m_sHost = sConnectString.Right( sConnectString.GetLength() - at - 1 );

	// Create socket
	if (!Create())
	{
		Error("Failed to create a socket."); return;
	}

	m_sResult = "Start connection ...";
	m_pOwner->ProcessSocket();
	
	// Connect to host
	if(!Connect(m_sHost, ms_uFingerPort))
	{
		Error(); return;
	}

	m_sResult = "Connected.";
	m_pOwner->ProcessSocket();

	// Construct socket file and archives
	m_pFile = new CSocketFile(this);
	m_pArchiveIn = new CArchive(m_pFile,CArchive::load);
	m_pArchiveOut = new CArchive(m_pFile,CArchive::store);

	// Sending data to host
	TRY
	{
		m_pArchiveOut->WriteString(m_sUser);
		m_pArchiveOut->Flush();
	}
	CATCH(CFileException, e)
	{
		m_pArchiveOut->Abort();
		Error("Server has reset the connection."); return;
	}
	END_CATCH

	m_sResult = "Request sent.";
	m_pOwner->ProcessSocket();
}


void CFingerSocket::OnReceive(int nErrorCode)
{
	CSocket::OnReceive(nErrorCode);

	m_sResult = "Received data:";
	// Receive hosts response
	TRY
	{
		do
		{
			CString tmp;
			m_pArchiveIn->ReadString(tmp);
			m_sResult += "\r\n" + tmp;
		}
		while (!m_pArchiveIn->IsBufferEmpty());
	}
	CATCH(CFileException, e)
	{
		m_pArchiveOut->Abort();
		Error("Server has reset the connection."); return;
	}
	END_CATCH
	
	m_bSuccessful = true;
	m_pOwner->ProcessSocket();
}

// Inform dialog about completion
//
void CFingerSocket::OnClose(int nErrorCode)
{
	CSocket::OnClose(nErrorCode);

	m_sResult = "Disconnected.";
	m_bCompleted = true;
	m_pOwner->ProcessSocket();
}

// Dispath errors
//
void CFingerSocket::Error()
{
	switch(::WSAGetLastError())
	{
	case WSAEINVAL:	m_sResult = "This host name is invalid."; break;
	case WSAETIMEDOUT: m_sResult = "Connection timed out."; break;
	case WSAECONNREFUSED: m_sResult = "Connection refused."; break;
	case WSAEINTR: m_sResult = "Interrupted function call."; break;
	default:
		m_sResult.Format("%d.", ::WSAGetLastError() );
		m_sResult.Insert(0,"Windows Sockets Error: ");
		break;
	}

	m_bCompleted = true;
	m_pOwner->ProcessSocket();
}

void CFingerSocket::Error( const CString& sMsg )
{
	m_sResult = sMsg;
	m_bCompleted = true;
	m_pOwner->ProcessSocket();
}
