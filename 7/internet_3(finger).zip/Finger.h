// Finger.h : main header file for the FINGER application
//

#if !defined(AFX_FINGER_H__C790ACE7_A242_11D3_A956_005004033132__INCLUDED_)
#define AFX_FINGER_H__C790ACE7_A242_11D3_A956_005004033132__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CFingerApp:
// See Finger.cpp for the implementation of this class
//

class CFingerApp : public CWinApp
{
public:
	CFingerApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFingerApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CFingerApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FINGER_H__C790ACE7_A242_11D3_A956_005004033132__INCLUDED_)
