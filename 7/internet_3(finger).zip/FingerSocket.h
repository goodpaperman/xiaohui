// FingerSocket.h: interface for the CFingerSocket class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FINGERSOCKET_H__C790ACF4_A242_11D3_A956_005004033132__INCLUDED_)
#define AFX_FINGERSOCKET_H__C790ACF4_A242_11D3_A956_005004033132__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CFingerThread;

class CFingerSocket : public CSocket  
{
private:
	CFingerSocket(const CFingerSocket& rSrc);		// no implementation
	void operator=(const CFingerSocket& rSrc);		// no implementation

// Construction
public:
	CFingerSocket(CFingerThread *pOwner);
	virtual ~CFingerSocket();

// Implementation
protected:
	static const UINT ms_uFingerPort;
	CFingerThread *m_pOwner;
	CSocketFile *m_pFile;
	CArchive *m_pArchiveIn, *m_pArchiveOut;
	CString m_sUser, m_sHost, m_sResult;
	bool m_bSuccessful, m_bCompleted;

public:
	bool Successful() const { return m_bSuccessful; }
	bool Completed() const { return m_bCompleted; }
	void Open( const CString& sConnectString );
	const CString& Result() const { return m_sResult; }

protected:
	void Error();
	void Error( const CString& sMsg );

// Overridable callbacks
protected:
	virtual void OnReceive(int nErrorCode);
	virtual void OnClose(int nErrorCode);
};

#endif // !defined(AFX_FINGERSOCKET_H__C790ACF4_A242_11D3_A956_005004033132__INCLUDED_)
