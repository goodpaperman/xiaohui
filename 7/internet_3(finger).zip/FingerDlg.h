// FingerDlg.h : header file
//

#if !defined(AFX_FINGERDLG_H__C790ACE9_A242_11D3_A956_005004033132__INCLUDED_)
#define AFX_FINGERDLG_H__C790ACE9_A242_11D3_A956_005004033132__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CFingerDlg dialog

class CFingerSocket;
class CFingerThread;

class CFingerDlg : public CDialog
{
// Construction
public:
	CFingerDlg(CWnd* pParent = NULL);	// standard constructor
	void ProcessThread(void* pThread, const CString& sMsg, bool bState);
	void ProcessThreadExit();

// Dialog Data
	//{{AFX_DATA(CFingerDlg)
	enum { IDD = IDD_FINGER_DIALOG };
	CComboBox	m_cInput;
	CString	m_sOutput;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFingerDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	int m_iActiveThreads;
	bool m_bViewSummary;
	int m_iCurrentItem;
	HICON m_hIcon;
	CString m_sResult;
	CMenu m_cMenu;
	CCriticalSection m_CritSection;

	static const CString ms_sExamples[2];

	void Finger(const CString& sInput);
	bool IsExample(const CString& sInput);
	bool AlreadyExist(const CString& sInput);
	void RemoveQuery(int n);
	void ShowResult();
	void UpdateTitleDec();
	void UpdateTitleInc();


	// Generated message map functions
	//{{AFX_MSG(CFingerDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnFinger();
	afx_msg void OnSelchangeCombo();
	afx_msg void OnOptions();
	afx_msg void OnAbout();
	afx_msg void OnHelp();
	afx_msg void OnOptionsCleanSummary();
	afx_msg void OnOptionsViewSummary();
	afx_msg void OnOptionsRefreshCurrent();
	afx_msg void OnOptionsDeleteCurrent();
	afx_msg void OnOptionsDeleteAll();
	afx_msg void OnOptionsRefreshAll();
	afx_msg void OnOptionsAbout();
	afx_msg void OnOptionsHelp();
	//}}AFX_MSG
	afx_msg LRESULT OnThreadEvent(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FINGERDLG_H__C790ACE9_A242_11D3_A956_005004033132__INCLUDED_)
