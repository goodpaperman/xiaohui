// Globals for CColorStaticST_Demo
#ifndef _GLOBALS_H
#define _GLOBALS_H

#define PROJECT_NAME "CColorStaticST v1.0"
#define SEMAPHORE_NAME "10CColorStaticST"

#define IDS_MAILADDR "mailto:davide_calabro@yahoo.com"
#define IDS_HOMEPAGEADDR  "http://members.tripod.com/~SoftechSoftware/index.html" 

#define STSIGN "SoftechSoftware"

#endif
