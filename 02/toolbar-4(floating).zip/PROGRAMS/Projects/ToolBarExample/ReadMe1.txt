Matthew Angel
mangel@uniserve.com

Microsoft Developer Studio Edition 4

Example:
Toolbar docking and floating
All of the information will be in the CMainFrame class.
all of the source codes are in the zip file 

Thank You.
Matthew