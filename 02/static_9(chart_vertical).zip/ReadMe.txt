/////////////////////////////////////////////////////////////////////////////
// Copyright (C) 1999 by Alexander Fedorov
// All rights reserved
//
// Distribute and use freely, except:
// 1. Don't alter or remove this notice.
// 2. Mark the changes you made
//
// Send bug reports, bug fixes, enhancements, requests, etc. to:
//    alexander.fedorov@usa.net
/////////////////////////////////////////////////////////////////////////////
