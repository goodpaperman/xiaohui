#include "stdafx.h"
#include "TREEdropsrc.h"


SCODE CTreeDropSource ::GiveFeedback(DROPEFFECT dropEffect)
{
	return DRAGDROP_S_USEDEFAULTCURSORS ;
}
