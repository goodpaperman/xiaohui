//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by LookMaSDI.rc
//
#define IDD_ABOUTBOX                    100
#define CG_IDD_CONTENTMENU              102
#define CG_ID_VIEW_CONTENTMENU          103
#define IDR_MAINFRAME                   128
#define IDR_LOOKMATYPE                  129
#define IDI_FILED                       140
#define IDI_FINISHED                    141
#define IDI_CALENDAR                    144
#define IDI_COMPOSE                     167
#define IDC_LIST_CONTENTS               1000

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
