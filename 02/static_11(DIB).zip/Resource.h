//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ExampleDIB.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_EXAMPLEDIB_FORM             101
#define IDR_MAINFRAME                   128
#define IDR_EXAMPLTYPE                  129
#define IDD_DLG_BITMAP                  130
#define IDB_BITMAP1                     131
#define IDB_BITMAP2                     132
#define IDB_BITMAP3                     133
#define IDB_BITMAP4                     134
#define IDB_BITMAP5                     135
#define IDB_BITMAP6                     136
#define IDC_RADIO1                      1000
#define IDC_RADIO2                      1001
#define IDC_RADIO3                      1002
#define IDC_RADIO4                      1003
#define IDC_RADIO5                      1004
#define IDC_RADIO6                      1005
#define IDC_BMP_EXAMPLE                 1006
#define IDC_BTN_1                       1007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
