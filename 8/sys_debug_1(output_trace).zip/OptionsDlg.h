#if !defined(AFX_OPTIONSDLG_H__56CFE4CE_2AB4_11D1_9D85_BF0AE3EDB06A__INCLUDED_)
#define AFX_OPTIONSDLG_H__56CFE4CE_2AB4_11D1_9D85_BF0AE3EDB06A__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// OptionsDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// COptionsDlg dialog

class COptionsDlg : public CDialog
{
// Construction
public:
	COptionsDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(COptionsDlg)
	enum { IDD = IDD_DIALOG_OPTIONS };
	CButton	m_ShowAnimation;
	CButton	m_ShowReversed;
	CButton	m_ShowNumber;
	CButton	m_ShowLevel3;
	CButton	m_ShowLevel2;
	CButton	m_ShowLevel1;
	CButton	m_ShowLevel0;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COptionsDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(COptionsDlg)
	virtual void OnOK();
	virtual void OnCancel();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OPTIONSDLG_H__56CFE4CE_2AB4_11D1_9D85_BF0AE3EDB06A__INCLUDED_)
