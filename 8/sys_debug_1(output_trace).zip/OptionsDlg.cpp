// OptionsDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Debug.h"
#include "OptionsDlg.h"
#include "DebugDlg.h"

#include "Globals.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// COptionsDlg dialog


COptionsDlg::COptionsDlg(CWnd* pParent /*=NULL*/)
	: CDialog(COptionsDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(COptionsDlg)
	//}}AFX_DATA_INIT
}


void COptionsDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COptionsDlg)
	DDX_Control(pDX, IDC_CHECK_SHOWANIMATION, m_ShowAnimation);
	DDX_Control(pDX, IDC_CHECK_SHOWREVERSED, m_ShowReversed);
	DDX_Control(pDX, IDC_CHECK_SHOWNUMBER, m_ShowNumber);
	DDX_Control(pDX, IDC_CHECK_LEVEL3, m_ShowLevel3);
	DDX_Control(pDX, IDC_CHECK_LEVEL2, m_ShowLevel2);
	DDX_Control(pDX, IDC_CHECK_LEVEL1, m_ShowLevel1);
	DDX_Control(pDX, IDC_CHECK_LEVEL0, m_ShowLevel0);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(COptionsDlg, CDialog)
	//{{AFX_MSG_MAP(COptionsDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COptionsDlg message handlers

void COptionsDlg::OnOK() 
{
	if(m_ShowLevel0.GetCheck() == 1)
		bShowLevel0 = TRUE;
	else
		bShowLevel0 = FALSE;

	if(m_ShowLevel1.GetCheck() == 1)
		bShowLevel0 = TRUE;
	else
		bShowLevel1 = FALSE;

	if(m_ShowLevel2.GetCheck() == 1)
		bShowLevel2 = TRUE;
	else
		bShowLevel2 = FALSE;

	if(m_ShowLevel3.GetCheck() == 1)
		bShowLevel3 = TRUE;
	else
		bShowLevel3 = FALSE;

	if(m_ShowNumber.GetCheck() == 1)
		bShowNumber = TRUE;
	else
		bShowNumber = FALSE;

	if(m_ShowReversed.GetCheck() == 1)
		bShowReversed = TRUE;
	else
		bShowReversed = FALSE;

	if(m_ShowAnimation.GetCheck() == 1)
		bShowAnimation = TRUE;
	else
		bShowAnimation = FALSE;

	CDialog::OnOK();
}

void COptionsDlg::OnCancel() 
{
	CDialog::OnCancel();
}

BOOL COptionsDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	if(bShowLevel0)
		m_ShowLevel0.SetCheck(1);

	if(bShowLevel1)
		m_ShowLevel1.SetCheck(1);

	if(bShowLevel2)
		m_ShowLevel2.SetCheck(1);

	if(bShowLevel3)
		m_ShowLevel3.SetCheck(1);

	if(bShowNumber)
		m_ShowNumber.SetCheck(1);

	if(bShowReversed)
		m_ShowReversed.SetCheck(1);

	if(bShowAnimation)
		m_ShowAnimation.SetCheck(1);

	CenterWindow();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

