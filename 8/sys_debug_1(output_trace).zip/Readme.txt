------------------------------------------------------------------------------
Program     : Visual C++ Custom Debug Monitor 1.0
Files       : CDebug.cpp   CDebug.h    Debug.exe
Author      : Daniel Chirca
Email       : D.Chirca@finsiel.ro
Version     : 1.0
------------------------------------------------------------------------------

Program description
------------------------------------------------------------------------------
CDebug class implements for Visual C++ more or less the functionality
that Visual Basic provides, i.e. the posibility
to insert into your C++ source code calls like Debug.printf(...), and
watch the messages in a separate window (Immediate window), without
the need to work with the Debug version of the project.

Using the program
------------------------------------------------------------------------------
- Insert into your Visual C++ project the CDebug.cpp and CDebug.h files
- Create a global instance of the CDebug class, for example:
	CDebug Debug;
(don't forget the include statement: #include "Cdebug.h")
- insert your debug messages anywhere you like:
	Debug.Printf0(...);	or
	Debug.Printf1(...);	or
	Debug.Printf2(...);	or
	Debug.Printf3(...);
- run the Debug.exe program (a nice ideea is to put it into
your Tools menu from IDE environment), select the "Options"
button to customize his behaviour, then press the "Start" button.
- run your project.
- watch your messages...

Notes
------------------------------------------------------------------------------
- The Debug.printfx (where x=0, 1, 2, 3) functions accepts the same
arguments as the printf function does (formatting, ...)
- x(=0, 1, 2, 3) means the message level:
	printf0 sends level 0 messages
	printf1 sends level 1 messages
	printf2 sends level 2 messages
	printf3 sends level 3 messages
- Use the "Options" button from Debug.exe to customize
which messages you want to intercept...

Other Notes
------------------------------------------------------------------------------
- You are free to modify the source code in CDebug.cpp and CDebug.h anyway you want,
but please send me an e-mail if you do it.

Special thanks
------------------------------------------------------------------------------
I want to give thanks to Cecil A. Galbraith, from CustomSoft,
from which I took the ideea to develop my own debug utility.

Dan
May 2000
