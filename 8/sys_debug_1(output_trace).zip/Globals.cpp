//this file contains global variables
#include "stdafx.h"

BOOL bShowLevel0 = TRUE;
BOOL bShowLevel1 = TRUE;
BOOL bShowLevel2 = FALSE;
BOOL bShowLevel3 = FALSE;
BOOL bShowNumber = TRUE;
BOOL bShowReversed = FALSE;
BOOL bShowAnimation = TRUE;

BOOL bRunning = FALSE;
