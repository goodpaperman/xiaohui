// DebugDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Debug.h"
#include "DebugDlg.h"

#include "OptionsDlg.h"
#include "Globals.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

long nNumber = 0L;
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDebugDlg dialog

CDebugDlg::CDebugDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDebugDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDebugDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CDebugDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDebugDlg)
	DDX_Control(pDX, IDC_PROGRESS_LEVEL, m_ctlLevel);
	DDX_Control(pDX, IDSTOP, m_Stop);
	DDX_Control(pDX, IDC_MESSAGES, m_ctlMessages);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CDebugDlg, CDialog)
	//{{AFX_MSG_MAP(CDebugDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDOPTIONS, OnOptions)
	ON_BN_CLICKED(IDSTOP, OnStop)
	ON_BN_CLICKED(IDCLEARALL, OnClearall)
	ON_WM_COPYDATA()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDebugDlg message handlers

BOOL CDebugDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	if(bRunning)
	{
		m_Stop.SetWindowText("&Stop");
	}
	else
	{
		m_Stop.SetWindowText("&Start");
	}
	
	m_ctlLevel.SetPos(0);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CDebugDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CDebugDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CDebugDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

BOOL CAboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	CenterWindow();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDebugDlg::OnOptions() 
{
	COptionsDlg CMyOptionsDlg;
	CMyOptionsDlg.DoModal();
}

void CDebugDlg::OnStop() 
{
	bRunning = !bRunning;
	if(bRunning)
	{
		nNumber = 0;
		m_Stop.SetWindowText("&Stop");
	}
	else
	{
		m_Stop.SetWindowText("&Start");
	}
}

void CDebugDlg::OnCancel() 
{
	CDialog::OnCancel();
}

void CDebugDlg::OnClearall() 
{
	nNumber = 0;
	SetDlgItemText(IDC_EDIT_HWND, "");
	m_ctlLevel.SetPos(0);
	m_ctlMessages.SetWindowText("");
	m_ctlMessages.SetFocus();
}

BOOL CDebugDlg::OnCopyData(CWnd* pWnd, COPYDATASTRUCT* pCopyDataStruct) 
{
	char szMessage[512];

	if(!bRunning)
		return TRUE;

	char szHWND[16];
	sprintf(szHWND, "%#x", (LONG) pWnd->m_hWnd);
	SetDlgItemText(IDC_EDIT_HWND, szHWND);

	if(bShowAnimation)
	{
		m_ctlLevel.SetPos(25 * ((int)(pCopyDataStruct->dwData) + 1));
	}

	if(pCopyDataStruct->dwData == (DWORD) 0 && !bShowLevel0)
	{
		m_ctlLevel.SetPos(0);
		return TRUE;
	}

	if(pCopyDataStruct->dwData == (DWORD) 1 && !bShowLevel1)
	{
		m_ctlLevel.SetPos(0);
		return TRUE;
	}

	if(pCopyDataStruct->dwData == (DWORD) 2 && !bShowLevel2)
	{
		m_ctlLevel.SetPos(0);
		return TRUE;
	}

	if(pCopyDataStruct->dwData == (DWORD) 3 && !bShowLevel3)
	{
		m_ctlLevel.SetPos(0);
		return TRUE;
	}

	m_ctlMessages.SetFocus();

	if(bShowNumber)
	{
		nNumber++;
		wsprintf(szMessage, "%d: ", nNumber);
	}

	strncat(szMessage, (char *) pCopyDataStruct->lpData, pCopyDataStruct->cbData);
	strcat(szMessage, "\r\n");

	if(!bShowReversed)
	{
		m_ctlMessages.SetSel(-1, -1, TRUE);
		m_ctlMessages.ReplaceSel(szMessage, FALSE);
	}
	else
	{
		m_ctlMessages.SetSel(0, 0, TRUE);
		m_ctlMessages.ReplaceSel(szMessage, FALSE);
	}

	if(bShowAnimation)
		m_ctlLevel.SetPos(0);

	return TRUE;
	//return CDialog::OnCopyData(pWnd, pCopyDataStruct);
}
