//this file contains external global variables
extern BOOL bShowLevel0;
extern BOOL bShowLevel1;
extern BOOL bShowLevel2;
extern BOOL bShowLevel3;
extern BOOL bShowNumber;
extern BOOL bShowReversed;
extern BOOL bShowAnimation;

extern BOOL bRunning;
