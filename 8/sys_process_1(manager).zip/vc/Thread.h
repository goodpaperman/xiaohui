#if !defined(AFX_THREAD_H__D9D8FA61_203C_11D5_B1D9_FBA3F21F641C__INCLUDED_)
#define AFX_THREAD_H__D9D8FA61_203C_11D5_B1D9_FBA3F21F641C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Thread.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CThread window

class CThread : public CListCtrl
{
// Construction
public:
	CThread();

// Attributes
public:
	void DoRefresh();
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CThread)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CThread();

	// Generated message map functions
protected:
	//{{AFX_MSG(CThread)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_THREAD_H__D9D8FA61_203C_11D5_B1D9_FBA3F21F641C__INCLUDED_)
