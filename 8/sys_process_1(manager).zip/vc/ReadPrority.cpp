// ReadPrority.cpp : implementation file
//

#include "stdafx.h"
#include "MFCTList.h"
#include "ReadPrority.h"
#include "stdlib.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CReadPrority dialog


CReadPrority::CReadPrority(CWnd* pParent /*=NULL*/)
	: CDialog(CReadPrority::IDD, pParent)
{
	//{{AFX_DATA_INIT(CReadPrority)
	//}}AFX_DATA_INIT
}


void CReadPrority::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CReadPrority)
	DDX_Control(pDX, IDC_COMBO1, m_Priority);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CReadPrority, CDialog)
	//{{AFX_MSG_MAP(CReadPrority)
	ON_CBN_EDITCHANGE(IDC_COMBO1, OnEditchangeCombo1)
	ON_CBN_EDITUPDATE(IDC_COMBO1, OnEditupdateCombo1)
	ON_CBN_SELCHANGE(IDC_COMBO1, OnSelchangeCombo1)
	ON_CBN_SELENDOK(IDC_COMBO1, OnSelendokCombo1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CReadPrority message handlers

void CReadPrority::OnEditchangeCombo1() 
{
m_Priority.Clear();
m_Priority.EnableWindow(FALSE);	

	 
}

BOOL CReadPrority::OnInitDialog() 
{
	CDialog::OnInitDialog();

	CString SPRIORITY[4]={"High Priority class(128)","Idle priority class(64)",
		"Normal priority class(32)","Realtime priority class(256)"};
	m_Priority.ResetContent();
	int i=0;
	while (i<4)
	{
		m_Priority.AddString(SPRIORITY[i]);
		i++;
	}
	m_Priority.SetCurSel(0);

    priority=0;
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
DWORD CReadPrority::GetPriority()
{ 

   // UpdateData(TRUE);
//	priority=m_Priority.GetCurSel();
	//ASSERT(priority==CB_ERR);	
  if (priority>=0&&priority<4)
  {
	DWORD PRIORITY[4]={HIGH_PRIORITY_CLASS,IDLE_PRIORITY_CLASS,
		NORMAL_PRIORITY_CLASS,REALTIME_PRIORITY_CLASS};
	DWORD test=PRIORITY[priority];	
	return test;
  }
  else
	  return -1;
}

void CReadPrority::OnEditupdateCombo1() 
{
	// TODO: Add your control notification handler code here
	// TODO: Add your control notification handler code here

}

void CReadPrority::OnSelchangeCombo1() 
{
	// TODO: Add your control notification handler code here
	 UpdateData(TRUE);
     priority=m_Priority.GetCurSel();
//	 priority=((CComboBox *)GetDlgItem(IDC_COMBO1))->GetCurSel();
	 ASSERT(priority!=CB_ERR);
}

void CReadPrority::OnSelendokCombo1() 
{	
	// TODO: Add your control notification handler code here
		CString str;
	UpdateData(TRUE);
//	priority=m_Priority.GetCurSel();
	m_Priority.GetLBText(0,str);
	priority=atol(str);

//	 priority=((CComboBox *)GetDlgItem(IDC_COMBO1))->GetCurSel();
	ASSERT(priority!=CB_ERR);
}
