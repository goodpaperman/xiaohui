// MFCTListDlg.cpp : implementation file
//


#include "stdafx.h"
#include "MFCTList.h"
#include "MFCTListDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMFCTListDlg dialog

CMFCTListDlg::CMFCTListDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMFCTListDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMFCTListDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME); 

   if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT|WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC, 
		WS_CHILD | WS_VISIBLE | CBRS_ALIGN_TOP)
		||		!m_wndToolBar.LoadToolBar(IDR_MYTOOL)
	)
	{
	   TRACE0("Failed to create toolbar\n");
		return;      // fail to create
	}
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);

}

void CMFCTListDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMFCTListDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMFCTListDlg, CDialog)
	//{{AFX_MSG_MAP(CMFCTListDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_KILL, OnKill)
	ON_BN_CLICKED(IDC_REFRESH, OnRefresh)
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_TASKLIST, OnItemchangedTasklist)
	ON_BN_CLICKED(IDC_PRIORITY, OnPriority)
	ON_NOTIFY(LVN_COLUMNCLICK, IDC_TASKLIST, OnColumnclickTasklist)
	ON_NOTIFY(HDN_ITEMCHANGING, IDC_ThreadList, OnItemchangingThreadList)
	ON_NOTIFY(LVN_COLUMNCLICK, IDC_ThreadList, OnColumnclickThreadList)
	ON_COMMAND(IDD_ABOUTBOX, OnAboutbox)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMFCTListDlg message handlers

BOOL CMFCTListDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	flag=1;

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// add columns to list control
     SetWindowText(_T("My program!"));
	CListCtrl* pList = (CListCtrl*) GetDlgItem(IDC_TASKLIST);
	ASSERT(pList != NULL);

	pList->InsertColumn(0, _T("������"));
	pList->InsertColumn(1, _T("���̺�"));
	pList->InsertColumn(2, _T("�����̺�"));
    pList->InsertColumn(3, _T("������"));
	pList->InsertColumn(4, _T("�߳���"));
    pList->InsertColumn(5, _T("������"));
	pList->InsertColumn(6, _T("ִ���ļ���"));

	// load the control
    CListCtrl *pList1 = (CListCtrl*) GetDlgItem(IDC_ThreadList);
	ASSERT(pList1 != NULL);

	pList1->InsertColumn(0, _T("������"),LVCFMT_CENTER,60);
	pList1->InsertColumn(1, _T("���̺�"),LVCFMT_CENTER,60);
    pList1->InsertColumn(2, _T("������"),LVCFMT_CENTER,60);
    pList1->InsertColumn(3, _T("ִ��ʱ��"),LVCFMT_CENTER,80);
	pList1->InsertColumn(4, _T("ִ���ļ���"),LVCFMT_CENTER,160);

	DoRefresh();
	
	return TRUE;
	// return TRUE  unless you set the focus to a control
}

void CMFCTListDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

void CMFCTListDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CMFCTListDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CMFCTListDlg::OnKill() 
{

	// find the selected task and kill it
	CListCtrl* pList = (CListCtrl*) GetDlgItem(IDC_TASKLIST);
	ASSERT(pList != NULL);

	int nItem = pList->GetNextItem(-1, LVIS_SELECTED);

	// no sorting, so we know nItem is still an index into
	// our array

	CMFCTListApp* pApp = (CMFCTListApp*) AfxGetApp();
	CTaskList& refTaskList = pApp->GetTaskList();

	BOOL bResult = KillProcess(refTaskList[nItem], TRUE);
	if (bResult)
	{
		MessageBox("Kill worked!");
	    DoRefresh();
        DoTRefresh();
	}
	else
		MessageBox("Kill failed!");
}

void CMFCTListDlg::OnRefresh() 
{
	DoRefresh();
    DoTRefresh();
}


void CMFCTListDlg::DoRefresh()
{
	
	
    ClearThread();
	CListCtrl* pList = (CListCtrl*) GetDlgItem(IDC_TASKLIST);
	ASSERT(pList != NULL);

	// reset what's there

	pList->DeleteAllItems();

    //
    // Determine what system we're on and do the right thing
    //

    LPGetTaskList     GetTaskList;
    LPEnableDebugPriv EnableDebugPriv;

    OSVERSIONINFO verInfo;
	memset(&verInfo, 0, sizeof(verInfo));

    verInfo.dwOSVersionInfoSize = sizeof(verInfo);
    GetVersionEx(&verInfo);

    switch (verInfo.dwPlatformId)
    {
    case VER_PLATFORM_WIN32_NT:
		GetTaskList     = GetTaskListNT;
		EnableDebugPriv = EnableDebugPrivNT;
		break;

    case VER_PLATFORM_WIN32_WINDOWS:
		GetTaskList = GetTaskList95;
		EnableDebugPriv = EnableDebugPriv95;
		break;

    default:
//		m_bBroken = TRUE;
		pList->InsertItem(0, _T("Requires Win95 or WinNT"));
		return;
    }

    EnableDebugPriv();

    // get the task list for the system

	CMFCTListApp* pApp = (CMFCTListApp*) AfxGetApp();
	pApp->ClearTaskList();
	CTaskList& refTaskList = pApp->GetTaskList();

    DWORD numTasks = GetTaskList(refTaskList);

    // enumerate all windows and try to get the window
    // titles for each task

    GetWindowTitles(refTaskList);

    //
    // print the task list
    //

	int n;
	for (n = 0; n < refTaskList.GetSize(); n++)
	{   
	//	HANDLE  hProcess;
		CString str,str1;
		str.Format("0x%8.8X", refTaskList[n]->dwProcessId);
      //  hProcess = OpenProcess( PROCESS_ALL_ACCESS, FALSE, refTaskList[n]->dwProcessId );

		str.Format("0x%8.8X", refTaskList[n]->dwProcessId);
		int	nItem;
		nItem=pList->InsertItem(n, refTaskList[n]->ProcessName);
		pList->SetItemText(nItem, 1, str);
		CString pid;
		pid.Format("0x%8.8X",refTaskList[n]->th32ParentProcessID);
        pList->SetItemText(nItem, 2,pid );
		//DWORD pi=GetPriorityClass(hProcess);
  
		//pApp->m_tasklist[n]->SetPriority(pi);
        str1.Format("%6ld", refTaskList[n]->processPriority);
		pList->SetItemText(nItem, 3, str1);
        CString cnt;
		cnt.Format("%6ld", refTaskList[n]->cntThreads);
        pList->SetItemText(nItem, 4,cnt );
		pList->SetItemText(nItem, 5, refTaskList[n]->WindowTitle);
		pList->SetItemText(nItem, 6, refTaskList[n]->szExeFile);
	}

	pList->SetColumnWidth(0, LVSCW_AUTOSIZE);
	pList->SetColumnWidth(1, LVSCW_AUTOSIZE);
	pList->SetColumnWidth(2, LVSCW_AUTOSIZE);
	pList->SetColumnWidth(3, LVSCW_AUTOSIZE);
	pList->SetColumnWidth(4, LVSCW_AUTOSIZE);
	pList->SetColumnWidth(5, LVSCW_AUTOSIZE);
	pList->SetColumnWidth(6, LVSCW_AUTOSIZE);
	CWnd* pWnd = GetDlgItem(IDC_KILL);
	pWnd->EnableWindow(FALSE);
	CWnd* pWnd1 = GetDlgItem(IDC_PRIORITY);
	pWnd1->EnableWindow(FALSE);
   
	//END_SAMPLE
}

void CMFCTListDlg::OnItemchangedTasklist(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;

	CListCtrl* pList = (CListCtrl*) GetDlgItem(IDC_ThreadList);
	ASSERT(pList != NULL);
	int k = pList->GetNextItem(-1, LVIS_SELECTED);

	CWnd* pWnd = GetDlgItem(IDC_KILL);
	pWnd->EnableWindow(k==-1);
	CWnd* pWnd1 = GetDlgItem(IDC_PRIORITY);
	pWnd1->EnableWindow(k == -1);	
	*pResult = 0;
    DoTRefresh();
}

void CMFCTListDlg::OnPriority() 
{
	CReadPrority my;
	
	if(my.DoModal()==IDOK)
	{
        DWORD m_p=my.GetPriority();
	    ASSERT(m_p!=-1);
		CMFCTListApp* pApp = (CMFCTListApp*) AfxGetApp();
	    //pApp->ClearTaskList();
		CTaskList& refTaskList = pApp->GetTaskList();

      
		CListCtrl* pList = (CListCtrl*) GetDlgItem(IDC_TASKLIST);
	    ASSERT(pList != NULL);
		int n = pList->GetNextItem(-1, LVIS_SELECTED);
		HANDLE  hProcess;
		//CString str,str1;
		//str.Format("0x%8.8X", refTaskList[n]->dwProcessId);
        hProcess = OpenProcess( PROCESS_ALL_ACCESS, FALSE, refTaskList[n]->dwProcessId );
		BOOL i=SetPriorityClass(hProcess,m_p);
		if(i==0)
		{
			AfxMessageBox("seting Process priority  is fail!");
			return ;
		}
		OnRefresh();
	}
	// TODO: Add your control notification handler code here
	
}

void CMFCTListDlg::OnColumnclickTasklist(NMHDR* pNMHDR, LRESULT* pResult) 
{
	flag=!flag;
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	CListCtrl* pList = (CListCtrl*) GetDlgItem(IDC_TASKLIST);
    //pList->SortItems(CompareProc,pNMListView->iSubItem);
    DoRefresh();
    CMFCTListApp* pApp = (CMFCTListApp*) AfxGetApp();
	CTaskList& list = pApp->GetTaskList();
	int count=list.GetSize();

    count =list.GetUpperBound();
	for(int i=0;i<count;i++)
	{
		int max=i;
		for(int j=i+1;j<=count;j++)
		 switch(pNMListView->iSubItem)
		 {
		 case 0:
           if((lstrcmpi(list[max]->ProcessName,list[j]->ProcessName)<0))
				  max=j;
	
		   break;
		 case 1: 
			 if((unsigned long)list[j]->dwProcessId>(unsigned long)list[max]->dwProcessId)
			  max=j;
			 break;
		 case 2:
			 if((unsigned long)list[j]->th32ParentProcessID>(unsigned long)list[max]->th32ParentProcessID)
			  max=j; 
             
			 break;     
		 case 3:
	         if(list[j]->processPriority>list[max]->processPriority)
             max=j;
			 break;		 
		 case 4:
			 
			 if((list[j]->cntThreads>list[max]->cntThreads))
			 max=j;

			 break;
		 default:;
		}
		if(i^max)
		{
		CTaskListEntry temp;
		swap(&temp,list[max]);
		swap(list[max],list[i]);
		swap(list[i],&temp);
		}
	}
	/*CMFCTListApp* pApp = (CMFCTListApp*) AfxGetApp();
	pApp->ClearTaskList();
	CTaskList& refTaskList = pApp->GetTaskList();*/
	pList->DeleteAllItems();
	int n;
	for (n = 0; n <= count; n++)
	{   
		HANDLE  hProcess;
		CString str,str1;
		str.Format("0x%8.8X", list[n]->dwProcessId);
        hProcess = OpenProcess( PROCESS_ALL_ACCESS, FALSE, list[n]->dwProcessId );

		str.Format("0x%8.8X", list[n]->dwProcessId);
		int	nItem;
		nItem=pList->InsertItem(n, list[n]->ProcessName);
		pList->SetItemText(nItem, 1, str);
		CString pid;
		pid.Format("0x%8.8X",list[n]->th32ParentProcessID);
        pList->SetItemText(nItem, 2,pid );
		DWORD pi=GetPriorityClass(hProcess);
        str1.Format("%6ld", pi);
		pList->SetItemText(nItem, 3, str1);
        CString cnt;
		cnt.Format("%6ld", list[n]->cntThreads);
        pList->SetItemText(nItem, 4,cnt );
		pList->SetItemText(nItem, 5, list[n]->WindowTitle);
		pList->SetItemText(nItem, 6, list[n]->szExeFile);
	}

	pList->SetColumnWidth(0, LVSCW_AUTOSIZE);
	pList->SetColumnWidth(1, LVSCW_AUTOSIZE);
	pList->SetColumnWidth(2, LVSCW_AUTOSIZE);
	pList->SetColumnWidth(3, LVSCW_AUTOSIZE);
	pList->SetColumnWidth(4, LVSCW_AUTOSIZE);
	pList->SetColumnWidth(5, LVSCW_AUTOSIZE);
	pList->SetColumnWidth(6, LVSCW_AUTOSIZE);

	*pResult = 0;
}

int CALLBACK CMFCTListDlg::CompareProc(LPARAM lParam1,LPARAM lParam2,LPARAM lParamSort)
{
	//CMFCTListApp* pApp = (CMFCTListApp*) AfxGetApp();
	//CTaskList& refTaskList = pApp->GetTaskList();
   CTaskListEntry  *p1=( CTaskListEntry *)lParam1; 
   CTaskListEntry  *p2=( CTaskListEntry *)lParam2; 
   LPSTR ps1,ps2;
   DWORD i,j;
    int iResult;
	if(1)
	{
	  switch(lParamSort)
	  {
	  case 0:
		  ps1=p1->ProcessName;
		  ps2=p2->ProcessName;
		  iResult=lstrcmpi(ps1,ps2);
		  break;
	  case 1:
		  i=p1->cntThreads;
		  j=p2->cntThreads;
		  iResult=i>j;
		  break;
	  default:
		  iResult=1;
	  }
	}
  return iResult;
}
void CMFCTListDlg::swap(CTaskListEntry *a, CTaskListEntry  *list)

	{  
		a->dwSize=list->dwSize;  
	    a->cntUsage=list->cntUsage;   
	    a->th32ProcessID=list->th32ProcessID; 
        a->th32DefaultHeapID=list->th32DefaultHeapID;
		a->th32ModuleID=list->th32ModuleID; 
        a->cntThreads=list->cntThreads; 
        a->th32ParentProcessID=list->th32ParentProcessID;    
	    a->pcPriClassBase=list->pcPriClassBase;   
	    a->dwFlags=list->dwFlags; 
        lstrcpy(a->szExeFile,list->szExeFile); 
	    a->dwProcessId=list->dwProcessId;
        a->dwInheritedFromProcessId=list->dwInheritedFromProcessId;
        a->flags=list->flags;
        a->hwnd=list->hwnd;
		a->processPriority=list->processPriority;
        lstrcpy(a->ProcessName,list->ProcessName);
        lstrcpy(a->WindowTitle,list->WindowTitle);
	}
void CMFCTListDlg::DoTRefresh()
{
	CListCtrl* pList1 = (CListCtrl*) GetDlgItem(IDC_TASKLIST);
	ASSERT(pList1 != NULL);
	int k = pList1->GetNextItem(-1, LVIS_SELECTED);
	if(k==-1)return;
	
	CListCtrl* pList = (CListCtrl*) GetDlgItem(IDC_ThreadList);
	ASSERT(pList != NULL);

    // Determine what system we're on and do the right thing
    LPGetTaskList     GetTaskList;
    LPEnableDebugPriv EnableDebugPriv;

    OSVERSIONINFO verInfo;
	memset(&verInfo, 0, sizeof(verInfo));

    verInfo.dwOSVersionInfoSize = sizeof(verInfo);
    GetVersionEx(&verInfo);

    switch (verInfo.dwPlatformId)
    {
    case VER_PLATFORM_WIN32_NT:
		GetTaskList     = GetTaskListNT;
		EnableDebugPriv = EnableDebugPrivNT;
		break;

    case VER_PLATFORM_WIN32_WINDOWS:
		GetTaskList = GetTaskList95;
		EnableDebugPriv = EnableDebugPriv95;
		break;

    default:
//		m_bBroken = TRUE;
		pList->InsertItem(0, _T("Requires Win95 or WinNT"));
		return;
    }

    EnableDebugPriv();

  
	CMFCTListApp* pApp = (CMFCTListApp*) AfxGetApp();
	//pApp->ClearTaskList();
	CTaskList& refTaskList = pApp->GetTaskList();
    DWORD numTasks = GetTaskList(refTaskList);
	
	int Value=pList->DeleteAllItems();
	ASSERT(Value);
	
    HANDLE  hProcess;
	hProcess = OpenProcess( PROCESS_QUERY_INFORMATION, FALSE, refTaskList[k]->dwProcessId );
	DWORD i=0;
	for (i = 0; i < refTaskList[k]->cntThreads; i++)
	{   DWORD threadId=GetCurrentThreadId();
        HANDLE thread=GetCurrentThread();
        DWORD processId=GetCurrentProcessId();
        HANDLE process=GetCurrentProcess();
	    int	nItem;
     	CString str;
		str.Format("0x%8.8X",process);
		nItem=pList->InsertItem(i,str);
		str.Format("0x%8.8X", processId);//refTaskList[k]->dwProcessId); 
		pList->SetItemText(nItem, 1, str);
		str.Format("0x%8.8X",thread);
        pList->SetItemText(nItem, 2,str );
		str.Format("0x%8.8X",threadId);
        pList->SetItemText(nItem, 3,str );
		pList->SetItemText(nItem, 4, refTaskList[k]->szExeFile);
	}

	pList->SetColumnWidth(0, LVSCW_AUTOSIZE);
	pList->SetColumnWidth(1, LVSCW_AUTOSIZE);
	pList->SetColumnWidth(2, LVSCW_AUTOSIZE);
	pList->SetColumnWidth(3, LVSCW_AUTOSIZE);
	pList->SetColumnWidth(4, LVSCW_AUTOSIZE);
	//Sleep(1000);
  
}

void CMFCTListDlg::OnItemchangingThreadList(NMHDR* pNMHDR, LRESULT* pResult) 
{
	HD_NOTIFY *phdn = (HD_NOTIFY *) pNMHDR;
	// TODO: Add your control notification handler code here
	
	*pResult = 0;
}

void CMFCTListDlg::OnColumnclickThreadList(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	CListCtrl* pList = (CListCtrl*) GetDlgItem(IDC_ThreadList);
    pList->SortItems(CompareProc,pNMListView->iSubItem);	
	*pResult = 0;
 
}
void CMFCTListDlg::ClearThread()
{
 CListCtrl* pList = (CListCtrl*) GetDlgItem(IDC_ThreadList);
 pList->DeleteAllItems();
}

void CMFCTListDlg::OnAboutbox() 
{
	// TODO: Add your command handler code here
	CAboutDlg AboutDlg;
	AboutDlg.DoModal();
	
}

	