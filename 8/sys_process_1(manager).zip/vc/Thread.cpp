// Thread.cpp : implementation file
//

#include "stdafx.h"
#include "MFCTList.h"
#include "Thread.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

BEGIN_MESSAGE_MAP(CThread, CListCtrl)
	//{{AFX_MSG_MAP(CThread)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CThread message handlers


/////////////////////////////////////////////////////////////////////////////
// CThread

CThread::CThread()
{
}

CThread::~CThread()
{
}


void CThread::DoRefresh()
{
	CListCtrl* pList = (CListCtrl*) GetDlgItem(IDC_ThreadList);
	ASSERT(pList != NULL);

	// reset what's there

	pList->DeleteAllItems();

    //
    // Determine what system we're on and do the right thing
    //

    LPGetTaskList     GetTaskList;
    LPEnableDebugPriv EnableDebugPriv;

    OSVERSIONINFO verInfo;
	memset(&verInfo, 0, sizeof(verInfo));

    verInfo.dwOSVersionInfoSize = sizeof(verInfo);
    GetVersionEx(&verInfo);

    switch (verInfo.dwPlatformId)
    {
    case VER_PLATFORM_WIN32_NT:
		GetTaskList     = GetTaskListNT;
		EnableDebugPriv = EnableDebugPrivNT;
		break;

    case VER_PLATFORM_WIN32_WINDOWS:
		GetTaskList = GetTaskList95;
		EnableDebugPriv = EnableDebugPriv95;
		break;

    default:
//		m_bBroken = TRUE;
		pList->InsertItem(0, _T("Requires Win95 or WinNT"));
		return;
    }

    EnableDebugPriv();

    // get the task list for the system

	CMFCTListApp* pApp = (CMFCTListApp*) AfxGetApp();
	pApp->ClearTaskList();
	CTaskList& refTaskList = pApp->GetTaskList();

    DWORD numTasks = GetTaskList(refTaskList);

    // enumerate all windows and try to get the window
    // titles for each task

    GetWindowTitles(refTaskList);

    //
    // print the task list
    //

	int n;
	for (n = 0; n < refTaskList.GetSize(); n++)
	{   
		HANDLE  hProcess;
		CString str,str1;
		str.Format("0x%8.8X", refTaskList[n]->dwProcessId);
        hProcess = OpenProcess( PROCESS_ALL_ACCESS, FALSE, refTaskList[n]->dwProcessId );

		str.Format("0x%8.8X", refTaskList[n]->dwProcessId);
		int	nItem;
		nItem=pList->InsertItem(n, refTaskList[n]->ProcessName);
		pList->SetItemText(nItem, 1, str);
		CString pid;
		pid.Format("0x%8.8X",refTaskList[n]->th32ParentProcessID);
        pList->SetItemText(nItem, 2,pid );
		DWORD pi=GetPriorityClass(hProcess);
        str1.Format("%6ld", pi);
		pList->SetItemText(nItem, 3, str1);
        CString cnt;
		cnt.Format("%6ld", refTaskList[n]->cntThreads);
        pList->SetItemText(nItem, 4,cnt );
		pList->SetItemText(nItem, 5, refTaskList[n]->WindowTitle);
		pList->SetItemText(nItem, 6, refTaskList[n]->szExeFile);
	}

	pList->SetColumnWidth(0, LVSCW_AUTOSIZE);
	pList->SetColumnWidth(1, LVSCW_AUTOSIZE);
	pList->SetColumnWidth(2, LVSCW_AUTOSIZE);
	pList->SetColumnWidth(3, LVSCW_AUTOSIZE);
	pList->SetColumnWidth(4, LVSCW_AUTOSIZE);
	pList->SetColumnWidth(5, LVSCW_AUTOSIZE);
	pList->SetColumnWidth(6, LVSCW_AUTOSIZE);

	CWnd* pWnd = GetDlgItem(IDC_KILL);
	pWnd->EnableWindow(FALSE);
	CWnd* pWnd1 = GetDlgItem(IDC_PRIORITY);
	pWnd1->EnableWindow(FALSE);

	//END_SAMPLE
}

