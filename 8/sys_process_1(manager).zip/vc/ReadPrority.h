#if !defined(AFX_READPRORITY_H__22B8A5E5_1C9C_11D5_B1D9_E62B4BA2409A__INCLUDED_)
#define AFX_READPRORITY_H__22B8A5E5_1C9C_11D5_B1D9_E62B4BA2409A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ReadPrority.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CReadPrority dialog

class CReadPrority : public CDialog
{
// Construction
public:
	CReadPrority(CWnd* pParent = NULL);   // standard constructor
	int priority;
	DWORD GetPriority();
// Dialog Data
	//{{AFX_DATA(CReadPrority)
	enum { IDD = IDD_DIALOG1 };
	CComboBox	m_Priority;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CReadPrority)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CReadPrority)
	afx_msg void OnEditchangeCombo1();
	virtual BOOL OnInitDialog();
	afx_msg void OnEditupdateCombo1();
	afx_msg void OnSelchangeCombo1();
	afx_msg void OnSelendokCombo1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_READPRORITY_H__22B8A5E5_1C9C_11D5_B1D9_E62B4BA2409A__INCLUDED_)
