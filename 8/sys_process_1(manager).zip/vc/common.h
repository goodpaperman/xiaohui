
#ifndef __MCTLISTCOMMONDOTH__
#define __MCTLISTCOMMONDOTH__

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000




#include <afxtempl.h>

#define TITLE_SIZE          64
#define PROCESS_SIZE        MAX_PATH


// task list structure

//SAMPLE: derive this guy from CObject instead of
// using a plain struct

class CTaskListEntry : public CObject
{
public:
	CTaskListEntry() { ProcessName[0] = WindowTitle[0] = 0; }
	~CTaskListEntry() { }
    DWORD dwSize;  
	DWORD cntUsage;   
	DWORD th32ProcessID; 
    DWORD th32DefaultHeapID;
	DWORD th32ModuleID; 
    DWORD cntThreads; 
    DWORD th32ParentProcessID;    
	LONG  pcPriClassBase;   
	DWORD dwFlags; 
	DWORD processPriority;
    char szExeFile[MAX_PATH]; 
	DWORD       dwProcessId;
    DWORD       dwInheritedFromProcessId;
    BOOL        flags;
    HWND        hwnd;
    CHAR        ProcessName[PROCESS_SIZE];
    CHAR        WindowTitle[TITLE_SIZE];
public:
	CTaskListEntry  &operator=(	CTaskListEntry  *list)
	{  
		dwSize=list->dwSize;  
	    cntUsage=list->cntUsage;   
	    th32ProcessID=list->th32ProcessID; 
        th32DefaultHeapID=list->th32DefaultHeapID;
		th32ModuleID=list->th32ModuleID; 
        cntThreads=list->cntThreads; 
        th32ParentProcessID=list->th32ParentProcessID;    
	    pcPriClassBase=list->pcPriClassBase;  
		processPriority=list->processPriority;
	    dwFlags=list->dwFlags; 
        lstrcpy(szExeFile,list->szExeFile); 
	    dwProcessId=list->dwProcessId;
        dwInheritedFromProcessId=list->dwInheritedFromProcessId;
        flags=list->flags;
        hwnd=list->hwnd;
        lstrcpy(ProcessName,list->ProcessName);
        lstrcpy(WindowTitle,list->WindowTitle);
		return *this;
	}
  void SetPriority(DWORD priority)
	{
		processPriority=priority;
	}
};


typedef CTypedPtrArray<CObArray, CTaskListEntry*> CTaskList;

//
// Function pointer types for accessing platform-specific functions
//

typedef DWORD (*LPGetTaskList)(CTaskList&);
typedef BOOL  (*LPEnableDebugPriv)(VOID);


//
// Function prototypes
//
DWORD GetTaskList95(CTaskList& refTask);

DWORD GetTaskListNT(CTaskList& refTask);

BOOL EnableDebugPriv95(VOID);

BOOL EnableDebugPrivNT(VOID);

BOOL
KillProcess(CTaskListEntry* pEntry, BOOL  fForce);

VOID GetWindowTitles( CTaskList& refList);

BOOL MatchPattern(PUCHAR String, PUCHAR Pattern);

#endif