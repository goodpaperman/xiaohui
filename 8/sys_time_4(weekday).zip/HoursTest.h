// HoursTest.h : main header file for the HOURSTEST application
//

#if !defined(AFX_HOURSTEST_H__169F2A85_BED8_11D3_9FF1_0004AC1DC008__INCLUDED_)
#define AFX_HOURSTEST_H__169F2A85_BED8_11D3_9FF1_0004AC1DC008__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CHoursTestApp:
// See HoursTest.cpp for the implementation of this class
//

class CHoursTestApp : public CWinApp
{
public:
	CHoursTestApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHoursTestApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CHoursTestApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HOURSTEST_H__169F2A85_BED8_11D3_9FF1_0004AC1DC008__INCLUDED_)
