// HoursTestDlg.h : header file
//
//{{AFX_INCLUDES()
#include "hoursselector.h"
//}}AFX_INCLUDES

#if !defined(AFX_HOURSTESTDLG_H__169F2A87_BED8_11D3_9FF1_0004AC1DC008__INCLUDED_)
#define AFX_HOURSTESTDLG_H__169F2A87_BED8_11D3_9FF1_0004AC1DC008__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CHoursTestDlg dialog

class CHoursTestDlg : public CDialog
{
// Construction
public:
	CHoursTestDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CHoursTestDlg)
	enum { IDD = IDD_HOURSTEST_DIALOG };
	COleDateTime	m_odtDate;
	COleDateTime	m_odtTime;
	CString	m_strVerbose;
	CHoursSelector	m_hsTimes;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHoursTestDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CHoursTestDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnCheck();
	afx_msg void OnVerboseHoursselector(LPCTSTR pszVerbose);
	DECLARE_EVENTSINK_MAP()
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HOURSTESTDLG_H__169F2A87_BED8_11D3_9FF1_0004AC1DC008__INCLUDED_)
