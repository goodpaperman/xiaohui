// HoursTestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "HoursTest.h"
#include "HoursTestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHoursTestDlg dialog

CHoursTestDlg::CHoursTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CHoursTestDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CHoursTestDlg)
	m_odtDate = COleDateTime::GetCurrentTime();
	m_odtTime = COleDateTime::GetCurrentTime();
	m_strVerbose = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CHoursTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CHoursTestDlg)
	DDX_DateTimeCtrl(pDX, IDC_DATE, m_odtDate);
	DDX_DateTimeCtrl(pDX, IDC_TIME, m_odtTime);
	DDX_Text(pDX, IDC_VERBOSE, m_strVerbose);
	DDX_Control(pDX, IDC_HOURSSELECTOR, m_hsTimes);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CHoursTestDlg, CDialog)
	//{{AFX_MSG_MAP(CHoursTestDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_CHECK, OnCheck)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHoursTestDlg message handlers

BOOL CHoursTestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	m_hsTimes.SetFocus();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CHoursTestDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CHoursTestDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


BEGIN_EVENTSINK_MAP(CHoursTestDlg, CDialog)
    //{{AFX_EVENTSINK_MAP(CHoursTestDlg)
	ON_EVENT(CHoursTestDlg, IDC_HOURSSELECTOR, 1 /* Verbose */, OnVerboseHoursselector, VTS_BSTR)
	//}}AFX_EVENTSINK_MAP
END_EVENTSINK_MAP()


void CHoursTestDlg::OnCheck() 
{
	UpdateData();

	COleSafeArray l_osaHours;
	char	szArray[84];

	l_osaHours = m_hsTimes.GetHoursArray();
	unsigned char cBits;

	//	Load the Information from the Grid to an Array
	for(long x=0; x<84; x++)	{
		l_osaHours.GetElement(&x, &cBits);
		szArray[x]= cBits;
	}

	COleDateTime l_odtDate(m_odtDate.GetYear(),  m_odtDate.GetMonth(), m_odtDate.GetDay(),
		m_odtTime.GetHour(), m_odtTime.GetMinute(), m_odtTime.GetSecond());
	long lOffset = ( ( ( l_odtDate.GetDayOfWeek() - 1 ) * 1440 ) + ( l_odtDate.GetHour() * 60 ) + l_odtDate.GetMinute() ) / 15;
	int nByte = lOffset / 8;
	int nBit = lOffset - (nByte * 8);
	if( ( ( szArray[nByte]>> nBit ) & 0x01 ) == 0x01 )	{
		MessageBox("Time Selected");
	}
	else	{
		if( MessageBox("Time Not Selected\x0A\x0A     Set Time?",NULL, MB_YESNO)==IDYES)	{
			unsigned char cBits = (1 << nBit);
			szArray[nByte] |= cBits;
			for(long x=0; x<84; x++)	{
				l_osaHours.PutElement(&x, &szArray[x]);
			}
			m_hsTimes.SetHoursArray(l_osaHours);
		}
	}
}

void CHoursTestDlg::OnVerboseHoursselector(LPCTSTR pszVerbose) 
{
	m_strVerbose = pszVerbose;
	UpdateData(FALSE);
}
