/*
This file is distributed "as is", e.g. there are no warranties 
and obligations and you could use it in your applications on your
own risk. Although your comments and questions are welcome.

Source:			QProfile.cpp
Author:			(c) Dan Kozub, 1999
URL   :			http://members.tripod.com/~DanKozub
Email :			Dan_Kozub@usa.net, Dan_Kozub@pemail.net
Last Modified:	Feb 7,1999
Version:		1.3
*/

/*
Description:
This example demonstrate how you can profile multi-threaded programs.

	main()
       |-------------------------------------|
       |                               SecondThread 
   Sorting arrays of 100 ints          Sorting arrays of 1000 ints
       |                                     |
        ------------------||------------------
                    Sort_Int_Arrray
                           |
                         qsort
The question is to know how common function Sort_Int_Array is used 
by each thread.
Macros QPROFILE_FUN and QPROFILE_MT_FUN1 are included to the fuctions
of interest. 
"_MT_" in macro means that information is registered for each thread.
Index "1" in macro means that one parameter can be supplied (ThreadID)
*/

#include "stdafx.h"
#include "QProfile.h"


bool Terminate_SecondThread = false;

int Sort_Int_Array(int * array, int number);
int compare_ints( const void *arg1, const void *arg2 );
DWORD WINAPI SecondThread( LPVOID lpParameter);


REM("============main==========================")
int main( int argc , char *argv[]){
QProfile::SortBy = QProfile_Sort_Time;
QProfile::Output=QProfile_Out_All|QProfile_Out_File_Append|QProfile_Out_Add_Source; //|QProfile_Out_DrawBar;
DWORD id;
HANDLE Handle = ::CreateThread(0, 0, &SecondThread, &id, 0, &id);
printf("\nProgram started...");
{
QPROFILE_FUN1("Sorting int array[100], thread:%lx",GetCurrentThreadId());
int Number = 100;
int * Array =  new int[Number];
for (int i=0; i<1000; i++){
	for (int c=0; c<Number; c++) 
						Array[c]=rand();
	Sort_Int_Array(Array,Number);
};
delete Array;}
Terminate_SecondThread = true;
while (Terminate_SecondThread) Sleep(100);
::CloseHandle(Handle);
Sleep(1000);
printf("\nProgram Finished");
return 1;}


REM("============SecondThread==================")
DWORD WINAPI SecondThread( LPVOID lpParameter){
QPROFILE_FUN1("Sorting int array[1000],thread: %lx",GetCurrentThreadId());
int Number = 1000;
int * Array =  new int[Number];
while(1){
	for (int c=0; c<Number; c++) 
						Array[c]=rand();
	Sort_Int_Array(Array,Number);
	if (Terminate_SecondThread) break;
};
delete Array;
Terminate_SecondThread = false;
return 0;};




REM("============Sort_Int_Array================")
int Sort_Int_Array(int * array, int number){
QPROFILE_MT_FUN1("Sort_Int_Array, thread:%lx",GetCurrentThreadId());
{
QPROFILE_FUN("::qsort - all threads");
qsort( (void *)array, (size_t)number, sizeof(int), compare_ints );
}
return 1;}


REM("============compare_ints==================")
int compare_ints( const void *arg1, const void *arg2 ){
   int A = *(int*)arg1; int B = *(int*)arg2;
if (A==B) return 0;
if (A>B) return 1;
return -1;}


/*
You'll get in the VC debug window 

----------------- Profiling  results -----------------
Date: 07.02.1999, Time: 13:08.32
                                          ------------------------------------------------------
                                          |-Child|Total |  Hits  |Time/call |   MIN   |   MAX   | Function    
                                          ------------------------------------------------------
                                   (  0) :|      |100.00|       1|  7032.837|    0.000|    0.000|Total time
C:\Cpp\UTIL\SOURCE\QProfileTest.cpp( 19) :| 57.43| 83.59|       1|  5878.893| 5878.893| 5878.893|Sorting int array[100], thread:ffc481ff
C:\Cpp\UTIL\SOURCE\QProfileTest.cpp( 57) :|  0.30| 26.16|    1000|     1.840|    0.299|  150.408|  Sort_Int_Array, thread:ffc481ff(31.3%)
C:\Cpp\UTIL\SOURCE\QProfileTest.cpp( 39) :| 47.03| 77.31|       1|  5437.054| 5437.054| 5437.054|Sorting int array[1000],thread: ffc48bbb
C:\Cpp\UTIL\SOURCE\QProfileTest.cpp( 57) :|  0.14| 30.28|     386|     5.517|    4.243|   25.024|  Sort_Int_Array, thread:ffc48bbb(39.2%)
C:\Cpp\UTIL\SOURCE\QProfileTest.cpp( 59) :|      | 55.99|    1386|     2.841|    0.278|  150.383|::qsort - all threads
                                          
------------------------------------------------------


and almost the same information will be written to 
QProfile.txt in the current directory and consol

----------------- Profiling  results -----------------
Date: 07.02.1999, Time: 13:08.32
------------------------------------------------------
|-Child|Total |  Hits  |Time/call |   MIN   |   MAX   | Function    
------------------------------------------------------
|      |100.00|       1|  7032.837|    0.000|    0.000|Total time
| 57.43| 83.59|       1|  5878.893| 5878.893| 5878.893|Sorting int array[100], thread:ffc481ff
|  0.30| 26.16|    1000|     1.840|    0.299|  150.408|  Sort_Int_Array, thread:ffc481ff(31.3%)
| 47.03| 77.31|       1|  5437.054| 5437.054| 5437.054|Sorting int array[1000],thread: ffc48bbb
|  0.14| 30.28|     386|     5.517|    4.243|   25.024|  Sort_Int_Array, thread:ffc48bbb(39.2%)
|      | 55.99|    1386|     2.841|    0.278|  150.383|::qsort - all threads

------------------------------------------------------

*/