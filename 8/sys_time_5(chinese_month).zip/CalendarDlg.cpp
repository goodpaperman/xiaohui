// CalendarDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Calendar.h"
#include "CalendarDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCalendarDlg dialog

CCalendarDlg::CCalendarDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCalendarDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCalendarDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CCalendarDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCalendarDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CCalendarDlg, CDialog)
	//{{AFX_MSG_MAP(CCalendarDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_CREATE()
//	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_WM_SIZE()
	ON_WM_DESTROY()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
	ON_COMMAND(IDM_RESTORE, OnMyRestore)
	ON_COMMAND(IDM_ABOUTBOX, OnAbout)
	ON_MESSAGE(UM_NOTIFY,OnMyNotify)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCalendarDlg message handlers
 
BOOL CCalendarDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
   
	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	//ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	
    SYSTEMTIME systime;
	WORD iLunarYear, iLunarMonth, iLunarDay;
	::GetSystemTime(&systime);
	CCalendar::GetLunarDate(systime.wYear, systime.wMonth, systime.wDay, 
		                    iLunarYear, iLunarMonth, iLunarDay);
	char yearbuf[20],monthbuf[20],daybuf[20];
	CCalendar::FormatLunarYear(iLunarYear, yearbuf);
	CCalendar::FormatMonth(iLunarMonth, monthbuf); 
	memmove(monthbuf, monthbuf+2, strlen(monthbuf)+1);
	CCalendar::FormatLunarDay(iLunarDay, daybuf); 
	sprintf(m_NotifyIconData.szTip,"%4d��%d��%d�� %s%s%s",
		    systime.wYear,systime.wMonth,systime.wDay,yearbuf,monthbuf,daybuf);

	m_NotifyIconData.cbSize = sizeof(NOTIFYICONDATA);
	m_NotifyIconData.hIcon = m_hIcon;
	m_NotifyIconData.hWnd =  GetSafeHwnd();
		
	m_NotifyIconData.uCallbackMessage = UM_NOTIFY;
	m_NotifyIconData.uFlags = NIF_MESSAGE|NIF_TIP|NIF_ICON;
	m_NotifyIconData.uID = IDIC_NOTIFY;
	EndWaitCursor(); 
	//ShowWindow(SW_SHOWMINIMIZED);
	//PostMessage(WM_SIZE, SW_SHOWMINIMIZED,0);
	SetTimer(500, 5000, NULL);
	return TRUE;  // return TRUE  unless you set the focus to a control
}
void CCalendarDlg::OnAbout()
{
	CAboutDlg dlgAbout;
	dlgAbout.DoModal();
}

void CCalendarDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CCalendarDlg::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	if (IsIconic())
	{
		

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
		
	}
	else
	{
		CDialog::OnPaint();
	}
	
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CCalendarDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

int CCalendarDlg::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{

	if (CDialog::OnCreate(lpCreateStruct) == -1)
		return -1;
   
   m_oCalendar.Create(CRect(5, 5, 0, 0), this, IDC_CALENDARFRM); 	
   return 0;
}

void CCalendarDlg::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
	if(nType == SIZE_MINIMIZED)
	{
	   KillTimer(500);
	   SYSTEMTIME systime;
	   WORD iLunarYear, iLunarMonth, iLunarDay;
	   ::GetSystemTime(&systime);
	   CCalendar::GetLunarDate(systime.wYear, systime.wMonth, systime.wDay, 
		                    iLunarYear, iLunarMonth, iLunarDay);
	   char yearbuf[20],monthbuf[20],daybuf[20];
	   CCalendar::FormatLunarYear(iLunarYear, yearbuf);
	   CCalendar::FormatMonth(iLunarMonth, monthbuf); 
	   memmove(monthbuf, monthbuf+2, strlen(monthbuf)+1);
	   CCalendar::FormatLunarDay(iLunarDay, daybuf); 
	   sprintf(m_NotifyIconData.szTip,"%4d��%d��%d�� %s%s%s",
	   systime.wYear,systime.wMonth,systime.wDay,yearbuf,monthbuf,daybuf);
	   Shell_NotifyIcon(NIM_ADD, &m_NotifyIconData);
	   ShowWindow(SW_HIDE);   
 	}
	else
	{ 
	//	Shell_NotifyIcon(NIM_DELETE, &m_NotifyIconData);
	}
	
}

void CCalendarDlg::OnMyNotify(UINT nID, LPARAM lParam)
{
	WINDOWPLACEMENT wndPlace;
	GetWindowPlacement(&wndPlace);
	if(lParam == WM_LBUTTONUP)
	{
		WINDOWPLACEMENT wndPlace;
		GetWindowPlacement(&wndPlace);
		if(wndPlace.showCmd == SW_SHOWMINIMIZED)
		{
	      ShowWindow(SW_SHOW);//SW_RESTORE);
	      ShowWindow(SW_RESTORE);
	      SetActiveWindow(); 
		}
		else
		{
			ShowWindow(SW_SHOWMINIMIZED);
		}
	}
	else if(lParam == WM_RBUTTONUP && wndPlace.showCmd == SW_SHOWMINIMIZED)
	{

		CMenu PopMenu;
		PopMenu.CreatePopupMenu();
	    PopMenu.AppendMenu(MF_STRING, IDM_RESTORE,  _T("�ָ�(&R)"));
	    PopMenu.AppendMenu(MF_STRING, IDOK,      _T("�ر�(&C)")); 
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			PopMenu.AppendMenu(MF_SEPARATOR);
			PopMenu.AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
		POINT pt; 
        GetCursorPos(&pt);   
		PopMenu.TrackPopupMenu(TPM_LEFTALIGN|TPM_RIGHTBUTTON, pt.x, pt.y, this); 
		//TRACE("%d,%d, %d\n",lParam, HIWORD(wParam), LOWORD(wParam));
	}
   
}
void CCalendarDlg::OnMyRestore()
{
	ShowWindow(SW_SHOW); 
	ShowWindow(SW_RESTORE);
	SetActiveWindow();
}

void CCalendarDlg::OnDestroy() 
{
	CDialog::OnDestroy();
    Shell_NotifyIcon(NIM_DELETE, &m_NotifyIconData);
	KillTimer(500);
}

void CCalendarDlg::OnTimer(UINT nIDEvent) 
{
	CDialog::OnTimer(nIDEvent);
	if(GetActiveWindow()!=this)
	   ShowWindow(SW_SHOWMINIMIZED);
}


