#if !defined(AFX_FINDMODULEDLG_H__6D7841EC_9D91_11D3_BFD7_0010E3B966CE__INCLUDED_)
#define AFX_FINDMODULEDLG_H__6D7841EC_9D91_11D3_BFD7_0010E3B966CE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FindModuleDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFindModuleDlg dialog

class CFindModuleDlg : public CDialog
{
// Construction
public:
	void SetDefaultFileName(LPCTSTR lpszFilePath);
	virtual BOOL OnInitDialog(void);
	CFindModuleDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFindModuleDlg)
	enum { IDD = IDD_FIND_MODULE_DIALOG };
	CString	m_szModuleName;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFindModuleDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	CString m_szInitialFileName;
	// Generated message map functions
	//{{AFX_MSG(CFindModuleDlg)
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnModuleFileBrowse();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FINDMODULEDLG_H__6D7841EC_9D91_11D3_BFD7_0010E3B966CE__INCLUDED_)
