// FindModuleDlg.cpp : implementation file
//

#include "stdafx.h"
#include "displayloadedmodules.h"
#include "FindModuleDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFindModuleDlg dialog


CFindModuleDlg::CFindModuleDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFindModuleDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFindModuleDlg)
	m_szModuleName = _T("");
	//}}AFX_DATA_INIT
}


void CFindModuleDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFindModuleDlg)
	DDX_Text(pDX, IDC_EDIT_MODULE_NAME, m_szModuleName);
	DDV_MaxChars(pDX, m_szModuleName, 256);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CFindModuleDlg, CDialog)
	//{{AFX_MSG_MAP(CFindModuleDlg)
	ON_BN_CLICKED(IDC_MODULE_FILE_BROWSE, OnModuleFileBrowse)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFindModuleDlg message handlers

void CFindModuleDlg::OnOK() 
{
	// TODO: Add extra validation here

    // Store filename for next call
    (GetDlgItem(IDC_EDIT_MODULE_NAME))->GetWindowText(m_szInitialFileName);
	
	CDialog::OnOK();
}

void CFindModuleDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	
	CDialog::OnCancel();
}

BOOL CFindModuleDlg::OnInitDialog()
{
    BOOL bReturnCode = CDialog::OnInitDialog();
    (GetDlgItem(IDC_EDIT_MODULE_NAME))->SetWindowText(m_szInitialFileName);
    (GetDlgItem(IDC_EDIT_MODULE_NAME))->SetFocus();

    return(FALSE); // FALSE because we set the focus
}

void CFindModuleDlg::OnModuleFileBrowse() 
{
    CFileDialog oFileDialog(TRUE, // Open...
							NULL, // default filename extension
							m_szInitialFileName, // initial filename
							OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST, // options
							"Executable Files (*.exe;*.dll;*.ocx)|*.exe; *.dll; *.ocx|All Files (*.*)|*.*||", // two filters for modules
							this);
    if ( oFileDialog.DoModal() == IDOK ) {
        CString szModuleName=oFileDialog.GetPathName();
        (GetDlgItem(IDC_EDIT_MODULE_NAME))->SetWindowText(szModuleName);
        SetDefaultFileName(szModuleName);
    }
}

void CFindModuleDlg::SetDefaultFileName(LPCTSTR lpszFilePath)
{
    m_szInitialFileName = lpszFilePath;
}
