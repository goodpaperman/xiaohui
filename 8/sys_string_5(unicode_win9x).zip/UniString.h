#ifndef __UNISTRING_H__
#define __UNISTRING_H__

//
// Kim, Sang-Yup Wrote:
//
// UniString.cpp : header file
//
// Written by Kim, Sang-Yup (atom@nwserver.human.co.kr)
// Copyright (c) 1998.
//
// This code may be used in compiled form in any way you desire. 
// This file may be redistributed unmodified by any means PROVIDING 
// it is not sold for profit without the authors written consent, 
// and providing that this notice and the authors name is included. 
// If the source code in this file is used in any commercial application 
// then a simple email would be nice. This file is provided "as is" 
// with no expressed or implied warranty. The author accepts 
// no liability if it causes any damage whatsoever. 
// It's free - so you get what you pay for.
//
// CUniString is modeled on class CString to manipulate UNICODE string. 
// If you want to do with UNICODE string in Window 95/98(not Window NT), 
// it can help you.
//
// Examples:
//
// CString sCString;			// CString variable
// CUniString sUniString;		// CUniString variable
//
// sUniString = sCString;		// CString to CUnistring
// sUniString("Test String");
// sUniString(sCString);
//
// sCString = sUniString;		// CUniString to CString
//
// sUniString.Mid(5);
// sUniString.Mid(5,2);
// sUniString.Left(5);
// sUniString.Right(5);

// And other Comparison functions
//


// CUniString class interface: support operations for UNI CODE strings
//
// ******************PUBLIC OPERATIONS*********************
// =							--> Usual assignment
// [ ]							--> Indexing with bounds check
// ==, !=, <, <=, >, >=			--> Usual relational and equality
// << and >>					--> Serialization
// unsigned int GetLength( )	--> Return strlen equivalent
// GetBuffer()					--> Get buffer pointer
// Mid(int nFirst)	
// Mid(int nFirst, int nCount)	--> Extracts a substring of length nCount 
//									characters from this CUniString object, 
//									starting at position nFirst (zero-based)
//									and return a copy of the extracted substring.
// Left(int nCount)				--> Extracts the first nCount characters from 
//									this CString object and returns ...
// Right(int nCount)			--> Extracts the last nCount characters from 
//									this CString object and returns ...


#include <iostream.h>
#include <string.h>

#define INIT_BUFFER_LEN 100

#define _UNISTRING

class CUniString
{
public:

#ifdef _DEBUG
	  CString m_pchDebugData;
#endif

    // Constructors
    CUniString( ) : m_pchData( NullString ), m_nBufferLen( -1 ) { }
    CUniString( const LPWSTR Value );
    CUniString( const LPCSTR Value );
    CUniString( const CUniString & Value );

    // Destructor
    ~CUniString( ) { if( m_nBufferLen != -1 ) delete [ ] m_pchData; }

    // CString like functions & methods
    int	 GetLength( ) const { return wcslen( m_pchData ); }
	BOOL IsEmpty() const;
	void Empty();                       // free up the data
    LPWSTR GetBuffer( int MaxStrLen );
	LPWSTR GetBufferSetLength(int nNewLength);

	CUniString Mid(int nFirst, int nCount) const;
	CUniString Mid(int nFirst) const;
	CUniString Left(int nCount) const;
	CUniString Right(int nCount) const;

    // Some operator
	
	// Assignment operator
    const CUniString & operator=( const CUniString & Rhs );
    const CUniString & operator=( LPWSTR Rhs );
	const CUniString & operator=( const CString & string );
	const CUniString & operator=( const LPCSTR Rhs );

	operator LPWSTR() const;           // as a C string

    const CUniString & operator=( const WCHAR Rhs );
    const CUniString & operator+=( const WCHAR Rhs );
	const CUniString & operator+=( const LPWSTR lpsz );
	const CUniString & operator+=( const CUniString& string );
	const CUniString & operator+=( const CString& string );

    WCHAR operator[ ]( int Index ) const;
    WCHAR & operator[ ]( int Index );

    // Friends for comparison
    friend int operator ==
        ( const CUniString & Lhs, const CUniString & Rhs );
    friend int operator !=
        ( const CUniString & Lhs, const CUniString & Rhs );
    friend int operator <
        ( const CUniString & Lhs, const CUniString & Rhs );
    friend int operator >
        ( const CUniString & Lhs, const CUniString & Rhs );
    friend int operator <=
        ( const CUniString & Lhs, const CUniString & Rhs );
    friend int operator >=
        ( const CUniString & Lhs, const CUniString & Rhs );

	// Friends for Serialization
	friend CUniString AFXAPI operator+(const CUniString& string1, const CUniString& string2);
	friend CArchive& AFXAPI operator<<(CArchive& ar, const CUniString& string);
	friend CArchive& AFXAPI operator>>(CArchive& ar, CUniString& string);

private:
    LPWSTR	m_pchData;			// Stores the chars
    int		m_nBufferLen;       // Max strlen for Buffer
    static	LPWSTR NullString;  // Member for uninitialized case
	void	Release();
	static int PASCAL SafeStrlen(const LPWSTR lpsz);

	// Initialization function
	void Init();
	void AllocBuffer(int nLen);
	void AllocCopy(CUniString& dest, int nCopyLen, int nCopyIndex, int nExtraLen) const;
	void ConcatCopy(int nSrc1Len, LPWSTR lpszSrc1Data,	int nSrc2Len, LPWSTR lpszSrc2Data);
	void ConcatInPlace(int nSrcLen, const LPWSTR lpszSrcData);
};


istream & operator>>( istream & In, CUniString & Value );


inline int
operator==( const CUniString & Lhs, const CUniString & Rhs )
{
    return wcscmp( Lhs.m_pchData, Rhs.m_pchData ) == 0;
}

inline int
operator!=( const CUniString & Lhs, const CUniString & Rhs )
{
    return wcscmp( Lhs.m_pchData, Rhs.m_pchData ) != 0;
}

inline int
operator<( const CUniString & Lhs, const CUniString & Rhs )
{
    return wcscmp( Lhs.m_pchData, Rhs.m_pchData ) < 0;
}

inline int
operator>( const CUniString & Lhs, const CUniString & Rhs )
{
    return wcscmp( Lhs.m_pchData, Rhs.m_pchData ) > 0;
}

inline int
operator<=( const CUniString & Lhs, const CUniString & Rhs )
{
    return wcscmp( Lhs.m_pchData, Rhs.m_pchData ) <= 0;
}

inline int
operator>=( const CUniString & Lhs, const CUniString & Rhs )
{
    return wcscmp( Lhs.m_pchData, Rhs.m_pchData ) >= 0;
}

#endif // __UNISTRING_H__
