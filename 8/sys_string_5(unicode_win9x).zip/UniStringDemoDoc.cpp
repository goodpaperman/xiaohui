// UniStringDemoDoc.cpp : implementation of the CUniStringDemoDoc class
//

#include "stdafx.h"
#include "UniStringDemo.h"

#include "UniStringDemoDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CUniStringDemoDoc

IMPLEMENT_DYNCREATE(CUniStringDemoDoc, CDocument)

BEGIN_MESSAGE_MAP(CUniStringDemoDoc, CDocument)
	//{{AFX_MSG_MAP(CUniStringDemoDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUniStringDemoDoc construction/destruction

CUniStringDemoDoc::CUniStringDemoDoc()
{
	// TODO: add one-time construction code here

}

CUniStringDemoDoc::~CUniStringDemoDoc()
{
}

BOOL CUniStringDemoDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CUniStringDemoDoc serialization

void CUniStringDemoDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CUniStringDemoDoc diagnostics

#ifdef _DEBUG
void CUniStringDemoDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CUniStringDemoDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CUniStringDemoDoc commands
