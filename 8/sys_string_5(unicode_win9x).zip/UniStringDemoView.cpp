// UniStringDemoView.cpp : implementation of the CUniStringDemoView class
//

#include "stdafx.h"
#include "UniStringDemo.h"

#include "UniStringDemoDoc.h"
#include "UniStringDemoView.h"

#include "UniString.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CUniStringDemoView

IMPLEMENT_DYNCREATE(CUniStringDemoView, CView)

BEGIN_MESSAGE_MAP(CUniStringDemoView, CView)
	//{{AFX_MSG_MAP(CUniStringDemoView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUniStringDemoView construction/destruction

CUniStringDemoView::CUniStringDemoView()
{
	// TODO: add construction code here

}

CUniStringDemoView::~CUniStringDemoView()
{
}

BOOL CUniStringDemoView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CUniStringDemoView drawing

void CUniStringDemoView::OnDraw(CDC* pDC)
{
	CUniStringDemoDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here

	CString sCString="Hello";			// CString variable
	CUniString sUniString, sUniTest;	// CUniString variable

	sUniString = sCString;				// CString to CUnistring
	sUniString = CUniString(sCString);
	sUniString = CUniString("01234567890123456789 Test String54321");

	sCString = sUniString;				// CUniString to CString

	sUniTest = sUniString;
	::TextOutW(pDC->m_hDC, 100, 100, sUniTest, sUniTest.GetLength());
	sUniTest = sUniString.Mid(5);
	::TextOutW(pDC->m_hDC, 100, 120, sUniTest, sUniTest.GetLength());
	sUniTest = sUniString.Mid(5,2);
	::TextOutW(pDC->m_hDC, 100, 140, sUniTest, sUniTest.GetLength());
	sUniTest = sUniString.Left(5);
	::TextOutW(pDC->m_hDC, 100, 160, sUniTest, sUniTest.GetLength());
	sUniTest = sUniString.Right(5);
	::TextOutW(pDC->m_hDC, 100, 180, sUniTest, sUniTest.GetLength());
}

/////////////////////////////////////////////////////////////////////////////
// CUniStringDemoView diagnostics

#ifdef _DEBUG
void CUniStringDemoView::AssertValid() const
{
	CView::AssertValid();
}

void CUniStringDemoView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CUniStringDemoDoc* CUniStringDemoView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CUniStringDemoDoc)));
	return (CUniStringDemoDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CUniStringDemoView message handlers
