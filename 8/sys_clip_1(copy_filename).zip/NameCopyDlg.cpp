// NameCopyDlg.cpp : implementation file
//

#include "stdafx.h"
#include "NameCopy.h"
#include "NameCopyDlg.h"
#include "resource.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNameCopyDlg dialog

CNameCopyDlg::CNameCopyDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CNameCopyDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CNameCopyDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_pRich = NULL;
	m_pPasteBtn = m_pCloseBtn = NULL;
}

void CNameCopyDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNameCopyDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CNameCopyDlg, CDialog)
	ON_WM_CONTEXTMENU()
	//{{AFX_MSG_MAP(CNameCopyDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BTN_PASTENAMES, OnBtnPasteNames)
	ON_NOTIFY(EN_DROPFILES, IDC_RICHEDIT, OnDropfilesRichedit)
	ON_COMMAND(ID_EDIT_CLEAR, OnEditClear)
	ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
	ON_COMMAND(ID_EDIT_CUT, OnEditCut)
	ON_COMMAND(ID_EDIT_PASTE, OnEditPaste)
	ON_COMMAND(ID_EDIT_PASTEFNAMES, OnEditPastefnames)
	ON_COMMAND(ID_EDIT_SELECTALL, OnEditSelectall)
	ON_COMMAND(ID_EDIT_UNDO, OnEditUndo)
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNameCopyDlg message handlers

BOOL CNameCopyDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	m_pRich = (CRichEditCtrl*)GetDlgItem(IDC_RICHEDIT);
	m_pPasteBtn = GetDlgItem(IDC_BTN_PASTENAMES);
	m_pCloseBtn = GetDlgItem(IDCANCEL);

	//Let the RichEdit accept the files which are dragged-&-dropped into it
	::DragAcceptFiles( m_pRich->m_hWnd, TRUE );

	//Let the richedit send the required notifications later
	m_pRich->SendMessage( EM_SETEVENTMASK, 0, (long)( ENM_DROPFILES | ENM_MOUSEEVENTS ));
	
	//Postion this dialog always on top, for easy usage.
	::SetWindowPos(m_hWnd, HWND_TOPMOST, 0,0,0,0, SWP_NOMOVE|SWP_NOSIZE);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CNameCopyDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CNameCopyDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

/*
	Don't let the default OK to do the unnecessary extra work. We simply close it.
*/
void CNameCopyDlg::OnOK() 
{
	CDialog::OnCancel();
}

/*
	Paste File Names button handler
*/
void CNameCopyDlg::OnBtnPasteNames() 
{
	COleDataObject odj;
	if( odj.AttachClipboard() )
	{
		if( odj.IsDataAvailable( CF_HDROP ) )
		{
			STGMEDIUM StgMed;
			FORMATETC fmte = { CF_HDROP,
        				(DVTARGETDEVICE FAR *)NULL,
        				DVASPECT_CONTENT,
        				-1,
        				TYMED_HGLOBAL };
			if( odj.GetData( CF_HDROP, &StgMed, &fmte ) )
			{
				HDROP hDrop = (HDROP)StgMed.hGlobal;
				CopyFileNames( hDrop );
				if (StgMed.pUnkForRelease)
				{
					StgMed.pUnkForRelease->Release();
				}
				else
				{
					::GlobalFree(StgMed.hGlobal);
				}
				return;
			}
		}
	}
	AfxMessageBox( "Please do one of the following:\n"
		"1.Select some files from explorer, copy them and then press 'Paste File Names' button\n  or\n"
		"2.Select some files from explorer, drag and drop them into the rich-edit control\n" );
}

/*
	This function, given a HDROP, queries, gets the file names,
	and pastes them into richedit control.
*/
void CNameCopyDlg::CopyFileNames( HDROP hDrop )
{
	UINT cFiles = ::DragQueryFile(hDrop, (UINT)-1, NULL, 0);				
	CString szText;
	szText.Format( "There are %d files/directories\r\n", cFiles );
	
	char szFile[MAX_PATH];
	
	for( UINT count = 0; count < cFiles; count++ )
	{
		::DragQueryFile(hDrop, count, szFile, sizeof(szFile));
		szText += szFile;
		szText += "\r\n";
	}
	m_pRich->ReplaceSel(szText);
}

/*
	ENM_DROPFILES notification handler
*/
void CNameCopyDlg::OnDropfilesRichedit(NMHDR* pNMHDR, LRESULT* pResult) 
{
	ENDROPFILES *pEnDropFiles = reinterpret_cast<ENDROPFILES *>(pNMHDR);
	// TODO: The control will not send this notification unless you override the
	// CDialog::OnInitDialog() function to send the EM_SETEVENTMASK message
	// to the control with the ENM_DROPFILES flag ORed into the lParam mask.
	
	CopyFileNames( (HDROP)pEnDropFiles->hDrop );
	*pResult = 0;
}

/*
	Use this code to display the popup menu only for rich-edit control.
*/
void CNameCopyDlg::OnContextMenu(CWnd*, CPoint point)
{
	// CG: This block was added by the Pop-up Menu component
	{
		CRect rect;
		m_pRich->GetWindowRect(rect);
		if( !rect.PtInRect(point) )
			return;

		CMenu menu;
		VERIFY(menu.LoadMenu(IDR_POP_RICH));

		CMenu* pPopup = menu.GetSubMenu(0);
		ASSERT(pPopup != NULL);
		CWnd* pWndPopupOwner = this;

		while (pWndPopupOwner->GetStyle() & WS_CHILD)
			pWndPopupOwner = pWndPopupOwner->GetParent();

		pPopup->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, point.x, point.y,
			pWndPopupOwner);
	}
}

/*
	Override the OnNotify to get the mouse-event of richedit, and post the WM_CONTEXTMENU yourself.
*/
BOOL CNameCopyDlg::OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult) 
{	
	if( wParam )
	{
		MSGFILTER* pMF = (MSGFILTER*)lParam;
		if( pMF -> msg == WM_RBUTTONDOWN )
		{
			if( pMF->nmhdr.hwndFrom == m_pRich->m_hWnd )
			{
				//Post this message sothat the 'cursor' also comes into the rich-edit control
				m_pRich -> PostMessage( WM_LBUTTONDOWN, MK_LBUTTON, pMF->lParam );

				CPoint pt( LOWORD(pMF->lParam), HIWORD(pMF->lParam) );
				m_pRich->ClientToScreen(&pt);
				PostMessage( WM_CONTEXTMENU, (WPARAM)pMF->nmhdr.hwndFrom, MAKELONG( pt.x, pt.y ) );
			}
		}
	}	
	return CDialog::OnNotify(wParam, lParam, pResult);
}


/*
	Popup menu handlers
*/
void CNameCopyDlg::OnEditClear() 
{
	m_pRich->ReplaceSel("", TRUE);	
}

void CNameCopyDlg::OnEditCopy() 
{
	m_pRich->Copy();
}

void CNameCopyDlg::OnEditCut() 
{
	m_pRich->Cut();
}

void CNameCopyDlg::OnEditPaste() 
{
	m_pRich->Paste();
}

void CNameCopyDlg::OnEditPastefnames() 
{
	PostMessage(WM_COMMAND, MAKELONG(IDC_BTN_PASTENAMES, BN_CLICKED), (LPARAM)(GetDlgItem(IDC_BTN_PASTENAMES)->m_hWnd));
}

void CNameCopyDlg::OnEditSelectall() 
{
	m_pRich->SetSel(0, -1);
}

void CNameCopyDlg::OnEditUndo() 
{
	m_pRich->Undo();	
}

/*
	Allow resizing of the dialog, to enable the user to view more
*/
void CNameCopyDlg::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
	
	if( m_pRich && m_pCloseBtn && m_pPasteBtn )
	{
		CRect rectC, rectP, rectD, rectR;
		GetClientRect( rectD );
		m_pPasteBtn->GetClientRect( rectP );
		m_pCloseBtn->GetClientRect( rectC );

		if( (rectD.Width() > (rectC.Width()+rectP.Width()+10)) && 
			(rectD.Height() > (rectC.Height()+rectP.Height()+10)) )
		{
			//use around 2 pixels for separation between boundarie
			int nH = rectP.Height();
			rectP.top = rectD.bottom - nH - 2;
			rectP.bottom = rectD.bottom - 2;
			rectP.left = 2;
			rectP.right += 2;
			m_pPasteBtn->MoveWindow( rectP );

			int nW = rectC.Width();
			rectC.top = rectP.top;
			rectC.bottom = rectP.bottom;
			rectC.left = rectD.right - nW - 2;
			rectC.right = rectD.right - 2;
			m_pCloseBtn->MoveWindow( rectC );

			rectR.top = rectD.top + 2;
			rectR.bottom = rectD.bottom - nH - 4;
			rectP.left = 2;
			rectP.right = rectD.right - 2;
			m_pRich->MoveWindow( rectR );			
		}
	}
}
