// NameCopyDlg.h : header file
//

#if !defined(AFX_NAMECOPYDLG_H__748FBA3D_A4BD_11D2_981B_006008A2106F__INCLUDED_)
#define AFX_NAMECOPYDLG_H__748FBA3D_A4BD_11D2_981B_006008A2106F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CNameCopyDlg dialog

class CNameCopyDlg : public CDialog
{
// Construction
public:
	CNameCopyDlg(CWnd* pParent = NULL);	// standard constructor
	CRichEditCtrl* m_pRich;
	CWnd *m_pPasteBtn, *m_pCloseBtn;

	void CopyFileNames( HDROP hDrop );

// Dialog Data
	//{{AFX_DATA(CNameCopyDlg)
	enum { IDD = IDD_NAMECOPY_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNameCopyDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	virtual BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult);
	//}}AFX_VIRTUAL

// Implementation
protected:
	afx_msg void OnContextMenu(CWnd*, CPoint point);
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CNameCopyDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();
	afx_msg void OnBtnPasteNames();
	afx_msg void OnDropfilesRichedit(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnEditClear();
	afx_msg void OnEditCopy();
	afx_msg void OnEditCut();
	afx_msg void OnEditPaste();
	afx_msg void OnEditPastefnames();
	afx_msg void OnEditSelectall();
	afx_msg void OnEditUndo();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NAMECOPYDLG_H__748FBA3D_A4BD_11D2_981B_006008A2106F__INCLUDED_)
