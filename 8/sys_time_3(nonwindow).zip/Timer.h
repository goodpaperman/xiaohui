
#if !defined(AFX_UTILIT_H__C2AF2763_C421_11D3_A828_0040C72D0A06__INCLUDED_)
#define AFX_UTILIT_H__C2AF2763_C421_11D3_A828_0040C72D0A06__INCLUDED_

#include "resource.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000



/***********************************************************************
 *	CTimerSupport class
 ***********************************************************************
 */
class CTimerSupport  
{
public:
	CTimerSupport();
	virtual ~CTimerSupport();

	virtual void OnTimer (UINT nTimerID){};

protected:
	UINT SetTimer(UINT nTimerEvent, UINT nElapse);
	BOOL KillTimer(UINT nTimerID);
	UINT GetTimerEvent (UINT nTimerID) 
	{
		return ((STimerInfo *)nTimerID)->uiEvent;
	}
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_UTILIT_H__C2AF2763_C421_11D3_A828_0040C72D0A06__INCLUDED_)

/* Dear compiler, no more source code */
