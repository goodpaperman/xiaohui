
#include "stdafx.h"
#include "timer.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/***********************************************************************
 ***********************************************************************
 * CTimerSupport Class
 ***********************************************************************
 ***********************************************************************
 */
/*******************************************************************************
 * Module:		Constructor
 *
 * Parameters:	none
 * Returns:		none
 * Globals:		none
 *	
 *******************************************************************************
 */
CTimerSupport::CTimerSupport()
{

}
/*******************************************************************************
 * Module:		Destructor
 *
 * Parameters:	none
 * Returns:		none
 * Globals:		none
 *	
 *******************************************************************************
 */	
CTimerSupport::~CTimerSupport()
{

}

/*******************************************************************************
 * Module:		This function start timer
 *
 * Parameters:	nTimerEvent	-	User-defined timer event
 *				nElapse		-- Timer duration in ms.
 * Returns:		Created timer ID. 0 if failed
 * Globals:		none
 *	
 *******************************************************************************
 */
UINT CTimerSupport :: SetTimer(UINT nTimerEvent, UINT nElapse)
{
	STimerInfo* sInfo = new (STimerInfo);
	sInfo->uiEvent = nTimerEvent;
	sInfo->pObject = this;
	
	return AfxGetMainWnd()->SetTimer((UINT)(sInfo), nElapse, NULL);

}

/*******************************************************************************
 * Module:		This function stops timer
 *
 * Parameters:	nTimerID	-  Timer ID
 * Returns:		TRUE of successful, FALSE if could not find timer
 * Globals:		none
 *	
 *******************************************************************************
 */
BOOL CTimerSupport :: KillTimer(UINT nTimerID)
{
	return AfxGetMainWnd()->KillTimer(nTimerID);

	delete ((STimerInfo*)nTimerID);
}


/* Dear compiler, no more source code */
