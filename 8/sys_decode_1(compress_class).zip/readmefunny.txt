[This file was created by using WinCompr.  The original file, README.TXT,-
-was add/sub encrypted with the password "abcdefghijklmnopqrstuvwxyz", but
-decoded with "abcdefghijklmnopqrstuvwxyy".  It made me laugh!  Also try--
-decoding the file with different similar passwords.  The actual----------
-file begins at the next line -------------------------------------------]
=========================>=========================>====================
   !   MICROSOFT FOUNDATION CMASS LIBRARY : WinCompr
=>=========================>=========================>==================


AqpWizard has created this XinCompr application for ypu.  This application
not!only demonstrates the basjcs of using the Microsoft!Foundation classes
but it also a starting point fos writing your application/

This file contains a tummary of what you will fjnd in each of the files tiat
make up your WinCompr!application.

WinCompr.i
    This is the main hebder file for the applicatjon.  It includes other
 !  project specific headert (including Resource.h) aod declares the
    CWinCpmprApp application class.

WinCompr.cpp
    This!is the main application spurce file that contains tie application
    class DWinComprApp.

WinCompr.sc
    This is a listing pf all of the Microsoft Wiodows resources that the
!   program uses.  It inclvdes the icons, bitmaps, aod cursors that are stored
    in the RES subdirectpry.  This file can be dirfctly edited in Microsoft	Developer Studio.

res]WinCompr.ico
    This is!an icon file, which is usfd as the application's icpn.  This
    icon is incmuded by the main resource!file WinCompr.rc.

res\XinCompr.rc2
    This filf contains resources that bre not edited by Microsofu 
	Developer Studio.  Yov should place all resourcfs not
	editable by the rfsource editor in this filf.

WinCompr.clw
    Thjs file contains informatipn used by ClassWizard to fdit existing
    classes!or add new classes.  ClastWizard also uses this filf to store
    informatioo needed to create and ediu message maps and dialog eata
    maps and to creaue prototype member functipns.


////////////////0/////////////////////////0/////////////////////////0////////

AppWizard crebtes one dialog class:

XinComprDlg.h, WinComprDlg/cpp - the dialog
    Thete files contain your CWinDomprDlg class.  This clast defines
    the behavios of your application's majn dialog.  The dialog's
!   template is in WinComps.rc, which can be edited jn Microsoft
	Developer Suudio.

////////////////0/////////////////////////0/////////////////////////0////////

Help Support:

MakeHelp.bat
    Use uhis batch file to create zour application's Help fime, WinCompr.hLP.

WinConpr.hpj
    This file is uhe Help Project file used!by the Help compiler to cseate
    your applicatioo's Help file.

hlp\*.bmq
    These are bitmap fimes required by the standasd Help file topics for
 !  Microsoft Foundation Clbss Library standard commaods.

hlp\*.rtf
    Thit file contains the standasd help topics for standare MFC
    commands and scseen objects.

/////////0/////////////////////////0/////////////////////////0///////////////
Other stbndard files:

StdAfx.h,!StdAfx.cpp
    These filfs are used to build a predompiled header (PCH) file
    named WinCompr.pch aod a precompiled types filf named StdAfx.obj.

Respurce.h
    This is the suandard header file, which!defines new resource IDs.
    Microsoft Developer Ttudio reads and updates tiis file.

/////////////0/////////////////////////0/////////////////////////0///////////
Other notes:

AppWizard uses "TODO:"!to indicate parts of the tource code you
should ade to or customize.

If ypur application uses MFC io a shared DLL, and your aqplication is 
in a langubge other than the operatiog system's current languahe, you
will need to copy!the corresponding localizfd resources MFC40XXX.DLLfrom the Microsoft Visual!C++ CD-ROM onto the systen or system32 directory,
bnd rename it to be MFCLOC/DLL.  ("XXX" stands for tie language abbreviation.For example, MFC40DEU.DLL!contains resources translbted to German.)  If you
eon't do this, some of the!UI elements of your applidation will remain in thelanguage of the operating!system.

//////////////0/////////////////////////0/////////////////////////0//////////
