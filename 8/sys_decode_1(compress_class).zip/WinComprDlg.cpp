// WinComprDlg.cpp : implementation file
//

#include "stdafx.h"
#include "WinCompr.h"
#include "WinComprDlg.h"
#define EXPORTING
#include "../comprlib.h"
#include "wcio.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWinComprDlg dialog

CWinComprDlg::CWinComprDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CWinComprDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CWinComprDlg)
	m_strInput = _T("");
	m_strOutput = _T("");
	m_strPassword = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CWinComprDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWinComprDlg)
	DDX_Control(pDX, IDC_RATIO, m_wndRatio);
	DDX_Control(pDX, IDC_STATUS, m_wndStatus);
	DDX_Control(pDX, IDC_PROGRESS, m_wndProgress);
	DDX_Control(pDX, IDC_READ, m_wndRead);
	DDX_Control(pDX, IDC_WRITTEN, m_wndWritten);
	DDX_Control(pDX, IDC_METHOD, m_wndMethod);
	DDX_Text(pDX, IDC_INPUT, m_strInput);
	DDX_Text(pDX, IDC_OUTPUT, m_strOutput);
	DDX_Text(pDX, IDC_PASSWORD, m_strPassword);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CWinComprDlg, CDialog)
	//{{AFX_MSG_MAP(CWinComprDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_DESTROY()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_INPUT_BROWSE, OnInputBrowse)
	ON_BN_CLICKED(IDC_OUTPUT_BROWSE, OnOutputBrowse)
	ON_CBN_SELCHANGE(IDC_METHOD, OnSelchangeMethod)
	ON_BN_CLICKED(IDC_PASSWORD_BROWSE, OnPasswordBrowse)
	ON_BN_CLICKED(IDC_ENCODE, OnEncode)
	ON_BN_CLICKED(IDC_DECODE, OnDecode)
	ON_WM_DROPFILES()
	ON_EN_CHANGE(IDC_INPUT, OnChangeInput)
	ON_EN_CHANGE(IDC_OUTPUT, OnChangeOutput)
	ON_MESSAGE(WM_SETSTATUS, OnSetStatus)
	ON_EN_CHANGE(IDC_PASSWORD, OnChangePassword)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWinComprDlg message handlers

BOOL CWinComprDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	CString strAboutMenu;
	strAboutMenu.LoadString(IDS_ABOUTBOX);
	if (!strAboutMenu.IsEmpty())
	{
		pSysMenu->AppendMenu(MF_SEPARATOR);
		pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	m_wndMethod.SetCurSel(6);
	
	// TODO: Add extra initialization here
	
	// CG: The following block was added by the ToolTips component.
	{
		// Create the ToolTip control.
		m_tooltip.Create(this);
		m_tooltip.Activate(TRUE);

		m_tooltip.AddTool(GetDlgItem(IDC_INPUT), IDC_INPUT);
		m_tooltip.AddTool(GetDlgItem(IDC_OUTPUT), IDC_OUTPUT);
		m_tooltip.AddTool(GetDlgItem(IDC_INPUT_BROWSE), IDC_INPUT_BROWSE);
		m_tooltip.AddTool(GetDlgItem(IDC_OUTPUT_BROWSE),IDC_OUTPUT_BROWSE);
		m_tooltip.AddTool(GetDlgItem(IDC_METHOD), IDC_METHOD);
		m_tooltip.AddTool(GetDlgItem(IDC_PASSWORD), IDC_PASSWORD);
		m_tooltip.AddTool(GetDlgItem(IDC_PASSWORD_BROWSE), IDC_PASSWORD_BROWSE);
		m_tooltip.AddTool(GetDlgItem(IDC_STATUS), IDC_STATUS);
		m_tooltip.AddTool(GetDlgItem(IDC_READ), IDC_READ);
		m_tooltip.AddTool(GetDlgItem(IDC_WRITTEN), IDC_WRITTEN);
		m_tooltip.AddTool(GetDlgItem(IDC_PROGRESS), IDC_PROGRESS);
		m_tooltip.AddTool(GetDlgItem(IDOK), IDOK);
		m_tooltip.AddTool(GetDlgItem(IDC_ENCODE), IDC_ENCODE);
		m_tooltip.AddTool(GetDlgItem(IDC_DECODE), IDC_DECODE);
		m_tooltip.AddTool(GetDlgItem(ID_HELP), ID_HELP);

		// TODO: Use one of the following forms to add controls:
		// m_tooltip.AddTool(GetDlgItem(IDC_<name>), <string-table-id>);
		// m_tooltip.AddTool(GetDlgItem(IDC_<name>), "<text>");
	}
	GetDlgItem(IDC_PASSWORD)->EnableWindow(FALSE);
	GetDlgItem(IDC_PASSWORD_BROWSE)->EnableWindow(FALSE);
	GetDlgItem(IDC_ENCODE)->EnableWindow(FALSE);
	GetDlgItem(IDC_DECODE)->EnableWindow(FALSE);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CWinComprDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

void CWinComprDlg::OnDestroy()
{
	WinHelp(0L, HELP_QUIT);
	CDialog::OnDestroy();
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CWinComprDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CWinComprDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CWinComprDlg::OnInputBrowse() 
{
	CFileDialog dlg(TRUE);

	if (dlg.DoModal() != IDOK)
		return;

	m_strInput = dlg.GetPathName();

	UpdateData(FALSE);
}

void CWinComprDlg::OnOutputBrowse() 
{
	CFileDialog dlg(FALSE);

	if (dlg.DoModal() != IDOK)
		return;

	m_strOutput = dlg.GetPathName();

	UpdateData(FALSE);
}

void CWinComprDlg::OnSelchangeMethod() 
{
	CString str;

	// Get selection text
	m_wndMethod.GetLBText(m_wndMethod.GetCurSel(), str);
	
	// Enable the Encode and Decode buttons if this is a method, but if
	// it's a catagory disable them.
	GetDlgItem(IDC_ENCODE)->EnableWindow(str[0] != '-');
	GetDlgItem(IDC_DECODE)->EnableWindow(str[0] != '-');

	// If the selected algorithm is Add/Sub Encryption or XOR Encryption
	// (they require passwords) enable the password controls.
	GetDlgItem(IDC_PASSWORD)->
		EnableWindow(str == "Add/Sub" || str == "XOR");
	GetDlgItem(IDC_PASSWORD_BROWSE)->
		EnableWindow(str == "Add/Sub" || str == "XOR");
}

// Browse for a password file
void CWinComprDlg::OnPasswordBrowse() 
{
	CFileDialog dlg(TRUE, NULL, NULL,
		OFN_HIDEREADONLY, _T("Password Files (*.PW)|*.PW|"));
	CStdioFile file;
	DWORD filelen;
	TCHAR* buf;
	CString str;
	int i;

	if (dlg.DoModal() != IDOK)
		return;

	// Read the whole file as the password
	file.Open(dlg.GetPathName(), CFile::modeRead);

	// Find out how long the file is
	file.SeekToEnd();
	filelen = file.GetPosition();
	file.SeekToBegin();
	
	// And read the whole thing
	buf = new char[filelen];
	file.Read(buf, filelen);
	file.Close();

	// Convert the buffer to a CString object
	for (i = 0; i < (int)filelen; i++)
	{
		str += buf[i];
	}
	delete[] buf;

	m_strPassword = str;
	UpdateData(FALSE);
}

// A struct that contains all the data needed to encode or decode
typedef struct tagTHREADINFO
{
	TCHAR* m_szInput;              // Source file
	TCHAR* m_szOutput;             // Desination file
	CStatic* m_wndRead;            // Bytes read static
	CStatic* m_wndWritten;         // Bytes wrote static
	UINT m_cursel;                 // Method selection
	TCHAR* m_szPassword;           // Password for encryption/decryption
	CProgressCtrl* m_wndProgress;  // Progress control
	CStatic* m_wndStatus;          // Status static control
} THREADINFO, *LPTHREADINFO;

// Thread function to encode the file
UINT Encode(LPVOID pParam)
{
	LPTHREADINFO info = (LPTHREADINFO)pParam;
	CString strStatus;

	CWinComprIO::Set();

	CWinComprIO::m_source = fopen(info->m_szInput, "rb");
	CWinComprIO::m_dest = fopen(info->m_szOutput, "wb");
	CWinComprIO::m_wndRead = info->m_wndRead;
	CWinComprIO::m_wndWritten = info->m_wndWritten;
	CWinComprIO::m_wndProgress = info->m_wndProgress;

	if (!CWinComprIO::m_source || !CWinComprIO::m_dest)
	{
		AfxMessageBox(IDS_CANTOPENFILES);
		CWinComprIO::m_lRead = CWinComprIO::m_lWritten = 0;
		delete info;
		return 0;
	}

	// Set the progress bar range from 0 to the size of the input file
	info->m_wndProgress->SetRange(0, CWinComprIO::stream_size());

	// Encode the file using the selected method
	switch (info->m_cursel)
	{
	case 0: break;
	case 1: arithmetic_encode(); break;
	case 2: dmc_encode(); break;
	case 3: huffman_encode(); break;
	case 4: lzari_encode(); break;
	case 5: lzhuf_encode(); break;
	case 6: lzss_encode(); break;
	case 7: lzw_encode(); break;
	case 8: rle1_encode(); break;
	case 9: rle2_encode(); break;
	case 10: break; //splay_encode(); break;
	case 11: break;
	case 12: addsub_encode(info->m_szPassword); break;
	case 13: invert_encode(); break;
	case 14: addsub_encode(info->m_szPassword); break;
	case 15: break;
	case 16: hex_encode(); break;
	case 17: nb_encode(); break;
	case 18: uu_encode(); break;
	case 19: xx_encode(); break;
	}

	fclose(CWinComprIO::m_source);
	fclose(CWinComprIO::m_dest);

	delete info;

	// Reset read/written byte count
	CWinComprIO::m_lRead = CWinComprIO::m_lWritten = 0;

	AfxGetMainWnd()->SendMessage(WM_SETSTATUS, IDS_STATUS_IDLE);
	AfxGetMainWnd()->KillTimer(2);

	return 0;
}

void CWinComprDlg::OnEncode()
{
	LPTHREADINFO info;
	TCHAR* szInput;
	TCHAR* szOutput;
	TCHAR* szPassword;
	CString strStatus;

	info = new THREADINFO;

	UpdateData();

	szInput = m_strInput.GetBuffer(MAX_PATH);
	szOutput = m_strOutput.GetBuffer(MAX_PATH);
	szPassword = m_strPassword.GetBuffer(MAX_PATH);

	// Fill in the info fields
	info->m_szInput = szInput;
	info->m_szOutput = szOutput;
	info->m_wndRead = &m_wndRead;
	info->m_wndWritten = &m_wndWritten;
	info->m_cursel = m_wndMethod.GetCurSel();
	info->m_szPassword = szPassword;
	info->m_wndProgress = &m_wndProgress;
	info->m_wndStatus = &m_wndStatus;

	AfxGetMainWnd()->SendMessage(WM_SETSTATUS, IDS_STATUS_ENCODING);
	AfxGetMainWnd()->SetTimer(2, 1000, NULL);

	// Encode it!
	AfxBeginThread(Encode, info);
}

// Thread function to decode the file
UINT Decode(LPVOID pParam)
{
	LPTHREADINFO info = (LPTHREADINFO)pParam;
	CString strStatus;

	CWinComprIO::Set();

	CWinComprIO::m_source = fopen(info->m_szInput, "rb");
	CWinComprIO::m_dest = fopen(info->m_szOutput, "wb");
	CWinComprIO::m_wndRead = info->m_wndRead;
	CWinComprIO::m_wndWritten = info->m_wndWritten;
	CWinComprIO::m_wndProgress = info->m_wndProgress;

	if (!CWinComprIO::m_source || !CWinComprIO::m_dest)
	{
		AfxMessageBox(IDS_CANTOPENFILES);
		delete info;
		return 0;
	}

	// Set the progress bar range from 0 to the size of the input file
	info->m_wndProgress->SetRange(0, CWinComprIO::stream_size());

	// Encode the file using the selected method
	switch (info->m_cursel)
	{
	case 0: break;
	case 1: arithmetic_decode(); break;
	case 2: dmc_decode(); break;
	case 3: break; //huffman_decode(); break;
	case 4: lzari_decode(); break;
	case 5: lzhuf_decode(); break;
	case 6: lzss_decode(); break;
	case 7: break; //lzw_decode(); break;
	case 8: rle1_decode(); break;
	case 9: rle2_decode(); break;
	case 10: break; //splay_encode(); break;
	case 11: break;
	case 12: addsub_decode(info->m_szPassword); break;
	case 13: invert_decode(); break;
	case 14: addsub_decode(info->m_szPassword); break;
	case 15: break;
	case 16: hex_decode(); break;
	case 17: nb_decode(); break;
	case 18: uu_decode(); break;
	case 19: xx_decode(); break;
	}

	fclose(CWinComprIO::m_source);
	fclose(CWinComprIO::m_dest);

	delete info;

	// Reset the read/written byte counts
	CWinComprIO::m_lRead = CWinComprIO::m_lWritten = 0;

	AfxGetMainWnd()->SendMessage(WM_SETSTATUS, IDS_STATUS_IDLE);
	AfxGetMainWnd()->KillTimer(2);

	return 0;
}

// Indicates that the status should be set
LRESULT CWinComprDlg::OnSetStatus(WPARAM wParam, LPARAM lParam)
{
	CString str;

	str.LoadString(wParam);

	m_wndStatus.SetWindowText(str);

	return wParam;
}

void CWinComprDlg::OnDecode() 
{
	LPTHREADINFO info;
	TCHAR* szInput;
	TCHAR* szOutput;
	TCHAR* szPassword;
	CString strStatus;

	info = new THREADINFO;

	UpdateData();

	szInput = m_strInput.GetBuffer(MAX_PATH);
	szOutput = m_strOutput.GetBuffer(MAX_PATH);
	szPassword = m_strPassword.GetBuffer(MAX_PATH);

	info->m_szInput = szInput;
	info->m_szOutput = szOutput;
	info->m_wndRead = &m_wndRead;
	info->m_wndWritten = &m_wndWritten;
	info->m_cursel = m_wndMethod.GetCurSel();
	info->m_szPassword = szPassword;
	info->m_wndProgress = &m_wndProgress;
	info->m_wndStatus = &m_wndStatus;

	AfxGetMainWnd()->SendMessage(WM_SETSTATUS, IDS_STATUS_DECODING);
	AfxGetMainWnd()->SetTimer(2, 1000, NULL);

	// Decode it!
	AfxBeginThread(Decode, info);
}

// We only include WinNetwk.h because ShlObj.h complains about NETRESOURCE!
#include <winnetwk.h>
#include <shlobj.h>

// Welcome to the most kludgy function in the program!
void CWinComprDlg::OnDropFiles(HDROP hDropInfo) 
{
	LPDROPFILES info;
	TCHAR* ptr;
	int x, y;

	info = (LPDROPFILES)hDropInfo;
	CString str;

	x = info->pt.x;
	y = info->pt.y;

	// Now THIS is how you get the dropped filename!
	ptr = (char*)info;
	ptr = &*ptr;
	ptr += 20;

	// Yes it's hard-coded in
	if (x >= 70 && y >= 20 && x <= 240 && y <= 39)   // Source file
	{
		m_strInput = ptr;
		UpdateData(FALSE);
	} else if (x >= 70 && y >= 44 && x <= 240 && y < 60) { // Dest file
		m_strOutput = ptr;
		UpdateData(FALSE);
	} else {
		AfxMessageBox(IDS_INVALID_DROP);
	}
	
	OnChangeInput();
	OnChangeOutput();

	CDialog::OnDropFiles(hDropInfo);
}

void CWinComprDlg::OnChangeInput() 
{
	UpdateData();
	
	// Disable window if empty, else enable
	GetDlgItem(IDC_ENCODE)->
		EnableWindow(!m_strInput.IsEmpty() && !m_strOutput.IsEmpty());
	GetDlgItem(IDC_DECODE)->
		EnableWindow(!m_strInput.IsEmpty() && !m_strOutput.IsEmpty());
}

void CWinComprDlg::OnChangeOutput() 
{
	UpdateData();

	// Disable Encode/Decode if control is empty
	GetDlgItem(IDC_ENCODE)->
		EnableWindow(!m_strOutput.IsEmpty() && !m_strInput.IsEmpty());
	GetDlgItem(IDC_DECODE)->
		EnableWindow(!m_strOutput.IsEmpty() && !m_strInput.IsEmpty());
}

BOOL CWinComprDlg::PreTranslateMessage(MSG* pMsg)
{
	// CG: The following block was added by the ToolTips component.
	{
		// Let the ToolTip process this message.
		m_tooltip.RelayEvent(pMsg);

		return CDialog::PreTranslateMessage(pMsg);
	}
}

void CWinComprDlg::OnChangePassword() 
{
	if (GetDlgItem(IDC_PASSWORD)->IsWindowEnabled())
	{
		// Password required
		UpdateData();
		GetDlgItem(IDC_ENCODE)->EnableWindow(!m_strPassword.IsEmpty());
		GetDlgItem(IDC_DECODE)->EnableWindow(!m_strPassword.IsEmpty());
	}	
}

void CWinComprDlg::OnTimer(UINT nIDEvent) 
{
	CDialog::OnTimer(nIDEvent);

	CString strIdle, str, strWritten, strRead;
	register float percent;
	int written, read;

	strIdle.LoadString(IDS_STATUS_IDLE);
	if (strIdle == str)
		return;    // Not doing anything, no need to calculate ratios
	GetDlgItem(IDC_WRITTEN)->GetWindowText(str);
	_stscanf(str, "%d", &written);
	GetDlgItem(IDC_READ)->GetWindowText(str);
	_stscanf(str, "%d", &read);

	if (!read || !written)
		return;   // zero
	// Update the ratio
	percent = //100 -
		((float)(stream_size() - written) / (float)(stream_size())) * 100;
	str.Format("%g%%", percent);
	m_wndRatio.SetWindowText(str);
}
