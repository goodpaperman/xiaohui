// WinComprDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CWinComprDlg dialog

class CWinComprDlg : public CDialog
{
// Construction
public:
	CWinComprDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CWinComprDlg)
	enum { IDD = IDD_WINCOMPR_DIALOG };
	CStatic	m_wndRatio;
	CStatic	m_wndStatus;
	CProgressCtrl	m_wndProgress;
	CStatic	m_wndRead;
	CStatic	m_wndWritten;
	CComboBox	m_wndMethod;
	CString	m_strInput;
	CString	m_strOutput;
	CString	m_strPassword;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWinComprDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CToolTipCtrl m_tooltip;
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CWinComprDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnDestroy();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnInputBrowse();
	afx_msg void OnOutputBrowse();
	afx_msg void OnSelchangeMethod();
	afx_msg void OnPasswordBrowse();
	afx_msg void OnEncode();
	afx_msg void OnDecode();
	afx_msg void OnDropFiles(HDROP hDropInfo);
	afx_msg void OnChangeInput();
	afx_msg void OnChangeOutput();
	afx_msg LRESULT OnSetStatus(WPARAM wParam, LPARAM lParam);
	afx_msg void OnChangePassword();
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
