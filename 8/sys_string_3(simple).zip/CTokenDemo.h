// CTokenDemo.h : main header file for the CTOKENDEMO application
//

#if !defined(AFX_CTOKENDEMO_H__7CEAEBF6_D15D_11D2_9CA9_444553540000__INCLUDED_)
#define AFX_CTOKENDEMO_H__7CEAEBF6_D15D_11D2_9CA9_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CCTokenDemoApp:
// See CTokenDemo.cpp for the implementation of this class
//

class CCTokenDemoApp : public CWinApp
{
public:
	CCTokenDemoApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCTokenDemoApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CCTokenDemoApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CTOKENDEMO_H__7CEAEBF6_D15D_11D2_9CA9_444553540000__INCLUDED_)
