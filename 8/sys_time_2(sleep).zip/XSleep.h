#ifndef _XSLEEP_H_
#define _XSLEEP_H_

void XSleep(int nWaitInMSecs);

#endif // _XSLEEP_H_
