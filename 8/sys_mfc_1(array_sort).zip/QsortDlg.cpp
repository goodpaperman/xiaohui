// QsortDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Qsort.h"
#include "QsortDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

typedef struct {
	int index;
	float fSomeFloat;
	TCHAR SomeString[128];
} UserType;

BOOL operator > (UserType & first, UserType & second)
{
	return (first.index > second.index);
}

BOOL operator < (UserType & first, UserType & second)
{
	return (first.index < second.index);
}

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CQsortDlg dialog

CQsortDlg::CQsortDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CQsortDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CQsortDlg)
	m_uiArrSize = 1000000;
	m_bAscending = TRUE;
	m_CsCQArrayTime = _T("");
	m_CsQsortTime = _T("");
	m_CsQuickSortTime = _T("");
	m_iType = 0;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CQsortDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CQsortDlg)
	DDX_Text(pDX, IDC_ARRAYSIZE, m_uiArrSize);
	DDV_MinMaxUInt(pDX, m_uiArrSize, 1, 10000000);
	DDX_Check(pDX, IDC_ASCENDING, m_bAscending);
	DDX_Text(pDX, IDC_CQARRAYTIME, m_CsCQArrayTime);
	DDX_Text(pDX, IDC_QSORTTIME, m_CsQsortTime);
	DDX_Text(pDX, IDC_QUICKSORTTIME, m_CsQuickSortTime);
	DDX_Radio(pDX, IDC_TYPE, m_iType);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CQsortDlg, CDialog)
	//{{AFX_MSG_MAP(CQsortDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_CQARRAY, OnStartCQArray)
	ON_BN_CLICKED(IDC_STARTQUICKSORT, OnStartQuickSort)
	ON_BN_CLICKED(IDC_QSORT, OnStartQsort)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CQsortDlg message handlers

BOOL CQsortDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CQsortDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CQsortDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CQsortDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CQsortDlg::OnStartCQArray() 
{
	CWaitCursor cwaitcursor;
	UpdateData(TRUE);
	CTime start, end;
	CTimeSpan tot;

	if (m_iType == 0) {
		CQArray <int, int &> qArr;

		qArr.SetSize(m_uiArrSize);

		srand(1);

		for (UINT i = 0; i < m_uiArrSize; i++) {
			qArr[i] = rand();
		}
#ifdef _DEBUG
		TRACE(_T("Not sorted:\n"));
		for (i = 0; i < m_uiArrSize; i++) {
			TRACE(_T("%d "),qArr[i]);
		}
		TRACE(_T("\n"));
#endif
		start = CTime::GetCurrentTime();
		qArr.QuickSort(m_bAscending);
		end = CTime::GetCurrentTime();
		tot = end - start;
#ifdef _DEBUG
		TRACE(_T("Sorted:\n"));
		for (i = 0; i < m_uiArrSize; i++) {
			TRACE(_T("%d "),qArr[i]);
		}
		TRACE(_T("\n"));
#endif
	} else {
		CQArray <UserType, UserType &> qArr;

		qArr.SetSize(m_uiArrSize);

		srand(1);

		for (UINT i = 0; i < m_uiArrSize; i++) {
			UserType data;

			data.index = rand(); 
			data.fSomeFloat = (float)data.index;
			_stprintf(data.SomeString,_T("%d"),data.index);

			qArr[i] = data;
		}

		start = CTime::GetCurrentTime();
		qArr.QuickSort(m_bAscending);
		end = CTime::GetCurrentTime();
		tot = end - start;
	}

	m_CsCQArrayTime.Format(_T("%d s"),tot.GetTotalSeconds());

	UpdateData(FALSE);	
}

void CQsortDlg::OnStartQuickSort() 
{
	CWaitCursor cwaitcursor;
	UpdateData(TRUE);
	CTime start, end;
	CTimeSpan tot;

	if (m_iType == 0) {
		int *dataArray = new int[m_uiArrSize];

		srand(1);

		for (UINT i = 0; i < m_uiArrSize; i++) {
			dataArray[i] = rand();
		}

#ifdef _DEBUG
		TRACE(_T("Not sorted:\n"));
		for (i = 0; i < m_uiArrSize; i++) {
			TRACE(_T("%d "),dataArray[i]);
		}
		TRACE(_T("\n"));
#endif

		start = CTime::GetCurrentTime();
		QuickSort(dataArray,m_uiArrSize,m_bAscending);
		end = CTime::GetCurrentTime();

#ifdef _DEBUG
		TRACE(_T("Sorted:\n"));
		for (i = 0; i < m_uiArrSize; i++) {
			TRACE(_T("%d "),dataArray[i]);
		}
		TRACE(_T("\n"));
#endif

		delete [] dataArray;
	} else {
		UserType *dataArray = new UserType[m_uiArrSize];

		srand(1);

		for (UINT i = 0; i < m_uiArrSize; i++) {
			UserType data;

			data.index = rand(); 
			data.fSomeFloat = (float)data.index;
			_stprintf(data.SomeString,_T("%d"),data.index);

			dataArray[i] = data;
		}

		start = CTime::GetCurrentTime();
		QuickSort(dataArray,m_uiArrSize,m_bAscending);
		end = CTime::GetCurrentTime();

		delete [] dataArray;
	}

	tot = end - start;
	m_CsQuickSortTime.Format(_T("%d s"),tot.GetTotalSeconds());

	UpdateData(FALSE);	
}

int CompareAscending(const void *left, const void *right)
{
	int iLeft = *((int*)left);
	int iRight = *((int*)right);

    if ( iLeft > iRight )
	    return 1;
	else  if ( iLeft < iRight )
	    return -1;
	else
	    return 0;
}

int CompareDescending(const void *left, const void *right)
{
	int iLeft = *((int*)left);
	int iRight = *((int*)right);

    if ( iLeft > iRight )
	    return -1;
	else  if ( iLeft < iRight )
	    return 1;
	else
	    return 0;
}

int CompareAscendingUserType(const void *left, const void *right)
{
	UserType iLeft = *((UserType*)left);
	UserType iRight = *((UserType*)right);

    if ( iLeft > iRight )
	    return 1;
	else  if ( iLeft < iRight )
	    return -1;
	else
	    return 0;
}

int CompareDescendingUserType(const void *left, const void *right)
{
	UserType iLeft = *((UserType*)left);
	UserType iRight = *((UserType*)right);

    if ( iLeft > iRight )
	    return -1;
	else  if ( iLeft < iRight )
	    return 1;
	else
	    return 0;
}

void CQsortDlg::OnStartQsort() 
{
	CWaitCursor cwaitcursor;
	UpdateData(TRUE);

	CTime start, end;
	CTimeSpan tot;

	srand(1);

	if (m_iType == 0) {

		int *dataArray = new int[m_uiArrSize];
		for (UINT i = 0; i < m_uiArrSize; i++) {
			dataArray[i] = rand();
		}
#ifdef _DEBUG
		TRACE(_T("Not sorted:\n"));
		for (i = 0; i < m_uiArrSize; i++) {
			TRACE(_T("%d "),dataArray[i]);
		}
		TRACE(_T("\n"));
#endif
		if (m_bAscending) {
			start = CTime::GetCurrentTime();
			qsort(dataArray,m_uiArrSize,sizeof(int),CompareAscending);
			end = CTime::GetCurrentTime();
		} else {
			start = CTime::GetCurrentTime();
			qsort(dataArray,m_uiArrSize,sizeof(int),CompareDescending);
			end = CTime::GetCurrentTime();
		}
#ifdef _DEBUG
		TRACE(_T("Sorted:\n"));
		for (i = 0; i < m_uiArrSize; i++) {
			TRACE(_T("%d "),dataArray[i]);
		}
		TRACE(_T("\n"));
#endif
		delete [] dataArray;
	} else {
		UserType *dataArray = new UserType[m_uiArrSize];

		srand(1);

		for (UINT i = 0; i < m_uiArrSize; i++) {
			UserType data;

			data.index = rand(); 
			data.fSomeFloat = (float)data.index;
			_stprintf(data.SomeString,_T("%d"),data.index);

			dataArray[i] = data;
		}

		if (m_bAscending) {
			start = CTime::GetCurrentTime();
			qsort(dataArray,m_uiArrSize,sizeof(UserType),CompareAscendingUserType);
			end = CTime::GetCurrentTime();
		} else {
			start = CTime::GetCurrentTime();
			qsort(dataArray,m_uiArrSize,sizeof(UserType),CompareDescendingUserType);
			end = CTime::GetCurrentTime();
		}

		delete [] dataArray;
	}

	tot = end - start;
	m_CsQsortTime.Format(_T("%d s"),tot.GetTotalSeconds());

	UpdateData(FALSE);
}

