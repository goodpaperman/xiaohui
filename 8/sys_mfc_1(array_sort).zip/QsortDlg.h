// QsortDlg.h : header file
//

#if !defined(AFX_QSORTDLG_H__46BC0B39_1991_11D3_AFCF_0080ADB99E81__INCLUDED_)
#define AFX_QSORTDLG_H__46BC0B39_1991_11D3_AFCF_0080ADB99E81__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// CQsortDlg dialog

class CQsortDlg : public CDialog
{
// Construction
public:
	CQsortDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CQsortDlg)
	enum { IDD = IDD_QSORT_DIALOG };
	UINT	m_uiArrSize;
	BOOL	m_bAscending;
	CString	m_CsCQArrayTime;
	CString	m_CsQsortTime;
	CString	m_CsQuickSortTime;
	int		m_iType;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CQsortDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CQsortDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnStartCQArray();
	afx_msg void OnStartQuickSort();
	afx_msg void OnStartQsort();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_QSORTDLG_H__46BC0B39_1991_11D3_AFCF_0080ADB99E81__INCLUDED_)
