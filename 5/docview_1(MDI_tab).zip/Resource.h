//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DEMO.RC
//
#define IDD_ABOUTBOX				100
#define IDR_MAINFRAME				128
#define IDR_DEMOTYPE				129
#define IDD_WINDOW_MANAGE           130    
#define IDR_TABVIEW_MENU            131    
#define IDC_WINDOWLIST_ACTIVATE     1000    
#define IDC_WINDOWLIST_CLOSE        1001    
#define IDC_WINDOWLIST_SAVE         1002    
#define IDC_WINDOWLIST_TILEHORZ     1003    
#define IDC_WINDOWLIST_MINIMIZE     1004    
#define IDC_WINDOWLIST_CASCADE      1005    
#define IDC_WINDOWLIST_TILEVERT     1006    
#define IDC_WINDOWLIST_LIST     	1007
#define ID_VIEW_VIEWTAB             32771    
#define ID_VIEW_FULLSCREEN          32772    
#define ID_WINDOW_NEXT              32773    
#define ID_WINDOW_PREVIOUS          32774    
#define ID_WINDOW_CLOSE_ALL         32775    
#define ID_WINDOW_SAVE_ALL          32776    
#define ID_WINDOW_MANAGE            32777    
#define IDS_WINDOW_MANAGE   		32778

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS			1
#define _APS_NEXT_RESOURCE_VALUE	132
#define _APS_NEXT_CONTROL_VALUE		1008
#define _APS_NEXT_SYMED_VALUE		101
#define _APS_NEXT_COMMAND_VALUE		32780
#endif
#endif
