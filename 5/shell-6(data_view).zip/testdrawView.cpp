// testdrawView.cpp : implementation of the CTestdrawView class
//

#include "stdafx.h"
#include "testdraw.h"
#include "GraphSettingsDlg.h"
#include "Graph.h"
#include "GraphSeries.h"
#include "GraphDlg.h"

#include "testdrawDoc.h"
#include "testdrawView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestdrawView

IMPLEMENT_DYNCREATE(CTestdrawView, CView)

BEGIN_MESSAGE_MAP(CTestdrawView, CView)
	//{{AFX_MSG_MAP(CTestdrawView)
	ON_COMMAND(ID_DRAW_BAR, OnDrawBar)
	ON_COMMAND(ID_DRAW_LINE, OnDrawLine)
	ON_COMMAND(ID_DRAW_PIE, OnDrawPie)
	ON_COMMAND(ID_DRAW_BAR_DLG, OnDrawBarDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestdrawView construction/destruction

CTestdrawView::CTestdrawView()
{
	// TODO: add construction code here

}

CTestdrawView::~CTestdrawView()
{
}

BOOL CTestdrawView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CTestdrawView drawing

void CTestdrawView::OnDraw(CDC* pDC)
{
	CTestdrawDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here

	if(graphComplete)
		testGraph->DrawGraph(pDC);
	
	UpdateWindow();

}

/////////////////////////////////////////////////////////////////////////////
// CTestdrawView diagnostics

#ifdef _DEBUG
void CTestdrawView::AssertValid() const
{
	CView::AssertValid();
}

void CTestdrawView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CTestdrawDoc* CTestdrawView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTestdrawDoc)));
	return (CTestdrawDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTestdrawView message handlers

void CTestdrawView::OnInitialUpdate() 
{
	CView::OnInitialUpdate();
	
	// TODO: Add your specialized code here and/or call the base class
	graphComplete = FALSE;
}

void CTestdrawView::OnDrawBar() 
{
	// TODO: Add your command handler code here
	testGraph = new CGraph();
	testGraph->SetGraphTitle("Bar Chart");

	testGraph->SetTickSpace(100);
	testGraph->SetTickRange(300);
	testGraph->SetXAxisAlignment(0);
//	testGraph->SetXAxisAlignment(90);
//	testGraph->SetXAxisAlignment(270);
//	testGraph->SetXAxisAlignment(45);
//	testGraph->SetXAxisAlignment(315);
	testGraph->SetXAxisLabel("Games");
	testGraph->SetYAxisLabel("Scores");

	//set up some series
	CGraphSeries* series1 = new CGraphSeries();
	CGraphSeries* series2 = new CGraphSeries();
	CGraphSeries* series3 = new CGraphSeries();
	series1->SetLabel("day 1");
	series2->SetLabel("day 2");
	series3->SetLabel("day 3");
	series1->SetData(0, 150);
	series1->SetData(1, 202);
	series1->SetData(2, 230);
	series1->SetData(3, 185);
	series1->SetData(4, 198);
	series1->SetData(5, 234);
	series1->SetData(6, 170);
	series1->SetData(7, 190);
	series1->SetData(8, 188);
	series1->SetData(9, 209);
	series2->SetData(0, 199);
	series2->SetData(1, 140);
	series2->SetData(2, 279);
	series3->SetData(0, 204);
	series3->SetData(1, 221);
	series3->SetData(2, 208);
	testGraph->AddSeries(series1);
	testGraph->AddSeries(series2);
	testGraph->AddSeries(series3);

	//set up legend
	testGraph->SetLegend(0, "game 1");
	testGraph->SetLegend(1, "game 2");
	testGraph->SetLegend(2, "game 3");
	testGraph->SetLegend(3, "game 4");
	testGraph->SetLegend(4, "game 5");
	testGraph->SetLegend(5, "game 6");
	testGraph->SetLegend(6, "game 7");
	testGraph->SetLegend(7, "game 8");
	testGraph->SetLegend(8, "game 9");
	testGraph->SetLegend(9, "game 10");
		
	graphComplete = TRUE;
	Invalidate(TRUE);
	
}

void CTestdrawView::OnDrawLine() 
{
	// TODO: Add your command handler code here
	testGraph = new CGraph(1);
	testGraph->SetGraphTitle("Line Graph");

	//	testGraph.SetGraphType(1);
	testGraph->SetTickSpace(100);
	testGraph->SetTickRange(300);
//	testGraph->SetXAxisAlignment(0);
//	testGraph->SetXAxisAlignment(90);
//	testGraph->SetXAxisAlignment(270);
//	testGraph->SetXAxisAlignment(45);
	testGraph->SetXAxisAlignment(315);
	testGraph->SetXAxisLabel("Games");
	testGraph->SetYAxisLabel("Scores");

	//set up some series
	CGraphSeries* series1 = new CGraphSeries();
	CGraphSeries* series2 = new CGraphSeries();
	CGraphSeries* series3 = new CGraphSeries();
	series1->SetLabel("day 1");
	series2->SetLabel("day 2");
	series3->SetLabel("day 3");
	series1->SetData(0, 150);
	series1->SetData(1, 202);
	series1->SetData(2, 230);
	series2->SetData(0, 199);
	series2->SetData(1, 140);
	series2->SetData(2, 279);
	series3->SetData(0, 204);
	series3->SetData(1, 221);
	series3->SetData(2, 208);
	testGraph->AddSeries(series1);
	testGraph->AddSeries(series2);
	testGraph->AddSeries(series3);

	//set up legend
	testGraph->SetLegend(0, "game 1");
	testGraph->SetLegend(1, "game 2");
	testGraph->SetLegend(2, "game 3");
		
	graphComplete = TRUE;
	Invalidate(TRUE);
	
}

void CTestdrawView::OnDrawPie() 
{
	// TODO: Add your command handler code here
	testGraph = new CGraph(2);
	testGraph->SetGraphTitle("Pie Chart");
	
	//set up legend
	testGraph->SetLegend(0, "game 1");
	testGraph->SetLegend(1, "game 2");
	testGraph->SetLegend(2, "game 3");
	testGraph->SetLegend(3, "game 4");
	testGraph->SetLegend(4, "game 5");
	testGraph->SetLegend(5, "game 6");
	testGraph->SetLegend(6, "game 7");
	testGraph->SetLegend(7, "game 8");
	testGraph->SetLegend(8, "game 9");
	testGraph->SetLegend(9, "game 10");

	//set up some series
	CGraphSeries* series1 = new CGraphSeries();
	CGraphSeries* series2 = new CGraphSeries();
	CGraphSeries* series3 = new CGraphSeries();
	series1->SetLabel("day 1");
	series2->SetLabel("day 2");
	series3->SetLabel("day 3");
	series1->SetData(0, 15);
	series1->SetData(1, 5);
	series1->SetData(2, 2);
	series1->SetData(3, 8);
	series1->SetData(4, 30);
	series1->SetData(5, 6);
	series1->SetData(6, 7);
	series1->SetData(7, 9);
	series1->SetData(8, 8);
	series1->SetData(9, 10);
	series2->SetData(0, 15);
	series2->SetData(1, 15);
	series2->SetData(2, 15);
	series3->SetData(0, 10);
	series3->SetData(1, 20);
	series3->SetData(2, 30);
	series3->SetData(3, 40);
	series3->SetData(4, 50);

	testGraph->AddSeries(series1);
	testGraph->AddSeries(series2);
	testGraph->AddSeries(series3);

	graphComplete = TRUE;
	Invalidate(TRUE);
}

void CTestdrawView::OnDrawBarDlg() 
{
	// TODO: Add your command handler code here
	CGraphDlg graphDlg;

	graphDlg.DoModal();
}
