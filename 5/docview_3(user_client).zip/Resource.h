//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TestApp.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_TESTAPTYPE                  129
#define IDB_SYSMENU                     132
#define IDB_BITMAP1                     134
#define IDD_BACKGROUND                  135
#define IDC_CHECK1                      1000
#define IDC_AUTOSAVE                    1000
#define IDC_FILENAME                    1001
#define IDC_BROWSE                      1002
#define IDC_CENTERED                    1003
#define IDC_TILED                       1004
#define IDC_RESET                       1005
#define IDC_BKCOLOR                     1006
#define IDC_STRETCH                     1008
#define IDC_CUSTOM                      1009
#define IDC_EDITX                       1010
#define IDC_EDITY                       1011
#define IDC_SPIN1                       1012
#define IDC_SPIN2                       1013
#define ID_BUTTON_PREV                  32776
#define ID_BUTTON_NEXT                  32777
#define ID_BUTTON_CASCADE               32778
#define ID_BUTTON_TILE                  32779
#define ID_BUTTON_TILE2                 32780
#define ID_BUTTON_CLOSE                 32781
#define ID_BUTTON_CLOSEALL              32782
#define ID_BUTTON_RESTORE               32784
#define ID_BUTTON_MINIMIZE              32785
#define ID_BUTTON_MAXIMIZE              32786
#define ID_BUTTON32789                  32789
#define ID_BUTTON32790                  32790
#define ID_FOCUS_ITEM1                  32796
#define ID_VIEW_BACKGROUND              32797

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32798
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
