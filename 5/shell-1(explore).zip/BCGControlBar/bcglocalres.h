#ifndef __BCGLOCALRES_H
#define __BCGLOCALRES_H

class CBCGLocalResource
{
public:
	CBCGLocalResource();
	~CBCGLocalResource();

protected:
	HINSTANCE m_hInstOld;
};

#endif __BCGLOCALRES_H
