#if !defined(AFX_TOOLDOCKBAR_H__361B6E45_2C5A_11D2_8BE6_00A0C9B05590__INCLUDED_)
#define AFX_TOOLDOCKBAR_H__361B6E45_2C5A_11D2_8BE6_00A0C9B05590__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// ToolDockBar.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CToolDockBar window

class CToolDockBar : public CWnd
{
// Construction
public:
	CToolDockBar();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CToolDockBar)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CToolDockBar();

	// Generated message map functions
protected:
	//{{AFX_MSG(CToolDockBar)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TOOLDOCKBAR_H__361B6E45_2C5A_11D2_8BE6_00A0C9B05590__INCLUDED_)
