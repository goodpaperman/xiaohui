
#include "stdafx.h"
#include "bcglocalres.h"

///////////////////////////////////////////////////////////////////////
// CBCGLocalResource implementation - stub for static library

#ifndef _AFXDLL

CBCGLocalResource::CBCGLocalResource()
{
}

CBCGLocalResource::~CBCGLocalResource()
{
}

#endif
