// ToolDockBar.cpp : implementation file
//

#include "stdafx.h"
#include "bcgcontrolbar.h"
#include "ToolDockBar.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CToolDockBar

CToolDockBar::CToolDockBar()
{
}

CToolDockBar::~CToolDockBar()
{
}


BEGIN_MESSAGE_MAP(CToolDockBar, CWnd)
	//{{AFX_MSG_MAP(CToolDockBar)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CToolDockBar message handlers
