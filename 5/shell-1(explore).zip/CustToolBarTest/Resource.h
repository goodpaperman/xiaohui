//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CustToolBarTest.rc
//
#define IDD_ABOUTBOX                    100
#define CG_IDR_POPUP_CUST_TOOL_BAR_TEST_VIEW 102
#define IDR_MAINFRAME                   128
#define IDR_CUSTTOTYPE                  129
#define IDR_POPUP_TOOLBAR               130
#define IDR_BUTTON_MENU                 137
#define ID_USER_TOOL1                   32771
#define ID_USER_TOOL2                   32772
#define ID_USER_TOOL3                   32773
#define ID_VIEW_USER_TOOBAR             32774
#define ID_VIEW_CUSTOMIZE               32775
#define ID_USER_TOOLS                   32776
#define ID_USER_CONFIGURATION           32778
#define ID_POPUP_ONE                    32779
#define ID_POPUP_TWO                    32780
#define ID_VIEW_USER_TOOLBAR1           32804
#define ID_VIEW_USER_TOOLBAR2           32805
#define ID_VIEW_USER_TOOLBAR3           32806
#define ID_VIEW_USER_TOOLBAR4           32807
#define ID_VIEW_USER_TOOLBAR5           32808
#define ID_VIEW_USER_TOOLBAR6           32809
#define ID_VIEW_USER_TOOLBAR7           32810
#define ID_VIEW_USER_TOOLBAR8           32811
#define ID_VIEW_USER_TOOLBAR9           32812
#define ID_VIEW_USER_TOOLBAR10          32813

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         32782
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
